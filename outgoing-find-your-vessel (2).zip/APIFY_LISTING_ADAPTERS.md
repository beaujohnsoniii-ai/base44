# Apify listing adapter handoff

Reviewed 2026-10-19. This is a disabled implementation preparation, not a live scraping result.

## Delivered

`base44/shared/apify-boat-adapters.mjs` contains pure request planners, per-Actor row normalization and an offline bridge into `assessListing`. The pure adapter contains no fetch, token access, execution or writes. The separately guarded backend test transport described below is disabled by default. `APIFY_LISTING_RUNTIME.enabled` is false; every plan has `executable:false`. Production `compare-listings` remains on `DISABLED_RESOLVER_RUNTIME`; ownership and entitlement checks are unchanged.

| Actor | Prepared mode | Boundaries |
| --- | --- | --- |
| copious_atoll/boat-trader-scraper | Filter discovery, one search page | Exact-link requests return unsupported with no input. maxPages:1 may still produce many paid results. No documented hours field. |
| getascraper/yachtworld-scraper | One detail URL candidate, fetchDetails:true, maxItems:1 | startUrls are documented as extra pages, so output still must match the exact requested URL and listing ID. No promise that a one-item limit bounds all costs. No separate make field in the published output. |

Normalization only accepts marketplace detail paths, corresponding numeric IDs, explicit fields and valid units. No values come from saved model data, URL slugs or title inference. YachtWorld year must agree with the URL before exact association. BoatTrader USD currency is explicitly attributed to its documented output contract. Missing/conflicting/ambiguous values stay null; zero engine hours remains zero. Units are not converted. General length is not treated as rigged length, and no towing weight is inferred.

Each normalized field retains the source field path and raw value. The record separates source URL, Actor ID, provider scrape timestamp and observation time; it never stamps an old row as newly retrieved. Source permission and live retrieval remain unverified. Quotes used by the offline Compare bridge are labeled normalized Actor claims, not page quotations or manufacturer verification. No finalist recommendations are enabled.

Fixtures in `tests/fixtures/apify-boat-rows.json` are synthetic contract examples, not actual marketplace records. Eight tests cover disabled behavior, input bounds, identity rejection, unknown fields, hours, currencies, measurement definitions and the unchanged production gate.

## Current prerequisites for any live integration

- A disabled server-side Apify test transport is now implemented and mock-tested; secure app credential configuration and live transport have not been established or tested by this work. The signed-in browser account is not proof of backend API access; no credentials were created or read.
- Source-access permission, actual runtime behavior and spend limits require review before enabling retrieval. Do not use either Actor as an automatic workaround for an existing marketplace access restriction.
- Copious cannot implement the current exact-link Compare retrieval requirement with its documented input contract. Keep broad discovery separate.
- YachtWorld output still needs independent make evidence; do not silently borrow the selected model's identity. Live outputs/schema/build need confirmation before activation.
- Preserve existing Compare authentication, paid-window and owner checks, safe egress/source permission requirements, bounded response/deadline behavior, and authorization for any metered attempt. Input plans alone are not sufficient activation approval.
- No Actor run or paid validation was performed. No publication or security changes occurred. The existing uncertain Firecrawl ledger was not modified.

## Official provider contracts

- https://apify.com/copious_atoll/boat-trader-scraper
- https://apify.com/copious_atoll/boat-trader-scraper/input-schema
- https://apify.com/getascraper/yachtworld-scraper
- https://apify.com/getascraper/yachtworld-scraper/input-schema
- https://apify.com/getascraper/yachtworld-scraper/api/openapi

## Disabled backend test preparation

`base44/functions/apify-listing-readiness/entry.ts` accepts POST with only an optional action (`status` or `run_approved_test`). It authenticates admin before reading the key-presence boolean. `status` returns only `key_configured`, never the value of `APIFY_API_TOKEN`. No endpoint was invoked during implementation and no secret was configured or inspected.

`base44/shared/apify-listing-test.mjs` holds immutable disabled production policy and the guarded transport. It rejects execution unless all of these server-owned controls exist: approved exact YachtWorld URL, explicit approval ID, future-dated source permission, pinned numeric Actor build, positive charge cap no greater than USD 0.10, and explicitly verified atomic reservation semantics. None is armed by this patch; a request body cannot provide or override them.

The transport sends exactly one POST to the fixed Apify origin `/v2/actors/getascraper~yachtworld-scraper/runs`, with `maxTotalChargeUsd` equal to the specific approved cap, `maxItems=1`, `timeout=60`, `waitForFinish=20`, `restartOnError=false` and the pinned build. Bearer authentication is in the header, redirects are rejected and responses are capped at 256 KiB. A 25-second local deadline does not cancel an already-started Actor; the provider run timeout and charge cap remain necessary.

A succeeded run must echo the requested limits/build before one bounded dataset GET is attempted. The dataset request reads at most two rows to detect overflow, and exactly one matching normalized row is required. A nonterminal run remains uncertain and spent; there is no polling, retry, resurrect, restart or automatic subsequent run. The Apify maximum-cost parameter is provider-enforced; mocks only verify that it is sent, not real billing behavior. Dataset access and account-level billing are not independently verified as covered by that run cap.

The reserved approval must belong to the authenticated admin and bind the Actor, URL, cap, source reference, expiry, one call and one item. Reservation is conditional `ready -> reserved` with nonce readback. Completion is `complete` or `uncertain`; failed persistence leaves it spent/reserved. Sanitized fixed failure codes and stages are retained, alongside a run receipt when obtained. Unknown transport errors and raw provider response/error text are never stored. No final-billing claim is made.

**Deliberate activation blocker:** the dedicated `ApifyListingTestApproval` store is not provisioned or seeded, and `atomic_reservation_verified` remains false. No entity schema/RLS or existing permissions were changed. The conditional SDK mock is not evidence of deployed atomicity. Before arming any future test, establish a supported atomic conditional reservation store and its admin-only access contract; existing admins remain a trust boundary. Do not reuse or reset the Firecrawl ledger.

Thirteen additional mock/source tests cover auth before secret/cost, disabled zero egress, missing secret/cap/source/build/atomic contract, scope/owner checks, one-start behavior, uncertain lockout, response bounds, normalization, and actual handler rejection of browser policy overrides. Production Compare ownership, paid entitlements, source gate and disabled runtime remain unchanged.

Official API contract: https://docs.apify.com/api/v2/actors-runs-post
Official API authentication: https://docs.apify.com/integrations/api

Provider documentation can change. Public examples are contract guidance, not independent evidence that any individual boat is available or accurately described.
