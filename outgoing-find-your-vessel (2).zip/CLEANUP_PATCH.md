# SOUND HEADING — Dashboard cleanup patch

Paste sections into Base44's editor or apply in your local clone.

## 1. REMOVE the text navigation bar (Dashboard.jsx)

Delete this block entirely — the journey icon strip above it already covers it:

```jsx
        <nav className="sh-dashboard-nav" aria-label="Match account sections">
          <Link to="/my-matches">My matches</Link><a href="#buyer-profile">Buyer profile</a>
          <a href="#saved-candidates">Saved boats ({boats.length})</a><a href="#research-notes">Reports</a><a href="#packages">Account access</a>
        </nav>
```

Also delete the matching CSS in `dashboard.css`:

```css
.sh-dashboard-customer .sh-dashboard-nav { display:flex;flex-wrap:wrap;gap:8px;background:#fff;padding:12px;border-radius:12px;border:1px solid #d5dade; }
.sh-dashboard-customer .sh-dashboard-nav a { padding:12px 16px;border-radius:8px;color:#122d40;text-decoration:none;min-height:44px; }
.sh-dashboard-customer .sh-dashboard-nav a:hover { background:#f0e7d7; }
.sh-dashboard-customer .sh-dashboard-nav a:focus-visible { outline:3px solid #b58b4c;outline-offset:2px; }
```

## 2. REMOVE Dashboard's duplicate saved-candidates section

Delete:

```jsx
        {!isPaid && <section id="saved-candidates" aria-label="Saved candidates">
          <CandidatesCollapsible boats={boats} onAdd={addBoat} onRemove={removeBoat} onUpdate={updateBoat} maxBoats={MAX_BOATS} minBoats={MIN_BOATS} onAnalyze={() => navigate("/boat-analysis")} prefill={prefillBoat} />
        </section>}
```

`SuggestedBoatsPanel` already renders `CandidatesCollapsible` with that same id for free and paid users. This copy created a duplicate DOM id and a second add-boat entry point.

## 3. Clean up now-unused imports (Dashboard.jsx)

- Delete: `import CandidatesCollapsible from "@/components/CandidatesCollapsible";`
- Trim lucide: `import { Anchor, FileText, ArrowRight, Sparkles, Download } from "lucide-react";` (removes Calculator, Pencil, FlaskConical, Home)

## 4. Buyer-facing badge language (CompareImportResults.jsx)

In `StatusBadge`, replace the raw status text with:

```jsx
  const LABELS = {
    evaluated: "Verified",
    insufficient_evidence: "Partial data",
    unsupported_source: "Source not supported",
    fetch_failed: "Couldn't read this page",
    access_blocked: "Couldn't read this page",
    extraction_failed: "Couldn't read this page",
    ambiguous_listing: "Listing unclear",
  };
  return <span className={"inline-block text-xs font-medium px-2 py-1 rounded border " + cls">{LABELS[status] || "Unknown"}</span>;
```

## 5. Collapse match-detail dump on Compare cards (CompareSavedCandidates.jsx)

Wrap the match summary / strengths / gaps / specs / notes block inside each boat card in a `<details>`:

```jsx
          <details className="text-sm">
            <summary className="cursor-pointer text-muted-foreground">Why it matched</summary>
            {boat.match?.summary && <p className="mt-1">{boat.match.summary}</p>}
            {boat.match?.matches?.length > 0 && <p className="mt-1">Strengths: {boat.match.matches.join("; ")}</p>}
            {boat.match?.gaps?.length > 0 && <p className="mt-1">To verify: {boat.match.gaps.join("; ")}</p>}
            {boat.specs && <p className="mt-1 whitespace-pre-wrap">{boat.specs}</p>}
            {boat.notes && <p className="mt-1 whitespace-pre-wrap">{boat.notes}</p>}
          </details>
```

Title, Select button, and original link stay always visible.

## 6. REMOVE redundant "Save current selection" button (CompareSavedCandidates.jsx)

`persistSelection` already saves on every click. Delete:

```jsx
      <Button variant="outline" disabled={busy || comparing} onClick={() => persistSelection(selected)} className="min-h-11 mt-3">Save current selection</Button>
```

## 7. REMOVE redundant "Save links" button (CompareSavedCandidates.jsx, ListingFields)

Helper text already says changes save on Compare. In the `sh-compare-actions` div, delete the Save links Button; keep Add listing and Clear links.

## 8. Deduplicate question-tier picker

`FreeMatchPreview` reads the tier buttons. If Dashboard also renders a second "Choose a question set" block with the same `PLAN_TIERS.map`, delete it.

## 9. Move Compare Import block up

In CompareSavedCandidates, move the "Compare your saved listings" div (with the Import details button) to sit directly under the model-grid header, before the cards — paste, import, results top to bottom.
