import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import * as evidence from '../base44/shared/listing-intake.mjs';
import { runIntakeAction } from '../base44/shared/listing-intake-service.mjs';
import { NOW, OWNER, LISTING_ID, UPLOAD_ID, candidate, completedUpload, completeData, harness, request, statusIs } from './listing-intake-fixtures.mjs';

function dataFor(model='224', year=2025, make='BlackJack') {
  const data=completeData(), listing=data.listings[0];
  listing.model={...listing.model,make:'Blackjack',model:'224',year:2020,title:'Blackjack 224 2020'};
  listing.uploads[0].extraction.candidates=[candidate('make',make),candidate('model',model),candidate('year',year)];
  return data;
}
test('year-only differences preserve exact advertised facts and do not block confirmation',async()=>{
 for(const year of [2025,2026]){
  const data=dataFor('224',year),original=structuredClone(data);
  const merged=evidence.mergedListingEvidence(data.listings[0]);
  assert.deepEqual(merged.identity_conflicts,[]);assert.equal(merged.year_difference,true);
  const saved=(await evidence.confirmListing(data,LISTING_ID,{},'fp',NOW)).listings[0];
  assert.equal(saved.versions[0].fields.year.value,year);assert.equal(saved.versions[0].model.year,2020);
  assert.deepEqual(data,original);assert.equal(saved.identity_resolution,null);
 }
});
test('case, spacing, punctuation and an exact make prefix are equivalent, not fuzzy model matching',()=>{
 for(const model of ['224','BlackJack 224','blackjack-224','2 2 4']){
  assert.deepEqual(evidence.mergedListingEvidence(dataFor(model,2020,'BLACKJACK').listings[0]).identity_conflicts,[],model);
 }
 for(const model of ['256 Coastal','BlackJack 256 Coastal','224 Coastal','224 Sport','2240']){
  assert.deepEqual(evidence.mergedListingEvidence(dataFor(model).listings[0]).identity_conflicts,['model'],model);
 }
 assert.ok(evidence.mergedListingEvidence(dataFor('224',2020,'Other make').listings[0]).identity_conflicts.includes('make'));
});
test('equivalent screenshot model formatting preserves both sources and exact original values',()=>{
 const listing=dataFor().listings[0];
 listing.uploads.push(completedUpload('upload_second_01',[candidate('model','BlackJack 224','upload_second_01')]));
 const merged=evidence.mergedListingEvidence(listing);
 assert.deepEqual(merged.conflicts,[]);assert.equal(merged.fields.model.value,'224');
 assert.equal(merged.fields.model.candidates[1].value,'BlackJack 224');
});
test('different screenshot years remain a real unresolved source conflict',async()=>{
 const data=dataFor();data.listings[0].uploads.push(completedUpload('upload_second_01',[candidate('year',2026,'upload_second_01')]));
 assert.ok(evidence.mergedListingEvidence(data.listings[0]).conflicts.includes('year'));
 await assert.rejects(evidence.confirmListing(data,LISTING_ID,{},'fp',NOW),statusIs(409));
});
test('a real alternative requires a deliberate bound choice and preserves exact identity',async()=>{
 const data=dataFor('BlackJack 256 Coastal',2026),listing=data.listings[0];
 await assert.rejects(evidence.confirmListing(data,LISTING_ID,{},'fp',NOW),statusIs(409));
 listing.identity_resolution=await evidence.reviewListingIdentity(listing,'keep_alternative',undefined,OWNER.id,NOW);
 assert.equal(listing.identity_resolution.choice,'keep_alternative');
 assert.match(listing.identity_resolution.identity_digest,/^[a-f0-9]{64}$/);
 assert.equal(evidence.mergedListingEvidence(listing).identity_review_current,true);
 const saved=(await evidence.confirmListing(data,LISTING_ID,{},'fp',NOW)).listings[0];
 assert.equal(saved.versions[0].fields.model.value,'BlackJack 256 Coastal');assert.equal(saved.versions[0].model.model,'224');
});
test('changed identity value, selected source, revision, extra identity evidence or digest invalidate choice',async()=>{
 for(const mutate of [
  l=>l.uploads[0].extraction.candidates.find(c=>c.field==='model').value='256 Sport',
  l=>l.revision++,
  l=>l.uploads.push(completedUpload('upload_second_01',[candidate('model','BlackJack 256 Coastal','upload_second_01')])),
  l=>{l.resolutions.model={choice:'unknown'};l.resolutions.make={choice:'unknown'};l.uploads[0].extraction.candidates.find(c=>c.field==='make').value='Other make';},
  l=>l.identity_resolution.identity_digest='0'.repeat(64),
 ]){
  const data=dataFor('256 Coastal'),l=data.listings[0];
  l.identity_resolution=await evidence.reviewListingIdentity(l,'keep_alternative',null,OWNER.id,NOW);
  mutate(l);
  // Unknown is an explicit source-field resolution, not an alternative acceptance.
  if(evidence.mergedListingEvidence(l).identity_conflicts.length) await assert.rejects(evidence.confirmListing(data,LISTING_ID,{},'fp',NOW),statusIs(409));
  else assert.equal(evidence.mergedListingEvidence(l).identity_review_current,false);
 }
});
test('unbound old notes do not approve new mismatches; optional new notes are bound',async()=>{
 const data=dataFor('256 Coastal'),l=data.listings[0];
 l.identity_resolution={note:'Previously reviewed',reviewed_by:OWNER.id};
 await assert.rejects(evidence.confirmListing(data,LISTING_ID,{},'fp',NOW),statusIs(409));
 l.identity_resolution=await evidence.reviewListingIdentity(l,undefined,'This is an intentional alternative.',OWNER.id,NOW);
 assert.equal(l.identity_resolution.choice,'review_note');assert.equal(evidence.mergedListingEvidence(l).identity_review_current,true);
 await assert.rejects(evidence.reviewListingIdentity(l,'automatic',null,OWNER.id,NOW),statusIs(400));
 await assert.rejects(evidence.reviewListingIdentity(dataFor().listings[0],'keep_alternative',null,OWNER.id,NOW),statusIs(409));
});
test('actual service action persists only explicit choice, replays idempotently and never calls providers or Match writes',async()=>{
 const h=await harness({data:dataFor('BlackJack 256 Coastal')});
 const body=request('review_identity',{choice:'keep_alternative'});
 const result=await runIntakeAction(await h.context(),body);
 assert.equal(result.listings[0].evidence.identity_review_current,true);assert.equal(result.listings[0].status,'draft');
 const saved=structuredClone(h.state.record);await runIntakeAction(await h.context(),body);assert.deepEqual(h.state.record,saved);
 assert.equal(h.calls.commits.length,1);assert.deepEqual(h.calls.forbidden,[]);
 for(const name of ['uploads','signs','extracts'])assert.equal(h.calls[name].length,0);
});
test('resolve_field selecting a different identity source invalidates the previously bound approval',async()=>{
 const data=dataFor('256 Coastal'),l=data.listings[0];
 l.uploads.push(completedUpload('upload_second_01',[candidate('model','256 Sport','upload_second_01')]));
 l.resolutions.model={choice:UPLOAD_ID+':model'};
 l.identity_resolution=await evidence.reviewListingIdentity(l,'keep_alternative',null,OWNER.id,NOW);
 const h=await harness({data});
 const result=await runIntakeAction(await h.context(),request('resolve_field',{field:'model',choice:'upload_second_01:model'}));
 assert.equal(result.listings[0].evidence.identity_review_current,false);
 await assert.rejects(runIntakeAction(await h.context(),request('confirm',{operation_id:'confirm_second_01',revision:2})),statusIs(409));
});
test('reopen/reset invalidate approval while preserving confirmed history',async()=>{
 const data=dataFor('256 Coastal'),l=data.listings[0];l.identity_resolution=await evidence.reviewListingIdentity(l,'keep_alternative',null,OWNER.id,NOW);
 const saved=await evidence.confirmListing(data,LISTING_ID,{},'fp',NOW);
 const reopened=evidence.reopenListing(saved,LISTING_ID),reset=evidence.resetListing(saved,LISTING_ID,true,NOW);
 assert.equal(reopened.listings[0].identity_resolution,null);assert.equal(reset.listings[0].identity_resolution,null);
 assert.deepEqual(reopened.listings[0].versions,saved.listings[0].versions);assert.deepEqual(reset.listings[0].versions,saved.listings[0].versions);
});

// Execute the actual card with synthetic hooks; no browser, network or real records.
let states=[],si=0;
const React={createElement:(type,props,...children)=>({type,props:{...props,children:children.flat(Infinity)}}),useState:initial=>{const i=si++;if(!(i in states))states[i]=initial;return[states[i],value=>states[i]=value];}};
const compiled=ts.transpileModule(fs.readFileSync('src/components/ListingIntakePanel.jsx','utf8'),{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const module={};new Function('exports','require',compiled+'\nexports.Card=ListingReviewCard;')(module,name=>{
 if(name==='react')return {default:React,...React};
 if(name==='@/components/ui/button')return {Button:'button'};
 if(name==='lucide-react')return Object.fromEntries(['Check','Upload','RotateCcw','Search'].map(k=>[k,k]));
 if(name.includes('listing-intake.mjs'))return evidence;
 return {};
});
const nodes=n=>!n||typeof n!=='object'?[]:[n,...(n.props?.children||[]).flatMap(nodes)];
const text=n=>typeof n==='string'||typeof n==='number'?String(n):(n?.props?.children||[]).map(text).join('');
function render(l,onAction=()=>{}){si=0;return module.Card({listing:{...l,evidence:evidence.mergedListingEvidence(l)},index:0,busy:false,processingEnabled:true,uploadsRemaining:3,request:()=>{throw Error('No request allowed');},onAction,onFiles:()=>{throw Error('No upload allowed');}});}
function button(tree,label){return nodes(tree).find(n=>n.type==='button'&&text(n)===label);}
test('actual card enables year-only confirmation with visible warning and no required note',()=>{
 states=[];const tree=render(dataFor().listings[0]);
 assert.equal(button(tree,'Confirm listing details').props.disabled,false);
 assert.ok(text(tree).includes('Advertised year: 2025'));assert.ok(text(tree).includes('Model-year specifications are not transferred'));
 assert.equal(button(tree,'Keep as alternative model'),undefined);
});
test('actual card makes genuine alternative choice explicit and does not save or confirm on render',async()=>{
 states=[];const l=dataFor('BlackJack 256 Coastal',2026).listings[0],calls=[],tree=render(l,(...args)=>calls.push(args));
 assert.equal(button(tree,'Confirm listing details').props.disabled,true);assert.equal(calls.length,0);
 assert.ok(text(tree).includes('Selected model: Blackjack 224 2020'));assert.ok(text(tree).includes('Screenshot: BlackJack · BlackJack 256 Coastal · 2026'));
 button(tree,'Keep as alternative model').props.onClick();assert.deepEqual(calls,[['review_identity',{listing_id:LISTING_ID,choice:'keep_alternative'}]]);
 l.identity_resolution=await evidence.reviewListingIdentity(l,'keep_alternative',null,OWNER.id,NOW);
 assert.equal(button(render(l),'Confirm listing details').props.disabled,false);
});
test('actual card explains source conflicts and pending reads beside disabled confirmation',()=>{
 for(const change of [l=>l.uploads.push(completedUpload('upload_second_01',[candidate('year',2026,'upload_second_01')])),l=>l.uploads.push({id:'pending_upload_01',status:'uploaded',name:'pending.png'})]){
  states=[];const l=dataFor().listings[0];change(l);const tree=render(l);
  assert.equal(button(tree,'Confirm listing details').props.disabled,true);assert.ok(/conflicting source details|not fully read/.test(text(tree)));
 }
});
test('only an open intake dialog hides the floating launcher, with automatic DOM-lifecycle cleanup',()=>{
 const css=fs.readFileSync('src/components/listing-intake.css','utf8');
 assert.ok(css.includes('body:has(.sh-listing-intake[data-state="open"]) .sh-guide-launcher {display:none;}'));
 assert.doesNotMatch(css,/z-index:/);
 const panel=fs.readFileSync('src/components/ListingIntakePanel.jsx','utf8');
 assert.ok(panel.includes('<Dialog open onOpenChange='));
 assert.ok(panel.includes('className="sh-listing-intake '));
 // Radix Content owns data-state. No sticky body class, event listener, Guide reset,
 // launcher-position mutation, provider call, or JS cleanup dependency is added.
 assert.ok(fs.readFileSync('src/components/ui/dialog.jsx','utf8').includes('<DialogPrimitive.Content'));
 assert.ok(fs.readFileSync('src/components/GuideLauncher.jsx','utf8').includes('className="sh-guide-launcher"'));
 assert.ok(panel.includes('There is no overall submission or listing assessment yet.'));
});
