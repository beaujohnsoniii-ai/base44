import test from 'node:test';
import assert from 'node:assert/strict';
import { runProgrammaticChecks } from '../base44/shared/qa-programmatic.ts';
import {
  explicitStorageDimensionCapFt,
  explicitLiftCapacityLb,
  screenPhysicalCandidate,
} from '../base44/shared/physical-specs.ts';

test('legacy storage notes preserve explicit beam and height maximums', () => {
  assert.equal(explicitStorageDimensionCapFt('Marina max beam 9 ft 6 in', 'beam'), 9.5);
  assert.equal(explicitStorageDimensionCapFt('beam limit 10 ft', 'beam'), 10);
  assert.equal(explicitStorageDimensionCapFt('max storage height 12 ft', 'height'), 12);
  assert.equal(explicitStorageDimensionCapFt('9 ft max beam', 'beam'), 9);
});

test('descriptive slip and dimension values are not fabricated hard caps', () => {
  assert.equal(explicitStorageDimensionCapFt('10 ft beam slip', 'beam'), null);
  assert.equal(explicitStorageDimensionCapFt('Boat has 12 ft overall height', 'height'), null);
  assert.equal(explicitLiftCapacityLb('Boat weighs 6000 lb dry'), null);
});

test('legacy lift capacities are treated as hard limits', () => {
  assert.equal(explicitLiftCapacityLb('6,000 lb lift'), 6000);
  assert.equal(explicitLiftCapacityLb('lift capacity 8000 lbs'), 8000);
  assert.equal(explicitLiftCapacityLb('max loaded weight 7,500 lb'), 7500);
  const over = screenPhysicalCandidate(
    { loaded_storage_weight_lb: 6500, __catalog_verified_fields: ['storage_weight_lb'] },
    { storage: 'lift_kept', storage_capacity: '6,000 lb lift' },
  );
  assert.equal(over.excluded, true);
  assert.match(over.reasons.join(' '), /loaded storage weight/);
});

test('legacy beam and height limits exclude known overages and flag unknowns', () => {
  const profile = { storage: 'dry_stack', storage_capacity: 'max beam 9 ft; max height 10 ft' };
  const over = screenPhysicalCandidate({ beam_ft: 9.5, storage_height_ft: 11, __catalog_verified_fields: ['beam_ft', 'storage_height_ft'] }, profile);
  assert.equal(over.excluded, true);
  assert.equal(over.reasons.length, 2);
  const unknown = screenPhysicalCandidate({ length: '24 ft' }, profile);
  assert.equal(unknown.excluded, false);
  assert.match(unknown.verification_required.join(' '), /beam/i);
  assert.match(unknown.verification_required.join(' '), /storage height/i);
});

test('the stricter of structured and legacy facility limits wins', () => {
  const profile = { hard_max_beam_ft: 10, storage_capacity: 'beam max 9 ft' };
  assert.equal(screenPhysicalCandidate({ beam_ft: 9.5, __catalog_verified_fields: ['beam_ft'] }, profile).excluded, true);
});

test('QA detects legacy facility violations without structured fields', () => {
  const boat = { title: 'QA Boat', make: 'QA', model: 'Boat',
    specs: 'Beam 9 ft 6 in · Storage height 11 ft · Loaded weight 6500 lb',
    verification_required: [] };
  const result = runProgrammaticChecks([boat], {
    storage: 'lift_kept', storage_capacity: 'max beam 9 ft; max height 10 ft; 6000 lb lift',
  }, 'free', []);
  assert.ok(result.checks.storage_violations.some(x => /beam/.test(x)));
  assert.ok(result.checks.storage_violations.some(x => /height/.test(x)));
  assert.ok(result.checks.storage_violations.some(x => /weight/.test(x)));
  assert.ok(result.checks.hard_constraint_violations.length >= 3);
});

test('QA requires verification for unknown legacy facility dimensions', () => {
  const boat = { title: 'QA Boat', make: 'QA', model: 'Boat',
    specs: 'Dry weight 4500 lb', verification_required: [] };
  const result = runProgrammaticChecks([boat], {
    storage: 'lift_kept', storage_capacity: 'max beam 9 ft; 6000 lb lift',
  }, 'free', []);
  assert.ok(result.checks.storage_violations.some(x => /beam/.test(x)));
  assert.ok(result.checks.storage_violations.some(x => /loaded(?:\/storage| storage) weight/.test(x)));
});
