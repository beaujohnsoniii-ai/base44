import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import ts from "typescript";
const source=readFileSync("base44/functions/buyer-launch-test/entry.ts","utf8");
const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
function harness(user){
 let runs=0;
 const exports={};
 const client={auth:{me:async()=>{if(user instanceof Error)throw user;return user;}},asServiceRole:{entities:{BoatModelCatalog:{}}}};
 new Function("exports","require",compiled)(exports,name=>{
 if(name.startsWith("npm:"))return {createClientFromRequest:()=>client};
 if(name.includes("advisor-reasoning"))return {loadManufacturerMap:async()=>({brief:"",list:[]})};
 if(name.includes("question-tiers"))return {loadQuestionTiers:async()=>({})};
 if(name.includes("catalog-loader"))return {loadPublishedMatchCatalog:async()=>({records:[]})};
 if(name.includes("suggest-engine"))return {generateRecommendations:async(c,input)=>{runs++;assert.equal(input.profile.created_by_id,"owner");return {suggestions:[{title:"Test engine output"}]};}};
 throw Error(name);
 });
 return {run:(body={plan:"market_match",profile:{}},method="POST")=>exports.default(new Request("https://example.test",{method,...(method==="POST"?{body:JSON.stringify(body)}:{})})),runs:()=>runs};
}
test("launch test refuses anonymous, ordinary users and GET before engine calls",async()=>{
 for(const [user,status] of [[new Error("unauthorized"),401],[null,403],[{role:"user"},403]]){
 const h=harness(user);assert.equal((await h.run()).status,status);assert.equal(h.runs(),0);
 }
 const h=harness({id:"owner",role:"admin"});assert.equal((await h.run({},"GET")).status,405);assert.equal(h.runs(),0);
});
test("launch test rejects invalid input and runs real engine contract without persistence",async()=>{
 const h=harness({id:"owner",role:"admin"});
 assert.equal((await h.run({plan:"invented",profile:{}})).status,400);assert.equal(h.runs(),0);
 const result=await (await h.run()).json();assert.equal(h.runs(),1);assert.equal(result.payment_taken,false);assert.equal(result.persisted,false);
 assert.doesNotMatch(source,/\.create\(|\.update\(|\.delete\(/);
});
test("checkout refuses POST before reading secrets, creating clients, calling providers or writing purchases",async()=>{
 const src=readFileSync("base44/functions/create-checkout/entry.ts","utf8");
 const js=ts.transpileModule(src,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 let handler;const deny=()=>{throw Error("Checkout reached a forbidden side effect");};
 new Function("exports","require","Deno","fetch",js)({},()=>new Proxy({},{get:()=>deny}),{serve:fn=>{handler=fn;},env:{get:deny}},deny);
 const response=await handler(new Request("https://example.test",{method:"POST",body:"{}"}));
 assert.equal(response.status,503);assert.match((await response.json()).error,/Payments are disabled/);
});
