import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const home = fs.readFileSync('src/pages/Home.jsx','utf8');
const css = fs.readFileSync('src/pages/Home.css','utf8');
const nav = fs.readFileSync('src/components/Navbar.jsx','utf8');
test('the journey stages stay shared while the homepage presents the site v2 design', async () => {
 const {journeyStages,journeyPaths,journeyLaunchStages}=await import('../src/lib/journey.js');
 assert.deepEqual(journeyStages,['Match','Compare','Ownership','Analyze','Deal']);
 assert.deepEqual(journeyLaunchStages,['Match']);
 assert.equal(journeyPaths.Match,'/match');
 // The homepage is now the approved site v2 page: it composes the design's own sections.
 for (const section of ['SiteHeader','Hero','Premise','HowItWorks','Waters','StatementBand','SiteFooter']) {
  assert.ok(home.includes(`import ${section} from "@/components/home-v2/`), `${section} section missing from the homepage`);
  assert.ok(home.includes(`<${section}`) || home.includes(`<${section} />`), `${section} not rendered by the homepage`);
 }
 assert.ok(!home.includes('<HeadingQuiz') && !home.includes('<Services') && !home.includes('<PromiseSection') && !home.includes('<Journal'), 'removed sections must not render at the homepage root');
 assert.ok(!fs.readFileSync('src/components/home-v2/Premise.jsx','utf8').includes('<Waters'));
 assert.ok(home.includes('useSiteV2Styles'), 'the design stylesheet must be loaded by the page');
 assert.ok(home.includes('useSiteV2Motion'), 'the design motion must be attached by the page');
});
test('the homepage keeps the design document stylesheet scoped to its own route', () => {
 const styles=fs.readFileSync('src/hooks/useSiteV2Styles.js','utf8');
 assert.match(styles,/"\/site-v2\/assets\/css\/site\.css"/);
 assert.match(styles,/links\.forEach\(\(link\) => link\.remove\(\)\)/, 'the stylesheet must be removed on unmount so other pages keep their styling');
 assert.ok(fs.statSync('public/site-v2/assets/css/site.css').size > 10000);
 assert.ok(fs.statSync('public/site-v2/assets/css/fonts.css').size > 500);
 for (const asset of ['hero_full.jpg','hero_full_m.jpg','logo_v16.png','sprite.svg']) {
  assert.ok(fs.statSync(`public/site-v2/assets/img/${asset}`).size > 1000, `${asset} missing from the site v2 assets`);
 }
 assert.ok(fs.statSync('public/site-v2/assets/fonts/CormorantGaramond-var.woff2').size > 1000);
 assert.ok(css.includes('@media(max-width:760px)'));
 assert.ok(css.includes('prefers-reduced-motion'));
 assert.ok(css.includes('focus-visible'));
 assert.ok(fs.statSync('public/images/coastal-home.webp').size > 100000);
 assert.ok(css.includes('/images/coastal-home.webp'));
});
const header = fs.readFileSync('src/components/AppHeader.jsx','utf8');
const headerCss = fs.readFileSync('src/components/site-header.css','utf8');
test('shared header preserves real account state and protected My Helm destination', () => {
 assert.ok(nav.includes('<AppHeader />'));
 assert.ok(header.includes('authed ? "/helm" : "/login?returnTo=%2Fhelm"'));
 assert.ok(header.includes('My Account'));
 assert.ok(header.includes('aria-label="Mobile"'));
 assert.ok(header.includes('logout()'));
});
test('shared app branding matches the existing homepage v16 artwork without cropping', () => {
 const siteHeader=fs.readFileSync('src/components/home-v2/SiteHeader.jsx','utf8');
 for(const path of ['/site-v2/assets/img/logo_v16.svg','/site-v2/assets/img/logo_v16.webp']) {
  assert.ok(header.includes(path)); assert.ok(siteHeader.includes(path));
 }
 assert.ok(header.includes('width="326" height="160"'));
 assert.ok(headerCss.includes('object-fit:contain'));
 assert.ok(headerCss.includes("@import url('/site-v2/assets/css/fonts.css')"));
 assert.doesNotMatch(headerCss, /@import[^;]*\/assets\/css\/site\.css/);
});
test('shared header has scoped responsive mobile and reduced-motion rules', () => {
 assert.ok(headerCss.includes('@media (max-width:760px)'));
 assert.ok(headerCss.includes('@media (max-width:1024px)'));
 assert.ok(headerCss.includes('.sh-site .burger{display:block}'));
 assert.ok(headerCss.includes('prefers-reduced-motion'));
 assert.ok(header.includes('aria-expanded={menuOpen}'));
});
test('desktop and mobile header use actual homepage anchors and omit redundant Boats link', () => {
 assert.ok(!header.includes('["Boats", "/match"]'));
 for(const id of ['promise','how','journal']) assert.ok(header.includes('/#'+id));
 assert.equal((header.match(/LINKS.map/g)||[]).length,2);
 assert.ok(header.includes('setMenuOpen(false)'));
});