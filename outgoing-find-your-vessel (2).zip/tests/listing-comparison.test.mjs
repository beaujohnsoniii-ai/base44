import test from "node:test";
import assert from "node:assert/strict";
import {registerHooks} from "node:module";
import {extractListingClaims} from "../base44/shared/listing-claims.mjs";
import {withCompareDeadline} from "../base44/shared/compare-deadline.mjs";
import {assessListing,evaluateReadableListings,selectListingInputs,recommendFinalists} from "../base44/shared/listing-comparison.mjs";
const page="For sale | Make: Mock | Model: 23 | Year: 2021 | Price: USD 70,000 | Engine-down draft: 1.1 ft | Capacity: 6 persons";
const input={url:"https://dealer.com/boat/1",expected_make:"Mock",expected_model:"23"};
test("exact quoted page facts produce a provisional profile comparison",()=>{
 const result=assessListing({purchase_budget_max:85000,hard_max_draft_ft:1.2,passenger_count:2},input,page,extractListingClaims(page));
 assert.equal(result.eligible,false);assert.equal(result.structured_checks_complete,true);assert.equal(result.facts.asking_price.value,70000);
 assert.equal(assessListing({purchase_budget_max:60000},input,page,extractListingClaims(page)).eligible,false);
});
test("no model specifications are borrowed when exact identity differs",()=>{
 const result=assessListing({purchase_budget_max:85000},{...input,expected_model:"Pro Guide"},page,extractListingClaims(page));
 assert.equal(result.eligible,false);assert.match(result.concerns.join(" "),/differs/);
});
test("a listing from a different model year is not treated as saved-model specifications",()=>{
 const candidate={...input,expected_year:2026};
 const result=assessListing({},candidate,page,extractListingClaims(page));
 assert.equal(result.facts.year.value,2021);
 assert.equal(result.structured_checks_complete,false);
 assert.match(result.concerns.join(" "),/year 2021 differs from saved Match model year 2026/);
});
test("blocked pages never invoke extraction or invent finalists",async()=>{
 const out=await evaluateReadableListings({},[input],[{ok:false,error:"HTTP 403",text:""}],()=>{throw Error("must not run");});
 assert.equal(out.results[0].status,"unreadable");assert.deepEqual(out.recommendation.finalist_urls,[]);
});
test("unquoted values and ambiguous draft cannot establish fit",()=>{
 const out=assessListing({hard_max_draft_ft:1.2},input,page,{page_kind:"listing",facts:[{field:"draft_ft",value:0.5,unit:"ft",basis:"engine_down",quote:"made up 0.5 ft"}]});
 assert.equal(out.eligible,false);assert.equal(out.facts.draft_ft,undefined);
});
test("selection supports nine saved URLs and rejects search pages",()=>{
 const models=[1,2,3].map(i=>({id:String(i),listing_urls:[1,2,3].map(n=>"https://dealer.com/"+i+"/"+n)}));
 assert.equal(selectListingInputs(models,["1","2","3"],x=>x).length,9);
 assert.throws(()=>selectListingInputs([{id:"1",listing_urls:["https://www.google.com/search?q=boat"]}],["1"],x=>x),/actual seller/);
});
const key=Symbol.for("compare.test");
const hooks=registerHooks({resolve(s,c,next){if(s.startsWith("npm:@base44/sdk"))return{url:"data:text/javascript,"+encodeURIComponent('export const createClientFromRequest=()=>globalThis[Symbol.for("compare.test")];'),shortCircuit:true};return next(s,c);}});
const {default:handler}=await import("../base44/functions/compare-listings/entry.ts");hooks.deregister();
function client(plan="market_match",otherOwner=false){
 return {auth:{me:async()=>({id:"buyer",plan})},entities:{
 BuyerProfile:{filter:async()=>[{id:"profile",created_by_id:"buyer",purchase_budget_max:85000,hard_max_draft_ft:1.2,passenger_count:2}]},
 CompareWorkspace:{filter:async()=>[{created_by_id:"buyer",selected_ids:["model"]}]},
 SavedBoat:{get:async()=>({id:"model",created_by_id:otherOwner?"other":"buyer",make:"Mock",model:"23",listing_urls:[input.url]})}}};
}
const request=()=>new Request("https://app.com/api",{method:"POST",body:JSON.stringify({profile:{purchase_budget_max:1},urls:["https://ignored.com"]})});
test("server rejects access and another buyer before public fetch",async t=>{
 const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);globalThis.fetch=()=>{throw Error("must not fetch");};
 globalThis[key]=client("free");assert.equal((await handler(request())).status,403);
 globalThis[key]=client("market_match",true);assert.equal((await handler(request())).status,403);
});
test("real handler retains owner profile and saved URLs; unapproved sources are not fetched",async t=>{
  const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);const urls=[];
  globalThis.fetch=async url=>{urls.push(url);return new Response(page,{headers:{"content-type":"text/plain"}});};
  globalThis[key]=client();const res=await handler(request());assert.equal(res.status,200);
  const out=await res.json();assert.deepEqual(urls,[]);assert.equal(out.results[0].eligible,false);assert.equal(out.results[0].url,input.url);assert.equal(out.buyer_profile_id,"profile");assert.equal(out.retrieval_available,true);assert.equal(out.mode,"approved_source_import");assert.equal(out.results[0].status,"unsupported_source");assert.deepEqual(out.recommendation.finalist_urls,[]);
 });

test("authenticated handler accepts exact-URL buyer capture without network retrieval",async t=>{
 const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);globalThis.fetch=()=>{throw Error("must not fetch");};
 const url="https://www.pocketyachtco.com/new-boats-for-sale-detail/2027-sailfish-245-dc69f9343243796522ec060063";
 const copied=[
  "2027 Sailfish 245 DC","New Bern, NC","Request Pricing","Status New","Year 2027",
  "Manufacturer Sailfish","Model 245 DC","Engine Model F300XSB2 (White)","Boat Length 26",
  "Beam 8.5.ft","Hull Type Fiberglass","Serial Number 10171515",
  "This Sailfish 245 DC is currently on order and available for purchase.",
  "room for up to 12 onboard, comfortable seating throughout",
 ].join("\n");
 const c=client();c.entities.SavedBoat.get=async()=>({id:"model",created_by_id:"buyer",make:"Sailfish",model:"245 DC",year:2027,title:"2027 Sailfish 245 DC",listing_urls:[url]});
 globalThis[key]=c;
 const res=await handler(new Request("https://app.com/api",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({captures:[{url,text:copied}]})}));
 assert.equal(res.status,200);
 const out=await res.json(),result=out.results[0];
 assert.equal(result.url,url);assert.equal(result.status,"partial_evidence");assert.equal(result.resolution.transport,"user_capture");
 assert.equal(result.source_evidence.provenance,"user_supplied_capture");assert.equal(result.facts.year.value,2027);
 assert.equal(result.facts.beam_ft.value,8.5);assert.equal(result.facts.passenger_capacity.value,12);
 assert.equal(result.facts.make.provenance,"user_supplied_capture");assert.deepEqual(out.recommendation.finalist_urls,[]);
});

test("even apparently complete or forged eligible results cannot become ranked finalists",()=>{
 const good=assessListing({purchase_budget_max:85000},input,page,extractListingClaims(page));
 assert.deepEqual(recommendFinalists([{...good,eligible:true,evidence_coverage:99}]).finalist_urls,[]);
 const weak=assessListing({purchase_budget_max:85000},input,"For sale | Make: Mock | Model: 23 | Price: USD 70,000 |",extractListingClaims("For sale | Make: Mock | Model: 23 | Price: USD 70,000 |"));
 assert.equal(weak.eligible,false);assert.deepEqual(recommendFinalists([weak]).finalist_urls,[]);
});
test("overall deadline bounds stalled work and stops later work through its signal",async()=>{
 let signalSeen;const start=Date.now();
 await assert.rejects(withCompareDeadline(async signal=>{signalSeen=signal;await new Promise(()=>{});},20),/COMPARE_DEADLINE/);
 assert.equal(signalSeen.aborted,true);assert.ok(Date.now()-start<1000);
});
test("unauthenticated expired and cross-owner profile/workspace do not reach model reads",async()=>{
 for(const kind of ["anonymous","expired","profile","workspace"]){
  const c=client();let reads=0;c.entities.SavedBoat.get=async()=>{reads++;throw Error("must not read");};
  if(kind==="anonymous")c.auth.me=async()=>null;
  if(kind==="expired")c.auth.me=async()=>({id:"buyer",plan:"market_match",plan_expires:"2000-01-01"});
  if(kind==="profile")c.entities.BuyerProfile.filter=async()=>[{created_by_id:"other"}];
  if(kind==="workspace")c.entities.CompareWorkspace.filter=async()=>[{created_by_id:"other",selected_ids:["model"]}];
  globalThis[key]=c;assert.ok([400,401,403].includes((await handler(request())).status));assert.equal(reads,0);
 }
});