import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
import { STAGE_PRODUCTS, normalizePlan } from "../base44/shared/stages.ts";
import { PLAN_TIERS } from "../src/lib/stages.js";
import { TIER_RESULT_COUNTS } from "../base44/shared/tier-results.mjs";
function previewHandler() {
 const source=fs.readFileSync("base44/functions/preview-match/entry.ts","utf8");
 const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const exports={};new Function("exports","require",js)(exports,name=>{if(name.includes("tier-results"))return {TIER_RESULT_COUNTS};throw Error(name);});return exports.default;
}
const request=activities=>new Request("https://example.invalid/preview",{method:"POST",body:JSON.stringify({activities})});
test("frontend and server products use the four agreed names without changing plan ids, prices or aliases",()=>{
 for(const [id,name,price]of [["match_plus","Bosun",9],["refined_match","First Mate",29],["market_match","Captain",99]]){
 assert.equal(PLAN_TIERS.find(t=>t.id===id).name,name);assert.equal(STAGE_PRODUCTS[id].name,name);assert.equal(Number(STAGE_PRODUCTS[id].price),price);}
 assert.equal(normalizePlan("initial_boat_match"),"match_plus");assert.equal(normalizePlan("buyer_pass"),"market_match");
 assert.equal(STAGE_PRODUCTS.initial_boat_match.name,"Bosun");assert.equal(STAGE_PRODUCTS.buyer_pass.name,"Captain");
 assert.deepEqual(TIER_RESULT_COUNTS,{free:{suggestCount:4,minCount:4,highlightCount:0},match_plus:{suggestCount:14,minCount:10,highlightCount:0},refined_match:{suggestCount:14,minCount:10,highlightCount:7},market_match:{suggestCount:14,minCount:10,highlightCount:3}});
});
test("Deckhand supplies four distinct labelled examples for each activity and for empty or unknown input",async()=>{
 const run=previewHandler();
 for(const activities of [[],["Unknown"],["Fishing"],["Day cruising"],["Overnight cruising"],["Watersports / tubing"],["Diving"],["Entertaining"],["Commuting"],["Liveaboard"],["Fishing","Fishing"],["Fishing","Day cruising","Overnight cruising","Liveaboard"]]){
 const res=await run(request(activities));assert.equal(res.status,200);const data=await res.json();
 assert.equal(data.directions.length,4,JSON.stringify(activities));assert.equal(new Set(data.directions.map(d=>d.id)).size,4);
 assert.ok(data.directions.every(d=>["activity_starting_point","general_example"].includes(d.example_kind)));
 if(!activities.length||activities[0]==="Unknown")assert.ok(data.directions.every(d=>d.example_kind==="general_example"));
 assert.match(data.note,/not verified model recommendations/i);
 for(const d of data.directions){assert.equal(d.suitability_score,undefined);assert.equal(d.highlighted,undefined);}
 }
});
test("preview ignores paid matching inputs and preserves input validation",async()=>{
 const run=previewHandler();
 const a=await (await run(request(["Fishing"]))).json();
 const b=await (await run(new Request("https://example.invalid",{method:"POST",body:JSON.stringify({activities:["Fishing"],activity_weights:{Fishing:100},purchase_budget_max:100,hard_max_draft_ft:1,liked_models:[{make:"Fake"}]})}))).json();
 assert.deepEqual(a,b);assert.equal((await run(new Request("https://example.invalid"))).status,405);
 assert.equal((await run(new Request("https://example.invalid",{method:"POST",body:"{"}))).status,400);
 assert.equal((await run(new Request("https://example.invalid",{method:"POST",body:"x".repeat(4097)}))).status,413);
});
test("draft restriction copy keeps existing free-text and feet fields",()=>{
 const s=fs.readFileSync("src/components/IntroQuestionnaire.jsx","utf8");
 assert.match(s,/>Draft restrictions, if any</);assert.match(s,/value=\{data.draft\}/);assert.match(s,/value=\{data.hard_max_draft_ft\}/);assert.match(s,/Maximum acceptable vessel draft \(ft\)/);assert.match(s,/not the water depth/i);
});

function loadModule(path, dependencies={}) {
 const js=ts.transpileModule(fs.readFileSync(path,"utf8"),{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const exports={};new Function("exports","require",js)(exports,name=>{if(name in dependencies)return dependencies[name];throw Error("Unexpected import "+name);});return exports;
}
test("Membership renders four named, priced tiers in order with early-access links and honest benefits",()=>{
 const stages=loadModule("src/lib/stages.js");
 const tiers=loadModule("src/lib/tiers.js",{"@/lib/stages":stages});
 const React={createElement:(type,props,...children)=>({type,props:{...props,children}})};
 const pricing=loadModule("src/components/home-v2/Pricing.jsx",{"react":{__esModule:true,default:React},"@/components/home-v2/Icon":{default:"Icon"},"@/lib/tiers":tiers,"@/lib/stages":stages});
 const rows=pricing.MEMBERSHIP_TIERS;
 assert.deepEqual(rows.map(r=>[r.id,r.title,r.price]),[["free","Deckhand","Free"],["match_plus","Bosun","$9"],["refined_match","First Mate","$29"],["market_match","Captain","$99"]]);
 assert.match(rows[0].items.join(" "),/Four illustrative example results/);
 assert.doesNotMatch(rows[0].items.join(" "),/ownership cost|personalized|suitability|matches built/i);
 assert.match(rows[1].items.join(" "),/10–14/);assert.match(rows[1].items.join(" "),/No models marked as recommendations/);
 assert.match(rows[2].items.join(" "),/full 10–14.*5–7/);assert.match(rows[3].items.join(" "),/full model pool.*Top 3/);
 const walk=n=>!n?[]:Array.isArray(n)?n.flatMap(walk):typeof n==="object"?[n,...walk(n.props?.children)]:[];
 const nodes=walk(pricing.default());assert.equal(nodes.filter(n=>n.type==="article").length,4);
 const links=nodes.filter(n=>n.type==="a");assert.equal(links.length,4);assert.ok(links.every(n=>n.props.href==="#account"));
 assert.equal(tiers.UPGRADES_OPEN,false);
});
test("editing and saving the draft question preserves prior text and feet values without water-depth conversion",()=>{
 const deps=loadModule("src/lib/stages.js");const fields=loadModule("src/lib/question-fields.js",{"../../base44/shared/question-tier-defaults.mjs":{DEFAULT_FIELD_TIERS:{}}});
 // Use the real default tier table; Captain exposes every field regardless of its gate.
 let states=[],cursor=0,payload;
 const React={createElement:(type,props,...children)=>({type,props:{...props,children}})};
 const useState=initial=>{const i=cursor++;if(!(i in states))states[i]=typeof initial==="function"?initial():initial;return [states[i],v=>states[i]=typeof v==="function"?v(states[i]):v];};
 const source=fs.readFileSync("src/components/IntroQuestionnaire.jsx","utf8");
 const js=ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const exports={};
 new Function("exports","require","window",js)(exports,name=>{
 if(name==="react")return {__esModule:true,default:React,useState};
 if(name.includes("question-fields"))return fields;
 if(name.includes("/stages"))return deps;
 if(name.includes("activityWeights"))return {apportionActivityWeights:(a,w)=>w,toggleActivityWeightSelection:()=>({})};
 return new Proxy({__esModule:true,default:name.split("/").at(-1)},{get:(o,k)=>k in o?o[k]:String(k)});
 },{location:{search:""}});
 const profile={draft:"Old answer: shallow creek at low tide",hard_max_draft_ft:3.25};
 const walk=n=>!n?[]:Array.isArray(n)?n.flatMap(walk):typeof n==="object"?[n,...walk(n.props?.children)]:[];
 const render=()=>{cursor=0;return walk(exports.default({initialProfile:profile,plan:"market_match",onComplete:p=>payload=p,submitLabel:"Save fixture"}));};
 const jump=i=>render().find(n=>n.props?.["aria-label"]==="Jump to section").props.onChange({target:{value:String(i)}});
 jump(5);let inputs=render();assert.equal(inputs.find(n=>n.props?.id==="draft").props.value,profile.draft);
 assert.equal(inputs.find(n=>n.props?.id==="hard_max_draft_ft").props.value,3.25);
 const slider=render().find(n=>n.props?.["aria-label"]==="Jump to section");jump(slider.props.max);
 render().find(n=>n.type==="Button"&&n.props.children.flat().includes("Save fixture")).props.onClick();
 assert.equal(payload.draft,profile.draft);assert.equal(payload.hard_max_draft_ft,3.25);
 jump(5);render().find(n=>n.props?.id==="hard_max_draft_ft").props.onChange({target:{value:"2.5"}});
 jump(slider.props.max);render().find(n=>n.type==="Button"&&n.props.children.flat().includes("Save fixture")).props.onClick();
 assert.equal(payload.draft,profile.draft);assert.equal(payload.hard_max_draft_ft,2.5);
});
