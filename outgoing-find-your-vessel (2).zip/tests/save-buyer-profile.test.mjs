import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { saveBuyerProfile } from "../base44/shared/save-buyer-profile.mjs";
function fixture({ rows = [], failCreate = false, commitThenThrow = false } = {}) {
  let claim = "", creates = 0, updates = 0;
  const user = { id: "buyer", email: "synthetic@example.invalid" };
  const db = {
    User: { updateMany: async (query, update) => {
      assert.equal(query.id, user.id); assert.deepEqual(query.profile_creation_claim, { $in: [null, ""] });
      if (claim) return { updated: 0 };
      claim = update.$set.profile_creation_claim; return { updated: 1 };
    }},
    BuyerProfile: {
      filter: async query => rows.filter(row => row.created_by_id === query.created_by_id).slice().reverse().slice(0, 1),
      create: async data => { creates++; await new Promise(r=>setImmediate(r)); if(failCreate)throw Error("ambiguous transport failure");
        const row={...data,id:"profile-"+creates}; rows.push(row);if(commitThenThrow)throw Error("response lost");return row; },
      update: async (id, patch) => { updates++; const row=rows.find(row=>row.id===id);assert.ok(row);Object.assign(row,patch);return row; },
    },
  };
  return {client:{asServiceRole:{entities:db}},user,rows,creates:()=>creates,updates:()=>updates};
}
const answers={experience_level:"beginner",activities:["Fishing"],purchase_budget_max:60000};
test("simultaneous first submissions across separate requests create at most one owner profile",async()=>{
 const h=fixture();const results=await Promise.allSettled(Array.from({length:12},()=>saveBuyerProfile(h.client,h.user,answers)));
 assert.equal(h.creates(),1);assert.equal(h.rows.length,1);assert.ok(results.some(r=>r.status==="fulfilled"));
 assert.ok(results.filter(r=>r.status==="rejected").every(r=>r.reason.status===409));
 await saveBuyerProfile(h.client,h.user,answers);assert.equal(h.creates(),1);
});
test("restart and edits retain the existing owner id, Likes, notes and server-managed fields",async()=>{
 const own={id:"owner",created_by_id:"buyer",liked_models:[{make:"A"}],research_notes:"Do not lose",advisor_credit:20};
 const other={id:"other",created_by_id:"other",research_notes:"Private"};
 const h=fixture({rows:[other,own]});
 await saveBuyerProfile(h.client,h.user,{...answers,created_by_id:"other",id:"other",liked_models:[],research_notes:"Overwrite",advisor_credit:999,plan:"market_match"});
 assert.equal(h.creates(),0);assert.equal(h.updates(),1);assert.equal(own.id,"owner");assert.deepEqual(own.liked_models,[{make:"A"}]);assert.equal(own.research_notes,"Do not lose");assert.equal(own.advisor_credit,20);assert.equal(own.plan,undefined);assert.equal(other.research_notes,"Private");
});
test("draft adoption on a second tab cannot overwrite an existing account profile",async()=>{
 const own={id:"owner",created_by_id:"buyer",activities:["Day cruising"]};const h=fixture({rows:[own]});
 assert.equal((await saveBuyerProfile(h.client,h.user,answers,{onlyIfMissing:true})).id,"owner");
 assert.deepEqual(own.activities,["Day cruising"]);assert.equal(h.updates(),0);
});
test("a create whose response is lost is recovered without creating a second record",async()=>{
 const h=fixture({commitThenThrow:true});
 await assert.rejects(()=>saveBuyerProfile(h.client,h.user,answers),/response lost/);
 const recovered=await saveBuyerProfile(h.client,h.user,answers);assert.equal(recovered.id,"profile-1");assert.equal(h.creates(),1);
});
test("an ambiguous failed create keeps the permanent claim and refuses unsafe automatic creation",async()=>{
 const h=fixture({failCreate:true});
 await assert.rejects(()=>saveBuyerProfile(h.client,h.user,answers),/transport failure/);
 await assert.rejects(()=>saveBuyerProfile(h.client,h.user,answers),/needs recovery/);assert.equal(h.creates(),1);
});
test("unauthenticated and incomplete requests cannot acquire a claim or create rows",async()=>{
 const h=fixture();await assert.rejects(()=>saveBuyerProfile(h.client,null,answers),e=>e.status===401);
 await assert.rejects(()=>saveBuyerProfile(h.client,h.user,{}),e=>e.status===400);assert.equal(h.creates(),0);
});
test("buyer creation and deletion are closed outside admin/service-role and all app creation uses the server function",()=>{
 const schema=JSON.parse(fs.readFileSync("base44/entities/BuyerProfile.jsonc","utf8"));
 assert.deepEqual(schema.rls.create,{user_condition:{role:"admin"}});assert.deepEqual(schema.rls.delete,{user_condition:{role:"admin"}});
 for(const path of ["src/pages/Questionnaire.jsx","src/pages/Dashboard.jsx","src/pages/EditProfile.jsx"]){const s=fs.readFileSync(path,"utf8");assert.doesNotMatch(s,/BuyerProfile.create\(/);assert.match(s,/functions.invoke\("save-(?:buyer|matching)-profile"/);}
});
