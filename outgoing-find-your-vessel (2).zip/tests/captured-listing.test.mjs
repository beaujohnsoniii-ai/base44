import test from "node:test";
import assert from "node:assert/strict";
import { CAPTURE_LIMITS, normalizeCapturedListings } from "../base44/shared/captured-listing.mjs";
import { resolveApprovedListing } from "../base44/shared/approved-listing-resolver.mjs";
import { normalizePublicListingUrl } from "../base44/shared/remote-listing.ts";

const url="https://www.pocketyachtco.com/new-boats-for-sale-detail/2027-sailfish-245-dc69f9343243796522ec060063";
const text=[
  "2027 Sailfish 245 DC",
  "New Bern, NC",
  "Request Pricing",
  "Status New",
  "Year 2027",
  "Manufacturer Sailfish",
  "Model 245 DC",
  "Engine Model F300XSB2 (White)",
  "Boat Length 26",
  "Beam 8.5.ft",
  "Hull Type Fiberglass",
  "Serial Number 10171515",
  "This Sailfish 245 DC is currently on order and available for purchase.",
  "room for up to 12 onboard, comfortable seating throughout",
].join("\n");

test("captured rows bind only to an authoritative saved URL",()=>{
  const rows=normalizeCapturedListings([{url,text}],[normalizePublicListingUrl(url)],normalizePublicListingUrl);
  assert.equal(rows.get(normalizePublicListingUrl(url)),text);
  assert.throws(()=>normalizeCapturedListings([{url:"https://dealer.example/other",text}],[normalizePublicListingUrl(url)],normalizePublicListingUrl),/did not match/);
  assert.throws(()=>normalizeCapturedListings([{url,text:"x".repeat(CAPTURE_LIMITS.per_listing_chars+1)}],[normalizePublicListingUrl(url)],normalizePublicListingUrl),/too long/);
});

test("buyer capture resolves an exact dealer URL without any network request",async()=>{
  const original=globalThis.fetch;
  globalThis.fetch=()=>{throw Error("must not fetch");};
  try{
    const result=await resolveApprovedListing(
      {passenger_count:8,hard_max_beam_ft:9},
      {url,expected_make:"Sailfish",expected_model:"245 DC",expected_year:2027,model_title:"2027 Sailfish 245 DC"},
      null,
      {capturedText:text},
    );
    assert.equal(result.status,"partial_evidence");
    assert.equal(result.resolution.transport,"user_capture");
    assert.equal(result.source_evidence.provenance,"user_supplied_capture");
    assert.equal(result.facts.make.value,"Sailfish");
    assert.equal(result.facts.year.value,2027);
    assert.equal(result.facts.beam_ft.value,8.5);
    assert.equal(result.facts.passenger_capacity.value,12);
    assert.equal(result.facts.make.provenance,"user_supplied_capture");
  } finally { globalThis.fetch=original; }
});

test("capture with no listing context is rejected without fetching",async()=>{
  const original=globalThis.fetch;
  globalThis.fetch=()=>{throw Error("must not fetch");};
  try{
    const result=await resolveApprovedListing(
      {},
      {url,expected_make:"Sailfish",expected_model:"245 DC"},
      null,
      {capturedText:"Sailfish 245 DC ".repeat(8)},
    );
    assert.equal(result.status,"capture_insufficient_evidence");
    assert.equal(result.eligible,false);
    assert.deepEqual(result.facts,{});
  } finally { globalThis.fetch=original; }
});
