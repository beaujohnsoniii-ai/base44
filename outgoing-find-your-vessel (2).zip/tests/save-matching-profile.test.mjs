import {applyPastLikeChoice} from "../base44/shared/liked-preferences.mjs";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
import {saveBuyerProfile,ProfileSaveError} from "../base44/shared/save-buyer-profile.mjs";
import {profileInputFingerprint} from "../base44/shared/profile-input-fingerprint.mjs";
import {DEFAULT_FIELD_TIERS} from "../base44/shared/question-tier-defaults.mjs";
const source=fs.readFileSync("base44/functions/save-matching-profile/entry.ts","utf8");
const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
function fixture({reject=false,ignoreContext=false,ignoreAnswers=false,legacyContext=false}={}){
 const original={id:"p",created_by_id:"buyer",updated_date:"2026-10-24T17:39:56.898000",match_context_id:"reset-context",experience_level:"intermediate",activity_weights:{Fishing:45,Entertaining:55},purchase_budget_max:200000,liked_models:[{title:"Keep"}],research_notes:"Keep",advisor_credit:29};if(legacyContext!==false){if(legacyContext==="missing")delete original.match_context_id;else original.match_context_id=legacyContext;}let row=structuredClone(original),updates=0,patch;
 const entities={BuyerProfile:{filter:async()=>[structuredClone(row)],updateMany:async(q,u)=>{updates++;assert.equal(q.id,"p");assert.equal(q.created_by_id,"buyer");assert.equal(q.updated_date,original.updated_date);assert.deepEqual(q.match_context_id,{$in:[original.match_context_id??null]});patch=u.$set;if(reject)return {updated:0};for(const [k,v] of Object.entries(patch)){if(ignoreContext&&k==="match_context_id"||ignoreAnswers&&k!=="match_context_id")continue;row[k]=v;}return {updated:1};}}};
 const client={auth:{me:async()=>({id:"buyer"})},asServiceRole:{entities}};const exports={};new Function("exports","require",js)(exports,name=>name.startsWith("npm:")?{createClientFromRequest:()=>client}:name.includes("liked-preferences")?{applyPastLikeChoice}:name.includes("save-buyer-profile")?{saveBuyerProfile,ProfileSaveError}:name.includes("profile-input-fingerprint")?{profileInputFingerprint}:{DEFAULT_FIELD_TIERS});
 const invoke=(profile,reset_context=true,extra={})=>exports.default(new Request("https://example.invalid/save",{method:"POST",body:JSON.stringify({profile,reset_context,...extra}),headers:{"Content-Type":"application/json"}}));
 return {invoke,row,original,updates:()=>updates,patch:()=>patch};
}
test("actual save handler writes current questionnaire answers and context in one conditional update",async()=>{
 const h=fixture();const response=await h.invoke({activity_weights:{Fishing:10,Entertaining:90},purchase_budget_max:300000,liked_models:[],advisor_credit:999});assert.equal(response.status,200);const data=await response.json();assert.equal(data.profile_save_version,"profile-save-v1");assert.equal(data.reset_context_applied,true);assert.notEqual(data.profile.match_context_id,h.original.match_context_id);assert.deepEqual(data.profile.activity_weights,{Fishing:10,Entertaining:90});assert.equal(h.updates(),1);assert.deepEqual(h.row.liked_models,h.original.liked_models);assert.equal(h.row.advisor_credit,29);assert.equal(h.row.research_notes,"Keep");assert.deepEqual(Object.keys(h.patch()).sort(),["activity_weights","match_context_id","purchase_budget_max"].sort());
});
test("material edits rotate context and identical Reset answers also rotate",async()=>{
 for(const reset of [false,true]){const h=fixture();const input=reset?{activity_weights:h.original.activity_weights}:{purchase_budget_max:250000};assert.equal((await h.invoke(input,reset)).status,200);assert.notEqual(h.row.match_context_id,h.original.match_context_id);}
 const unchanged=fixture();assert.equal((await unchanged.invoke({purchase_budget_max:200000},false)).status,200);assert.equal(unchanged.row.match_context_id,unchanged.original.match_context_id);
});
test("concurrent edit rejection leaves existing buyer answers untouched",async()=>{
 const h=fixture({reject:true});assert.equal((await h.invoke({purchase_budget_max:300000})).status,409);assert.deepEqual(h.row,h.original);
});
test("context-only or answers-only partial persistence is never acknowledged as a saved profile",async()=>{
 for(const options of [{ignoreContext:true},{ignoreAnswers:true}]){const h=fixture(options);const r=await h.invoke({purchase_budget_max:300000});assert.equal(r.status,503);assert.match((await r.json()).error,/may already be saved/);}
});
test("actual save entrypoint scopes opt-in to the freshly persisted context and Reset overrides it",async()=>{
 const h=fixture();const r=await h.invoke({use_past_likes:true},false);assert.equal(r.status,200);
 assert.equal(h.row.past_likes_context_id,h.row.match_context_id);
 assert.notEqual(h.row.match_context_id,h.original.match_context_id);
 assert.deepEqual(h.row.liked_models,h.original.liked_models);
 const reset=fixture();assert.equal((await reset.invoke({use_past_likes:true},true)).status,200);
 assert.equal(reset.row.past_likes_context_id,null);
});

for(const legacyContext of ["missing",null,""]){
 test(`legacy ${String(legacyContext)} context: unchanged save preserves exact Match fingerprint and history`,async()=>{
  const h=fixture({legacyContext});const before=await profileInputFingerprint(h.original);
  const response=await h.invoke({purchase_budget_max:h.original.purchase_budget_max},false);
  assert.equal(response.status,200);const result=await response.json();
  assert.equal(result.reset_context_applied,false);assert.equal(await profileInputFingerprint(result.profile),before);
  assert.deepEqual(h.row,h.original);assert.equal(h.updates(),1);assert.ok(!Object.hasOwn(h.patch(),"match_context_id"));
 });
 test(`legacy ${String(legacyContext)} context: only_if_missing reads without overwriting answers or inventing context`,async()=>{
  const h=fixture({legacyContext});const response=await h.invoke({purchase_budget_max:999999,use_past_likes:true},false,{only_if_missing:true});
  assert.equal(response.status,200);const result=await response.json();assert.deepEqual(result.profile,JSON.parse(JSON.stringify(h.original)));
  assert.deepEqual(h.row,h.original);assert.equal(h.updates(),0);
 });
 test(`legacy ${String(legacyContext)} context: material edit and explicit Reset each create one verified context`,async()=>{
  for(const reset of [false,true]){
   const h=fixture({legacyContext});const input=reset?{purchase_budget_max:h.original.purchase_budget_max}:{purchase_budget_max:250000};
   const response=await h.invoke(input,reset);assert.equal(response.status,200);
   assert.ok(h.row.match_context_id);assert.notEqual(await profileInputFingerprint(h.row),await profileInputFingerprint(h.original));
   assert.deepEqual(h.row.liked_models,h.original.liked_models);assert.equal(h.row.advisor_credit,29);assert.equal(h.row.research_notes,"Keep");assert.equal(h.updates(),1);
  }
 });
}
test("legacy unchanged saves still reject concurrent writes and failed answer persistence",async()=>{
 const conflict=fixture({legacyContext:"missing",reject:true});assert.equal((await conflict.invoke({purchase_budget_max:200000},false)).status,409);assert.deepEqual(conflict.row,conflict.original);
 const partial=fixture({legacyContext:null,ignoreAnswers:true});assert.equal((await partial.invoke({purchase_budget_max:250000},false)).status,503);
 const missing=fixture({legacyContext:null,ignoreContext:true});assert.equal((await missing.invoke({purchase_budget_max:200000},true)).status,503);
});

test("legacy explicit past-Like opt-in creates a context while absent or false does not",async()=>{
 for(const legacyContext of ["missing",null,""]){
  const enabled=fixture({legacyContext});const response=await enabled.invoke({use_past_likes:true},false);assert.equal(response.status,200);
  assert.ok(enabled.row.match_context_id);assert.equal(enabled.row.past_likes_context_id,enabled.row.match_context_id);
  assert.deepEqual(enabled.row.liked_models,enabled.original.liked_models);assert.equal(enabled.row.advisor_credit,29);assert.equal(enabled.updates(),1);
  for(const input of [{},{use_past_likes:false}]){
   const unchanged=fixture({legacyContext});assert.equal((await unchanged.invoke(input,false)).status,200);
   assert.equal(await profileInputFingerprint(unchanged.row),await profileInputFingerprint(unchanged.original));
   assert.equal(unchanged.row.match_context_id,unchanged.original.match_context_id);
   assert.deepEqual(unchanged.row.liked_models,unchanged.original.liked_models);assert.equal(unchanged.row.advisor_credit,29);
  }
 }
});
