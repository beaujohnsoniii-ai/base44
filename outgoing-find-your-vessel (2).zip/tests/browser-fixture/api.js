const fail=()=>{throw new Error('Browser fixture blocks external side effects');};
export const base44={auth:{isAuthenticated:async()=>true,me:async()=>({id:'browser-fixture-admin',role:'admin'}),logout:fail},entities:{Manufacturer:{list:async()=>[]}},functions:{invoke:fail}};
