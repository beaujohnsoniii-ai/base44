export function useAuth(){return {user:{id:'browser-fixture-admin',role:'admin'},isLoadingAuth:false};}
