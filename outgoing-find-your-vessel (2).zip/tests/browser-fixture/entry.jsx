import React from 'react';
import {createRoot} from 'react-dom/client';
import {BrowserRouter} from 'react-router-dom';
import AdminJourneyTrial from '../../src/pages/AdminJourneyTrial';
import Home from '../../src/pages/Home';
import '../../src/index.css';
createRoot(document.getElementById('root')).render(<BrowserRouter>{location.pathname==='/home'?<Home/>:<AdminJourneyTrial/>}</BrowserRouter>);
