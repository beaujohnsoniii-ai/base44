import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {freshJourney,journeyReducer,journeyResults,journeyPurchase} from "../src/lib/journey-trial.mjs";
import {PLAN_TIERS} from "../src/lib/stages.js";
import {tierResultCounts} from "../src/lib/tier-results.js";
const answers={activities:["Fishing"],experience_level:"experienced",purchase_budget_max:207500,hard_max_overall_length_ft:26};
test("fresh questionnaire to free four, each simulated package with its marks, Likes, candidates and reset",()=>{
 let s=freshJourney();assert.equal(s.profile,null);assert.equal(s.plan,"free");
 s=journeyReducer(s,{type:"answers",profile:answers});assert.equal(s.phase,"results");assert.equal(journeyResults(s).length,4);
 s=journeyReducer(s,{type:"like",id:"sailfish-245-dc",liked:true});assert.equal(journeyResults(s)[0].fixture_id,"sailfish-245-dc");
 for(const [product,plan,amount] of [["match_plus","match_plus",9],["upgrade_match_plus_to_refined","refined_match",20],["upgrade_refined_to_market","market_match",70]]){
  s=journeyReducer(s,{type:"purchase",product});assert.equal(s.purchase.amount,amount);assert.equal(s.plan===plan,false);
  s=journeyReducer(s,{type:"confirm_purchase"});assert.equal(s.plan,plan);assert.equal(s.phase,"questionnaire");
  s=journeyReducer(s,{type:"answers",profile:s.profile});assert.equal(s.phase,"results");
  // The isolated trial presents the four fixtures it holds and never pads toward
  // the tier's target pool; the tier decides the marks, exactly as production does.
  const rows=journeyResults(s);
  assert.equal(rows.length,4);
  assert.equal(rows.filter(b=>b.highlighted===true).length,Math.min(4,tierResultCounts(plan).highlightCount));
 }
 s=journeyReducer(s,{type:"add",boat:{title:"Temporary"},key:"one"});
 s=journeyReducer(s,{type:"report"});assert.equal(s.report,true);assert.equal(s.candidates.length,1);
 assert.deepEqual(journeyReducer(s,{type:"reset"}),freshJourney());
 assert.equal(answers.id,undefined);
});
test("direct package, cancelled purchase, invalid tier and update allowance",()=>{
 let s=journeyReducer(freshJourney(),{type:"answers",profile:answers});
 assert.equal(journeyPurchase(s,"market_match").amount,99);
 s=journeyReducer(s,{type:"purchase",product:"refined_match"});s=journeyReducer(s,{type:"cancel_purchase"});assert.equal(s.plan,"free");
 assert.equal(journeyPurchase(s,"admin"),null);
 s=journeyReducer(s,{type:"purchase",product:"match_plus"});s=journeyReducer(s,{type:"confirm_purchase"});
 for(let i=0;i<8;i++)s=journeyReducer(s,{type:"refresh"});
 assert.equal(s.updates,PLAN_TIERS.find(t=>t.id==="match_plus").updates);
 assert.equal(journeyPurchase(s,"free"),null);
});
test("simulation keeps unknown price and evidence and never pads models to advertised count",()=>{
 const rows=journeyResults(journeyReducer(freshJourney(),{type:"answers",profile:answers}));
 assert.equal(rows.find(b=>b.fixture_id==="sailfish-245-dc").price_range_min,null);
 assert.equal(rows.find(b=>b.fixture_id==="sailfish-232-cc").price_range_min,null);
 assert.ok(rows.every(b=>b.verification_required.length && !("suitability_score" in b)));
});
test("isolated journey never imports API client, persists data, invokes generation or checkout",()=>{
 const page=readFileSync(new URL("../src/pages/AdminJourneyTrial.jsx",import.meta.url),"utf8");
 const logic=readFileSync(new URL("../src/lib/journey-trial.mjs",import.meta.url),"utf8");
 assert.doesNotMatch(page+logic,/base44Client|\.entities\.|\.invoke\(|fetch\(|localStorage|sessionStorage|create-checkout/);
 assert.match(page,/user\?\.role!=="admin"/);
 assert.match(page,/onToggleLike=\{/);
 assert.match(page,/simulation checkoutAvailable/);
 assert.match(page,/initialProfile=\{state.profile\}/);
 const fixture=readFileSync(new URL("../src/lib/journey-trial-fixtures.mjs",import.meta.url),"utf8");
 assert.doesNotMatch(fixture,/created_by_id|6ace25a2|6abbd00e|research_notes|family_use/);
});
test("Like injection returns before persistent endpoint; normal panel default remains unchanged",()=>{
 const panel=readFileSync(new URL("../src/components/SuggestedBoatsPanel.jsx",import.meta.url),"utf8");
 assert.match(panel,/if \(onToggleLike\) \{ await onToggleLike\(b, !isLiked\); return; \}/);
 const card=readFileSync(new URL("../src/components/PlanTierCard.jsx",import.meta.url),"utf8");
 assert.match(card,/simulation = false/);
 assert.match(card,/display only/);
});