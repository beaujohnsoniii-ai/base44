import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
import {apportionActivityWeights,toggleActivityWeightSelection} from "../src/lib/activityWeights.js";
import {FIELD_TIERS} from "../src/lib/question-fields.js";
import {generateRecommendations} from "../base44/shared/suggest-engine.ts";
import {DEFAULT_MATCH_PLUS_FIELDS,DEFAULT_REFINED_MATCH_FIELDS,DEFAULT_MARKET_MATCH_FIELDS} from "../base44/shared/question-tiers.ts";

const source=fs.readFileSync("src/components/IntroQuestionnaire.jsx","utf8");
const js=ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
// Component-contract harness: execute the real form and callbacks, substituting
// leaf UI controls and React hooks. No DOM, network, SDK or persistence exists.
function form(profile,plan="free"){
 let states=[],cursor=0,saved=[];
 const React={createElement:(type,props,...children)=>({type,props:{...props,children}})};
 const useState=initial=>{const i=cursor++;if(!(i in states))states[i]=typeof initial==="function"?initial():initial;return [states[i],value=>{states[i]=typeof value==="function"?value(states[i]):value;}];};
 const exports={};
 new Function("exports","require","window",js)(exports,name=>{
  if(name==="react")return {__esModule:true,default:React,useState};
  if(name.includes("activityWeights"))return {apportionActivityWeights,toggleActivityWeightSelection};
  if(name.includes("question-fields"))return {FIELD_TIERS};
  if(name.includes("/stages"))return {normalizePlan:p=>p};
  return new Proxy({__esModule:true,default:name.split("/").at(-1)},{get:(o,k)=>k in o?o[k]:String(k)});
 },{location:{search:""}});
 const render=()=>{cursor=0;return exports.default({initialProfile:profile,plan,onComplete:p=>saved.push(p),submitLabel:"Save fixture"});};
 const walk=node=>!node?[]:Array.isArray(node)?node.flatMap(walk):typeof node==="object"?[node,...walk(node.props?.children)]:[];
 const nodes=()=>walk(render());
 const jump=n=>nodes().find(x=>x.props?.["aria-label"]==="Jump to section").props.onChange({target:{value:String(n)}});
 const weights=()=>nodes().find(x=>x.type==="ActivityWeightPie");
 const finish=()=>{const slider=nodes().find(x=>x.props?.["aria-label"]==="Jump to section");jump(slider.props.max);const button=nodes().find(x=>x.type==="Button"&&x.props.children.flat().includes("Save fixture"));assert.ok(button);button.props.onClick();return saved.at(-1);};
 return {nodes,jump,weights,finish,saved};
}
const profile={activities:["Fishing","Day cruising"],activity_weights:{Fishing:80,"Day cruising":20},operating_area:"coastal",vessel_class:"private",boat_size_range:"18_24",experience_level:"intermediate",storage:"trailer",purchase_budget_max:85000,ownership_timeframe:"just_exploring"};
test("Discovery and each paid question set expose activity priorities on the activities step",()=>{
 for(const plan of ["free","match_plus","refined_match","market_match"]){const h=form({...profile,match_question_tier:plan},plan);h.jump(2);assert.ok(h.weights(),plan);}
});
test("editing weights survives back/next and the saved-payload revisit",()=>{
 const h=form(profile);h.jump(2);h.weights().props.onChange({Fishing:25,"Day cruising":75});h.jump(1);h.jump(2);
 assert.deepEqual(h.weights().props.weights,{Fishing:25,"Day cruising":75});
 const payload=h.finish();assert.deepEqual(payload.activity_weights,{Fishing:25,"Day cruising":75});
 const again=form(JSON.parse(JSON.stringify(payload)));again.jump(2);assert.deepEqual(again.weights().props.weights,payload.activity_weights);
});
test("interruption before Save does not mutate the supplied profile or submit it",()=>{
 const original=structuredClone(profile),h=form(profile);h.jump(2);h.weights().props.onChange({Fishing:10,"Day cruising":90});
 assert.equal(h.saved.length,0);assert.deepEqual(profile,original);
 const resumed=form(profile);resumed.jump(2);assert.deepEqual(resumed.weights().props.weights,original.activity_weights);
});
test("single activity and legacy missing weights retain safe defaults",()=>{
 const single=form({...profile,activities:["Fishing"],activity_weights:{}});single.jump(2);assert.ok(single.weights());assert.deepEqual(single.finish().activity_weights,{Fishing:100});
 const legacy=form({...profile,activity_weights:{}});assert.deepEqual(legacy.finish().activity_weights,{Fishing:50,"Day cruising":50});
});
test("saved Discovery weights enter paid scoring instructions without unlocking free scoring fields",async()=>{
 for(const plan of ["free","match_plus","refined_match","market_match"]){
  let prompt="";const client={asServiceRole:{integrations:{Core:{InvokeLLM:async p=>{prompt=p.prompt;return {contradiction:{flagged:true},suggestions:[]};}}}}};
  await generateRecommendations(client,{profile,plan,tierFields:{matchPlus:new Set(DEFAULT_MATCH_PLUS_FIELDS),refinedMatch:new Set(DEFAULT_REFINED_MATCH_FIELDS),marketMatch:new Set(DEFAULT_MARKET_MATCH_FIELDS)},manufacturerMap:{brief:"",list:[]},likedModels:[],savedBoats:[],existingSuggestions:[],isFirstPaidGeneration:false,hadContradiction:false,refresh:false,contradictionRerunCount:0});
  const summary=JSON.parse(prompt.split("Buyer profile (needs / wants / budget / priorities):\n")[1]);
  if(plan==="free")assert.equal("activity_weights" in summary,false);else assert.deepEqual(summary.activity_weights,profile.activity_weights);
  assert.match(prompt,/activities_use: 0-25 points\. Weight fit to each selected activity by activity_weights/);
  assert.match(prompt,/dominant activity should drive the core hull/);
 }
});
test("create, browser-draft and edit save paths pass the weight-bearing form payload intact",()=>{
 const questionnaire=fs.readFileSync("src/pages/Questionnaire.jsx","utf8"),edit=fs.readFileSync("src/pages/EditProfile.jsx","utf8");
 assert.match(questionnaire,/functions.invoke\("save-matching-profile", \{ profile: profileData, reset_context: resetting \}\)/);assert.doesNotMatch(questionnaire,/BuyerProfile.create\(/);assert.match(questionnaire,/JSON.stringify\(profileData\)/);
 assert.match(edit,/functions.invoke\("save-matching-profile", \{ profile: profileData \}\)/);
 assert.match(source,/activity_weights: apportionActivityWeights\(data.activities, data.activity_weights\)/);
});
