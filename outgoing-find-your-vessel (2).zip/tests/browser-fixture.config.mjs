import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
export default defineConfig({plugins:[react()],resolve:{alias:[{find:'@/lib/AuthContext',replacement:path.resolve('tests/browser-fixture/auth.jsx')},{find:'@/api/base44Client',replacement:path.resolve('tests/browser-fixture/api.js')},{find:'@',replacement:path.resolve('src')}]},build:{outDir:'/tmp/journey-preview',emptyOutDir:true,rollupOptions:{input:path.resolve('tests/browser-fixture/index.html')}},publicDir:false});
