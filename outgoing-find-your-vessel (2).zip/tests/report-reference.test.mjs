import test from "node:test";
import assert from "node:assert/strict";
import {
  isModelRecommendation,
  reportReferenceLinkLabel,
  reportReferenceMetadata,
} from "../src/lib/report-reference.js";

test("model guidance never turns a legacy price into an asking price or claims availability", () => {
  const rec = {
    title: "Parker 2520",
    availability: "Model guidance — not a specific listing",
    asking_price: "$124,900",
    review_date: "October 14, 2026",
  };
  assert.equal(isModelRecommendation(rec), true);
  const meta = reportReferenceMetadata(rec).join(" / ");
  assert.match(meta, /Model recommendation/);
  assert.match(meta, /Reviewed October 14/);
  assert.doesNotMatch(meta, /124,900|Availability:|Asking price:/);
  assert.equal(reportReferenceLinkLabel(rec, "https://www.google.com/search?q=Parker+2520"), "Search model listings");
  assert.equal(reportReferenceLinkLabel(rec, "https://example.com/models/parker"), "Explore model examples");
});

test("an identifiable buyer-submitted listing retains seller price and qualified availability", () => {
  const rec = {
    title: "Used Parker 2520",
    availability: "advertised",
    asking_price: "$99,500",
    review_date: "October 14, 2026",
    link: "https://example.com/boat/123",
  };
  assert.equal(isModelRecommendation(rec), false);
  assert.deepEqual(reportReferenceMetadata(rec), [
    "Asking price: $99,500",
    "Reviewed October 14, 2026",
    "Availability: advertised",
  ]);
  assert.equal(reportReferenceLinkLabel(rec, rec.link), "Listing");
});

test("missing metadata is not invented", () => {
  assert.deepEqual(reportReferenceMetadata({}), []);
  assert.deepEqual(reportReferenceMetadata(null), []);
});
