import test from "node:test";import assert from "node:assert/strict";
import {extractListingDocument,nullableListingFacts} from "../base44/shared/listing-document.mjs";
import {assessListing} from "../base44/shared/listing-comparison.mjs";
import {resolveListing} from "../base44/shared/listing-resolver.mjs";
import {resolveWithCache} from "../base44/shared/listing-cache.mjs";
const url="https://dealer.com/boat/exact";const input={url,expected_make:"Mock",expected_model:"23"};
const product=(extra={})=>({"@type":"Vehicle",url,brand:{name:"Mock"},model:"23",vehicleModelDate:"2021",engineHours:290,offers:{"@type":"Offer",price:"70000",priceCurrency:"USD"},...extra});
const html=node=>'<html><body>Individual boat for sale. Seller claims need confirmation.</body><script type="application/ld+json">'+JSON.stringify(node)+'</script></html>';
function doc(node=product()){return {url,final_url:url,html:html(node),retrieved_at:new Date().toISOString()};}
test("JSON-LD is parsed before script removal; identity currency and engine hours retain evidence",()=>{
 const parsed=extractListingDocument(doc());const r=assessListing({purchase_budget_max:85000},input,parsed.text,parsed.extraction);
 assert.equal(r.facts.make.value,"Mock");assert.equal(r.facts.year.value,2021);assert.equal(r.facts.asking_price.value,70000);
 assert.equal(r.facts.asking_price_currency.value,"USD");assert.equal(r.facts.engine_hours.value,290);
 assert.ok(parsed.evidence.every(e=>e.json_path&&e.source_url===url));assert.equal(nullableListingFacts(r.facts).draft_ft,null);
});
test("zero engine hours are explicit; empty or mileage values do not become hours",()=>{
 for(const extra of [{engineHours:""},{engineHours:null,mileageFromOdometer:290}]){
 const p=extractListingDocument(doc(product(extra)));assert.ok(!p.extraction.facts.some(f=>f.field==="engine_hours"));}
 const p=extractListingDocument(doc(product({engineHours:0})));const r=assessListing({},input,p.text,p.extraction);assert.equal(r.facts.engine_hours.value,0);
});
test("non-USD price remains a source claim and cannot establish USD budget fit",()=>{
 const p=extractListingDocument(doc(product({offers:{price:70000,priceCurrency:"EUR"}})));
 const r=assessListing({purchase_budget_max:85000},input,p.text,p.extraction);
 assert.equal(r.facts.asking_price.unit,"EUR");assert.equal(r.checks[0].status,"unknown");assert.equal(r.eligible,false);
});
test("multiple structured boat objects are ambiguous and malformed scripts never execute",()=>{
 const p=extractListingDocument(doc([product(),product({model:"99"})]));assert.match(p.ambiguity,/Multiple/);
 globalThis.__listingScriptRan=false;const q=extractListingDocument({html:'<script type="application/ld+json">globalThis.__listingScriptRan=true</script>'+' '.repeat(120),final_url:url});
 assert.equal(globalThis.__listingScriptRan,false);assert.equal(q.extraction.page_kind,"unknown");
});
test("a related product with a different canonical URL is not promoted to listing facts",()=>{
 const p=extractListingDocument(doc(product({url:"https://dealer.com/other"})));assert.equal(p.extraction.page_kind,"unknown");
});
test("source conflicting offers are withheld rather than selecting a sale price",()=>{
 const p=extractListingDocument(doc(product({offers:[{price:70000,priceCurrency:"USD"},{price:75000,priceCurrency:"USD"}]})));
 assert.ok(!p.extraction.facts.some(f=>f.field==="asking_price"));
});
function fixture(){
 const rows=[],calls={read:0,discover:0};const runtime={provider:{kind:"approved_listing_provider",safe_transport:"base44_custom_integration_proxy",downstream_public_egress_verified:true,redirects_permission_checked:true,search_authorized:true,usage_authorized:true,approval_reference:"TEST ONLY",
 discover:async q=>{assert.ok(!Object.hasOwn(q,"profile"));calls.discover++;return {candidates:[]};},
 read:async()=>{calls.read++;return doc();}},source_permissions:[{hostname:"dealer.com",automated_read:true,approval_reference:"TEST ONLY",valid_until:"2099-01-01"}]};
 const cache={filter:async q=>rows.filter(r=>Object.entries(q).every(([k,v])=>r[k]===v)).slice(-1),create:async r=>rows.push(r)};
 return {runtime,cache,rows,calls,args:{owner:"a",profile:{id:"p",created_by_id:"a",purchase_budget_max:85000},inputs:[input],runtime,cache}};
}
test("owner/profile-bound fresh cache avoids retrieval; explicit refresh and changed profile recheck",async()=>{
 const f=fixture();let r=await resolveWithCache(f.args);assert.equal(f.calls.read,1);assert.equal(r.results[0].cache.status,"stored");
 r=await resolveWithCache(f.args);assert.equal(f.calls.read,1);assert.equal(r.results[0].cache.status,"hit");
 await resolveWithCache({...f.args,refresh:true});assert.equal(f.calls.read,2);
 await resolveWithCache({...f.args,profile:{...f.args.profile,purchase_budget_max:60000}});assert.equal(f.calls.read,3);
});
test("expired cache and another account do not reuse evidence",async()=>{
 const f=fixture();await resolveWithCache(f.args);f.rows[0].expires_at="2000-01-01";await resolveWithCache(f.args);assert.equal(f.calls.read,2);
 await resolveWithCache({...f.args,owner:"b",profile:{...f.args.profile,created_by_id:"b"}});assert.equal(f.calls.read,3);
 await assert.rejects(resolveWithCache({...f.args,owner:"other"}),/owner/);
});
test("revoked source permission invalidates cache and never retrieves that source",async()=>{
 const f=fixture();await resolveWithCache(f.args);f.runtime.source_permissions=[];
 const r=await resolveWithCache(f.args);assert.equal(f.calls.read,1);assert.equal(r.results[0].status,"no_verified_source");assert.deepEqual(r.recommendation.finalist_urls,[]);
});
test("disabled provider never reads cache, invokes providers or stores failed evidence",async()=>{
 const f=fixture();f.args.runtime={provider:null,source_permissions:[]};f.cache.filter=()=>{throw Error("must not read cache");};
 const r=await resolveWithCache(f.args);assert.equal(f.calls.read,0);assert.equal(f.rows.length,0);assert.equal(r.results[0].status,"resolver_unavailable");
 assert.ok(Object.values(r.results[0].nullable_facts).every(v=>v===null));
});
