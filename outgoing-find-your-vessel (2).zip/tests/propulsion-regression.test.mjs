import test from 'node:test';
import assert from 'node:assert/strict';
import {enforcePropulsion} from '../base44/shared/propulsion-constraints.mjs';
import {generateRecommendations,MATCH_SCORE_CAPS} from '../base44/shared/suggest-engine.ts';
const profile={unacceptable_compromises:"No inboards, No outdrives, No project boats",purchase_budget_max:1430000,boat_size_range:"30_40",hard_max_overall_length_ft:45};
const bad=[{title:"Sabre",make:"Sabre",model:"38 Salon Express",engines:"Twin Volvo Penta IPS500 (D6 370hp)"},{title:"Back Cove",make:"Back Cove",model:"41",engines:"Single Cummins QSM11",matches:["Inboard propulsion"]}];
test('reported inboards excluded; outboards survive misleading inboard preference prose',()=>{
 const kept=enforcePropulsion([...bad,{title:"MJM",engines:"Triple Mercury Verado 400hp",gaps:["differs from preference for inboards"]}],profile);
 assert.deepEqual(kept.map(x=>x.title),["MJM"]);
});
test('unknown propulsion remains unresolved',()=>assert.equal(enforcePropulsion([{engines:"diesel"}],profile)[0].__propulsion_pending,true));
const generateWith=async(hybridMarker)=>{
 let calls=0;
 const good={title:"Outboard candidate",make:"Test",model:"Model",engines:"Twin outboards",score_breakdown:{...MATCH_SCORE_CAPS},why_suggested:"Perfect fit",summary:"Perfect",matches:["Fits everything"]};
 const client={asServiceRole:{integrations:{Core:{InvokeLLM:async()=>{calls++;return {suggestions:[...bad,good]};}}}}};
 const result=await generateRecommendations(client,{profile,plan:"market_match",tierFields:{matchPlus:new Set(),refinedMatch:new Set(),marketMatch:new Set()},manufacturerMap:{brief:"",list:[]},likedModels:[],savedBoats:[],existingSuggestions:[],isFirstPaidGeneration:false,hadContradiction:false,refresh:true,contradictionRerunCount:0,resolveHybrid:async(candidates)=>({candidates:candidates.map(x=>({...x,...hybridMarker})),catalog:[]})});
 return {calls,result};
};
test('both generation passes reject reported violations and a true conflict suppresses score',async()=>{
 const {calls,result}=await generateWith({__hybrid_conflict:true});
 assert.equal(calls,2);
 assert.equal(result.suggestions.length,1);
 assert.equal(result.suggestions[0].suitability_score,null);
 assert.deepEqual(result.suggestions[0].match.matches,[]);
 assert.doesNotMatch(result.suggestions[0].why_suggested,/Perfect/);
});
test('unconfirmed evidence keeps the score, measurements and fit reasons visible',async()=>{
 const {result}=await generateWith({__hybrid_pending:true});
 assert.equal(result.suggestions.length,1);
 const suggestion=result.suggestions[0];
 assert.equal(typeof suggestion.suitability_score,"number");
 assert.deepEqual(suggestion.match.matches,["Fits everything"]);
 assert.match(suggestion.why_suggested,/Perfect/);
 assert.doesNotMatch(suggestion.specs,/await source verification/);
});