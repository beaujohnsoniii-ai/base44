import test from "node:test";
import assert from "node:assert/strict";
import { apportionActivityWeights, toggleActivityWeightSelection } from "../src/lib/activityWeights.js";

const total = weights => Object.values(weights).reduce((sum, n) => sum + n, 0);

test("activity percentages sum to the target without negative or fractional slices", () => {
  const activities = ["Fishing", "Cruising", "Diving", "Swimming", "Liveaboard"];
  const cases = [
    {}, { Fishing: 0, Cruising: 0 },
    { Fishing: 99, Cruising: 1 },
    { Fishing: -3, Cruising: NaN },
    { Fishing: 33, Cruising: 33, Diving: 33, Swimming: 1 },
  ];
  for (const target of [0, 1, 2, 3, 4, 50, 97, 98, 99, 100]) {
    for (const current of cases) {
      const result = apportionActivityWeights(activities, current, target);
      assert.equal(total(result), target);
      assert.equal(Object.keys(result).length, activities.length);
      assert.ok(Object.values(result).every(n => Number.isInteger(n) && n >= 0 && n <= 100));
    }
  }
});

test("rounding drift is apportioned deterministically instead of producing negative shares", () => {
  assert.deepEqual(
    apportionActivityWeights(["A", "B", "C", "D"], {}, 3),
    { A: 1, B: 1, C: 1, D: 0 },
  );
  assert.deepEqual(
    apportionActivityWeights(["A", "B", "C"], { A: 33, B: 33, C: 33 }),
    { A: 34, B: 33, C: 33 },
  );
  assert.deepEqual(
    apportionActivityWeights(["Fishing", "Cruising"], { Fishing: 80, Cruising: 20 }),
    { Fishing: 80, Cruising: 20 },
  );
});

test("adding an activity preserves the buyer's relative priorities", () => {
  const next = toggleActivityWeightSelection(
    ["Fishing", "Day cruising"], { Fishing: 80, "Day cruising": 20 }, "Diving",
  );
  assert.deepEqual(next.activities, ["Fishing", "Day cruising", "Diving"]);
  assert.equal(total(next.weights), 100);
  assert.equal(next.weights.Diving, 33);
  assert.ok(next.weights.Fishing > next.weights["Day cruising"]);
});

test("removing an activity redistributes existing percentages and handles the last one", () => {
  const next = toggleActivityWeightSelection(
    ["A", "B", "C", "D"], { A: 33, B: 33, C: 33, D: 1 }, "D",
  );
  assert.deepEqual(next.activities, ["A", "B", "C"]);
  assert.equal(total(next.weights), 100);
  assert.ok(Object.values(next.weights).every(n => n >= 0));
  assert.deepEqual(
    toggleActivityWeightSelection(["A"], { A: 100 }, "A"),
    { activities: [], weights: {} },
  );
  assert.deepEqual(
    toggleActivityWeightSelection([], {}, "Fishing"),
    { activities: ["Fishing"], weights: { Fishing: 100 } },
  );
});

test("invalid percentage totals are rejected", () => {
  for (const requested of [-1, 101, 3.5]) {
    assert.throws(
      () => apportionActivityWeights(["Fishing"], {}, requested), RangeError,
    );
  }
});
