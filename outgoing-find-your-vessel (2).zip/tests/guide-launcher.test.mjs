import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { GUIDE_LAUNCHER_SIZE, readGuideViewport, fitGuideLauncher, clampGuidePosition, defaultGuidePosition, startGuideDrag, moveGuideDrag, keyboardGuidePosition } from '../src/components/guide-launcher-position.mjs';
const mobile={left:0,top:0,width:390,height:844};
const pointer=(x,y,id=1)=>({clientX:x,clientY:y,pointerId:id});
test('compass has a 96px touch target and accessible open/close/move/reset instructions',()=>{
 assert.equal(GUIDE_LAUNCHER_SIZE,96);const s=fs.readFileSync('src/components/GuideLauncher.jsx','utf8');
 assert.match(s,/className="sh-guide-launcher__rose"/);assert.match(s,/aria-label=\{open \? "Close Guide" : "Ask Guide"\}/);
 assert.match(s,/aria-keyshortcuts="Alt\+ArrowUp Alt\+ArrowDown Alt\+ArrowLeft Alt\+ArrowRight Home"/);
 for(const event of ['onPointerDown','onPointerMove','onPointerUp','onPointerCancel','onLostPointerCapture'])assert(s.includes(event));
 assert.match(s,/suppressClick.current && event.detail !== 0/);assert.match(s,/suppressClick.current = false;\n    onToggle\(\)/);
 assert.match(s,/setPointerCapture/);assert.match(s,/releasePointerCapture/);
});
test('default position and all boundaries stay within desktop/mobile viewport',()=>{
 for(const v of [mobile,{left:0,top:0,width:1440,height:900}]){
  const size=fitGuideLauncher(v);for(const p of [defaultGuidePosition(v),clampGuidePosition({x:-999,y:-999},v),clampGuidePosition({x:9999,y:9999},v)]){
   assert(p.x>=v.left&&p.y>=v.top);assert(p.x+size<=v.left+v.width);assert(p.y+size<=v.top+v.height);
  }
 }
});
test('short movements remain taps and six pixel movement becomes a drag',()=>{
 const d=startGuideDrag(pointer(200,200),{x:100,y:100});
 assert.equal(moveGuideDrag(d,pointer(203,204),mobile).dragging,false);
 const moved=moveGuideDrag(d,pointer(206,200),mobile);assert.equal(moved.dragging,true);assert.deepEqual(moved.position,{x:106,y:100});
 assert.equal(moveGuideDrag(moved,pointer(200,200),mobile).dragging,true);
});
test('unrelated pointers cannot move the launcher',()=>{
 const d=startGuideDrag(pointer(100,100),{x:100,y:100});assert.equal(moveGuideDrag(d,pointer(300,300,2),mobile),d);
});
test('large drag is clamped, resize can reclaim an offscreen position',()=>{
 const d=startGuideDrag(pointer(0,0),{x:100,y:100});assert.deepEqual(moveGuideDrag(d,pointer(9999,9999),mobile).position,{x:286,y:740});
 assert.deepEqual(clampGuidePosition({x:1000,y:800},{left:0,top:0,width:320,height:400}),{x:216,y:296});
});
test('keyboard arrows move in bounded steps and Home resets',()=>{
 assert.deepEqual(keyboardGuidePosition({x:8,y:8},'ArrowLeft',mobile),{x:8,y:8});
 assert.deepEqual(keyboardGuidePosition({x:8,y:8},'ArrowDown',mobile),{x:8,y:24});
 assert.deepEqual(keyboardGuidePosition({x:8,y:8},'Home',mobile),defaultGuidePosition(mobile));
});
test('visual viewport offsets and reduced mobile space stay reachable',()=>{
 const v=readGuideViewport({innerWidth:390,innerHeight:844,visualViewport:{offsetLeft:70,offsetTop:80,width:195,height:260}});
 const p=clampGuidePosition({x:0,y:9999},v);assert.deepEqual(p,{x:78,y:236});
 const small={left:0,top:0,width:80,height:90};assert.equal(fitGuideLauncher(small),64);
 assert.deepEqual(defaultGuidePosition(small,64),{x:8,y:8});
});
test('launcher uses the nautical compass artwork and has no animation or external asset',()=>{
 const s=fs.readFileSync('src/components/GuideLauncher.jsx','utf8'),css=fs.readFileSync('src/components/guide-launcher.css','utf8');
 assert.match(s,/fill="#071d32"/);assert.match(s,/stroke="#bda477"/);assert.match(s,/stroke="#f4efe3"/);assert.match(s,/<circle cx="56" cy="56" r="25"/);
 assert.match(css,/touch-action: none/);assert.match(css,/z-index: 60/);
 assert.doesNotMatch(s,/https?:|base44|fetch\(|agents\./);assert.doesNotMatch(css,/animation:|transition:/);
});
