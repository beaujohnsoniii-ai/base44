import test from "node:test";
import assert from "node:assert/strict";
import { loadCompareCandidates, saveMatchCandidate } from "../src/lib/matchCompareHandoff.js";
import { selectionFor } from "../src/lib/compareCandidates.js";

function mockClient(initialSaved = [], initialSuggestions = []) {
  const saved = initialSaved.map(item => ({ ...item }));
  const suggestions = initialSuggestions.map(item => ({ ...item }));
  let nextId = 1;
  let writes = 0;
  const entity = (rows) => ({
    async filter(filter, _order, limit, skip = 0) {
      return rows.filter(row => Object.entries(filter).every(([field, value]) => row[field] === value)).slice(skip, skip + limit);
    },
    async create(data) {
      writes++;
      const row = { ...data, id: "saved-" + nextId++, created_by_id: "buyer" };
      rows.push(row);
      return { ...row };
    },
    async update(id, patch) {
      writes++;
      const row = rows.find(x => x.id === id);
      if (!row) throw new Error("Missing saved record");
      Object.assign(row, patch);
      return { ...row };
    },
  });
  return { client: { entities: { SavedBoat: entity(saved), SuggestedBoat: entity(suggestions) } }, saved, get writes() { return writes; } };
}

test("three liked MATCH models become three durable Compare candidates and default selection", async () => {
  const suggestions = ["Parker", "Grady-White", "Sailfish"].map((make, index) => ({
    id: "result-" + index, created_by_id: "buyer", make, model: "25", year: 2025, liked: true,
    link: "https://example.org/" + index, match: { summary: "Candidate " + index },
  }));
  const fixture = mockClient([], suggestions);
  const cards = await loadCompareCandidates(fixture.client, "buyer");
  assert.equal(cards.length, 3);
  assert.deepEqual(selectionFor(cards), cards.map(b => b.id));
  cards.forEach((boat, index) => {
    assert.equal(boat.original_match_url, "https://example.org/" + index);
    assert.equal(boat.url, "");
    assert.equal(boat.source_suggestion_id, "result-" + index);
    assert.equal(boat.asking_price, null);
    assert.equal(boat.match.summary, "Candidate " + index);
  });
  // Compare should not multiply cards or incur needless writes on every view.
  assert.equal((await loadCompareCandidates(fixture.client, "buyer")).length, 3);
  assert.equal(fixture.writes, 3);
});

test("MATCH refresh reuses saved candidate without overwriting buyer pasted listing links", async () => {
  const fixture = mockClient([{
    id: "saved-older", created_by_id: "buyer", make: "Parker", model: "2520",
    year: "2025", source_suggestion_id: "older-result", original_match_url: "https://example.com/original",
    listing_urls: ["https://example.com/buyer-listing"], notes: "Needs survey",
  }]);
  const newResult = { id: "new-result", make: "Parker", model: "2520", year: 2025, link: "https://example.com/new" };
  const saved = await saveMatchCandidate(fixture.client, newResult, "buyer");
  assert.equal(saved.id, "saved-older");
  assert.equal(fixture.saved.length, 1);
  assert.equal(saved.original_match_url, "https://example.com/original");
  assert.deepEqual(saved.listing_urls, ["https://example.com/buyer-listing"]);
  assert.equal(saved.notes, "Needs survey");
});

test("manual listings remain separate from MATCH models and unrelated/test Likes are ignored", async () => {
  const fixture = mockClient([
    { id: "manual", created_by_id: "buyer", make: "Parker", model: "2520",
      year: 2025, url: "https://example.com/manual-listing" },
  ], [
    { id: "liked", created_by_id: "buyer", make: "Parker", model: "2520",
      year: 2025, liked: true },
    { id: "not-liked", created_by_id: "buyer", make: "Sailfish", model: "242", liked: false },
    { id: "test-liked", created_by_id: "buyer", make: "Test", model: "Fake",
      liked: true, test_profile_id: "qa_fake" },
    { id: "other-owner", created_by_id: "someone-else", make: "Another", model: "28", liked: true },
  ]);
  const cards = await loadCompareCandidates(fixture.client, "buyer");
  assert.equal(cards.length, 2);
  assert.equal(cards.find(b => b.id === "manual").url, "https://example.com/manual-listing");
  assert.equal(cards.filter(b => b.make === "Parker").length, 2);
  assert.ok(cards.some(b => b.source_suggestion_id === "liked"));
});

test("different model years preserve separate saved MATCH candidates", async () => {
  const fixture = mockClient([{
    id: "saved-old", created_by_id: "buyer", make: "Parker", model: "2520", year: 2021,
    source_suggestion_id: "old", original_match_url: "https://example.com/2021",
  }]);
  await saveMatchCandidate(fixture.client, {
    id: "new", make: "Parker", model: "2520", year: 2025, link: "https://example.com/2025",
  }, "buyer");
  assert.equal(fixture.saved.length, 2);
  assert.notEqual(fixture.saved[0].original_match_url, fixture.saved[1].original_match_url);
});
