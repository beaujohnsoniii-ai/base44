import test from "node:test";
import assert from "node:assert/strict";
import { researchJobActivity, stagedEvidenceSummary, safeResearchSourceUrl } from "../src/lib/researchReview.js";

test("2025 Parker staging displays source year, checked fields and publication blockers", () => {
  const record = {
    facts: { claims: [
      { field: "beam_ft", source_url: "https://www.parkerboats.com/brochure.pdf", value: 9.5 },
      { field: "hull_draft_ft", source_url: "https://www.parkerboats.com/brochure.pdf", value: 17/12 },
      { field: "speculative_price", value: 200000 },
    ] },
    verification_notes: JSON.stringify({
      status: "OFFICIAL PAGE CHECKED; STAGED ONLY",
      document_model_year: 2025,
      document_date: "2024-08-30",
      source_page: "35 printed; PDF 34",
      checks: ["2025 XLD has 21° deadrise.", "Do not merge 2021 XL into the 2025 XLD variant."],
      requires: "Check generation identity and installed-boat dimensions before publishing.",
    }),
  };
  const x = stagedEvidenceSummary(record);
  assert.equal(x.documentedClaims, 2);
  assert.match(x.sourceContext, /brochure model year 2025/);
  assert.match(x.sourceContext, /2024-08-30/);
  assert.match(x.sourceContext, /source page 35 printed/);
  assert.equal(x.checks.length, 2);
  assert.match(x.checks[1], /Do not merge/);
  assert.match(x.action, /before publishing/);
  assert.deepEqual(x.issues, []);
});

test("legacy source-review issues remain readable without a raw JSON dump", () => {
  const x = stagedEvidenceSummary({
    verification_notes: JSON.stringify({
      document_date: "2021-11-11",
      issues: ["Hull draft does not prove engine-down draft.", "Generation years are unknown."],
      requires: "Review original source PDF and establish year applicability.",
    }),
  });
  assert.equal(x.documentedClaims, 0);
  assert.equal(x.issues.length, 2);
  assert.match(x.sourceContext, /2021-11-11/);
  assert.match(x.action, /year applicability/);
});

test("unparseable notes fail legibly and do not dump an unbounded object into the UI", () => {
  const bad = stagedEvidenceSummary({ verification_notes: '{"raw": "very long broken payload"' });
  assert.deepEqual(bad.issues, ["Saved review notes need format repair; consult the staging record."]);
  const plain = stagedEvidenceSummary({ verification_notes: "Needs manufacturer confirmation" });
  assert.deepEqual(plain.issues, ["Needs manufacturer confirmation"]);
});

test("research activity surfaces a variant conflict but not misleading verification", () => {
  const detail = researchJobActivity({
    status: "needs_review",
    records_staged: 1,
    records_verified: 0,
    calls: 0,
    last_message: JSON.stringify({ variant_conflict: "2021 XL != 2025 XLD" }),
  });
  assert.match(detail, /1 staged/);
  assert.match(detail, /0 verified/);
  assert.match(detail, /Model-variant conflict/);
  assert.match(detail, /review pending/);
});

test("research source links allow public HTTPS documents but reject credential-bearing and private targets", () => {
  assert.equal(safeResearchSourceUrl("https://www.parkerboats.com/2025.pdf"), "https://www.parkerboats.com/2025.pdf");
  assert.equal(safeResearchSourceUrl("https://parkerboats.com/brochure.pdf?page=35"), "https://parkerboats.com/brochure.pdf?page=35");
  for (const url of [
    "http://www.parkerboats.com/2025.pdf", "https://localhost/a",
    "https://127.0.0.1/a", "https://[::1]/a", "https://printer.internal/a",
    "https://name:pass@example.com/a", "https://www.parkerboats.com:8443/a",
    "https://public.example.com/doc?api_key=secret",
    "https://www.parkerboats.com/doc?X-Amz-Signature=secret",
    "https://www.parkerboats.com/doc?access_token=secret",
    "file:///etc/passwd", "https://www.parkerboats.com".padEnd(5000, "x"),
  ]) {
    assert.equal(safeResearchSourceUrl(url), null, url.slice(0, 120));
  }
});

test("staging provenance counts exclude unsafe reference URLs without changing verification state", () => {
  const record = { status: "staged", facts: { claims: [
    { field: "beam_ft", source_url: "https://www.parkerboats.com/brochure.pdf" },
    { field: "draft_ft", source_url: "https://www.parkerboats.com/brochure.pdf?token=secret" },
    { field: "fuel_capacity_gal", source_url: "https://private.local/brochure.pdf" },
    { field: "price", source_url: "https://www.parkerboats.com:8443/brochure.pdf" },
    { field: "", source_url: "https://www.parkerboats.com/brochure.pdf" },
  ] } };
  assert.equal(stagedEvidenceSummary(record).documentedClaims, 1);
  assert.equal(record.status, "staged");
});
