// Synthetic fixtures only. No network access, live provider calls, or real private URIs.
import { webcrypto } from 'node:crypto';
import { deflateSync } from 'node:zlib';
import { newListing } from '../base44/shared/listing-intake.mjs';
import { profileInputFingerprint } from '../base44/shared/profile-input-fingerprint.mjs';
import { loadIntakeContext } from '../base44/shared/listing-intake-service.mjs';

if (!globalThis.crypto) Object.defineProperty(globalThis, 'crypto', { value: webcrypto });
export const NOW = '2026-10-24T12:00:00.000Z';
export const OWNER = Object.freeze({ id: 'owner_fixture_01', app_id: 'app_fixture_01', role: 'admin' });
export const POLICY = Object.freeze({ enabled: true, integrations_enabled: true, owner_id: OWNER.id, app_id: OWNER.app_id, record_id: 'intake_fixture_01' });
export const MODEL = Object.freeze({ source_type: 'saved', source_id: 'saved_model_001', model_key: 'bayliner:vr5:2022', make: 'Bayliner', model: 'VR5', year: 2022, title: 'Bayliner VR5' });
export const LISTING_ID = 'listing_fixture_01';
export const UPLOAD_ID = 'upload_fixture_01';
export const clone = value => structuredClone(value);
export const statusIs = status => error => error?.status === status;
export const output = (fields = {}, evidence = []) => ({ status: 'success', output: { features: [], unverified_claims: [], ...fields, evidence } });
export const source = (id = UPLOAD_ID, extra = {}) => ({ id, name: `${id}.png`, uploaded_at: NOW, ...extra });
export function candidate(field, value, sourceId = UPLOAD_ID, extra = {}) {
  return { id: `${sourceId}:${field}`, field, value, quote: `${field}: ${value}`, unit: '', basis: 'unspecified', source_id: sourceId, source_name: `${sourceId}.png`, uploaded_at: NOW, provenance: 'user_supplied_screenshot', verification: 'unverified_seller_claim', ...extra };
}
export function completedUpload(id = UPLOAD_ID, candidates = [candidate('asking_price', 42900, id, { quote: '$42,900', unit: '' })], extra = {}) {
  return { ...source(id), status: 'complete', sha256: 'a'.repeat(64), extraction: { candidates, features: [], claims: [], rejected: [] }, ...extra };
}
export function listingData() { return newListing({ listings: [], operations: [] }, MODEL, LISTING_ID, 'https://seller.example/boats/2022-bayliner-vr5-123', NOW); }
export function completeData() { const data = listingData(); data.listings[0].uploads.push(completedUpload()); return data; }

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) { crc ^= byte; for (let n = 0; n < 8; n++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0); }
  return (crc ^ 0xffffffff) >>> 0;
}
function pngChunk(type, bytes) {
  const payload = Buffer.concat([Buffer.from(type), bytes]), header = Buffer.alloc(4), checksum = Buffer.alloc(4);
  header.writeUInt32BE(bytes.length); checksum.writeUInt32BE(crc32(payload));
  return Buffer.concat([header, payload, checksum]);
}
export function pngBytes(width = 1, height = 1, variant = 0) {
  const header = Buffer.alloc(13); header.writeUInt32BE(width, 0); header.writeUInt32BE(height, 4); header[8] = 8; header[9] = 6;
  // A complete 1x1 PNG. Larger declared dimensions are used solely for cap rejection.
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]), pngChunk('IHDR', header), pngChunk('IDAT', deflateSync(Buffer.from([0, variant, 0, 0, 255]))), pngChunk('IEND', Buffer.alloc(0))]);
}
export function screenshot({ bytes = pngBytes(), type = 'image/png', name = 'listing.png', size = bytes.length } = {}) {
  const copy = Uint8Array.from(bytes);
  return { type, name, size, async arrayBuffer() { return copy.buffer.slice(0); } };
}
export function deferred() { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; }

export async function harness({ data = listingData(), revision = 1, profile: profileOverride = {}, record: recordOverride = {} } = {}) {
  const profile = { id: 'profile_fixture_01', created_by_id: OWNER.id, budget: 50000, match_question_tier: 'standard', match_context_id: 'context_fixture_01', use_past_likes: false, ...profileOverride };
  const fingerprint = await profileInputFingerprint(profile);
  const state = { profile, record: { id: POLICY.record_id, owner_id: OWNER.id, buyer_profile_id: profile.id, profile_fingerprint: fingerprint, stage_fixture: true, revision, data: clone(data), ...recordOverride }, saved: { ...MODEL, id: MODEL.source_id, created_by_id: OWNER.id }, suggested: { ...MODEL, id: 'suggested_model_01', created_by_id: OWNER.id, buyer_profile_id: profile.id, profile_input_fingerprint: fingerprint } };
  const calls = { profileReads: 0, recordReads: 0, commits: [], uploads: [], signs: [], extracts: [], forbidden: [] };
  const hooks = {};
  const forbidden = name => () => { calls.forbidden.push(name); throw new Error(`Forbidden fixture mutation: ${name}`); };
  const readonly = (name, methods) => new Proxy(methods, { get(target, prop) { return prop in target ? target[prop] : forbidden(`${name}.${String(prop)}`); } });
  const recordApi = {
    async get(recordId) { calls.recordReads++; if (hooks.get) await hooks.get(recordId); return clone(state.record); },
    async updateMany(where, patch) {
      calls.commits.push({ where: clone(where), patch: clone(patch) });
      if (hooks.beforeCommit) await hooks.beforeCommit(where, patch);
      if (!Object.entries(where).every(([key, value]) => state.record[key] === value)) return { updated: 0 };
      Object.assign(state.record, clone(patch.$set));
      if (hooks.afterCommit) await hooks.afterCommit(where, patch);
      return { updated: 1 };
    },
  };
  const core = {
    async CreateFileSignedUrl(request) { calls.signs.push(clone(request)); return hooks.sign ? hooks.sign(request) : { signed_url: 'https://signed.invalid/synthetic-fixture-only' }; },
    async ExtractDataFromUploadedFile(request) { calls.extracts.push(clone(request)); return hooks.extract ? hooks.extract(request) : output({ asking_price: 42900 }, [{ field: 'asking_price', quote: '$42,900' }]); },
  };
  const client = {
    entities: {
      BuyerProfile: readonly('BuyerProfile', { async filter() { calls.profileReads++; if (hooks.profileRead) await hooks.profileRead(); return state.profile ? [clone(state.profile)] : []; } }),
      User: readonly('User', {}),
      SavedBoat: readonly('SavedBoat', { async get() { return clone(state.saved); } }),
      SuggestedBoat: readonly('SuggestedBoat', { async get() { return clone(state.suggested); } }),
    },
    integrations: { Core: { async UploadPrivateFile(request) { calls.uploads.push(request); return hooks.upload ? hooks.upload(request) : { file_uri: `mp/private/${POLICY.app_id}/synthetic-upload.png` }; } } },
    asServiceRole: { entities: { ListingIntake: recordApi, BuyerProfile: readonly('ServiceBuyerProfile', {}), User: readonly('ServiceUser', {}) }, integrations: { Core: core } },
  };
  return { state, calls, hooks, client, policy: clone(POLICY), user: clone(OWNER), async context() { return loadIntakeContext(client, clone(OWNER), clone(POLICY)); } };
}
export function request(action, extra = {}) { return { action, operation_id: 'operation_fixture_01', revision: 1, listing_id: LISTING_ID, ...extra }; }
export function uploadedData() {
  const data = listingData();
  data.listings[0].uploads.push({ ...source(), status: 'uploaded', sha256: 'a'.repeat(64), file_uri: `mp/private/${POLICY.app_id}/synthetic-source.png` });
  return data;
}
