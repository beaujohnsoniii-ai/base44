import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
const css=readFileSync("src/pages/Home.css","utf8");
test("desktop trim preserves original image geometry and has no exposed bottom across viewport widths",()=>{
 for(const viewport of [761,800,1024,1100,1101,1280,1440,1920,2560]){
  for(const scrollbar of [0,15]){
   const width=viewport-scrollbar;
   const oldH=Math.min(1000,Math.max(viewport<=1100?670:720,viewport*.555));
   const scale=Math.max(width/1578,oldH/996);
   const imageH=996*scale;
   const originalY=.525*(oldH-imageH)-140;
   const gap=Math.max(0,140-(imageH-oldH)*.475);
   const extraTrim=Math.min(145,Math.max(60,viewport*.076));
   const newH=oldH-gap-extraTrim;
   assert.ok(Math.abs(newH-(Math.min(oldH,originalY+imageH)-extraTrim))<.001);
   assert.ok(newH>0 && newH<=oldH,"cropped scene must remain visible");
  }
 }
});
test("CSS keeps upward shift and original frame; mobile rules and brand asset unchanged",()=>{
 assert.match(css,/background-position:center calc\(52\.5% - 140px\)/);
 assert.match(css,/background-size:cover/);
 assert.match(css,/container-type:inline-size/);
 assert.match(css,/63\.1178707224cqw/);
 assert.match(css,/height:calc\(var\(--scene-frame\) - var\(--bottom-gap\) - clamp\(60px,7\.6vw,145px\)\)/);
 assert.match(css,/\.coastal-scene:before\{bottom:auto;height:var\(--scene-frame\)\}/);
 assert.match(css,/\.coastal-intro\{top:calc\(var\(--scene-frame\) \* \.025\)\}/);
 assert.match(css,/background-size:auto 590px;background-position:38% top/);
 assert.match(css,/\.coastal-services\{position:relative;inset:auto;width:auto;margin-top:275px/);
 assert.ok(!css.includes("clip-path"));
});
