import test from 'node:test';
import assert from 'node:assert/strict';
import {chooseDatasetCandidates,groundCandidateIdentities,loadDatasetCandidates} from '../base44/shared/dataset-candidates.mjs';
const row=(manufacturer,model,LOA=23)=>({manufacturer,model,workbook_version:1,raw_fields:{LOA,Type:'Bay', 'Primary Manufacturer Source':'https://example.com/specs'}});
test('rejects unmatched reported models without guessing replacements',()=>{
 const rows=[row('Sea Pro','230 Bay'),row('Southport','27 FE'),row('Young Brothers','30')];
 assert.deepEqual(groundCandidateIdentities([{make:'Sea Pro',model:'239 Deep V Bay'},{make:'Southport',model:'23 FE'},{make:'Young Brothers',model:'23 Bay'}],rows),[]);
 assert.equal(groundCandidateIdentities([{make:'Sea Pro',model:'230 Bay',year:2023}],rows)[0].model,'230 Bay');
});
test('selection requires source and retains breadth within bounded prompt',()=>{
 const rows=Array.from({length:100},(_,i)=>row('Builder '+Math.floor(i/10),'Bay '+i));
 rows.push({manufacturer:'Unsupported',model:'23',raw_fields:{LOA:23}});
 const selected=chooseDatasetCandidates(rows,{boat_size_range:'18_24',hard_max_draft_ft:1.2,activities:['Fishing']},20);
 assert.equal(selected.length,20);
 assert.ok(!selected.some(r=>r.manufacturer==='Unsupported'));
 for(const make of new Set(selected.map(r=>r.manufacturer)))assert.ok(selected.filter(r=>r.manufacturer===make).length<=5);
});
test('signed workbook source links are not accepted as public model evidence',()=>{
 const publicRow=row('Public','23 Bay');
 const signedRow=row('Signed','24 Bay');
 signedRow.raw_fields['Primary Manufacturer Source']='https://example.com/specs?' + ['access','token'].join('_') + '=dummy';
 const chosen=chooseDatasetCandidates([signedRow,publicRow],{boat_size_range:'18_24'});
 assert.deepEqual(chosen.map(r=>r.manufacturer),['Public']);
});
test('dataset pagination includes later pages',async()=>{
 const calls=[];
 const entity={list:async(sort,limit,skip)=>{calls.push(skip);return skip===0?Array.from({length:500},(_,i)=>row('Big','Model '+i,40)):[row('Small','23 Bay')];}};
 const selected=await loadDatasetCandidates(entity,{boat_size_range:'18_24'});
 assert.deepEqual(calls,[0,500]);
 assert.equal(selected[0].manufacturer,'Small');
});
