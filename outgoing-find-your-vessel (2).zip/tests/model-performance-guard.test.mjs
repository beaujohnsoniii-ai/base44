import test from "node:test";
import assert from "node:assert/strict";
import { withholdUnverifiedModelPerformance } from "../base44/shared/model-performance-guard.ts";
import { generateRecommendations, MATCH_SCORE_CAPS } from "../base44/shared/suggest-engine.ts";

test("model performance guard preserves layout and dimensional facts", () => {
  const output = withholdUnverifiedModelPerformance("Enclosed cabin and two berths. LOA is 25.5 ft. Cruises at 32 knots.");
  assert.equal(output.withheld, true);
  assert.match(output.text, /Enclosed cabin and two berths/);
  assert.match(output.text, /25\.5 ft/);
  assert.doesNotMatch(output.text, /32 knots/);
  assert.match(output.text, /independent published test evidence/);
});

test("a claimed publication without independent proof is not sufficient at model MATCH stage", () => {
  const claim = "Published factory test with twin 300 hp reports 1.8 MPG.";
  const result = withholdUnverifiedModelPerformance(claim);
  assert.equal(result.withheld, true);
  assert.doesNotMatch(result.text, /1\.8 MPG/i);
});

test("engine horsepower and fuel capacity are not mistaken for speed or efficiency", () => {
  const spec = "Twin 300 hp outboards. Fuel capacity 180 gallons. Draft 20 inches.";
  assert.deepEqual(withholdUnverifiedModelPerformance(spec), { text: spec, withheld: false });
});

test("model price bands and preferred length ranges are not mistaken for cruising range", () => {
  const facts = "Used-model price range $65,000–$90,000. Preferred length range 25–30 ft. Beam 8.5 ft.";
  assert.deepEqual(withholdUnverifiedModelPerformance(facts), { text: facts, withheld: false });

  const mixed = withholdUnverifiedModelPerformance("Price range $65,000–$90,000. Size range 25–30 ft. Cruising range 200 miles.");
  assert.equal(mixed.withheld, true);
  assert.match(mixed.text, /Price range \$65,000–\$90,000/);
  assert.match(mixed.text, /Size range 25–30 ft/);
  assert.doesNotMatch(mixed.text, /200 miles/);

  for (const claim of ["Range 300 miles.", "Fuel range about 275.", "Cruising range: 180."]) {
    assert.equal(withholdUnverifiedModelPerformance(claim).withheld, true, claim);
  }
});

test("buyer-facing MATCH records withhold LLM-only performance across all display fields", async () => {
  const fullScore = Object.fromEntries(Object.keys(MATCH_SCORE_CAPS).map(key => [key, 0]));
  const raw = {
    title: "Test Builder 31", make: "Test Builder", model: "31", year: 2023,
    length: "31 ft", engines: "Twin 250 hp outboards; 35 mph cruise",
    fuel: "180 gal", why_suggested: "Enclosed cabin for family. Cruises at 32 knots.",
    summary: "Two berths, 1.8 MPG at cruise.",
    matches: ["Dedicated berths", "Range 300 nmi under ideal conditions"],
    gaps: ["Will not reach 45 mph with standard power"],
    score_breakdown: fullScore, verification_required: [],
  };
  const client = { asServiceRole: { integrations: { Core: {
    InvokeLLM: async () => ({ suggestions: [raw], contradiction: { flagged: true, conflicts: [], explanation: "", closest_alternatives: [] } }),
  } } } };
  const result = await generateRecommendations(client, {
    profile: { vessel_class: "power", boat_size_range: "30_35" },
    plan: "free",
    tierFields: { matchPlus: new Set(), refinedMatch: new Set(), marketMatch: new Set() },
    manufacturerMap: { brief: "", list: [] },
    likedModels: [], savedBoats: [], existingSuggestions: [],
    isFirstPaidGeneration: false, hadContradiction: false, refresh: false, contradictionRerunCount: 0,
  });
  assert.equal(result.suggestions.length, 1);
  const s = result.suggestions[0];
  const display = [s.engines, s.why_suggested, s.match.summary, ...s.match.matches, ...s.match.gaps].join(" | ");
  assert.doesNotMatch(display, /35 mph|32 knots|1\.8 MPG|300 nmi|45 mph/i);
  assert.match(display, /Enclosed cabin for family/);
  assert.match(display, /180 gal/);
  assert.match(display, /Dedicated berths/);
  assert.ok(s.verification_required.some(flag => /numerical speed, range or fuel-consumption claims were withheld/i.test(flag)));
});

test("model MATCH withholds long-form and hyphenated numerical performance claims", () => {
  const claims = [
    "Burns 22 gallons per hour when cruising.",
    "Returns 2.2 nautical miles per gallon in a manufacturer test.",
    "Runs at 30 miles per hour in smooth water.",
    "Has a 450-mile range.",
    "Will reach a 34-knot cruise.",
  ];
  for (const claim of claims) {
    const result = withholdUnverifiedModelPerformance(claim);
    assert.equal(result.withheld, true, `Expected unsourced performance to be removed: ${claim}`);
    assert.notEqual(result.text, claim);
    assert.match(result.text, /independent published test evidence/);
  }
  const stableFacts = "Fuel capacity 180 gallons. Twin 300 hp outboards. Bridge clearance 9 ft.";
  assert.deepEqual(withholdUnverifiedModelPerformance(stableFacts), { text: stableFacts, withheld: false });
});
