import test from "node:test";
import assert from "node:assert/strict";
import { formatModelPriceGuidance } from "../src/lib/modelPriceGuidance.js";

test("model price range retains year/market context and always says verify", () => {
  const label = formatModelPriceGuidance({
    asking_price: 45000,
    price_range_min: 75000,
    price_range_max: 135000,
    price_range_context: "2019–2023 examples, US used market",
  });
  assert.match(label, /\$75,000–\$135,000/);
  assert.match(label, /2019–2023 examples, US used market/);
  assert.match(label, /verify current market/);
  assert.doesNotMatch(label, /45,000/);
});

test("missing model generation/year/market context is clearly flagged", () => {
  const label = formatModelPriceGuidance({ price_range_min: 90000, price_range_max: 130000 });
  assert.match(label, /generation\/year\/market context not provided/);
  assert.match(label, /verify current market/);
});

test("missing or invalid model range never falls back to listing asking price", () => {
  for (const input of [
    null, {}, { asking_price: 85000 },
    { price_range_min: null, price_range_max: 100000 },
    { price_range_min: 110000, price_range_max: 100000 },
  ]) {
    assert.equal(formatModelPriceGuidance(input), "model pricing requires verification");
  }
});
