import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
const React={createElement:(type,props,...children)=>({type,props:{...props,children}})};
function component(name,deps={},hooks={}){
 const js=ts.transpileModule(fs.readFileSync("src/components/home-v2/"+name+".jsx","utf8"),{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const exports={};new Function("exports","require",js)(exports,key=>key==="react"?{__esModule:true,default:React,...hooks}:key in deps?deps[key]:{__esModule:true,default:"Icon"});return exports;
}
function walk(n){if(!n)return [];if(Array.isArray(n))return n.flatMap(walk);if(typeof n!=="object")return [];if(typeof n.type==="function")return walk(n.type(n.props));return [n,...walk(n.props?.children)];}
test("package premise has only the left lift photo, no caption, sandbar or pillars",()=>{
 const nodes=walk(component("Premise").default()),imgs=nodes.filter(n=>n.type==="img");
 assert.equal(imgs.length,1);assert.equal(imgs[0].props.src,"/site-v2/assets/img/water_icw.jpg");
 assert.ok(nodes.some(n=>n.props?.className==="premise__lead"));assert.equal(nodes.filter(n=>n.type==="figcaption").length,0);
 assert.equal(nodes.filter(n=>n.type==="h3").length,0);
 assert.equal(nodes.filter(n=>n.props?.className==="kicker premise__home-waters").length,0);
 assert.equal(nodes.filter(n=>n.props?.className==="pillars").length,0);
 assert.equal(nodes.filter(n=>n.type==="article").length,0);
});
test("lower three-tile waters rail uses supplied aerial and responds to pointer and keyboard focus without chips",()=>{
 let active=0;const mod=component("Waters",{}, {useState:()=>[active,v=>active=v]});
 const render=()=>walk(mod.default()),cards=()=>render().filter(n=>n.type==="article");
 assert.deepEqual(mod.HOME_WATER_CARDS.map(c=>c.title),["Sandbars","Inshore","Offshore"]);
 assert.equal(mod.HOME_WATER_CARDS[0].img,"sandbar_featured.jpg");assert.match(mod.HOME_WATER_CARDS[0].body,/Shallow draft/);
 assert.match(mod.HOME_WATER_CARDS[1].body,/Creeks, flats/);assert.match(mod.HOME_WATER_CARDS[2].body,/open water/);
 assert.equal(cards().length,3);assert.equal(cards()[0].props["aria-expanded"],true);
 cards()[1].props.onMouseEnter();assert.equal(cards()[1].props["aria-expanded"],true);
 cards()[2].props.onFocus();assert.equal(cards()[2].props["aria-expanded"],true);
 render().find(n=>n.props?.className==="waters__rail has-active").props.onMouseLeave();assert.equal(cards()[0].props["aria-expanded"],true);
 for(const c of cards()){const children=walk(c);assert.equal(children.filter(n=>n.type==="p").length,1);assert.ok(!children.some(n=>["button","a","ul"].includes(n.type)));assert.equal(c.props.tabIndex,0);}
 const css=fs.readFileSync("public/site-v2/assets/css/site.css","utf8");
 assert.match(css,/\.waters__rail:has\(\.wtile:nth-child\(1\)\.is-active\)\{grid-template-columns:1\.85fr/);
 assert.doesNotMatch(css,/\.wtile\.is-active\s+\.waters__rail:has/);
});
test("homepage uses the supplied final stack with the storm backdrop on HowItWorks while leaving questionnaire functionality intact",()=>{
 const home=fs.readFileSync("src/pages/Home.jsx","utf8");
 const order=["Hero","Premise","HowItWorks","Waters","StatementBand"];
 const positions=order.map(name=>{const index=home.indexOf("<"+name+" ");assert.ok(index>=0,name);return index;});assert.deepEqual(positions,[...positions].sort((a,b)=>a-b));
 assert.doesNotMatch(home,/import (?:Services|HeadingQuiz|PromiseSection|Journal) from|<(?:Services|HeadingQuiz|PromiseSection|Journal)\b/);
 assert.equal((home.match(/<Waters \/>/g)||[]).length,1);
 const routes=fs.readFileSync("src/App.jsx","utf8");assert.match(routes,/path="\/questionnaire"/);
 const footer=fs.readFileSync("src/components/home-v2/SiteFooter.jsx","utf8");assert.doesNotMatch(footer,/#quiz|#services|#promise|#journal/);
 assert.match(fs.readFileSync("src/components/home-v2/HowItWorks.jsx","utf8"),/journal_storm.jpg/);
});
test("dashboard listing entry points use the existing Compare flow and never claim an import already succeeded",()=>{
 const helm=fs.readFileSync("src/pages/Dashboard.jsx","utf8");assert.match(helm,/Found a listing\?/);assert.match(helm,/navigate\("\/compare"\)/);
});