import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import { copyListingSearchLink } from '../src/lib/listingSearchFallback.js';
import * as evidence from '../base44/shared/listing-intake.mjs';
import * as links from '../src/lib/matchResultLink.js';

const url='https://www.google.com/search?q=Blackjack%20224%20for%20sale';
test('copy waits for clipboard confirmation and copies only the exact search URL',async()=>{
 let finish,received,settled=false;
 const pending=copyListingSearchLink(url,{writeText:value=>{received=value;return new Promise(resolve=>finish=resolve);}}).then(result=>{settled=true;return result;});
 assert.equal(received,url);assert.equal(settled,false);finish();assert.equal(await pending,true);
});
test('unavailable or rejected clipboard never reports success',async()=>{
 assert.equal(await copyListingSearchLink(url,null),false);
 assert.equal(await copyListingSearchLink(url,{}),false);
 assert.equal(await copyListingSearchLink(url,{writeText:async()=>{throw Error('blocked');}}),false);
});

const compile=path=>ts.transpileModule(fs.readFileSync(path,'utf8'),{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const utils={};new Function('exports','require','window',compile('src/lib/utils.js'))(utils,name=>name==='./matchResultLink'?links:name==='clsx'?{clsx:()=>''}:{twMerge:()=>''},{});
let ctx,requestCount=0;
const react={createElement:(type,props,...children)=>({type,props:{...props,children:children.flat(Infinity)}}),
 useState:initial=>{const i=ctx.si++;if(!(i in ctx.states))ctx.states[i]=initial;return[ctx.states[i],value=>ctx.states[i]=value];},
 useRef:initial=>{const i=ctx.ri++;return ctx.refs[i]??(ctx.refs[i]={current:initial});},
 useEffect:()=>{}};
const module={};new Function('exports','require',compile('src/components/ListingIntakePanel.jsx'))(module,name=>{
 if(name==='react')return {default:react,...react};
 if(name==='@/components/ui/button')return {Button:'button',buttonVariants:()=> 'existing-button'};
 if(name==='@/components/ListingLink')return {default:'native-link'};
 if(name==='@/components/ui/dialog')return Object.fromEntries(['Dialog','DialogContent','DialogHeader','DialogTitle','DialogDescription'].map(k=>[k,k]));
 if(name==='lucide-react')return Object.fromEntries(['Search','Upload','Check','RotateCcw'].map(k=>[k,k]));
 if(name==='@/lib/utils')return utils;
 if(name==='@/lib/listingSearchFallback')return {copyListingSearchLink};
 if(name==='@/lib/listingIntakeAction')return {listingIntakeRequest:()=>{requestCount++;throw Error('Copy must never call backend');}};
 if(name.includes('listing-intake.mjs'))return evidence;
 if(name.endsWith('.css'))return {};
 throw Error('Unexpected import '+name);
});
const nodes=tree=>!tree||typeof tree!=='object'?[]:[tree,...(tree.props?.children||[]).flatMap(nodes)];
const text=n=>typeof n==='string'?n:(n?.props?.children||[]).map(text).join('');
const boat={id:'blackjack_fixture',title:'Blackjack 224 2020',make:'Blackjack',model:'224',year:2020,link:'https://unrelated.invalid/ignored'};
const workspace={listings:[],operations:[],integrations_enabled:true,allowance:{screenshots_remaining:6},revision:0};
function render(context){ctx=context;ctx.si=0;ctx.ri=0;return module.default({boat,requestMode:'owner-prod',onClose:()=>{throw Error('Copy must not close');}});}
function fixture(){return {states:[structuredClone(workspace),{...boat,title:'Verified Blackjack 224'},'',false,false,''],refs:[]};}
test('actual intake native link and selectable fallback use the same exact no-year model search',()=>{
 const context=fixture(),tree=render(context),all=nodes(tree);
 const link=all.find(n=>n.type==='native-link'),fallback=all.find(n=>n.type==='textarea');
 assert.equal(link.props.href,url);assert.equal(fallback.props.value,url);assert.equal(fallback.props.readOnly,true);
 assert.ok(text(tree).includes('Google didn’t open?'));assert.ok(text(tree).includes('not saved as a listing reference'));
 assert.equal(link.props.onClick,undefined);assert.equal(link.props.disabled,undefined);
 const shared=fs.readFileSync('src/components/ListingLink.jsx','utf8');assert.match(shared,/target="_blank"/);assert.match(shared,/noopener noreferrer/);
});
test('actual copy action preserves workspace and does not close, navigate, or call backend',async()=>{
 const context=fixture(),original=structuredClone(context.states.slice(0,5));let copied;
 Object.defineProperty(globalThis.navigator,'clipboard',{configurable:true,value:{writeText:async value=>{copied=value;}}});
 const button=nodes(render(context)).find(n=>n.type==='button'&&text(n)==='Copy search link');
 await button.props.onClick();assert.equal(copied,url);assert.deepEqual(context.states.slice(0,5),original);assert.equal(requestCount,0);
 assert.ok(text(render(context)).includes('Search link copied. Paste it in your browser.'));
});
test('actual clipboard failure keeps a selectable URL and gives honest manual-copy instructions',async()=>{
 const context=fixture();
 Object.defineProperty(globalThis.navigator,'clipboard',{configurable:true,value:{writeText:async()=>{throw Error('blocked');}}});
 await nodes(render(context)).find(n=>n.type==='button'&&text(n)==='Copy search link').props.onClick();
 const tree=render(context);assert.ok(text(tree).includes('Automatic copy isn’t available here.'));
 assert.ok(!text(tree).includes('Search link copied.'));assert.equal(nodes(tree).find(n=>n.type==='textarea').props.value,url);assert.equal(requestCount,0);
});
test('fallback introduces no popup detection, automatic navigation, provider calls or listing writes',()=>{
 const helper=fs.readFileSync('src/lib/listingSearchFallback.js','utf8');
 assert.doesNotMatch(helper,/window\.open|location|fetch\s*\(|entities|functions|execCommand/);
 const panel=fs.readFileSync('src/components/ListingIntakePanel.jsx','utf8');
 const handler=panel.slice(panel.indexOf('const copySearch ='),panel.indexOf('const inFlight ='));
 assert.doesNotMatch(handler,/request\(|run\(|onClose\(|location|window\.open/);
});
