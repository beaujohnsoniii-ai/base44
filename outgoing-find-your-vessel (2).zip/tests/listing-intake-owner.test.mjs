import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { allowedOwnerTrialCaller, allowedStageCaller, loadIntakeContext, runIntakeAction } from '../base44/shared/listing-intake-service.mjs';
import { resetListing } from '../base44/shared/listing-intake.mjs';
import { harness, OWNER, POLICY, request, screenshot, uploadedData, completeData, LISTING_ID, UPLOAD_ID, NOW } from './listing-intake-fixtures.mjs';

const policy = { ...POLICY, workspace_kind: 'owner-production', workspace_label: 'owner-trial-fixture', max_uploads: 6, max_extractions: 6 };
async function ownerHarness(options = {}) {
  const h = await harness(options);
  h.state.record.stage_fixture = false; h.state.record.fixture_label = policy.workspace_label;
  h.client.auth = { me: async () => OWNER };
  h.ownerContext = () => loadIntakeContext(h.client, OWNER, policy);
  return h;
}
const spent = (action, count = 6) => Array.from({length: count}, (_, i) => ({ id: 'spent_operation_' + i, action, status: 'complete', payload_digest: 'retained', started_at: NOW }));

test('PROD owner trial is explicit and cannot relax the DEV gate', () => {
  assert.equal(allowedOwnerTrialCaller(OWNER, policy, 'prod'), true);
  for (const [u,p,e] of [
    [null,policy,'prod'], [{...OWNER,id:'other'},policy,'prod'], [{...OWNER,app_id:'other'},policy,'prod'],
    [{...OWNER,role:'user'},policy,'prod'], [{...OWNER,is_service:true},policy,'prod'], [{...OWNER,disabled:true},policy,'prod'],
    [OWNER,{...policy,enabled:false},'prod'], [OWNER,{...policy,workspace_kind:'dev-stage'},'prod'],
    [OWNER,{...policy,record_id:''},'prod'], [OWNER,{...policy,workspace_label:''},'prod'],
    [OWNER,policy,'dev'], [OWNER,policy,undefined],
  ]) assert.equal(allowedOwnerTrialCaller(u,p,e),false);
  assert.equal(allowedStageCaller(OWNER,policy,'prod'),false);
});

test('owner production context rejects wrong row marker, label, ID or owner', async () => {
  for (const change of [{stage_fixture:true},{fixture_label:'another'},{id:'another'},{owner_id:'other'}]) {
    const h=await ownerHarness(); Object.assign(h.state.record,change);
    await assert.rejects(h.ownerContext(), e=>e.status===403);
    assert.equal(h.calls.commits.length,0);
  }
});

test('new production owner workspace opens genuinely blank and read-only', async () => {
  const h=await ownerHarness({data:{listings:[],operations:[]},revision:0});
  const result=await runIntakeAction(await h.ownerContext(),{action:'read'});
  assert.deepEqual(result.listings,[]); assert.deepEqual(result.operations,[]);
  assert.equal(result.assessment_enabled,false); assert.deepEqual(h.calls.forbidden,[]);
  assert.equal(h.calls.commits.length,0); assert.equal(h.calls.uploads.length,0);
});

test('owner trial keeps exact current model validation and stale context blocks writes', async () => {
  const h=await ownerHarness();
  const result=await runIntakeAction(await h.ownerContext(),{action:'model',model_type:'suggestion',model_id:'suggested_model_01'});
  assert.equal(result.model.source_id,'suggested_model_01');
  h.state.profile.purchase_budget_max=75000;
  const ctx=await h.ownerContext(); assert.equal(ctx.stale,true);
  await assert.rejects(runIntakeAction(ctx,request('save_reference',{reference_url:''})),e=>e.status===409);
  assert.deepEqual(h.calls.forbidden,[]); assert.equal(h.calls.commits.length,0);
});

test('six-upload lifetime allowance survives populated reset without deleting history', async () => {
  const data=completeData(); data.operations=spent('upload');
  const h=await ownerHarness({data:resetListing(data,LISTING_ID,true,NOW)});
  await assert.rejects(runIntakeAction(await h.ownerContext(),request('upload',{upload_id:'fresh_upload_01',file:screenshot()})), e=>e.status===409);
  assert.equal(h.calls.uploads.length,0); assert.equal(h.calls.commits.length,0);
  assert.equal(h.state.record.data.listings[0].archived_revisions.length,1);
  assert.equal(h.state.record.data.operations.length,6);
});

test('six-reading lifetime allowance rejects a seventh provider call', async () => {
  const data=uploadedData(); data.operations=spent('read_screenshot');
  const h=await ownerHarness({data});
  await assert.rejects(runIntakeAction(await h.ownerContext(),request('read_screenshot',{upload_id:UPLOAD_ID})),e=>e.status===409);
  assert.equal(h.calls.signs.length,0); assert.equal(h.calls.extracts.length,0); assert.equal(h.calls.commits.length,0);
});

test('the sixth upload is permitted once and replay cannot use a seventh credit', async () => {
  const h=await ownerHarness(); h.state.record.data.operations=spent('upload',5);
  const body=request('upload',{upload_id:'fresh_upload_01',file:screenshot()});
  const result=await runIntakeAction(await h.ownerContext(),body);
  assert.equal(result.operations.filter(o=>o.action==='upload').length,6);
  assert.equal(h.calls.uploads.length,1);
  const replay=await runIntakeAction(await h.ownerContext(),body);
  assert.equal(replay.replayed,true); assert.equal(h.calls.uploads.length,1);
  assert.deepEqual(h.calls.forbidden,[]);
});

// Evaluate only our transport code with a synthetic SDK. No real token, HTTP or integration.
let receivedRequest;
globalThis.__ownerIntakeMockFactory = req => { receivedRequest=req; return globalThis.__ownerIntakeMockClient; };
const shared = resolve('base44/shared');
let httpSource=await readFile(resolve(shared,'listing-intake-http.ts'),'utf8');
httpSource=httpSource.replace("import { createClientFromRequest } from 'npm:@base44/sdk@0.8.57';", 'const createClientFromRequest = globalThis.__ownerIntakeMockFactory;');
for(const file of ['listing-intake.mjs','listing-intake-service.mjs','listing-intake-allowance.mjs']) httpSource=httpSource.replace("'./"+file+"'",JSON.stringify(pathToFileURL(resolve(shared,file)).href));
const {createIntakeHandler}=await import('data:text/javascript;base64,'+Buffer.from(httpSource).toString('base64'));
const input=(body,headers={})=>new Request('https://fixture.invalid/owner',{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(body)});

test('owner HTTP fixes PROD despite caller DEV header and gives truthful allowance', async () => {
  const h=await ownerHarness({data:{listings:[],operations:[]},revision:0});
  globalThis.__ownerIntakeMockClient=h.client;
  const response=await createIntakeHandler(policy,'prod',allowedOwnerTrialCaller)(input({action:'read'},{'X-Data-Env':'dev'}));
  const result=await response.json();
  assert.equal(response.status,200); assert.equal(receivedRequest.headers.get('X-Data-Env'),'prod');
  assert.equal(result.workspace_kind,'owner-production'); assert.deepEqual(result.allowance,{screenshots_remaining:6,readings_remaining:6});
  assert.equal(h.calls.commits.length,0); assert.equal(h.calls.uploads.length,0);
});

test('owner HTTP rejects arbitrary browser environment, record, profile and private URI', async () => {
  for(const key of ['data_env','record_id','owner_id','buyer_profile_id','file_uri']) {
    const h=await ownerHarness(); globalThis.__ownerIntakeMockClient=h.client;
    const response=await createIntakeHandler(policy,'prod',allowedOwnerTrialCaller)(input({action:'read',[key]:'not-trusted'}));
    assert.equal(response.status,400); assert.equal(h.calls.commits.length,0); assert.equal(h.calls.signs.length,0);
  }
});

test('anonymous and other-owner HTTP requests fail before entity access', async () => {
  for(const user of [null,{...OWNER,id:'other_owner'}]) {
    let accessed=false;
    globalThis.__ownerIntakeMockClient={auth:{me:async()=>user},entities:new Proxy({}, {get(){accessed=true;throw Error('must not read');}})};
    const response=await createIntakeHandler(policy,'prod',allowedOwnerTrialCaller)(input({action:'read'}));
    assert.equal(response.status,user?403:401); assert.equal(accessed,false);
  }
});

const calls=[];
globalThis.__ownerIntakeClient={functions:{fetch:async(endpoint,opts)=>{calls.push({endpoint,opts});return Response.json({listings:[]});}}};
let clientSource=await readFile(resolve('src/lib/listingIntakeAction.js'),'utf8');
clientSource=clientSource.replace("import { base44 } from '@/api/base44Client';",'const base44=globalThis.__ownerIntakeClient;');
clientSource=clientSource.replace("import { requestDeadline } from './requestDeadline';",'const requestDeadline=fn=>fn(new AbortController().signal);');
const transport=await import('data:text/javascript;base64,'+Buffer.from(clientSource).toString('base64'));

test('explicit owner-prod mode uses the PROD endpoint for every action, including multipart and preview', async () => {
  calls.length=0;
  for(const action of ['read','model','add_listing','save_reference','read_screenshot','preview_source','confirm','reset_listing']) await transport.listingIntakeRequest({action},'owner-prod');
  await transport.listingIntakeRequest({action:'upload',file:new Blob(['synthetic'],{type:'image/png'})},'owner-prod');
  assert.equal(calls.length,9);
  for(const call of calls){assert.equal(call.endpoint,'/listing-intake-owner');assert.equal(call.opts.headers['X-Data-Env'],'prod');}
  assert.ok(calls.at(-1).opts.body instanceof FormData);
  await transport.listingIntakeRequest({action:'read'},'dev');
  assert.equal(calls.at(-1).endpoint,'/listing-intake'); assert.equal(calls.at(-1).opts.headers['X-Data-Env'],'dev');
  await assert.rejects(transport.listingIntakeRequest({action:'read'},'prod'));
});

test('ordinary default production presentation remains off; only explicit exact owner mode can show Review', () => {
  const owner={id:'6abbd00e2cbdcfbf9bef007f',app_id:'6abbd00d2cbdcfbf9bef007e',role:'admin'};
  assert.equal(transport.canPreviewListingIntake(owner),false);
  assert.equal(transport.canPreviewListingIntake(owner,'owner-prod'),true);
  assert.equal(transport.canPreviewListingIntake({...owner,id:'other'},'owner-prod'),false);
  assert.equal(transport.canPreviewListingIntake({...owner,is_service:true},'owner-prod'),false);
});

test('all panel request routes share explicit mode, including retained source preview and pending replay', async () => {
  const panel=await readFile(resolve('src/components/ListingIntakePanel.jsx'),'utf8');
  assert.equal((panel.match(/listingIntakeRequest\(/g)||[]).length,1);
  assert.match(panel,/listingIntakeRequest\(body, requestMode\)/);
  assert.match(panel,/request=\{request\}/);
  assert.match(panel,/await request\(pendingRequest.current\)/);
  const ownerEntry=await readFile(resolve('base44/functions/listing-intake-owner/entry.ts'),'utf8');
  assert.match(ownerEntry,/createIntakeHandler\(OWNER_POLICY, 'prod', allowedOwnerTrialCaller\)/);
  assert.match(ownerEntry,/max_uploads: 9, max_extractions: 9/);
  assert.doesNotMatch(ownerEntry,/suggest-boats|compare-listings|create\(|update\(|file_uri/);
});

test('only actual My Helm opts into owner production; Compare default stays disabled', async () => {
  const dashboard=await readFile(resolve('src/pages/Dashboard.jsx'),'utf8');
  assert.equal((dashboard.match(/listingIntakeDataEnv="owner-prod"/g)||[]).length,1);
  const compare=await readFile(resolve('src/components/CompareSavedCandidates.jsx'),'utf8');
  assert.match(compare,/listingIntakeDataEnv = "prod"/);
  const entry=await readFile(resolve('base44/functions/listing-intake/entry.ts'),'utf8');
  assert.match(entry,/integrations_enabled: false/);
  assert.match(entry,/createIntakeHandler\(STAGE_POLICY, 'dev', allowedStageCaller\)/);
});

test('new owner contract rejects stale browser read/write before entity/provider access, without touching data',async()=>{
 const nextPolicy={...policy,submission_policy:'current-top-three-single-screenshot-v1',max_uploads:9,max_extractions:9};
 for(const action of ['read','model','upload','add_listing','read_screenshot']){
  const h=await ownerHarness();const before=structuredClone(h.state.record);globalThis.__ownerIntakeMockClient=h.client;
  const response=await createIntakeHandler(nextPolicy,'prod',allowedOwnerTrialCaller)(input({action}));
  assert.equal(response.status,409);assert.match((await response.json()).error,/Refresh the My Helm page once/);
  assert.deepEqual(h.state.record,before);assert.equal(h.calls.recordReads,0);assert.equal(h.calls.uploads.length,0);assert.equal(h.calls.extracts.length,0);
 }
});

test('new client contract works with prior policy during staged rollout and is sent in JSON/multipart',async()=>{
 const h=await ownerHarness();globalThis.__ownerIntakeMockClient=h.client;
 const response=await createIntakeHandler(policy,'prod',allowedOwnerTrialCaller)(input({action:'read',client_contract:2}));
 assert.equal(response.status,200);
 calls.length=0;await transport.listingIntakeRequest({action:'read'},'owner-prod');
 assert.equal(JSON.parse(calls[0].opts.body).client_contract,2);
 await transport.listingIntakeRequest({action:'upload',file:new Blob(['synthetic'],{type:'image/png'})},'owner-prod');
 assert.equal(calls[1].opts.body.get('client_contract'),'2');
});
