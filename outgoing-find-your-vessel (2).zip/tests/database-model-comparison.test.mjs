import test from "node:test";
import assert from "node:assert/strict";
import {registerHooks} from "node:module";
import {compareStoredModels} from "../base44/shared/model-comparison.mjs";
import {compareModelsWithSavedSelection} from "../src/lib/compareModelsAction.js";
const boat={id:"b",created_by_id:"u",make:"Builder",model:"23",year:2025,title:"Builder 23"};
const review={status:"source_confirmed",value:8,unit:"ft",basis:"beam",year_start:2024,year_end:2025,source_url:"https://builderboats.com/specs"};
const row={id:"r",manufacturer:"Builder",model:"23",generation:"2024–2025",workbook_version:109,raw_fields:{Beam:8,LOA:23,"Primary Manufacturer Source":"https://builderboats.com/specs"},field_reviews:{Beam:review}};
function database(rows=[row],issues=[]){return {entities:{ResearchDataset:{filter:async()=>structuredClone(rows)},DataReviewIssue:{filter:async()=>structuredClone(issues)}}};}
function fixture(){
 let space;const calls=[];
 const client={auth:{me:async()=>({id:"u"})},entities:{
  SavedBoat:{get:async()=>boat,update:()=>{throw Error("Must not write listing links");}},
  CompareWorkspace:{get:async()=>space,create:async d=>space={...d,id:"w",created_by_id:"u"},update:async(id,d)=>space={...space,...d}}
 },functions:{invoke:async(name,body)=>{calls.push({name,body});return {data:{mode:"database_models",results:[]}};}}};
 return {client,calls,args:{boats:[boat],selected:["b"],workspace:null}};
}
test("model action succeeds without URLs and ignores invalid unsaved listing drafts",async()=>{
 const f=fixture();const out=await compareModelsWithSavedSelection(f.client,{...f.args,drafts:{b:["javascript:invalid"]}});
 assert.deepEqual(f.calls,[{name:"compare-listings",body:{mode:"models"}}]);assert.deepEqual(out.workspace.selected_ids,["b"]);
});
test("model action rejects another owner's candidate before selection writes or invocation",async()=>{
 const f=fixture();f.client.entities.SavedBoat.get=async()=>({...boat,created_by_id:"other"});
 await assert.rejects(compareModelsWithSavedSelection(f.client,f.args),/unavailable/);assert.equal(f.calls.length,0);
});
test("model comparison reads stored evidence with no external request or data mutation",async t=>{
 const old=globalThis.fetch;t.after(()=>globalThis.fetch=old);globalThis.fetch=()=>{throw Error("No provider request");};
 const out=await compareStoredModels(database(),[boat]);
 assert.equal(out.mode,"database_models");assert.equal(out.results[0].fields.find(f=>f.field==="Beam").value,8);
 assert.equal(out.results[0].fields.find(f=>f.field==="LOA").status,"not_checked");assert.equal(out.results[0].research[0].values.LOA,"23");
 assert.equal(out.results[0].fields.find(f=>f.field==="Beam").source_url,review.source_url);
});
test("unknown and out-of-generation years never borrow reviewed values",async()=>{
 for(const year of [null,2020]){
 const out=await compareStoredModels(database(),[{...boat,year}]);
 assert.notEqual(out.results[0].fields.find(f=>f.field==="Beam").status,"source_confirmed");
 }
});
test("conflicts, mismatched units, unsafe sources and truncated research withhold confirmation",async()=>{
 for(const rows of [
  [{...row,field_reviews:{Beam:{...review,status:"conflict"}}}],
  [{...row,field_reviews:{Beam:{...review,unit:"m"}}}],
  [{...row,field_reviews:{Beam:{...review,source_url:"https://builderboats.com/specs?token=secret"}}}],
  Array.from({length:100},(_,i)=>({...row,id:"r"+i}))
 ]){
 const out=await compareStoredModels(database(rows),[boat]);assert.notEqual(out.results[0].fields.find(f=>f.field==="Beam").status,"source_confirmed");
 }
});
test("unrelated model rows do not become research for a selected model",async()=>{
 const out=await compareStoredModels(database([{...row,model:"23 XL"}]),[boat]);assert.equal(out.results[0].research.length,0);
});
const hooks=registerHooks({resolve(s,c,next){if(s.startsWith("npm:@base44/sdk"))return {url:"data:text/javascript,"+encodeURIComponent('export const createClientFromRequest=()=>globalThis[Symbol.for("model.compare.client")];'),shortCircuit:true};return next(s,c);}});
const {default:handler}=await import("../base44/functions/compare-listings/entry.ts");hooks.deregister();
function backend(){
 return {auth:{me:async()=>({id:"u",plan:"market_match",plan_expires:"2099-01-01"})},entities:{
 BuyerProfile:{filter:async()=>[{id:"p",created_by_id:"u"}]},CompareWorkspace:{filter:async()=>[{id:"w",created_by_id:"u",selected_ids:["b"]}]},SavedBoat:{get:async()=>boat}
 },asServiceRole:database()};
}
const request=()=>new Request("https://app.com/api",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({mode:"models"})});
test("real authenticated handler returns database model results without listing URLs or fetch",async t=>{
 const old=globalThis.fetch;t.after(()=>globalThis.fetch=old);globalThis.fetch=()=>{throw Error("No provider request");};
 globalThis[Symbol.for("model.compare.client")]=backend();
 const response=await handler(request());assert.equal(response.status,200);const out=await response.json();
 assert.equal(out.mode,"database_models");assert.equal(out.results[0].id,"b");assert.equal(out.results[0].fields.find(f=>f.field==="Beam").value,8);
});
test("model handler rejects anonymous, expired and another owner's saved model before research access",async()=>{
 for(const kind of ["anonymous","expired","other"]){
  const c=backend();let reads=0;c.asServiceRole.entities.ResearchDataset.filter=async()=>{reads++;throw Error("Must not read");};
  if(kind==="anonymous")c.auth.me=async()=>null;
  if(kind==="expired")c.auth.me=async()=>({id:"u",plan:"market_match",plan_expires:"2000-01-01"});
  if(kind==="other")c.entities.SavedBoat.get=async()=>({...boat,created_by_id:"other"});
  globalThis[Symbol.for("model.compare.client")]=c;const response=await handler(request());assert.ok([401,403].includes(response.status));assert.equal(reads,0);
 }
});
