import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
const body=readFileSync("src/components/HomeBody.jsx","utf8");
test("homepage body uses unique section anchors and a semantic expectations list",()=>{
 const ids=[...body.matchAll(/<section id="([^"]+)"/g)].map(m=>m[1]);
 assert.equal(ids.length,new Set(ids).size);
 for(const id of ["about","how-it-works","packages","resources"]) assert.ok(ids.includes(id));
 assert.match(body,/<ul className="grid sm:grid-cols-2[^>]+>[\s\S]*?PROMISE_POINTS.map[\s\S]*?<\/ul>/);
});
test("homepage copy is shorter, separates sample from live listing, and preserves package data",()=>{
 assert.ok(!body.includes("Our Honest Promise"));
 assert.ok(!body.includes("The Counsel Behind It"));
 assert.ok(!body.includes("Reviewed 2026-09-29"));
 assert.ok(body.includes("not a verified current listing"));
 assert.ok(body.includes("No current price or availability is verified here"));
 assert.ok(body.includes("Independent Vessel Acquisition Advisory"));
 for(const text of ["$9","$29","$99","$20 from Bosun","$70 from First Mate","PLAN_TIERS[0].deliverables","PLAN_TIERS[1].deliverables","PLAN_TIERS[2].deliverables","EXPLORE_FREE.map"]) assert.ok(body.includes(text));
 assert.ok(body.includes('navigate("/match")'));
});
test("body spacing is compact and responsive without changing header or hero",()=>{
 assert.ok(!body.includes("py-20"));
 assert.ok(!body.includes("mt-14"));
 assert.ok(body.includes("py-12 md:py-14"));
 assert.ok(body.includes('text-center sm:text-left'));
 assert.ok(!body.includes("coastal-stacked-name"));
 assert.ok(!body.includes("coastal-scene"));
});
