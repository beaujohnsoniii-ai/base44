import test from "node:test";import assert from "node:assert/strict";import fs from "node:fs";import {registerHooks} from "node:module";import ts from "typescript";
const K=Symbol.for("compare.ui.fixture"),R=Symbol.for("compare.ui.hooks");
const moduleUrl=code=>"data:text/javascript,"+encodeURIComponent(code);
const react=moduleUrl('const h=()=>globalThis[Symbol.for("compare.ui.hooks")];export const useState=v=>{const c=h(),i=c.si++;if(!(i in c.states))c.states[i]=typeof v==="function"?v():v;return [c.states[i],n=>c.states[i]=typeof n==="function"?n(c.states[i]):n];};export const useRef=v=>{const c=h(),i=c.ri++;return c.refs[i]??(c.refs[i]={current:v});};export const useEffect=f=>{h().effects.push(f);};export default {createElement:(type,props,...children)=>({type,props:{...props,children:children.flat(Infinity)}})};');
const hook=registerHooks({resolve(s,c,next){
 if(s==="react")return {url:react,shortCircuit:true};
 if(s==="react-router-dom")return {url:moduleUrl('export const Link="a";'),shortCircuit:true};
 if(s==="@/api/base44Client")return {url:moduleUrl('export const base44=new Proxy({},{get:(_,k)=>globalThis[Symbol.for("compare.ui.fixture")].client[k]});'),shortCircuit:true};
 if(s==="@/components/ui/button")return {url:moduleUrl('export const Button="button";'),shortCircuit:true};
 if(s==="@/components/ModelComparisonView")return {url:moduleUrl('export default ()=>null;'),shortCircuit:true};
 if(s==="@/lib/useListingIntake")return {url:moduleUrl('export const useListingIntake=()=>({enabled:false,reviewBoat:null,counts:null});'),shortCircuit:true};
 if(s==="@/components/ListingIntakePanel")return {url:moduleUrl('export default ()=>null;'),shortCircuit:true};
 if(s==="@/components/CompareImportResults")return {url:moduleUrl('export default ()=>null;'),shortCircuit:true};
 if(s==="@/lib/requestDeadline")return {url:moduleUrl('import {requestDeadline as run} from '+JSON.stringify(new URL("../src/lib/requestDeadline.js",import.meta.url).href)+';export const requestDeadline=(f,m,msg)=>run(f,globalThis[Symbol.for("compare.ui.fixture")].milliseconds||m,msg);'),shortCircuit:true};
 if(s.startsWith("@/lib/"))return next(new URL("../src/lib/"+s.slice(6)+".js",import.meta.url).href,c);
 return next(s,c);
}});
const code=ts.transpileModule(fs.readFileSync("src/components/CompareSavedCandidates.jsx","utf8"),{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {default:Component}=await import(moduleUrl(code));hook.deregister();
const boat={id:"b",created_by_id:"u",make:"Mock",model:"Boat",listing_urls:["https://dealer.com/old"]};
const space={id:"w",created_by_id:"u",selected_ids:["b"]};
function fixture(){
 const c={milliseconds:10,writes:0,gets:0,invokes:0};
 c.client={auth:{me:async()=>({id:"u"})},entities:{SavedBoat:{update:async()=>{c.writes++;return boat;},get:async()=>{c.gets++;return boat;}},CompareWorkspace:{update:async()=>{c.writes++;return space;},get:async()=>space}},functions:{invoke:async()=>{c.invokes++;return new Promise(()=>{});}}};
 globalThis[K]=c;return c;
}
function render(fn,props={},ctx={states:[],refs:[],effects:[]}){
 ctx.si=0;ctx.ri=0;ctx.effects=[];globalThis[R]=ctx;return {tree:fn(props),ctx};
}
function nodes(tree){if(!tree||typeof tree!=="object")return [];return [tree,...(tree.props?.children||[]).flatMap(nodes)];}
const text=n=>typeof n==="string"?n:(n?.props?.children||[]).map(text).join("");
function parent(){return render(Component,{}, {states:[[boat],space,["b"],false,"","",false,0,{},false,null,"",false],refs:[],effects:[]});}
test("actual JSX exposes Compare, keeps listing input and pauses duplicate writes until uncertainty resolves",async()=>{
 const c=fixture();let finish;c.client.entities.SavedBoat.update=()=>{c.writes++;return new Promise(resolve=>finish=resolve);};
 const p=parent(),child=nodes(p.tree).find(n=>n.type?.name==="ListingFields");
 const saved=[];const props={...child.props,onSaved:v=>saved.push(v)};
 const fields=render(child.type,props),save=nodes(fields.tree).find(n=>n.type==="button"&&text(n)==="Save links");
 const first=save.props.onClick(),duplicate=save.props.onClick();await duplicate;await first;
 assert.equal(c.writes,1);assert.equal(c.gets,0);assert.equal(saved.length,0);
 const updated=render(Component,{},p.ctx);
 assert.equal(nodes(updated.tree).find(n=>n.type==="button"&&text(n)==="Compare").props.disabled,true);
 assert.ok(nodes(updated.tree).some(n=>n.props?.role==="alert"&&text(n).includes("further saves are paused")));
 finish(boat);await new Promise(resolve=>setTimeout(resolve,0));assert.equal(saved.length,0);assert.equal(c.gets,0);
 const remaining=render(child.type,props,fields.ctx);assert.equal(nodes(remaining.tree).find(n=>n.type==="input").props.value,"https://dealer.com/old");
 assert.ok(text(remaining.tree).includes("Link save was not confirmed"));assert.ok(!text(remaining.tree).includes("Listing links saved to your account."));
});
test("actual JSX renders transient capture and clears it when the bound URL changes",()=>{
 fixture();const p=parent(),child=nodes(p.tree).find(n=>n.type?.name==="ListingFields");let captures;
 const props={...child.props,captureValues:["copied listing text"],onCaptureValues:value=>{captures=value;},onDirty:()=>{}};
 const fields=render(child.type,props),all=nodes(fields.tree);
 const area=all.find(n=>n.type==="textarea"),input=all.find(n=>n.type==="input");
 assert.equal(area.props.value,"copied listing text");assert.equal(area.props.maxLength,16000);
 assert.match(area.props.placeholder,/not saved/);assert.match(text(fields.tree),/transient/);
 input.props.onChange({target:{value:"https://dealer.com/replacement"}});
 assert.deepEqual(captures,[""]);
});
test("actual JSX stalled selection ends busy state, keeps previous selection and prevents a second write",async()=>{
 const c=fixture();c.client.entities.CompareWorkspace.update=()=>{c.writes++;return new Promise(()=>{});};
 const p=parent(),save=nodes(p.tree).find(n=>n.type==="button"&&text(n)==="Save current selection");
 await Promise.all([save.props.onClick(),save.props.onClick()]);assert.equal(c.writes,1);
 const next=render(Component,{},p.ctx);assert.deepEqual(p.ctx.states[2],["b"]);
 assert.ok(text(next.tree).includes("Selection save was not confirmed"));assert.ok(!text(next.tree).includes("Your Compare selection is saved."));
 assert.equal(nodes(next.tree).find(n=>n.type==="button"&&text(n)==="Compare").props.disabled,true);
});
test("actual JSX stalled load ends spinner and exposes Retry",async()=>{
 const c=fixture();c.client.auth.me=()=>new Promise(()=>{});
 const p=render(Component);p.ctx.effects[0]();await new Promise(resolve=>setTimeout(resolve,20));
 const next=render(Component,{},p.ctx);assert.equal(p.ctx.states[3],false);assert.ok(text(next.tree).includes("could not be loaded"));
 assert.ok(nodes(next.tree).some(n=>n.type==="button"&&text(n)==="Retry"));
});
