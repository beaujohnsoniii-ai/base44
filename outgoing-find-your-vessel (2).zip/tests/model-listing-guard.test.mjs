import test from "node:test";
import assert from "node:assert/strict";
import { withholdListingSpecificModelClaims } from "../base44/shared/model-listing-guard.ts";
import { generateRecommendations, MATCH_SCORE_CAPS } from "../base44/shared/suggest-engine.ts";

test("a specific used boat's engine hours are not model-level facts", () => {
  for (const narrative of [
    "Cabin sleeps four. Engines have 650 hours.",
    "Yamaha outboards show 1,250 hrs.",
    "Engine hours: 780.",
    "Twin motors with 410 hours.",
    "There are 900 hours on the engines.",
  ]) {
    const out = withholdListingSpecificModelClaims(narrative);
    assert.equal(out.withheld, true, narrative);
    assert.doesNotMatch(out.text, /(?:650|1,250|780|410|900)\s*(?:hours|hrs)/i);
  }
});

test("a seller's actual asking price must not enter a model-level rationale", () => {
  for (const narrative of [
    "The seller asks $92,000.",
    "A boat is listed for $78,500.",
    "Currently listed at $155k.",
    "$82,000 asking price.",
    "The boat is for sale at $125,000.",
    "A 2023 example is offered for $120k.",
    "One individual boat is priced at $135,000.",
    "The listing is available for $84,000.",
  ]) {
    const out = withholdListingSpecificModelClaims(narrative);
    assert.equal(out.withheld, true, narrative);
    assert.doesNotMatch(out.text, /\$(?:92,000|78,500|155k|82,000|125,000|120k|135,000|84,000)/i);
  }
});

test("model market bands, equipment, capacities, service intervals and layouts remain", () => {
  for (const narrative of [
    "Used model price range $65,000–$90,000 for 2021–2024.",
    "Twin 300 hp outboards with a 180-gallon fuel tank.",
    "Factory service intervals may be 100 hours.",
    "Cabin has two berths. LOA 31 ft. Draft 2.1 ft.",
  ]) {
    assert.deepEqual(withholdListingSpecificModelClaims(narrative), { text: narrative, withheld: false });
  }
});

test("the guard preserves unrelated sentences while withholding listing-specific facts", () => {
  const out = withholdListingSpecificModelClaims("Has protected helm seating. Seller asking price: $110,000. Has a walkaround deck.");
  assert.equal(out.withheld, true);
  assert.match(out.text, /protected helm seating/);
  assert.match(out.text, /walkaround deck/);
  assert.doesNotMatch(out.text, /\$110,000/);
});

test("MODEL MATCH removes LLM listing facts from the buyer-facing record", async () => {
  const raw = {
    title: "Sailfish 232 CC — used example $110,000, 780 engine hrs",
    make: "Sailfish", model: "232 CC", year: 2027,
    length: "23.5 ft", engines: "Single 250 hp outboard. Engine hours: 780.",
    why_suggested: "Enclosed head for guests. Seller asking price: $110,000.",
    summary: "Fishing and family layout. The seller asks $110,000.",
    matches: ["Twin baitwells", "The boat is listed for $110,000."],
    gaps: ["Engines have 780 hours."],
    score_breakdown: Object.fromEntries(Object.keys(MATCH_SCORE_CAPS).map(key => [key, 0])),
    verification_required: [],
  };
  const client = { asServiceRole: { integrations: { Core: {
    InvokeLLM: async () => ({ suggestions: [raw], contradiction: { flagged: true, conflicts: [], explanation: "", closest_alternatives: [] } }),
  } } } };
  const result = await generateRecommendations(client, {
    profile: { vessel_class: "power", boat_size_range: "20_25" },
    plan: "free",
    tierFields: { matchPlus: new Set(), refinedMatch: new Set(), marketMatch: new Set() },
    manufacturerMap: { brief: "", list: [] },
    likedModels: [], savedBoats: [], existingSuggestions: [],
    isFirstPaidGeneration: false, hadContradiction: false, refresh: false, contradictionRerunCount: 0,
  });
  assert.equal(result.suggestions.length, 1);
  const s = result.suggestions[0];
  assert.equal(s.title, "Sailfish 232 CC 2027");
  const display = [s.title, s.engines, s.why_suggested, s.match.summary,
    ...s.match.matches, ...s.match.gaps].join(" | ");
  assert.doesNotMatch(display, /780\s*(?:engine\s*)?(?:hours|hrs)|\$110,000/i);
  assert.match(display, /Enclosed head for guests/);
  assert.match(display, /Twin baitwells/);
  assert.ok(s.verification_required.some(note => /seller asking price or engine hours were withheld/i.test(note)));
});
