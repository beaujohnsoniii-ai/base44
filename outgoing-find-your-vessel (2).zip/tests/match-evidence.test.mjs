import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {
  MATCH_FIELD_CLASSES,
  buyerConstraintIds,
  classifyRecordedFields,
  dedupeFlags,
  evidenceAudit,
  buildEvidenceFlags,
} from "../base44/shared/match-evidence.mjs";

const SOURCE = "https://www.whaler.com/specs/example";
const confirmed = (field, value, unit) => ({ field, status: "source_confirmed", value, unit, source_url: SOURCE, checked_at: "2026-01-01T00:00:00.000Z" });
const conflict = (field) => ({ field, status: "conflict", message: "Sources disagree." });
const missing = (field) => ({ field, status: "missing", message: "No usable value is recorded." });

test("specifications are classified by whether they can decide a stated buyer limit", () => {
  assert.equal(MATCH_FIELD_CLASSES["Beam"].matchClass, "critical");
  assert.equal(MATCH_FIELD_CLASSES["LOA"].matchClass, "critical");
  assert.equal(MATCH_FIELD_CLASSES["Draft Engines Down"].matchClass, "critical");
  assert.equal(MATCH_FIELD_CLASSES["Passenger Capacity"].matchClass, "critical");
  // Dry weight excludes fuel, fluids and gear, and fuel capacity is range
  // context: neither can decide storage, lift or tow compliance.
  assert.equal(MATCH_FIELD_CLASSES["Dry Weight / Displacement"].matchClass, "optional");
  assert.equal(MATCH_FIELD_CLASSES["Fuel Capacity (gal)"].matchClass, "optional");
  assert.equal(MATCH_FIELD_CLASSES["Fuel Capacity (gal)"].constraintId, null);
  assert.equal(MATCH_FIELD_CLASSES["Dry Weight / Displacement"].constraintId, null);
});

test("a stated limit is read from structured fields or explicit maximum wording only", () => {
  assert.ok(buyerConstraintIds({ hard_max_beam_ft: 8.5 }).has("beam"));
  assert.ok(buyerConstraintIds({ hard_max_draft_ft: 3 }).has("draft"));
  assert.ok(buyerConstraintIds({ passenger_count: 6 }).has("passengers"));
  assert.ok(buyerConstraintIds({ occasional_passenger_count: 8 }).has("passengers"));
  // Descriptive facility notes are not limits.
  assert.equal(buyerConstraintIds({ storage_capacity: "30 ft slip at the marina" }).has("length"), false);
  assert.ok(buyerConstraintIds({ storage_capacity: "max 30 ft length at the slip" }).has("length"));
  assert.equal(buyerConstraintIds({}).size, 0);
});

test("the audit counts recorded facts only and never fills a gap with a value", () => {
  const audit = evidenceAudit({
    fields: [confirmed("Beam", 9.5, "ft"), conflict("Draft Engines Down"), missing("LOA")],
    verifiedFields: ["beam_ft"],
  });
  assert.equal(audit.critical.total, 3);
  assert.equal(audit.critical.confirmed, 1);
  assert.equal(audit.critical.disputed, 1);
  assert.equal(audit.critical.unconfirmed, 1);
  assert.deepEqual(audit.catalog_verified_fields, ["beam_ft"]);
  assert.match(audit.basis, /never estimated/i);
  // A disputed fact carries no value into customer output.
  assert.equal(audit.fields.find(row => row.field === "Draft Engines Down").value, null);
  assert.equal(audit.fields.find(row => row.field === "LOA").value, null);
  assert.equal(audit.fields.find(row => row.field === "Beam").value, 9.5);
  // Unknown field names are treated as optional context, never as critical.
  assert.equal(classifyRecordedFields([{ field: "Something New", status: "source_confirmed", value: 3 }])[0].matchClass, "optional");
});

test("a source dispute on a stated limit stays a visible blocker and is never suppressed", () => {
  const beam = buildEvidenceFlags({ fields: [conflict("Beam")], profile: { hard_max_beam_ft: 9 } });
  assert.equal(beam.blockers.length, 1);
  assert.equal(beam.verification.length, 0);
  assert.match(beam.blockers[0], /^Beam: independent sources disagree/);
  assert.match(beam.blockers[0], /stated beam limit/);

  // A safety limit stays blocked even when every other recorded fact is fine.
  const capacity = buildEvidenceFlags({
    fields: [confirmed("LOA", 32, "ft"), confirmed("Beam", 10, "ft"), conflict("Passenger Capacity")],
    profile: { passenger_count: 4 },
  });
  assert.equal(capacity.blockers.length, 1);
  assert.match(capacity.blockers[0], /Passenger Capacity/);
});

test("unrecorded evidence becomes a verification item, not a blocker", () => {
  const flags = buildEvidenceFlags({ fields: [missing("Beam"), conflict("Fuel Capacity (gal)")], profile: { hard_max_beam_ft: 10, passenger_count: 5 } });
  assert.equal(flags.blockers.length, 0);
  assert.deepEqual(flags.verification, ["Confirm this model's beam from a published specification before relying on your stated limit."]);
  assert.equal(flags.audit.critical.disputed, 0);
  assert.equal(flags.audit.optional.disputed, 1);
});

test("specifications tied to no stated buyer limit produce no customer-facing flags", () => {
  const flags = buildEvidenceFlags({
    fields: [conflict("Beam"), conflict("Fuel Capacity (gal)"), missing("Draft Engines Down")],
    profile: { purchase_budget_max: 80000, storage: "marina_slip" },
  });
  assert.deepEqual(flags.blockers, []);
  assert.deepEqual(flags.verification, []);
});

test("duplicate and already-covered notes collapse instead of stacking", () => {
  assert.deepEqual(dedupeFlags(["Beam: verify.", "beam   VERIFY.", "Beam: verify.", ""]), ["Beam: verify."]);
  const covered = buildEvidenceFlags({
    fields: [missing("Beam")],
    profile: { hard_max_beam_ft: 10 },
    existing: ["Verify beam against published model specifications before confirming physical fit."],
  });
  assert.equal(covered.verification.length, 0);
  const repeated = buildEvidenceFlags({
    fields: [missing("Beam")],
    profile: { hard_max_beam_ft: 10 },
    existing: ["Verify beam against published model specifications before confirming physical fit.", "Beam: unconfirmed."],
  });
  assert.equal(repeated.verification.length, 0);
});

test("hybrid resolution separates a source dispute from unrecorded evidence", () => {
  const hybrid = fs.readFileSync("base44/shared/hybrid-generation.ts", "utf8");
  assert.match(hybrid, /__hybrid_conflict:conflict,__hybrid_pending:unconfirmed/);
  assert.doesNotMatch(hybrid, /__hybrid_pending:conflict/);
  assert.doesNotMatch(hybrid, /f\.field\+": "\+f\.message/);
  assert.match(hybrid, /const unconfirmed=recorded&&fields\.some/);
});

test("only a true conflict downgrades a Match result; unconfirmed evidence keeps its measurements", () => {
  const engine = fs.readFileSync("base44/shared/suggest-engine.ts", "utf8");
  assert.match(engine, /const evidenceConflict = !!s\.__hybrid_conflict;/);
  assert.doesNotMatch(engine, /__hybrid_pending/);
  assert.doesNotMatch(engine, /Specifications await source verification/);
  assert.match(engine, /suitability_score: evidenceConflict \? null : completeScore/);
  assert.match(engine, /verification_required: dedupeFlags\(\[\.\.\.evidenceFlags\.blockers, \.\.\.verificationRequired, \.\.\.evidenceFlags\.verification\]\)/);
  assert.match(engine, /evidence_summary: evidenceFlags\.audit/);
  // Deterministic hard-constraint exclusions are untouched by this change.
  assert.equal((engine.match(/if \(screen\.excluded\) \{/g) || []).length, 2);
  const propulsion = fs.readFileSync("base44/shared/propulsion-constraints.mjs", "utf8");
  assert.match(propulsion, /return \{excluded:true,pending:false\}/);
});

test("model photos require a recorded licence; otherwise the card uses a placeholder", () => {
  const grounding = fs.readFileSync("base44/shared/catalog-grounding.ts", "utf8");
  assert.match(grounding, /function licensedImage/);
  assert.match(grounding, /delete sanitized\.image_url/);
  assert.match(grounding, /delete sanitized\.image_license/);
  const card = fs.readFileSync("src/components/match/MatchResultImage.jsx", "utf8");
  assert.match(card, /export function hasLicensedModelImage/);
  assert.match(card, /No licensed model photo on file/);
});

test("Match results present the marked models, the visible pool, evidence and Like without duplicate Save actions", () => {
  const showcase = fs.readFileSync("src/components/match/MatchResultsShowcase.jsx", "utf8");
  assert.match(showcase, /suggestions\.filter\(\(b\) => b\.highlighted === true\)/);
  assert.match(showcase, /Strongest match/);
  const card = fs.readFileSync("src/components/match/MatchResultCard.jsx", "utf8");
  for (const label of ["Limitations to confirm", "Find Listings", "Liked"]) {
    assert.ok(card.includes(label), `${label} missing from the Match result card`);
  }
  assert.doesNotMatch(card, /Save Model|Save for later/);
  assert.match(card, /onToggleLike/);
  assert.match(card, /<details/);
  // The ranking justification is one focused section on every card, so the fit
  // reasons and trade-offs are stated once against the stored position.
  assert.match(card, /<MatchRankingSummary boat=\{boat\} variant=\{variant\} rank=\{rank\} poolSize=\{poolSize\} \/>/);
  const ranking = fs.readFileSync("src/components/match/MatchRankingSummary.jsx", "utf8");
  for (const label of ["Why it fits", "Trade-offs to weigh", "Ranking note", "Data points used"]) {
    assert.ok(ranking.includes(label), `${label} missing from the ranking summary`);
  }
  const evidence = fs.readFileSync("src/components/match/MatchEvidenceDetails.jsx", "utf8");
  assert.match(evidence, /Technical evidence and sources/);
  assert.match(evidence, /MATCH-critical specifications/);
  const css = fs.readFileSync("src/components/match-results.css", "utf8");
  assert.match(css, /--primary/);
  assert.match(css, /--brass/);
  assert.doesNotMatch(css, /^\s*\/\//m, "CSS must not use JS-style comments");
  const panel = fs.readFileSync("src/components/SuggestedBoatsPanel.jsx", "utf8");
  assert.match(panel, /<MatchResultsShowcase/);
});