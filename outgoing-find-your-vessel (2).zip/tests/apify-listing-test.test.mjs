import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {registerHooks} from "node:module";
import {APIFY_TEST_POLICY,validateApifyTestPolicy,startApprovedYachtWorldTest,guardedApifyListingTest} from "../base44/shared/apify-listing-test.mjs";
const row=JSON.parse(readFileSync(new URL("./fixtures/apify-boat-rows.json",import.meta.url))).yachtworld;
function fixture(){
 const policy={enabled:true,approval_id:"fixture-approval",approved_url:row.listingUrl,max_total_charge_usd:0.05,
  source_permission_reference:"fixture-source",source_permission_valid_until:new Date(Date.now()+60000).toISOString(),atomic_reservation_verified:true,build:"0.2.1"};
 const slot={id:"slot",approval_id:policy.approval_id,owner_id:"owner",actor_id:"getascraper/yachtworld-scraper",approved_url:row.listingUrl,
  max_calls:1,max_items:1,max_total_charge_usd:0.05,source_permission_reference:"fixture-source",expires_at:new Date(Date.now()+60000).toISOString(),status:"ready"};
 const c={policy,slot,calls:[],secretReads:0,ledgerReads:0};
 c.ledger={filter:async()=>{c.ledgerReads++;return [{...slot}];},get:async()=>({...slot}),
  updateMany:async(q,d)=>{if(slot.status!==q.status)return {success:true,updated:0};Object.assign(slot,d.$set);return {success:true,updated:1};},
  update:async(id,d)=>Object.assign(slot,d)};
 c.client={auth:{me:async()=>({id:"owner",role:"admin"})},asServiceRole:{entities:{ApifyListingTestApproval:c.ledger}}};
 c.getSecret=()=>{c.secretReads++;return "fixture-key";};
 c.fetcher=async(url,opts)=>{c.calls.push({url,opts});return opts.method==="POST"?Response.json({data:{
  id:"run123456789",status:"SUCCEEDED",buildNumber:"0.2.1",defaultDatasetId:"data123456789",
  options:{maxTotalChargeUsd:0.05,maxItems:1,timeoutSecs:60},usageTotalUsd:0.00198}}):Response.json([row]);};
 return c;
}
const execute=c=>guardedApifyListingTest({...c,action:"run_approved_test"});
test("anonymous and non-admin cannot inspect key presence, reservations or trigger cost",async()=>{
 for(const user of [null,{id:"owner",role:"user"}]){
  const c=fixture();c.client.auth.me=async()=>user;
  assert.ok([401,403].includes((await execute(c)).status));assert.equal(c.secretReads,0);assert.equal(c.ledgerReads,0);assert.equal(c.calls.length,0);
 }
});
test("production disabled policy and missing policy controls produce zero egress and no reservation",async()=>{
 for(const change of [{...APIFY_TEST_POLICY},{enabled:false},{max_total_charge_usd:null},{max_total_charge_usd:1},{max_total_charge_usd:0},{approval_id:null},{source_permission_reference:null},{source_permission_valid_until:"2000-01-01"},{atomic_reservation_verified:false},{build:"latest"},{approved_url:"https://www.yachtworld.com/boats-for-sale/"}]){
  const c=fixture();c.policy=change.enabled===false?change:{...c.policy,...change};
  assert.equal((await execute(c)).status,409);assert.equal(c.calls.length,0);assert.equal(c.slot.status,"ready");assert.equal(c.secretReads,0);
 }
 assert.equal(validateApifyTestPolicy(APIFY_TEST_POLICY),"disabled");
});
test("readiness returns presence boolean only; missing token cannot spend reservation",async()=>{
 const c=fixture();const status=await guardedApifyListingTest({...c,policy:APIFY_TEST_POLICY});
 assert.equal(status.body.key_configured,true);assert.equal(status.body.enabled,false);assert.ok(!JSON.stringify(status).includes("fixture-key"));assert.equal(c.calls.length,0);
 c.getSecret=()=>undefined;assert.equal((await execute(c)).status,503);assert.equal(c.slot.status,"ready");
});
test("dedicated store absent or approval owner, URL, cap, expiry mismatch fails closed",async()=>{
 for(const change of [{owner_id:"other"},{max_calls:2},{max_items:2},{max_total_charge_usd:0.10},{expires_at:"2000-01-01"},{approved_url:row.listingUrl.replace("10260699","10260698")},{status:"uncertain"}]){
  const c=fixture();Object.assign(c.slot,change);assert.equal((await execute(c)).status,409);assert.equal(c.calls.length,0);
 }
 const c=fixture();delete c.client.asServiceRole.entities.ApifyListingTestApproval;assert.equal((await execute(c)).status,409);assert.equal(c.calls.length,0);
});
test("one reserved mocked run uses fixed origin, bearer header, cap/time/item/build controls and normalizes exact row",async()=>{
 const c=fixture();const result=await execute(c);
 assert.equal(result.status,200);assert.equal(c.calls.length,2);assert.equal(c.slot.status,"complete");
 const {url,opts}=c.calls[0],u=new URL(url);assert.equal(u.origin,"https://api.apify.com");
 assert.equal(u.pathname,"/v2/actors/getascraper~yachtworld-scraper/runs");
 assert.equal(u.searchParams.get("maxTotalChargeUsd"),"0.05");assert.equal(u.searchParams.get("maxItems"),"1");
 assert.equal(u.searchParams.get("timeout"),"60");assert.equal(u.searchParams.get("restartOnError"),"false");assert.equal(u.searchParams.get("build"),"0.2.1");
 assert.equal(u.searchParams.has("token"),false);assert.equal(opts.headers.Authorization,"Bearer fixture-key");assert.equal(opts.redirect,"error");
 assert.deepEqual(JSON.parse(opts.body).startUrls,[{url:row.listingUrl}]);assert.equal(JSON.parse(opts.body).maxItems,1);
 assert.equal(new URL(c.calls[1].url).searchParams.get("limit"),"2");assert.equal(c.calls[1].opts.redirect,"error");
 assert.equal(result.body.result.record.nullable_facts.engine_hours,250);assert.equal(result.body.result.record.nullable_facts.make,null);
 assert.equal(result.body.result.record.eligible,false);assert.equal(result.body.result.receipt.billing_final_confirmed,false);
 assert.equal((await execute(c)).status,409);assert.equal(c.calls.length,2);
});
test("concurrent mock reservations allow one run start; this does not establish deployed CAS atomicity",async()=>{
 const c=fixture();const results=await Promise.all([execute(c),execute(c)]);
 assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);assert.equal(c.calls.filter(x=>x.opts.method==="POST").length,1);
});
test("provider failure is uncertain, sanitized, spent and never automatically restarted",async()=>{
 const c=fixture();let attempts=0;c.fetcher=async()=>{attempts++;throw Error("Bearer fixture-key raw provider secret");};
 const result=await execute(c);assert.equal(result.status,502);assert.equal(c.slot.status,"uncertain");assert.equal(attempts,1);
 assert.equal(result.body.diagnostic.stage,"run_request");assert.equal(result.body.diagnostic.code,"UNCLASSIFIED_RUNTIME_ERROR");assert.ok(!JSON.stringify(result).includes("fixture-key"));
 assert.equal((await execute(c)).status,409);assert.equal(attempts,1);
});
test("run still running or charge cap echo absent remains spent with run receipt, no polling or dataset access",async()=>{
 for(const status of ["RUNNING","FAILED","SUCCEEDED"]){
  const c=fixture();c.fetcher=async(url,opts)=>{c.calls.push({url,opts});return Response.json({data:{id:"run123456789",status,buildNumber:"0.2.1",defaultDatasetId:"data123456789",options:status==="SUCCEEDED"?{}:{maxTotalChargeUsd:0.05,maxItems:1,timeoutSecs:60}}});};
  const result=await execute(c);assert.equal(result.status,502);assert.equal(c.calls.length,1);assert.equal(c.slot.status,"uncertain");
  assert.equal(result.body.diagnostic.receipt.run_id,"run123456789");assert.equal((await execute(c)).status,409);assert.equal(c.calls.length,1);
 }
});
test("wrong or multiple dataset rows cannot normalize into Compare evidence",async()=>{
 for(const rows of [[{...row,listingId:"wrong"}],[row,row],[]]){
  const c=fixture(),original=c.fetcher;c.fetcher=async(u,o)=>o.method==="POST"?original(u,o):Response.json(rows);
  assert.equal((await execute(c)).status,502);assert.equal(c.slot.status,"uncertain");
 }
});
test("uncertain ledger write failure preserves reserved state and does not offer retry",async()=>{
 const c=fixture();c.fetcher=async()=>{throw Error("secret");};c.ledger.update=async()=>{throw Error("private-ledger-error");};
 const r=await execute(c);assert.equal(r.body.test_status,"reserved_or_uncertain");assert.equal(c.slot.status,"reserved");
 assert.equal((await execute(c)).status,409);
});
test("HTTP/oversized/invalid JSON are fixed diagnostics with one start request",async()=>{
 for(const response of [()=>new Response("private",{status:401}),()=>new Response("x".repeat(262145)),()=>new Response("not json")]){
  const c=fixture();let n=0;c.fetcher=async()=>{n++;return response();};
  const r=await execute(c);assert.equal(r.status,502);assert.equal(n,1);assert.ok(!JSON.stringify(r).includes("private"));
 }
});
test("default backend endpoint accepts no browser URL/policy/key and never changes the Compare gate",()=>{
 const entry=readFileSync(new URL("../base44/functions/apify-listing-readiness/entry.ts",import.meta.url),"utf8");
 assert.match(entry,/k!=="action"/);assert.match(entry,/policy:APIFY_TEST_POLICY/);assert.match(entry,/secrets.get\("APIFY_API_TOKEN"\)/);
 const compare=readFileSync(new URL("../base44/functions/compare-listings/entry.ts",import.meta.url),"utf8");
 assert.match(compare,/resolveApprovedListings/);assert.doesNotMatch(compare,/apify/i);
});
const hook=registerHooks({resolve(s,c,next){
 if(s.startsWith("npm:@base44/sdk"))return {url:"data:text/javascript,"+encodeURIComponent('export const createClientFromRequest=()=>globalThis[Symbol.for("apify.endpoint.fixture")].client;'),shortCircuit:true};
 if(s==="base44:runtime")return {url:"data:text/javascript,"+encodeURIComponent('export const secrets={get:()=>{const c=globalThis[Symbol.for("apify.endpoint.fixture")];c.secretReads++;return "endpoint-fixture-secret";}};'),shortCircuit:true};
 return next(s,c);
}});
const {default:endpoint}=await import("../base44/functions/apify-listing-readiness/entry.ts");hook.deregister();
const request=body=>new Request("https://app.invalid/readiness",{method:"POST",body:JSON.stringify(body)});
test("actual endpoint authenticates before presence check and rejects browser control overrides",async()=>{
 for(const user of [null,{id:"u",role:"user"}]){
  const c=fixture();c.client.auth.me=async()=>user;globalThis[Symbol.for("apify.endpoint.fixture")]=c;
  assert.ok([401,403].includes((await endpoint(request({action:"status"}))).status));assert.equal(c.secretReads,0);
 }
 const c=fixture();globalThis[Symbol.for("apify.endpoint.fixture")]=c;
 assert.equal((await endpoint(request({action:"status",url:row.listingUrl}))).status,400);assert.equal(c.secretReads,0);
 const response=await endpoint(request({action:"status"})),data=await response.json();
 assert.equal(data.key_configured,true);assert.equal(data.enabled,false);assert.ok(!JSON.stringify(data).includes("endpoint-fixture-secret"));
 assert.equal((await endpoint(request({action:"run_approved_test"}))).status,409);assert.equal(c.slot.status,"ready");assert.equal(c.calls.length,0);
});
