import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { newListing, confirmListing, resetListing } from '../base44/shared/listing-intake.mjs';
import { NOW, MODEL, LISTING_ID, clone, completeData } from './listing-intake-fixtures.mjs';

// Static boundary checks only: no handler import/execution, network, or real provider.
// A missing source is visibly skipped, never represented as a verified pass.
const root = process.env.LISTING_INTAKE_SOURCE_ROOT || fileURLToPath(new URL('../', import.meta.url));
async function source(t, path) {
  try { return await readFile(resolve(root, path), 'utf8'); }
  catch (error) { if (error.code === 'ENOENT') { t.skip(`Source not materialized: ${path}`); return null; } throw error; }
}
const entryCode = text => text.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '').trim();
const generationFor = status => ({ status, operation_id: 'generation_fixture_01', reserved_at: NOW, profile_fingerprint: 'boundary_profile_fp', reservation: { record_revision: 1, scope: 'owner-dev-only' } });

async function wrapper(t) {
  return source(t, 'base44/functions/listing-intake-stage/entry.ts');
}

test('original suggest-boats entry only re-exports the shared handler and never pins DEV', async t => {
  const text = await source(t, 'base44/functions/suggest-boats/entry.ts'); if (!text) return;
  assert.match(entryCode(text), /^export\s*\{\s*default\s*\}\s*from\s*['"]\.\.\/\.\.\/shared\/suggest-boats-handler\.ts['"]\s*;?$/);
  assert.doesNotMatch(text, /X-Data-Env|['"]dev['"]|stage_generation|refresh\s*:/);
});

test('shared suggestion handler does not hardcode the DEV request environment', async t => {
  const text = await source(t, 'base44/shared/suggest-boats-handler.ts'); if (!text) return;
  assert.match(text, /export\s+default\s/);
  assert.doesNotMatch(text, /['"]X-Data-Env['"]\s*:\s*['"]dev['"]/i);
  assert.doesNotMatch(text, /\.set\(\s*['"]X-Data-Env['"]\s*,\s*['"]dev['"]\s*\)/i);
  assert.doesNotMatch(text, /stage_generation/, 'One-time generation authorization belongs to the isolated stage wrapper.');
});

test('stage generation pins DEV and passes only the fixed refresh body, never caller profile inputs', async t => {
  const text = await wrapper(t); if (!text) return;
  assert.match(text, /['"]X-Data-Env['"]/i);
  assert.match(text, /(?:\.set\(\s*['"]X-Data-Env['"]\s*,\s*['"]dev['"]|['"]X-Data-Env['"]\s*:\s*['"]dev['"])/i);
  assert.match(text, /suggestBoats\(devRequest\(req,\s*\{\s*refresh:\s*true\s*\}\)\)/);
  assert.match(text, /Object\.keys\(body\)\.some\(key => key !== 'action'\)/, 'Only the action selector is accepted; no caller profile/generation parameters.');
  assert.match(text, /return new Request\(req\.url,\s*\{ method: 'POST', headers, body: JSON\.stringify\(body\) \}\)/);
  assert.doesNotMatch(text, /\.\.\.\s*(?:body|input|payload|params)\b/);
  assert.match(text, /allowedStageCaller|owner_id/, 'A stage-only caller/owner guard is required.');
  assert.match(text, /loadIntakeContext|assertCurrentContext|profile_fingerprint/, 'Generation must retain the pinned profile/fixture context check.');
  assert.match(text, /record_id|fixture_id/, 'Generation must be scoped to one explicit fixture.');
});

test('stage wrapper reserves once before invoking the shared handler and never retries any existing generation', async t => {
  const text = await wrapper(t); if (!text) return;
  const handlerImport = text.match(/import\s+(\w+)\s+from\s*['"][^'"]*suggest-boats-handler\.ts['"]/);
  assert.ok(handlerImport, 'The stage wrapper must use the original shared handler, not a separate engine.');
  const handlerName = handlerImport[1], call = new RegExp(`\\b${handlerName}\\s*\\(`), callOffset = text.search(call);
  assert.ok(callOffset >= 0, 'The shared handler invocation must exist.');
  const prefix = text.slice(0, callOffset);
  assert.match(prefix, /stage_generation/);
  assert.match(prefix, /status\s*:\s*['"]reserved['"]/);
  assert.match(prefix, /await\s+(?:commitIntake|[^;\n]*updateMany)\s*\(/, 'The reservation must commit before calling the provider-backed handler.');
  assert.match(prefix, /if\s*\([^)]*stage_generation[^)]*\)/, 'Any saved generation, not only completed status, must stop another run.');
  assert.doesNotMatch(prefix, /stage_generation\??\.status\s*(?:===|==|!==|!=)\s*['"](?:failed|complete)['"]/, 'A failed/reserved generation must not become retryable.');
  assert.equal((text.match(new RegExp(`\\b${handlerName}\\s*\\(`, 'g')) || []).length, 1, 'Exactly one handler call site is allowed.');
  assert.doesNotMatch(text, /\b(?:retry|retries)\s*[:=]\s*[1-9]|setInterval\s*\(/i);
});

test('listing intake service cannot invoke stage generation or mutate User/BuyerProfile', async t => {
  const text = await source(t, 'base44/shared/listing-intake-service.mjs'); if (!text) return;
  assert.doesNotMatch(text, /suggest-boats-handler|functions\s*\.\s*(?:invoke|fetch)\s*\([^)]*(?:suggest|generation)/i);
  assert.doesNotMatch(text, /(?:User|BuyerProfile)\s*(?:\?\.)?\s*\.\s*(?:create|bulkCreate|update|updateMany|delete|deleteMany|upsert)\s*\(/);
  assert.doesNotMatch(text, /entities\s*\[\s*['"](?:User|BuyerProfile)['"]\s*\]\s*\.\s*(?:create|update|delete|upsert|updateMany)\s*\(/);
});

test('normal UI intake gate defaults to prod, while the private stage page opts into dev explicitly', async t => {
  const gate = await source(t, 'src/lib/listingIntakeAction.js'); if (!gate) return;
  assert.match(gate, /\bcanPreviewListingIntake\s*\([^)]*\b\w+\s*=\s*['"]prod['"]/);
  assert.match(gate, /(?:===\s*['"]dev['"]|!==\s*['"]dev['"])/);
  const page = await source(t, 'src/pages/AdminListingIntakeStage.jsx'); if (!page) return;
  assert.match(page, /useListingIntake\s*\(\s*['"]dev['"]\s*\)/);
  assert.match(page, /<MatchResultsShowcase\b/, 'The stage must use the same existing Match result cards.');
  assert.doesNotMatch(page, /<Compare\b/, 'The isolated preview must not mount side-effectful Compare.');
});

for (const status of ['reserved', 'failed', 'complete']) {
  test(`${status} stage generation authorization survives new listing, confirmation and reset unchanged`, async () => {
    const data = completeData(), generation = generationFor(status); data.stage_generation = clone(generation);
    const initial = clone(data);
    const added = newListing(data, MODEL, 'boundary_second_listing', '', NOW);
    assert.deepEqual(data, initial); assert.deepEqual(added.stage_generation, generation);
    const confirmed = await confirmListing(added, LISTING_ID, { budget: 50000 }, 'boundary_profile_fp', NOW);
    assert.deepEqual(confirmed.stage_generation, generation);
    const savedSnapshot = clone(confirmed.listings.find(card => card.id === LISTING_ID).versions[0]);
    const reset = resetListing(confirmed, LISTING_ID, true, NOW);
    assert.deepEqual(reset.stage_generation, generation);
    assert.deepEqual(reset.listings.find(card => card.id === LISTING_ID).versions[0], savedSnapshot);
    assert.deepEqual(reset.listings.find(card => card.id === 'boundary_second_listing'), added.listings.find(card => card.id === 'boundary_second_listing'));
    reset.stage_generation.reservation.scope = 'mutated-test-copy';
    assert.deepEqual(data.stage_generation, generation); assert.deepEqual(confirmed.stage_generation, generation);
  });
}
