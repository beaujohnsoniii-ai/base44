import test from "node:test";
import assert from "node:assert/strict";
import { isApprovedListingUrl, resolveApprovedListing } from "../base44/shared/approved-listing-resolver.mjs";

test("approved domains are recognized and unapproved or unsafe URLs are rejected",()=>{
  assert.ok(isApprovedListingUrl("https://www.boats.com/boat/123"));
  assert.ok(isApprovedListingUrl("https://www.boattrader.com/boat/2020-test-123/"));
  assert.ok(isApprovedListingUrl("https://www.yachtworld.com/boat/123"));
  assert.equal(isApprovedListingUrl("https://dealer.com/boat/123"),null);
  assert.equal(isApprovedListingUrl("https://localhost/boat"),null);
  assert.equal(isApprovedListingUrl("not a url"),null);
});

test("non-approved URL returns unsupported_source without fetching",async()=>{
  const original=globalThis.fetch;
  globalThis.fetch=()=>{throw Error("must not fetch");};
  try{
    const result=await resolveApprovedListing({},{url:"https://dealer.com/boat/123"},null);
    assert.equal(result.status,"unsupported_source");
    assert.equal(result.eligible,false);
    assert.ok(result.unknowns.some(u=>/saved but not imported/i.test(u)));
  } finally { globalThis.fetch=original; }
});

test("fetch failure returns fetch_failed with saved link warning",async()=>{
  const original=globalThis.fetch;
  globalThis.fetch=()=>Promise.resolve(new Response("",{status:403}));
  try{
    const result=await resolveApprovedListing({},{url:"https://www.boattrader.com/boat/2020-test-123/"},null);
    assert.equal(result.status,"fetch_failed");
    assert.equal(result.eligible,false);
    assert.ok(result.unknowns.some(u=>/saved but the page could not be read/i.test(u)));
  } finally { globalThis.fetch=original; }
});

test("approved source with JSON-LD produces extracted facts",async()=>{
  const original=globalThis.fetch;
  const html='<html><body>For sale | Make: Test | Model: 23 | Year: 2020 | Price: USD 50,000 | Engine-down draft: 1.1 ft | Capacity: 6 persons | Stock #: 3928 | This is a test listing page with enough content to pass the minimum length check for extraction.</body><script type="application/ld+json">{"@type":"Vehicle","url":"https://www.boattrader.com/boat/2020-test-123/","brand":{"name":"Test"},"model":"23","vehicleModelDate":"2020","offers":{"price":50000,"priceCurrency":"USD"}}</script></html>';
  globalThis.fetch=()=>Promise.resolve(new Response(html,{headers:{"content-type":"text/html"}}));
  try{
    const result=await resolveApprovedListing({purchase_budget_max:85000},{url:"https://www.boattrader.com/boat/2020-test-123/",expected_make:"Test",expected_model:"23"},null);
    assert.equal(result.status,"partial_evidence");
    assert.equal(result.facts.make.value,"Test");
    assert.equal(result.facts.year.value,2020);
    assert.equal(result.facts.asking_price.value,50000);
    assert.equal(result.eligible,false);
    assert.ok(result.resolution.source_url);
  } finally { globalThis.fetch=original; }
});