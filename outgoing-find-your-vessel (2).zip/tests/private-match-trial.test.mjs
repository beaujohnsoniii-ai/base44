import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { screenTrialPhysical, evaluateTrialMarket, runPrivateMatchTrial } from "../base44/shared/private-match-trial.mjs";
const profile = { id: "synthetic-unit-test", hard_max_overall_length_ft: 26, purchase_budget_min: 99000, purchase_budget_max: 207500 };
const e = { value: 27, unit: "ft", status: "verified", applicability: "applicable", measurement_basis: "rigged_overall", source_url: "https://manufacturer.example/spec", source_quote: "Rigged length 27 ft", verified_at: "2026-10-15" };
const boat = field => ({ id: "synthetic-unit-test", field_evidence: { overall_length_ft: field } });
test("only verified applicable over-limit measurement excludes", () => {
  assert.equal(screenTrialPhysical(boat(e),profile).excluded,true);
  for (const patch of [{status:"estimated"},{status:"conflicting"},{status:"missing"},{applicability:"unclear"},{measurement_basis:"hull"},{source_url:null},{source_quote:""},{verified_at:null},{value:"27"},{unit:"m"}]) {
    assert.equal(screenTrialPhysical(boat({...e,...patch}),profile).excluded,false);
    assert.equal(screenTrialPhysical(boat({...e,...patch}),profile).status,"provisional");
  }
});
test("at limit passes only named limits; no implicit draft/towing cap", () => {
  assert.equal(screenTrialPhysical(boat({...e,value:26}),profile).status,"verified_limits_within");
  assert.equal(screenTrialPhysical(boat(null),{draft:"2'",tow_capacity_lb:1000,storage:"private_dock"}).status,"no_structured_limits");
});
const comp = (price,key,patch={}) => ({source_url:"https://broker.example/"+key,retrieved_at:"2026-10-15",currency:"USD",asking_price:price,dedup_key:key,match_status:"matched",...patch});
const market = prices => ({comparables:prices.map((p,i)=>comp(p,String(i)))});
test("both endpoints affect fit; lower edge cannot hide upper over-budget price", () => {
  assert.equal(evaluateTrialMarket(market([100000,150000,200000]),profile).budget_state,"fully_within");
  assert.equal(evaluateTrialMarket(market([100000,180000,250000]),profile).budget_state,"overlaps");
  assert.equal(evaluateTrialMarket(market([220000,230000,250000]),profile).budget_state,"over_budget");
  assert.equal(evaluateTrialMarket(market([80000,85000,90000]),profile).budget_state,"below_budget_minimum");
  assert.equal(evaluateTrialMarket(market([80000,100000,150000]),profile).budget_state,"overlaps");
});
test("thin missing and unmatched prices stay provisional; no static-price fallback", () => {
  assert.equal(evaluateTrialMarket(market([150000]),profile).provisional,true);
  assert.equal(evaluateTrialMarket({price_usd:100000},profile).budget_state,"unknown");
  const r=evaluateTrialMarket({comparables:[comp(100000,"a"),comp(200000,"a"),comp(120000,"b",{currency:"EUR"}),comp(130000,"c",{match_status:"uncertain"}),comp(140000,"d",{retrieved_at:"2025-10-15"})]},profile);
  assert.equal(r.comparable_count,1); assert.equal(r.low,100000); assert.equal(r.high,100000); assert.equal(r.comparables.length,5);
});
test("retains raw evidence and does not exclude unknown budget", () => {
  const r=runPrivateMatchTrial(profile,[boat({...e,status:"estimated"})]);
  assert.equal(r.results[0].field_evidence.overall_length_ft.status,"estimated");
  assert.equal(r.results[0].physical.excluded,false);
  assert.equal(r.provider_calls,0); assert.equal(r.entity_writes,0); assert.equal(r.automated_hybrid,false);
  assert.throws(()=>runPrivateMatchTrial({},[boat(e)]));
  assert.throws(()=>runPrivateMatchTrial(profile,Array(16).fill(boat(e))));
});
test("trial evaluator cannot call providers or mutate entities", () => {
  const text=readFileSync(new URL("../base44/shared/private-match-trial.mjs",import.meta.url),"utf8");
  assert.doesNotMatch(text,/fetch\s*\(|InvokeLLM|createClient|\.entities\.|Deno\.env/);
});
