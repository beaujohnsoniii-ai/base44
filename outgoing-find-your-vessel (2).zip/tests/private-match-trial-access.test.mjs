import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import ts from "typescript";
const source = readFileSync(new URL("../base44/functions/private-match-trial/entry.ts",import.meta.url),"utf8");
const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
function harness(user, owner="owner") {
  let reads=0, runs=0;
  const exports={};
  const profile={id:"selected-profile",created_by_id:owner};
  const require=name=>{
    if(name.startsWith("npm:@base44/sdk")) return {createClientFromRequest:()=>({auth:{me:async()=>{if(user instanceof Error)throw user;return user;}},entities:{BuyerProfile:{filter:async()=>{reads++;return[profile];}}}})};
    if(name.includes("private-match-fixture")) return {default:{confirmed_buyer_profile:"selected-profile",boats:[],as_of:"2026-10-15",source_master:{},scope:"test",complete_boat_files:0}};
    if(name.includes("private-match-trial")) return {runPrivateMatchTrial:()=>{runs++;return{provider_calls:0,entity_writes:0};}};
    throw Error("Unexpected dependency "+name);
  };
  new Function("exports","require",compiled)(exports,require);
  return {call:(body={},method="POST")=>exports.default(new Request("https://trial.example",{method,...(method==="POST"?{body:JSON.stringify(body)}:{})})),counts:()=>({reads,runs})};
}
test("anonymous non-admin and wrong-method calls cannot read buyer data",async()=>{
 for(const [user,status] of [[new Error("unauthorized"),401],[{id:"owner",role:"user"},403],[null,403]]){
   const h=harness(user);assert.equal((await h.call()).status,status);assert.deepEqual(h.counts(),{reads:0,runs:0});
 }
 const h=harness({id:"owner",role:"admin"});assert.equal((await h.call({},"GET")).status,405);assert.equal(h.counts().reads,0);
});
test("selected profile is bound and must belong to authenticated admin",async()=>{
 const h=harness({id:"owner",role:"admin"});assert.equal((await h.call({profile_id:"other"})).status,400);assert.equal(h.counts().reads,0);
 const wrong=harness({id:"owner",role:"admin"},"different");assert.equal((await wrong.call()).status,404);assert.equal(wrong.counts().runs,0);
 const ok=harness({id:"owner",role:"admin"});assert.equal((await ok.call()).status,200);assert.deepEqual(ok.counts(),{reads:1,runs:1});
});
test("endpoint and frontend are isolated from live paid and customer-mutating flows",()=>{
 assert.doesNotMatch(source,/asServiceRole|\.create\(|\.update\(|\.delete\(|InvokeLLM|fetch\(|Deno\.env/);
 const page=readFileSync(new URL("../src/pages/AdminPrivateMatchTrial.jsx",import.meta.url),"utf8");
 assert.match(page,/user\?\.role !== "admin"/);
 assert.doesNotMatch(page,/invoke\("(?:suggest-boats|run-match-qa|generate-advisory)"/);
 assert.doesNotMatch(page,/private-match-fixture/);
});
