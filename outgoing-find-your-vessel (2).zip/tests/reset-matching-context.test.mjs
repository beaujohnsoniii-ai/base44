import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
const source=fs.readFileSync("base44/functions/reset-matching-context/entry.ts","utf8");
const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const requestId="6cb89b21-39a4-465a-9d3b-d8d84f6d5c86";
function fixture({unauthorized=false,ignored=false,lost=false,race=false}={}){
 let row={id:"p",created_by_id:"buyer",match_context_id:"old",activity_weights:{Fishing:79,Entertaining:21},liked_models:[{title:"Saved favorite"}],research_notes:"Keep",advisor_credit:29},writes=0;
 const original=structuredClone(row);
 const entities={BuyerProfile:{filter:async q=>{assert.deepEqual(q,{created_by_id:"buyer"});return [structuredClone(row)];},updateMany:async(q,u)=>{writes++;assert.equal(q.id,"p");assert.equal(q.created_by_id,"buyer");assert.deepEqual(Object.keys(u.$set),["match_context_id"]);if(race){row.match_context_id="concurrent";return {updated:0};}if(!ignored)row.match_context_id=u.$set.match_context_id;if(lost)throw Error("response lost");return {updated:1};}}};
 const client={auth:{me:async()=>{if(unauthorized)throw Error("auth");return {id:"buyer"};}},asServiceRole:{entities}};
 const exports={};new Function("exports","require",js)(exports,()=>({createClientFromRequest:()=>client}));
 const invoke=(body={})=>exports.default(new Request("https://example.invalid/reset",{method:"POST",body:JSON.stringify({buyer_profile_id:"p",expected_context_id:"old",request_id:requestId,...body}),headers:{"Content-Type":"application/json"}}));
 return {invoke,row,original,writes:()=>writes};
}
test("actual Reset entrypoint persists only context and verifies before acknowledgement",async()=>{
 const h=fixture();const response=await h.invoke();assert.equal(response.status,200);const data=await response.json();assert.equal(data.matching_context_version,"reset-matching-context-v1");assert.equal(data.reset_context_applied,true);assert.equal(data.request_id,requestId);assert.equal(data.profile.match_context_id,requestId);assert.deepEqual({...h.row,match_context_id:"old"},h.original);assert.equal(h.writes(),1);
});
test("same Reset request is idempotent after successful or response-lost persistence",async()=>{
 for(const lost of [false,true]){const h=fixture({lost});assert.equal((await h.invoke()).status,lost?503:200);assert.equal((await h.invoke()).status,200);assert.equal(h.writes(),1);}
});
test("Reset refuses unauthorized, wrong profile, changed context and invalid request IDs without writes",async()=>{
 const unauth=fixture({unauthorized:true});assert.equal((await unauth.invoke()).status,401);assert.equal(unauth.writes(),0);
 for(const [body,status] of [[{buyer_profile_id:"other"},409],[{expected_context_id:"stale"},409],[{request_id:"invalid"},400]]){const h=fixture();assert.equal((await h.invoke(body)).status,status);assert.equal(h.writes(),0);}
});
test("ignored writes and competing context changes never acknowledge Reset success",async()=>{
 const ignored=fixture({ignored:true});assert.equal((await ignored.invoke()).status,503);assert.deepEqual(ignored.row,ignored.original);
 const race=fixture({race:true});assert.equal((await race.invoke()).status,409);assert.equal(race.row.match_context_id,"concurrent");
});
test("Reset ignores submitted answers and accounting and never generates",async()=>{
 const h=fixture();assert.equal((await h.invoke({activity_weights:{Fishing:0},liked_models:[],advisor_credit:999})).status,200);assert.deepEqual({...h.row,match_context_id:"old"},h.original);assert.doesNotMatch(source,/suggest-boats|generateRecommendations|\.delete\(/);
});
