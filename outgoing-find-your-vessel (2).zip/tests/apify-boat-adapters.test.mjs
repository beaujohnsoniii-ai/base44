import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {APIFY_LISTING_RUNTIME,planApifyListingRequest,normalizeApifyBoatRow,assessApifyBoatRow} from "../base44/shared/apify-boat-adapters.mjs";
const fixture=JSON.parse(readFileSync(new URL("./fixtures/apify-boat-rows.json",import.meta.url)));
const yw=fixture.yachtworld,bt=fixture.boattrader;
test("default is disabled and request planning never invokes any transport",()=>{
 assert.equal(APIFY_LISTING_RUNTIME.enabled,false);
 const p=planApifyListingRequest("yachtworld",{url:yw.listingUrl});
 assert.equal(p.executable,false);assert.equal(p.actor_id,"getascraper/yachtworld-scraper");
 assert.deepEqual(p.input,{startUrls:[{url:yw.listingUrl}],fetchDetails:true,maxItems:1,onlyNewOrChanged:false,proxyConfiguration:{useApifyProxy:false}});
 for(const url of ["https://www.yachtworld.com/boats-for-sale/","https://www.yachtworld.com.evil.test/yacht/2019-key-west-239-dfs-10260699/","http://www.yachtworld.com/yacht/2019-key-west-239-dfs-10260699/","https://user:pass@www.yachtworld.com/yacht/2019-key-west-239-dfs-10260699/",yw.listingUrl+"?token=secret"])
  assert.throws(()=>planApifyListingRequest("yachtworld",{url}));
 assert.throws(()=>planApifyListingRequest("yachtworld",{url:yw.listingUrl,maxItems:300}));
});
test("Copious cannot turn an exact saved URL into broad discovery",()=>{
 const p=planApifyListingRequest("boattrader",{url:bt.listing_url});
 assert.equal(p.mode,"unsupported_exact_link");assert.equal(p.input,null);
 const discovery=planApifyListingRequest("boattrader",{boatType:"fishing",minPrice:10000,maxPrice:50000});
 assert.deepEqual(discovery.input,{boatType:"fishing",maxPages:1,minPrice:10000,maxPrice:50000});
 assert.equal(discovery.executable,false);assert.throws(()=>planApifyListingRequest("boattrader",{maxPages:50}));
 assert.throws(()=>planApifyListingRequest("boattrader",{minPrice:500,maxPrice:100}));
});
test("YachtWorld optional string fields produce bounded Actor evidence, no borrowed make",()=>{
 const r=normalizeApifyBoatRow("yachtworld",yw,{requested_url:yw.listingUrl});
 assert.equal(r.exact_listing,true);assert.equal(r.nullable_facts.year,2019);assert.equal(r.nullable_facts.engine_hours,250);
 assert.equal(r.nullable_facts.overall_length_ft,23.8);assert.equal(r.nullable_facts.make,null);assert.equal(r.nullable_facts.model,"239 DFS");
 assert.equal(r.nullable_facts.asking_price,54995);assert.equal(r.nullable_facts.asking_price_currency,"USD");
 assert.equal(r.field_evidence.find(f=>f.field==="engine_hours").raw_value,"250");
 assert.equal(r.provenance.live_retrieval_verified,false);assert.equal(r.eligible,false);
});
test("Copious retains discovery facts and documented USD but never invents hours or exact matching",()=>{
 const r=normalizeApifyBoatRow("boattrader",{...bt,engineHours:999},{requested_url:bt.listing_url});
 assert.equal(r.status,"discovery_only");assert.equal(r.exact_listing,false);
 assert.equal(r.nullable_facts.make,"Boston Whaler");assert.equal(r.nullable_facts.asking_price_currency,"USD");assert.equal(r.nullable_facts.engine_hours,null);
 assert.equal(r.field_evidence.find(f=>f.field==="asking_price_currency").currency_basis,"Actor documentation specifies USD");
});
test("missing, invalid, ambiguous and zero hours remain honest",()=>{
 for(const engineHours of [undefined,null,"","unknown","250/300","1,200","-1","250 miles"]){
  const r=normalizeApifyBoatRow("yachtworld",{...yw,engineHours,price:0,priceCurrency:""});
  assert.equal(r.nullable_facts.engine_hours,null);assert.equal(r.nullable_facts.asking_price,null);
 }
 assert.equal(normalizeApifyBoatRow("yachtworld",{...yw,engineHours:"0"}).nullable_facts.engine_hours,0);
 for(const lengthFt of ["23.8","7.3 m","23-24 ft",""] )assert.equal(normalizeApifyBoatRow("yachtworld",{...yw,lengthFt}).nullable_facts.overall_length_ft,null);
});
test("wrong IDs, domains and years cannot establish requested boat; nearby boats never substitute",()=>{
 for(const change of [{listingId:"999"},{listingUrl:"https://evil.test/yacht/2019-key-west-239-dfs-10260699/"},{listingUrl:"https://www.yachtworld.com/boats-for-sale/"}]){
  const r=normalizeApifyBoatRow("yachtworld",{...yw,...change},{requested_url:yw.listingUrl});
  assert.equal(r.exact_listing,false);assert.ok(Object.values(r.nullable_facts).every(v=>v===null));
 }
 assert.equal(normalizeApifyBoatRow("yachtworld",{...yw,year:"2024"},{requested_url:yw.listingUrl}).exact_listing,false);
 const r=assessApifyBoatRow({}, {url:yw.listingUrl.replace("10260699","10260698")},"yachtworld",yw);
 assert.deepEqual(r.facts,{});assert.equal(r.eligible,false);
 assert.throws(()=>normalizeApifyBoatRow("yachtworld",{...yw,description:"x".repeat(65537)}));
});
test("Compare bridge preserves unknown identity, currency and measurement boundaries",()=>{
 const input={url:yw.listingUrl,expected_make:"Key West",expected_model:"239 DFS"};
 const r=assessApifyBoatRow({purchase_budget_max:60000,hard_max_overall_length_ft:24,tow_capacity_lb:8000},input,"yachtworld",yw);
 assert.equal(r.facts.make,undefined);assert.equal(r.facts.year.value,2019);assert.equal(r.facts.engine_hours.value,250);
 assert.equal(r.checks.find(c=>c.criterion==="Rigged overall length").status,"unknown");
 assert.equal(r.checks.find(c=>c.criterion==="Trailering weight").status,"unknown");assert.equal(r.eligible,false);
 assert.equal(r.facts.engine_hours.provenance,"unverified_actor_listing_claim");
 const eur=assessApifyBoatRow({purchase_budget_max:60000},input,"yachtworld",{...yw,priceCurrency:"EUR"});
 assert.equal(eur.checks.find(c=>c.criterion==="Asking-price budget").status,"unknown");
 const discovery=assessApifyBoatRow({}, {url:bt.listing_url},"boattrader",bt);assert.deepEqual(discovery.facts,{});
});
test("production Compare resolver remains separate from disabled Apify adapter",()=>{
 const source=readFileSync(new URL("../base44/functions/compare-listings/entry.ts",import.meta.url),"utf8");
 assert.match(source,/resolveApprovedListings/);assert.doesNotMatch(source,/apify/i);
 const adapter=readFileSync(new URL("../base44/shared/apify-boat-adapters.mjs",import.meta.url),"utf8");
 assert.doesNotMatch(adapter,/\bfetch\s*\(|secrets\.get|functions\.invoke|entities\./);
});
