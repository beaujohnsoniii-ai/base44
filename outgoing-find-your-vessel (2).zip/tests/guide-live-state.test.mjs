// No-network component-state evidence, not DOM/browser/live-SDK evidence.
// Run: node guide-component-state.mjs [path/to/FloatingGuide.jsx]
// This executes the component's actual handlers with isolated dependency stubs.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import test from 'node:test';

const sourcePath = 'src/components/FloatingGuide.jsx';
const compiled = ts.transpileModule(fs.readFileSync(sourcePath, 'utf8'), {
  compilerOptions: {
    jsx: ts.JsxEmit.React,
    module: ts.ModuleKind.CommonJS,
    target: ts.ScriptTarget.ES2022,
  },
}).outputText;

function deferred() {
  let resolve, reject;
  const promise = new Promise((a, b) => { resolve = a; reject = b; });
  return { promise, resolve, reject };
}

function harness(overrides = {}) {
  let auth = { user: { id: 'buyer-a' }, isAuthenticated: true };
  let location = { pathname: '/my-matches', key: 'one' };
  let slots = [], cursor = 0, pending = [], dirty = true, tree;
  const calls = [], subscriptions = [];
  const makeCall = (name, fn) => (...args) => {
    calls.push({ name, args });
    return fn(...args);
  };
  const defaults = {
    listConversations: async () => [],
    createConversation: async () => ({ id: 'test-conversation', messages: [] }),
    getConversation: async () => ({ id: 'test-conversation', messages: [] }),
    addMessage: async () => {},
    subscribeToConversation: (id, callback) => {
      const sub = { id, callback, active: true };
      subscriptions.push(sub);
      return () => { sub.active = false; };
    },
  };
  const agents = Object.fromEntries(Object.entries(defaults).map(([name, fn]) => [
    name, makeCall(name, overrides[name] || fn),
  ]));
  const block = () => { throw new Error('Network or unexpected capability requested'); };

  const useState = initial => {
    const i = cursor++;
    if (!slots[i]) slots[i] = {
      kind: 'state', value: typeof initial === 'function' ? initial() : initial,
    };
    const slot = slots[i];
    assert.equal(slot.kind, 'state');
    return [slot.value, value => {
      const next = typeof value === 'function' ? value(slot.value) : value;
      if (!Object.is(next, slot.value)) { slot.value = next; dirty = true; }
    }];
  };
  const useRef = initial => {
    const i = cursor++;
    if (!slots[i]) slots[i] = { kind: 'ref', value: { current: initial } };
    assert.equal(slots[i].kind, 'ref');
    return slots[i].value;
  };
  const useEffect = (fn, deps) => {
    const i = cursor++;
    let slot = slots[i];
    if (!slot) slot = slots[i] = { kind: 'effect', deps: undefined, cleanup: undefined };
    assert.equal(slot.kind, 'effect');
    if (!deps || !slot.deps || deps.length !== slot.deps.length ||
      deps.some((value, index) => !Object.is(value, slot.deps[index]))) {
      pending.push({ slot, fn, deps });
    }
  };
  const React = {
    createElement: (type, props, ...children) => ({ type, props: { ...props, children } }),
  };
  const modules = {
    react: { __esModule: true, default: React, useState, useRef, useEffect },
    'react-router-dom': { Link: 'Link', useLocation: () => location },
    '@radix-ui/react-dialog': Object.fromEntries(
      ['Root', 'Portal', 'Overlay', 'Content', 'Title', 'Description', 'Close']
        .map(name => [name, 'Dialog.' + name]),
    ),
    'lucide-react': Object.fromEntries(
      ['Compass', 'ArrowUp', 'X', 'Sparkles'].map(name => [name, name]),
    ),
    '@/lib/AuthContext': { useAuth: () => auth },
    '@/api/base44Client': { base44: { agents } },
    '@/components/GuideLauncher': { __esModule: true, default: 'GuideLauncher' },
    '@/components/guide-panel.css': {},
  };
  const output = {};
  new vm.Script(compiled, { filename: sourcePath }).runInNewContext({
    exports: output,
    require: name => {
      if (!(name in modules)) throw new Error('Unexpected import ' + name);
      return modules[name];
    },
    fetch: block,
    WebSocket: class { constructor() { block(); } },
    XMLHttpRequest: class { constructor() { block(); } },
  });

  function flush() {
    for (let n = 0; dirty; n++) {
      assert.ok(n < 12, 'Render/effect loop');
      dirty = false;
      cursor = 0;
      pending = [];
      tree = output.default();
      const effects = pending;
      for (const { slot } of effects) slot.cleanup?.();
      for (const { slot, fn, deps } of effects) {
        slot.deps = deps;
        slot.cleanup = fn();
      }
    }
    return tree;
  }
  const walk = node => Array.isArray(node)
    ? node.flatMap(walk)
    : node && typeof node === 'object' ? [node, ...walk(node.props?.children)] : [];
  const nodes = () => walk(flush());
  const find = (type, predicate = () => true) => nodes()
    .find(node => node.type === type && predicate(node.props));
  const text = node => Array.isArray(node)
    ? node.map(text).join(' ')
    : node && typeof node === 'object' ? text(node.props?.children) : String(node ?? '');
  flush();
  return {
    calls, subscriptions, nodes, find, flush,
    text: () => text(flush()),
    count: name => calls.filter(call => call.name === name).length,
    open: () => { find('GuideLauncher').props.onToggle(); flush(); },
    type: value => { find('input').props.onChange({ target: { value } }); flush(); },
    submit: () => find('form').props.onSubmit({ preventDefault() {} }),
    auth: value => { auth = value; dirty = true; flush(); },
    navigate: () => {
      location = { pathname: '/compare', key: 'two' };
      dirty = true;
      flush();
    },
    input: () => find('input'),
    root: () => find('Dialog.Root'),
  };
}

const check = test;

await check('Open and prompt selection never call SDK', async () => {
  const h = harness();
  h.open();
  assert.equal(h.root().props.open, true);
  assert.equal(h.calls.length, 0);
  h.find('button', props => props.children.includes('Why this match?')).props.onClick();
  assert.match(h.input().props.value, /strongest match/);
  assert.equal(h.input().props.maxLength, 600);
  assert.equal(h.calls.length, 0);
});

await check('Rapid submissions share one in-flight send; busy input is disabled', async () => {
  const gate = deferred();
  const h = harness({ listConversations: () => gate.promise });
  h.open();
  h.type('My question');
  const first = h.submit();
  const second = h.submit();
  assert.equal(h.count('listConversations'), 1);
  const disabled = h.input().props.disabled;
  gate.resolve([]);
  await Promise.all([first, second]);
  h.flush();
  assert.equal(h.count('addMessage'), 1);
  assert.equal(h.input().props.value, '');
  assert.equal(disabled, true);
});

await check('Unauthenticated open has no input/prompts and no SDK work', async () => {
  const h = harness();
  h.auth({ user: null, isAuthenticated: false });
  h.open();
  assert.equal(h.input(), undefined);
  assert.equal(h.find('form'), undefined);
  assert.equal(h.find('button', props => props.children.includes('Why this match?')), undefined);
  assert.ok(h.find('Link'));
  assert.equal(h.calls.length, 0);
});

await check('Programmatic over-limit input is rejected; 600 characters are accepted', async () => {
  const h = harness();
  h.open();
  h.type('x'.repeat(601));
  await h.submit();
  assert.equal(h.calls.length, 0);
  assert.match(h.text(), /Keep your question to 600/);
  h.type('x'.repeat(600));
  await h.submit();
  assert.equal(h.count('addMessage'), 1);
  const message = h.calls.find(call => call.name === 'addMessage').args[1];
  assert.equal(message.content.length, 600);
  assert.equal(message.custom_context[0].data.path, '/my-matches');
});

await check('Failed send retains draft and does not retry automatically', async () => {
  const h = harness({ addMessage: async () => { throw new Error('Synthetic local failure'); } });
  h.open();
  h.type('Retain my draft');
  await h.submit();
  assert.equal(h.input().props.value, 'Retain my draft');
  assert.match(h.text(), /could not send/);
  assert.equal(h.find('button', props => props.type === 'submit').props.disabled, false);
  assert.equal(h.count('addMessage'), 1);
});

await check('Refresh failure reports sent state, not resend advice', async () => {
  const h = harness({ getConversation: async () => { throw new Error('Synthetic refresh failure'); } });
  h.open();
  h.type('One accepted question');
  await h.submit();
  assert.equal(h.input().props.value, '');
  assert.match(h.text(), /question was sent/);
  assert.equal(h.count('addMessage'), 1);
});

await check('User change invalidates pending conversation lookup', async () => {
  const gate = deferred();
  const h = harness({ listConversations: () => gate.promise });
  h.open();
  h.type('Do not send for another user');
  const request = h.submit();
  h.auth({ user: { id: 'buyer-b' }, isAuthenticated: true });
  gate.resolve([]);
  await request;
  assert.equal(h.count('createConversation'), 0);
  assert.equal(h.count('addMessage'), 0);
  assert.equal(h.root().props.open, false);
  assert.equal(h.input().props.value, '');
});

await check('Auth-only invalidation stops pending sends with same cached user id', async () => {
  const gate = deferred();
  const h = harness({ listConversations: () => gate.promise });
  h.open();
  h.type('Do not send after logout');
  const request = h.submit();
  h.auth({ user: { id: 'buyer-a' }, isAuthenticated: false });
  gate.resolve([]);
  await request;
  assert.equal(h.count('createConversation'), 0);
  assert.equal(h.count('addMessage'), 0);
  assert.equal(h.root().props.open, false);
});

await check('Auth-only invalidation clears conversation and subscription', async () => {
  const h = harness();
  h.open();
  h.type('Load conversation');
  await h.submit();
  h.flush();
  assert.equal(h.subscriptions.length, 1);
  const sub = h.subscriptions[0];
  sub.callback({ messages: [{ id: 'private', role: 'assistant', content: 'PRIVATE TEST SENTINEL' }] });
  assert.match(h.text(), /PRIVATE TEST SENTINEL/);
  h.auth({ user: { id: 'buyer-a' }, isAuthenticated: false });
  assert.equal(sub.active, false);
  assert.equal(h.root().props.open, false);
  sub.callback({ messages: [{ id: 'late', role: 'assistant', content: 'LATE TEST SENTINEL' }] });
  assert.doesNotMatch(h.text(), /PRIVATE TEST SENTINEL|LATE TEST SENTINEL/);
});

await check('Close and route-key navigation never submit', async () => {
  const h = harness();
  h.open();
  h.root().props.onOpenChange(false);
  assert.equal(h.root().props.open, false);
  h.open();
  h.navigate();
  assert.equal(h.root().props.open, false);
  assert.equal(h.calls.length, 0);
});
