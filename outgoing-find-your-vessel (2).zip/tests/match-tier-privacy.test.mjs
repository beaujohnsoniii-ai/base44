import test from "node:test";
import assert from "node:assert/strict";
import { isPaidPlan, tierRank } from "../base44/shared/stages.ts";
import { generateRecommendations, tierBudgetSummary, dedupeModelSuggestions } from "../base44/shared/suggest-engine.ts";
import {
  DEFAULT_MATCH_PLUS_FIELDS,
  DEFAULT_REFINED_MATCH_FIELDS,
  DEFAULT_MARKET_MATCH_FIELDS,
} from "../base44/shared/question-tiers.ts";

test("only recognized paid tiers grant paid-plan status", () => {
  for (const plan of [null, "", "free", "unknown", "expired", "trial"])
    assert.equal(isPaidPlan(plan), false, `unexpected paid status for ${plan}`);
  for (const plan of ["match_plus", "refined_match", "market_match", "initial_boat_match", "buyer_pass"])
    assert.equal(isPaidPlan(plan), true, `missing paid status for ${plan}`);
  assert.equal(tierRank("unrecognized_plan"), 0);
});

const tiers = {
  matchPlus: new Set(DEFAULT_MATCH_PLUS_FIELDS),
  refinedMatch: new Set(DEFAULT_REFINED_MATCH_FIELDS),
  marketMatch: new Set(DEFAULT_MARKET_MATCH_FIELDS),
};

test("same make/model across model years and repeated passes appears once", () => {
  const boats = [
    { make: " Parker ", model: " 2520", year: 2005 },
    { make: "parker", model: "2520 ", year: 2016 },
    { make: "Parker", model: "  2530 ", year: 2007 },
  ];
  assert.equal(dedupeModelSuggestions(boats).length, 2);
});

test("model identities require both make and model and collapse simple separator variations", () => {
  const boats = [
    { title: "Ambiguous", make: "", model: "" },
    { title: "Parker 2520-XLD", make: "Parker", model: "2520-XLD" },
    { title: "Parker 2520 XLD", make: "PARKER", model: "2520 XLD" },
    { title: "Parker 2520 XL", make: "Parker", model: "2520 XL" },
  ];
  assert.deepEqual(dedupeModelSuggestions(boats).map(s => s.model), ["2520-XLD", "2520 XL"]);
});

test("invalid model identities trigger a second search instead of reaching buyer results", async () => {
  let calls = 0;
  const client = { asServiceRole: { integrations: { Core: { InvokeLLM: async () => {
    calls++;
    return { suggestions: calls === 1
      ? [{ title: "Unidentified boat", make: "", model: "" }]
      : [{ title: "Parker 2530", make: "Parker", model: "2530" }] };
  } } } } };
  const result = await generateRecommendations(client, {
    profile: { purchase_budget_max: 100000 }, plan: "free", tierFields: tiers,
    manufacturerMap: { brief: "", list: [] }, likedModels: [], savedBoats: [],
    existingSuggestions: [], isFirstPaidGeneration: false, hadContradiction: false,
    refresh: false, contradictionRerunCount: 0,
  });
  assert.equal(calls, 2);
  assert.deepEqual(result.suggestions.map(s => [s.make, s.model]), [["Parker", "2530"]]);
});

test("the live MATCH engine deduplicates both generation passes", async () => {
  let calls = 0;
  const client = { asServiceRole: { integrations: { Core: {
    InvokeLLM: async () => {
      calls++;
      const boats = calls === 1
        ? [{ title: "Parker 2520", make: "Parker", model: "2520", asking_price: 50000 },
           { title: "Parker 2520 2016", make: "PARKER", model: " 2520 ", asking_price: 55000 }]
        : [{ title: "Parker 2520", make: "Parker", model: "2520", asking_price: 50000 },
           { title: "Parker 2530", make: "Parker", model: "2530", asking_price: 60000 }];
      return { suggestions: boats };
    },
  } } } };
  const result = await generateRecommendations(client, {
    profile: { purchase_budget_max: 100000 }, plan: "free", tierFields: tiers,
    manufacturerMap: { brief: "", list: [] }, likedModels: [], savedBoats: [],
    existingSuggestions: [], isFirstPaidGeneration: false, hadContradiction: false,
    refresh: false, contradictionRerunCount: 0,
  });
  assert.equal(calls, 2);
  assert.deepEqual(result.suggestions.map(s => s.model), ["2520", "2530"]);
  assert.ok(result.suggestions.every(s => s.asking_price === null), "MODEL MATCH must not preserve LLM-generated listing-style point prices");
  assert.match(result.scarcityNote, /does not prove that no other suitable boats exist/);
});

test("unverified dimensions require source confirmation before exclusions", async () => {
  const client = { asServiceRole: { integrations: { Core: {
    InvokeLLM: async () => ({ contradiction: { flagged: true }, suggestions: [
      { title: "Parker 2520 expensive", make: "Parker", model: "2520",
        asking_price: 150000, overall_length_ft: 32 },
      { title: "Parker 2520 viable", make: "Parker", model: "2520",
        asking_price: 70000, overall_length_ft: 28 },
    ] }),
  } } } };
  const result = await generateRecommendations(client, {
    profile: { purchase_budget_max: 100000, hard_max_overall_length_ft: 30 },
    plan: "free", tierFields: tiers, manufacturerMap: { brief: "", list: [] },
    likedModels: [], savedBoats: [], existingSuggestions: [],
    isFirstPaidGeneration: false, hadContradiction: false, refresh: false,
    contradictionRerunCount: 0,
  });
  assert.equal(result.suggestions.length, 1);
  assert.equal(result.suggestions[0].model, "2520");
  assert.match(result.suggestions[0].verification_required.join(" "), /rigged overall length/i);
});

test("unknown market price is flagged rather than silently treated as affordable", async () => {
  const client = { asServiceRole: { integrations: { Core: {
    InvokeLLM: async () => ({ contradiction: { flagged: true }, suggestions: [
      { title: "Unpriced 28", make: "Example", model: "28", length: "28 ft" },
    ] }),
  } } } };
  const result = await generateRecommendations(client, {
    profile: { purchase_budget_max: 90000 }, plan: "free", tierFields: tiers,
    manufacturerMap: { brief: "", list: [] }, likedModels: [], savedBoats: [],
    existingSuggestions: [], isFirstPaidGeneration: false, hadContradiction: false,
    refresh: false, contradictionRerunCount: 0,
  });
  assert.equal(result.suggestions.length, 1);
  assert.ok(result.suggestions[0].verification_required.some(s => /market price.*purchase budget/i.test(s)));
});

test("LLM-generated model price always carries an independent-verification flag even with year context", async () => {
  const client = { asServiceRole: { integrations: { Core: {
    InvokeLLM: async () => ({ contradiction: { flagged: true }, suggestions: [
      { title: "Example 28", make: "Example", model: "28",
        price_range_min: 60000, price_range_max: 85000,
        price_range_context: "2018–2022 US used models" },
    ] }),
  } } } };
  const result = await generateRecommendations(client, {
    profile: { purchase_budget_max: 100000 }, plan: "free", tierFields: tiers,
    manufacturerMap: { brief: "", list: [] }, likedModels: [], savedBoats: [],
    existingSuggestions: [], isFirstPaidGeneration: false, hadContradiction: false,
    refresh: false, contradictionRerunCount: 0,
  });
  assert.equal(result.suggestions.length, 1);
  const suggestion = result.suggestions[0];
  assert.equal(suggestion.price_range_context, "2018–2022 US used models");
  assert.ok(suggestion.verification_required.some(s => /verify.*model price range.*independent market evidence/i.test(s)));
});

test("LLM-only price bands above budget remain visible with a clear affordability warning", async () => {
  const client = { asServiceRole: { integrations: { Core: {
    InvokeLLM: async () => ({ contradiction: { flagged: true }, suggestions: [
      { title: "Example 30", make: "Example", model: "30", year: 2024,
        price_range_min: 145000, price_range_max: 180000,
        price_range_context: "2022–2024 used US market" },
    ] }),
  } } } };
  const result = await generateRecommendations(client, {
    profile: { purchase_budget_max: 100000 }, plan: "free", tierFields: tiers,
    manufacturerMap: { brief: "", list: [] }, likedModels: [], savedBoats: [],
    existingSuggestions: [], isFirstPaidGeneration: false, hadContradiction: false,
    refresh: false, contradictionRerunCount: 0,
  });
  assert.equal(result.suggestions.length, 1);
  assert.ok(result.suggestions[0].verification_required.some(s =>
    /starts above.*purchase ceiling.*independent market evidence/i.test(s)));
});

test("a model price band crossing the buyer ceiling gets a specific warning even with other price notes", async () => {
  const client = { asServiceRole: { integrations: { Core: {
    InvokeLLM: async () => ({ contradiction: { flagged: true }, suggestions: [
      { title: "Example 26", make: "Example", model: "26", year: 2022,
        price_range_min: 80000, price_range_max: 125000,
        price_range_context: "2021–2023 US used model estimate",
        verification_required: ["Price estimate needs independent review."],
      },
    ] }),
  } } } };
  const result = await generateRecommendations(client, {
    profile: { purchase_budget_max: 100000 }, plan: "free", tierFields: tiers,
    manufacturerMap: { brief: "", list: [] }, likedModels: [], savedBoats: [],
    existingSuggestions: [], isFirstPaidGeneration: false, hadContradiction: false,
    refresh: false, contradictionRerunCount: 0,
  });
  assert.equal(result.suggestions.length, 1);
  const flags = result.suggestions[0].verification_required.join(" ");
  assert.ok(flags.includes("crosses the $100,000 purchase ceiling"));
  assert.match(flags, /affordability is unconfirmed/i);
  assert.match(flags, /independent review/i);
});

test("an empty MATCH response does not falsely blame hard constraints or market scarcity", async () => {
  let calls = 0;
  const client = { asServiceRole: { integrations: { Core: {
    InvokeLLM: async () => {
      calls += 1;
      return { suggestions: [] };
    },
  } } } };
  const result = await generateRecommendations(client, {
    profile: { purchase_budget_max: 100000, boat_size_range: "24_30" },
    plan: "free", tierFields: tiers,
    manufacturerMap: { brief: "", list: [] }, likedModels: [], savedBoats: [],
    existingSuggestions: [], isFirstPaidGeneration: false, hadContradiction: false,
    refresh: false, contradictionRerunCount: 0,
  });
  assert.equal(calls, 2, "empty results should be retried once for distinct alternatives");
  assert.equal(result.suggestions.length, 0);
  assert.equal(result.hardFilterRemovedAll, true, "preserve existing no-result recovery behavior");
  assert.match(result.scarcityContradiction.explanation, /No independently supported hard-limit exclusions/);
  assert.match(result.scarcityContradiction.explanation, /does not establish that no suitable models exist/);
  assert.doesNotMatch(result.scarcityContradiction.conflicts.join(" "), /all.*hard.*constraints|known hard.*exclud/i);
  assert.match(result.scarcityNote, /previous matches.*preserved/i);
});

test("free MATCH budget excludes the paid minimum, including after downgrade", () => {
  const profile = { purchase_budget_min: 87500, purchase_budget_max: 125000 };
  assert.deepEqual(tierBudgetSummary(profile, "free"), [null, 125000]);
  assert.deepEqual(tierBudgetSummary(profile, "match_plus"), [87500, 125000]);
});

test("LLM profile summary respects each paid-question tier", async () => {
  const profile = {
    vessel_class: "private", activities: ["Fishing"], operating_area: "coastal",
    experience_level: "intermediate", boat_size_range: "24_30", storage: "marina_slip",
    purchase_budget_min: 87500, purchase_budget_max: 125000,
    passenger_count: 4, occasional_passenger_count: 7,
    activity_weights: { Fishing: 100 },
    family_use: "SPECIAL_FAMILY_REQUIREMENT",
    storage_capacity: "SPECIAL_STORAGE_NOTE",
    hard_max_overall_length_ft: 31, hard_max_beam_ft: 9.5,
    hard_max_height_ft: 11, hard_max_storage_weight_lb: 8000,
    hard_max_draft_ft: 2, tow_capacity_lb: 12000,
    overnight_requirements: "SPECIAL_OVERNIGHT_NEED",
    annual_ownership_budget: 12345,
  };
  for (const plan of ["free", "match_plus", "refined_match", "market_match"]) {
    let capturedPrompt = "";
    const client = {
      asServiceRole: { integrations: { Core: { InvokeLLM: async ({ prompt }) => {
        capturedPrompt = prompt;
        return { contradiction: { flagged: true, conflicts: [], explanation: "" }, suggestions: [] };
      } } } },
    };
    await generateRecommendations(client, {
      profile, plan, tierFields: tiers, manufacturerMap: { brief: "", list: [] },
      likedModels: [], savedBoats: [], existingSuggestions: [],
      isFirstPaidGeneration: false, hadContradiction: false, refresh: false,
      contradictionRerunCount: 0,
    });
    const summaryText = capturedPrompt.split("Buyer profile (needs / wants / budget / priorities):\n")[1];
    assert.ok(summaryText, "missing buyer profile in " + plan);
    const summary = JSON.parse(summaryText);
    assert.deepEqual(summary.budget, [plan === "free" ? null : 87500, 125000]);
    assert.equal("passenger_count" in summary, plan !== "free");
    assert.equal("occasional_passenger_count" in summary, plan !== "free");
    assert.equal("family_use" in summary, plan === "refined_match" || plan === "market_match");
    assert.equal("storage_capacity" in summary, plan === "refined_match" || plan === "market_match");
    for (const field of ["hard_max_overall_length_ft", "hard_max_beam_ft", "hard_max_height_ft", "hard_max_storage_weight_lb", "hard_max_draft_ft", "tow_capacity_lb"]) {
      assert.equal(field in summary, plan === "refined_match" || plan === "market_match", `${field} leaked into ${plan}`);
    }
    assert.equal("overnight_requirements" in summary, plan === "market_match");
    assert.equal("annual_ownership_budget" in summary, plan === "market_match");
  }
});
