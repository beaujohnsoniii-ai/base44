import test from 'node:test';
import assert from 'node:assert/strict';
import {
  IntakeError, newListing, confirmListing, abandonEmptyListing,
  restoreEmptyListing, resetListing,
} from '../base44/shared/listing-intake.mjs';
import { intakePublicView, runIntakeAction } from '../base44/shared/listing-intake-service.mjs';
import {
  NOW, OWNER, POLICY, MODEL, LISTING_ID, UPLOAD_ID, clone, source,
  candidate, completedUpload, listingData, completeData, harness, request,
} from './listing-intake-fixtures.mjs';

// All storage references below are synthetic fixtures, never user private URIs.
const RESET_AT = '2026-10-25T12:00:00.000Z';
const ARCHIVED_URI = `mp/private/${POLICY.app_id}/synthetic-archived-source.png`;
const CARD_TWO = 'listing_second_01';
const CARD_OTHER_MODEL = 'listing_other_model_01';
const SECOND_MODEL = { ...MODEL, source_id: 'saved_model_002', model_key: 'searay:spx190:2021', make: 'Sea Ray', model: 'SPX 190', year: 2021 };
const listingById = (data, id = LISTING_ID) => data.listings.find(listing => listing.id === id);
const rejection = error => error instanceof IntakeError && [400, 409].includes(error.status);
const protectedUnchanged = h => assert.deepEqual(h.calls.forbidden, [], 'No User or BuyerProfile write is permitted.');
const noProviderWork = h => assert.equal(h.calls.uploads.length + h.calls.extracts.length, 0);
const resetRequest = extra => request('reset_listing', extra);

function populatedData() {
  const data = completeData(), listing = listingById(data);
  listing.uploads[0].file_uri = ARCHIVED_URI;
  listing.resolutions.asking_price = { choice: `${UPLOAD_ID}:asking_price`, note: 'Buyer selected this source.', resolved_by: OWNER.id, resolved_at: NOW };
  listing.identity_resolution = { note: 'Buyer checked the listed identity.', reviewed_by: OWNER.id, reviewed_at: NOW };
  return data;
}
function severalCards() {
  let data = populatedData();
  data = newListing(data, MODEL, CARD_TWO, 'https://seller.example/listing/second-card', NOW);
  listingById(data, CARD_TWO).uploads.push(completedUpload('second_card_upload_01', [candidate('asking_price', 38900, 'second_card_upload_01', { quote: '$38,900' })]));
  data = newListing(data, SECOND_MODEL, CARD_OTHER_MODEL, 'https://seller.example/listing/other-model', NOW);
  listingById(data, CARD_OTHER_MODEL).uploads.push(completedUpload('other_model_upload_01', [candidate('asking_price', 45900, 'other_model_upload_01', { quote: '$45,900' })]));
  return data;
}
function model(index) { return { ...MODEL, source_id: `saved_model_${index}`, model_key: `make:model${index}:2022`, model: `Model ${index}` }; }
function archiveOf(listing) {
  assert.ok(Array.isArray(listing.archived_revisions), 'Reset must retain archived revisions.');
  assert.ok(listing.archived_revisions.length > 0, 'The previous draft must not disappear.');
  return listing.archived_revisions.at(-1);
}

test('abandon empty draft retains card ID, original reference, model and immutable input', () => {
  const original = listingData(), before = clone(original), reference = listingById(original).reference_url;
  const result = abandonEmptyListing(original, LISTING_ID, RESET_AT), abandoned = listingById(result);
  assert.deepEqual(original, before); assert.equal(result.listings.length, 1);
  assert.equal(abandoned.status, 'abandoned'); assert.equal(abandoned.id, LISTING_ID);
  assert.equal(abandoned.reference_url, reference); assert.deepEqual(abandoned.model, MODEL);
  assert.deepEqual(abandoned.uploads, []); assert.deepEqual(abandoned.versions, []);
  const restored = restoreEmptyListing(result, LISTING_ID, RESET_AT);
  assert.equal(listingById(restored).status, 'draft'); assert.equal(listingById(restored).id, LISTING_ID);
  assert.equal(listingById(restored).reference_url, reference);
  assert.equal(listingById(result).status, 'abandoned');
});

test('abandon rejects populated, historically confirmed, confirmed and already abandoned cards', () => {
  const uploaded = completeData();
  assert.throws(() => abandonEmptyListing(uploaded, LISTING_ID, RESET_AT), rejection);
  const historical = listingData(); listingById(historical).versions = [{ version: 1, digest: 'synthetic-history' }];
  assert.throws(() => abandonEmptyListing(historical, LISTING_ID, RESET_AT), rejection);
  const confirmed = listingData(); listingById(confirmed).status = 'confirmed';
  assert.throws(() => abandonEmptyListing(confirmed, LISTING_ID, RESET_AT), rejection);
  const abandoned = abandonEmptyListing(listingData(), LISTING_ID, RESET_AT);
  assert.throws(() => abandonEmptyListing(abandoned, LISTING_ID, RESET_AT), rejection);
  assert.throws(() => restoreEmptyListing(listingData(), LISTING_ID, RESET_AT), rejection);
});

test('abandoned cards release the per-model slot; restore fails while replacement occupies it', () => {
  let data = listingData();
  data = newListing(data, MODEL, 'listing_slot_two', '', NOW);
  data = newListing(data, MODEL, 'listing_slot_three', '', NOW);
  data = abandonEmptyListing(data, LISTING_ID, RESET_AT);
  data = newListing(data, MODEL, 'listing_slot_replacement', '', RESET_AT);
  assert.equal(data.listings.length, 4, 'Abandon must not delete historical card records.');
  assert.equal(data.listings.filter(card => card.status !== 'abandoned').length, 3);
  const before = clone(data);
  assert.throws(() => restoreEmptyListing(data, LISTING_ID, RESET_AT), rejection);
  assert.deepEqual(data, before);
  data = abandonEmptyListing(data, 'listing_slot_replacement', RESET_AT);
  data = restoreEmptyListing(data, LISTING_ID, RESET_AT);
  assert.equal(listingById(data).status, 'draft'); assert.equal(listingById(data).id, LISTING_ID);
  assert.equal(data.listings.filter(card => card.status !== 'abandoned').length, 3);
});

test('abandoning a models last active card frees its model slot; restoration rechecks model cap', () => {
  let data = { listings: [], operations: [] };
  for (let index = 1; index <= 3; index++) data = newListing(data, model(index), `model_card_${index}`, '', NOW);
  data = abandonEmptyListing(data, 'model_card_1', RESET_AT);
  data = newListing(data, model(4), 'model_card_4', '', RESET_AT);
  assert.throws(() => restoreEmptyListing(data, 'model_card_1', RESET_AT), rejection);
  assert.equal(listingById(data, 'model_card_1').status, 'abandoned');
  data = abandonEmptyListing(data, 'model_card_4', RESET_AT);
  const restored = restoreEmptyListing(data, 'model_card_1', RESET_AT);
  assert.equal(listingById(restored, 'model_card_1').status, 'draft');
  assert.deepEqual(listingById(restored, 'model_card_1').model, model(1));
});

test('abandoning one card does not free a model slot if that model still has another active card', () => {
  let data = newListing({ listings: [], operations: [] }, model(1), 'model_one_first', '', NOW);
  data = newListing(data, model(1), 'model_one_second', '', NOW);
  data = newListing(data, model(2), 'model_two_first', '', NOW);
  data = newListing(data, model(3), 'model_three_first', '', NOW);
  data = abandonEmptyListing(data, 'model_one_first', RESET_AT);
  assert.throws(() => newListing(data, model(4), 'model_four_first', '', RESET_AT), rejection);
});

test('populated draft reset needs explicit boolean confirmation; failure preserves the full record', () => {
  const data = populatedData(), before = clone(data);
  for (const consent of [undefined, false, null, 'true', 1]) {
    assert.throws(() => resetListing(data, LISTING_ID, consent, RESET_AT), rejection);
    assert.deepEqual(data, before);
  }
  assert.doesNotThrow(() => resetListing(data, LISTING_ID, true, RESET_AT));
});

test('confirmed reset needs explicit confirmation even when its current upload list is empty', async () => {
  let data = await confirmListing(populatedData(), LISTING_ID, { budget: 50000 }, 'profile-lifecycle', NOW);
  listingById(data).uploads = [];
  const before = clone(data);
  assert.throws(() => resetListing(data, LISTING_ID, false, RESET_AT), rejection);
  assert.deepEqual(data, before);
  const reset = resetListing(data, LISTING_ID, true, RESET_AT);
  assert.equal(listingById(reset).status, 'draft'); assert.deepEqual(listingById(reset).versions, listingById(data).versions);
});

test('empty draft resets without an extra confirmation and starts a fresh draft revision', () => {
  const data = listingData(), previous = clone(listingById(data));
  const reset = resetListing(data, LISTING_ID, false, RESET_AT), card = listingById(reset);
  assert.equal(card.id, LISTING_ID); assert.equal(card.status, 'draft'); assert.equal(card.revision, previous.revision + 1);
  assert.equal(card.reference_url, ''); assert.deepEqual(card.uploads, []); assert.deepEqual(card.resolutions, {});
  assert.equal(card.identity_resolution, null); assert.deepEqual(card.versions, []);
  assert.equal(archiveOf(card).reference_url, previous.reference_url);
  assert.deepEqual(listingById(data), previous);
});

test('reset archives only its chosen card and leaves same-model siblings and other models untouched', () => {
  const data = severalCards(), before = clone(data), original = listingById(data);
  const reset = resetListing(data, LISTING_ID, true, RESET_AT), card = listingById(reset), archive = archiveOf(card);
  assert.deepEqual(data, before); assert.equal(reset.listings.length, data.listings.length);
  assert.deepEqual(listingById(reset, CARD_TWO), listingById(before, CARD_TWO));
  assert.deepEqual(listingById(reset, CARD_OTHER_MODEL), listingById(before, CARD_OTHER_MODEL));
  assert.equal(archive.revision, original.revision); assert.deepEqual(archive.uploads, original.uploads);
  assert.deepEqual(archive.resolutions, original.resolutions); assert.equal(archive.reference_url, original.reference_url);
  assert.equal(archive.uploads[0].file_uri, ARCHIVED_URI);
  assert.equal(card.revision, original.revision + 1); assert.equal(card.status, 'draft');
  assert.deepEqual(card.uploads, []); assert.deepEqual(card.resolutions, {}); assert.equal(card.reference_url, '');
  assert.equal(card.identity_resolution, null); assert.deepEqual(card.model, original.model);
  assert.deepEqual(reset.operations, data.operations);
});

test('reset retains confirmed snapshot, digest, source screenshots and profile snapshot unchanged', async () => {
  const profile = { budget: 50000, needs: { use: 'family' } };
  const confirmed = await confirmListing(populatedData(), LISTING_ID, profile, 'profile-lifecycle', NOW);
  const snapshot = clone(listingById(confirmed).versions[0]), previous = clone(listingById(confirmed));
  const reset = resetListing(confirmed, LISTING_ID, true, RESET_AT), card = listingById(reset);
  assert.deepEqual(card.versions, [snapshot]); assert.equal(card.versions[0].digest, snapshot.digest);
  assert.deepEqual(card.versions[0].profile_snapshot, { budget: 50000, needs: { use: 'family' } });
  assert.deepEqual(archiveOf(card).uploads, previous.uploads); assert.equal(archiveOf(card).uploads[0].file_uri, ARCHIVED_URI);
  assert.deepEqual(listingById(confirmed), previous);
  card.uploads.push(completedUpload('fresh_revision_upload', [candidate('asking_price', 1, 'fresh_revision_upload', { quote: '$1' })]));
  card.resolutions.asking_price = { choice: 'unknown' };
  assert.deepEqual(card.versions[0], snapshot); assert.deepEqual(archiveOf(card).uploads, previous.uploads);
  const reconfirmed = await confirmListing(reset, LISTING_ID, profile, 'profile-lifecycle', RESET_AT);
  assert.equal(listingById(reconfirmed).versions.length, 2);
  assert.deepEqual(listingById(reconfirmed).versions[0], snapshot);
  assert.equal(listingById(reconfirmed).versions[1].version, previous.revision + 1);
  assert.equal(listingById(reconfirmed).versions[1].parent_version, snapshot.version);
});

test('successive resets append archival revisions rather than replacing earlier evidence', () => {
  const first = resetListing(populatedData(), LISTING_ID, true, RESET_AT);
  const firstArchive = clone(archiveOf(listingById(first)));
  listingById(first).uploads.push(completedUpload('fresh_revision_upload', [candidate('asking_price', 39900, 'fresh_revision_upload', { quote: '$39,900' })]));
  listingById(first).reference_url = 'https://seller.example/listing/revised-reference';
  const second = resetListing(first, LISTING_ID, true, '2026-10-26T12:00:00.000Z'), card = listingById(second);
  assert.equal(card.archived_revisions.length, 2); assert.deepEqual(card.archived_revisions[0], firstArchive);
  assert.equal(card.archived_revisions[1].revision, 2); assert.equal(card.archived_revisions[1].uploads[0].id, 'fresh_revision_upload');
  assert.equal(card.archived_revisions[1].reference_url, 'https://seller.example/listing/revised-reference');
  assert.equal(card.revision, 3);
});

test('pending upload or reading outcome blocks reset even with explicit confirmation', () => {
  for (const status of ['reserved', 'reading', 'uncertain']) {
    const data = populatedData(); listingById(data).uploads.push({ ...source('pending_source_01'), status });
    const before = clone(data);
    assert.throws(() => resetListing(data, LISTING_ID, true, RESET_AT), rejection);
    assert.deepEqual(data, before, `${status} source must not be hidden by a reset.`);
  }
});

test('reset does not reactivate an abandoned card through a path that bypasses slot checks', () => {
  const abandoned = abandonEmptyListing(listingData(), LISTING_ID, RESET_AT), before = clone(abandoned);
  assert.throws(() => resetListing(abandoned, LISTING_ID, true, RESET_AT), rejection);
  assert.deepEqual(abandoned, before);
});

test('public view strips current and every archived private URI without mutating saved archives', async () => {
  let data = resetListing(populatedData(), LISTING_ID, true, RESET_AT);
  listingById(data).uploads.push(completedUpload('new_current_source', [], { file_uri: `mp/private/${POLICY.app_id}/synthetic-current.png` }));
  data = resetListing(data, LISTING_ID, true, RESET_AT);
  listingById(data).uploads.push(completedUpload('another_current_source', [], { file_uri: `mp/private/${POLICY.app_id}/synthetic-another-current.png` }));
  const h = await harness({ data }), before = clone(h.state.record), view = intakePublicView(h.state.record);
  const card = view.listings.find(listing => listing.id === LISTING_ID);
  assert.equal(card.archived_revisions.length, 2);
  for (const upload of [...card.uploads, ...card.archived_revisions.flatMap(revision => revision.uploads)]) assert.ok(!('file_uri' in upload));
  assert.ok(!JSON.stringify(view).includes(`mp/private/${POLICY.app_id}/`));
  assert.deepEqual(h.state.record, before); protectedUnchanged(h);
});

test('service reset needs confirmation for populated card, archives only chosen card and never writes protected entities', async () => {
  const h = await harness({ data: severalCards() }), before = clone(h.state.record.data);
  await assert.rejects(runIntakeAction(await h.context(), resetRequest({ reset_confirmed: false })), rejection);
  assert.equal(h.calls.commits.length, 0); assert.deepEqual(h.state.record.data, before);
  const result = await runIntakeAction(await h.context(), resetRequest({ reset_confirmed: true }));
  const saved = listingById(h.state.record.data), view = result.listings.find(listing => listing.id === LISTING_ID);
  assert.equal(saved.status, 'draft'); assert.deepEqual(saved.uploads, []); assert.equal(saved.revision, 2);
  assert.equal(archiveOf(saved).uploads[0].file_uri, ARCHIVED_URI);
  assert.ok(!('file_uri' in archiveOf(view).uploads[0]));
  assert.deepEqual(listingById(h.state.record.data, CARD_TWO), listingById(before, CARD_TWO));
  assert.deepEqual(listingById(h.state.record.data, CARD_OTHER_MODEL), listingById(before, CARD_OTHER_MODEL));
  protectedUnchanged(h); noProviderWork(h); assert.equal(h.calls.signs.length, 0);
});

test('service empty reset omits confirmation safely; string confirmation cannot approve populated reset', async () => {
  const empty = await harness();
  await runIntakeAction(await empty.context(), resetRequest());
  assert.equal(listingById(empty.state.record.data).revision, 2); protectedUnchanged(empty);
  const populated = await harness({ data: populatedData() }), before = clone(populated.state.record);
  await assert.rejects(runIntakeAction(await populated.context(), resetRequest({ reset_confirmed: 'true' })), rejection);
  assert.deepEqual(populated.state.record, before); assert.equal(populated.calls.commits.length, 0); protectedUnchanged(populated);
});

test('service lifecycle operation replay never archives twice and mismatched confirmation digest rejects', async () => {
  const h = await harness({ data: populatedData() }), body = resetRequest({ reset_confirmed: true });
  await runIntakeAction(await h.context(), body);
  const beforeReplay = clone(h.state.record);
  const replay = await runIntakeAction(await h.context(), body);
  assert.equal(replay.replayed, true); assert.deepEqual(h.state.record, beforeReplay);
  assert.equal(listingById(h.state.record.data).archived_revisions.length, 1); assert.equal(h.calls.commits.length, 1);
  await assert.rejects(runIntakeAction(await h.context(), { ...body, reset_confirmed: false }), rejection);
  assert.deepEqual(h.state.record, beforeReplay); protectedUnchanged(h); noProviderWork(h);
});

test('service abandon and restore retain original card, reference and other cards without protected writes', async () => {
  let data = listingData(); data = newListing(data, SECOND_MODEL, CARD_OTHER_MODEL, '', NOW);
  const h = await harness({ data }), before = clone(h.state.record.data);
  await runIntakeAction(await h.context(), request('abandon_empty'));
  assert.equal(listingById(h.state.record.data).status, 'abandoned');
  assert.deepEqual(listingById(h.state.record.data, CARD_OTHER_MODEL), listingById(before, CARD_OTHER_MODEL));
  const replay = await runIntakeAction(await h.context(), request('abandon_empty')); assert.equal(replay.replayed, true);
  await runIntakeAction(await h.context(), request('restore_empty', { operation_id: 'restore_lifecycle_01', revision: h.state.record.revision }));
  assert.equal(listingById(h.state.record.data).status, 'draft');
  assert.equal(listingById(h.state.record.data).reference_url, listingById(before).reference_url);
  assert.equal(h.state.record.data.listings.length, 2); assert.equal(h.calls.commits.length, 2);
  protectedUnchanged(h); noProviderWork(h); assert.equal(h.calls.signs.length, 0);
});

test('service archived preview signs only the registered original source and does not change state', async () => {
  const data = resetListing(populatedData(), LISTING_ID, true, RESET_AT), h = await harness({ data }), before = clone(h.state.record);
  const result = await runIntakeAction(await h.context(), { action: 'preview_source', listing_id: LISTING_ID, upload_id: UPLOAD_ID });
  assert.equal(result.expires_in, 60); assert.equal(h.calls.signs.length, 1);
  assert.equal(h.calls.signs[0].file_uri, ARCHIVED_URI); assert.equal(h.calls.signs[0].expires_in, 60);
  assert.deepEqual(h.state.record, before); assert.equal(h.calls.commits.length, 0);
  await assert.rejects(runIntakeAction(await h.context(), { action: 'preview_source', listing_id: LISTING_ID, upload_id: 'unregistered_archived_01' }), error => error.status === 404);
  await assert.rejects(runIntakeAction(await h.context(), { action: 'preview_source', listing_id: LISTING_ID, upload_id: UPLOAD_ID, file_uri: `${ARCHIVED_URI}-forged` }), error => error.status === 400);
  assert.equal(h.calls.signs.length, 1); protectedUnchanged(h); noProviderWork(h);
});

test('archived preview rejects foreign-app registered sources without signing', async () => {
  const data = resetListing(populatedData(), LISTING_ID, true, RESET_AT);
  archiveOf(listingById(data)).uploads[0].file_uri = 'mp/private/another_app/synthetic-foreign.png';
  const h = await harness({ data });
  await assert.rejects(runIntakeAction(await h.context(), { action: 'preview_source', listing_id: LISTING_ID, upload_id: UPLOAD_ID }), error => [403,404,409].includes(error.status));
  assert.equal(h.calls.signs.length, 0); assert.equal(h.calls.commits.length, 0); protectedUnchanged(h);
});

test('pending lifecycle reset is rejected without dropping its unresolved source or operation', async () => {
  for (const status of ['reserved', 'reading', 'uncertain']) {
    const data = populatedData(); listingById(data).uploads.push({ ...source('pending_source_01'), status });
    const h = await harness({ data }), before = clone(h.state.record);
    await assert.rejects(runIntakeAction(await h.context(), resetRequest({ reset_confirmed: true })), rejection);
    assert.deepEqual(h.state.record, before); assert.equal(h.calls.commits.length, 0); protectedUnchanged(h); noProviderWork(h);
  }
});
