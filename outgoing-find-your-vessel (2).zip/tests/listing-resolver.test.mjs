import test from "node:test";
import assert from "node:assert/strict";
import {listingIdentityHint,resolveListing,resolveCompareListings} from "../base44/shared/listing-resolver.mjs";
// These synthetic documents test logic, not source permission or real retrieval.
const url="https://www.boattrader.com/boat/2012-blackjack-224-10159597/";
const source="https://dealer.com/inventory/example/";
const input={url,expected_make:"Blackjack",expected_model:"224"};
const profile={purchase_budget_max:85000,hard_max_draft_ft:1.2,passenger_count:2};
const page=(extra="")=>"For sale | Make: Blackjack | Model: 224 | Year: 2012 | Price: USD 43,995 | Engine-down draft: 1.1 ft | Capacity: 6 persons | Stock #: 3928 | "+url+" "+extra;
function runtime({text=page(),candidate=source,final=source,permission=true,stamp=new Date().toISOString(),discover,entity={}}={}){
 const calls=[];
 return {calls,provider:{kind:"approved_listing_provider",safe_transport:"base44_custom_integration_proxy",
 downstream_public_egress_verified:true,redirects_permission_checked:true,search_authorized:true,usage_authorized:true,
 approval_reference:"SYNTHETIC TEST ONLY",discover:discover|| (async q=>{calls.push(["discover",q]);return {candidates:[{url:candidate}]};}),
 read:async q=>{calls.push(["read",q]);const node={"@type":"Vehicle",url:source,brand:"Blackjack",model:"224",vehicleModelDate:"2012",sku:"3928",sameAs:url,offers:{price:43995,priceCurrency:"USD"},...entity};return {url:q.url,final_url:final,html:"<body>"+text+"</body><script type=\"application/ld+json\">"+JSON.stringify(node)+"</script>",retrieved_at:stamp};}},
 source_permissions:permission?[{hostname:"dealer.com",automated_read:true,approval_reference:"SYNTHETIC TEST ONLY",valid_until:"2099-01-01"}]:[]};
}
test("actual three saved URLs are recognized as URL hints and remain gated without live provider",async()=>{
 const urls=[url,"https://www.boattrader.com/boat/2024-shoalwater-21-catamaran-10364889/","https://www.boattrader.com/boat/2018-dorado-23-se-10187560/"];
 const ids=["10159597","10364889","10187560"];
 const output=await resolveCompareListings({},urls.map(url=>({url})));
 assert.deepEqual(output.results.map(r=>r.resolution.marketplace_id),ids);
 assert.ok(output.results.every(r=>r.status==="resolver_unavailable"&&r.eligible===false));
 assert.deepEqual(output.recommendation.finalist_urls,[]);
 console.log("Three-sample live automated coverage: 0/3; provider/source gate closed; no network used.");
});
test("generic different listing and marketplace IDs are parsed rather than a three-boat map",()=>{
 assert.equal(listingIdentityHint("https://www.boattrader.com/boat/2020-another-builder-99-87654321/").marketplace_id,"87654321");
 assert.equal(listingIdentityHint("https://dealer.com/new-inventory/").marketplace_id,null);
});
test("automatic discovery resolves exact association and quoted identity with provenance",async()=>{
 const r=runtime(),out=await resolveListing(profile,input,r);
 assert.equal(out.resolution.status,"resolved");assert.equal(out.resolution.source_url,source);
 assert.equal(out.facts.year.value,2012);assert.equal(out.source_metadata.stock_number.value,"3928");
 assert.equal(out.resolution.confidence,"exact_listing_reference_with_quoted_identity");
 assert.ok(out.resolution.retrieved_at);assert.equal(out.eligible,false);
 assert.equal(r.calls.filter(c=>c[0]==="discover").length,1);
});
test("source permission is checked before any source read",async()=>{
 const r=runtime({permission:false}),out=await resolveListing(profile,input,r);
 assert.equal(out.status,"no_verified_source");assert.equal(r.calls.filter(c=>c[0]==="read").length,0);
 assert.ok(out.resolution.attempts.every(a=>a.status==="source_permission_unestablished"));
});
test("wrong year boat is never substituted even with an exact URL in its text",async()=>{
 const r=runtime({text:page().replace("Year: 2012","Year: 2015"),entity:{vehicleModelDate:"2015"}}),out=await resolveListing(profile,input,r);
 assert.equal(out.status,"wrong_listing");assert.ok(out.resolution.attempts.some(a=>a.status==="conflicting_listing_year"));
});
test("similar model without an exact individual-listing association is rejected",async()=>{
 const r=runtime({text:page().replace(url,""),entity:{sameAs:null}}),out=await resolveListing(profile,input,r);
 assert.equal(out.status,"no_verified_source");assert.ok(out.resolution.attempts.some(a=>a.status==="identity_unconfirmed"));
});
test("redirect to an unapproved source, stale evidence and oversized text are withheld",async()=>{
 for(const options of [{final:"https://unapproved.com/boat"},{stamp:"2020-01-01"},{text:page()+"x".repeat(262144)}]){
 const out=await resolveListing(profile,input,runtime(options));assert.equal(out.status,"no_verified_source");
 assert.ok(out.resolution.attempts.some(a=>a.status==="invalid_provider_document"));
 }
});
test("conflicting sale and former price are retained as uncertainty, never cheapest chosen",async()=>{
 const out=await resolveListing(profile,input,runtime({text:page("Former Price: USD 47,995")}));
 assert.equal(out.facts.asking_price,undefined);assert.ok(out.unknowns.some(x=>/Conflicting price/.test(x)));assert.equal(out.eligible,false);
});
test("profile conflicts are exposed without finalist eligibility",async()=>{
 const out=await resolveListing({...profile,purchase_budget_max:40000},input,runtime());
 assert.ok(out.concerns.some(x=>/budget/i.test(x)));assert.equal(out.eligible,false);
});
test("unsafe or unapproved transport never discovers sources",async()=>{
 const r=runtime();r.provider.safe_transport="raw_fetch";const out=await resolveListing(profile,input,r);
 assert.equal(out.status,"resolver_unavailable");assert.equal(r.calls.length,0);
});
test("access challenges and provider failures remain unknown",async()=>{
 const a=await resolveListing(profile,input,runtime({text:page("Access denied captcha")}));
 assert.equal(a.status,"blocked");
 const b=await resolveListing(profile,input,runtime({discover:async()=>{throw Error("403");}}));
 assert.equal(b.status,"discovery_unavailable");
});

test("Shoalwater sample explicit marketplace association can resolve in a permitted synthetic document",async()=>{
 const u="https://www.boattrader.com/boat/2024-shoalwater-21-catamaran-10364889/";
 const r=runtime({entity:{brand:"Shoalwater",model:"21 Cat DLX",vehicleModelDate:"2024",sku:"PUR-0194A",sameAs:null,identifier:{propertyID:"BoatTrader",value:"10364889"}},text:"For sale | Make: Shoalwater | Model: 21 Cat DLX | Year: 2024 | Price: USD 68,995 | Stock #: PUR-0194A | BoatTrader listing ID: 10364889 | Seller inventory evidence fixture."});
 const out=await resolveListing(profile,{url:u,expected_make:"Shoalwater",expected_model:"21 Catamaran"},r);
 assert.equal(out.resolution.status,"resolved");assert.equal(out.resolution.association.kind,"entity_marketplace_id");
 assert.equal(out.source_metadata.stock_number.value,"PUR-0194A");assert.equal(out.eligible,false);
 assert.ok(out.concerns.some(c=>/identity differs/.test(c)));
});
test("Dorado sample never substitutes an unrelated 2015 boat for the 2018 URL",async()=>{
 const u="https://www.boattrader.com/boat/2018-dorado-23-se-10187560/";
 const r=runtime({entity:{brand:"Dorado",model:"Silver King",vehicleModelDate:"2015",sameAs:u},text:"For sale | Make: Dorado | Model: Silver King | Year: 2015 | Price: USD 40,000 | "+u+" | This is a synthetic wrong-boat document."});
 const out=await resolveListing(profile,{url:u,expected_make:"Dorado Custom Boats",expected_model:"23 Pro Guide"},r);
 assert.equal(out.status,"wrong_listing");assert.ok(out.resolution.attempts.some(a=>a.status==="conflicting_listing_year"));
});
test("aborted overall request cancels the signal supplied to the provider",async()=>{
 const controller=new AbortController();let observed;
 const r=runtime({discover:async({signal})=>{observed=signal;await new Promise((_,reject)=>signal.addEventListener("abort",()=>reject(Error("abort")),{once:true}));}});
 const result=resolveListing(profile,input,r,controller.signal);
 await new Promise(resolve=>setTimeout(resolve,5));controller.abort();await result;
 assert.equal(observed.aborted,true);assert.equal(r.calls.filter(c=>c[0]==="read").length,0);
});

