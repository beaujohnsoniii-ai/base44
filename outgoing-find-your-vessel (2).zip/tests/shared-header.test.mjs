import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
const nav=readFileSync("src/components/Navbar.jsx","utf8");
const css=readFileSync("src/pages/Home.css","utf8");
const dashboard=readFileSync("src/pages/Dashboard.jsx","utf8");
test("all Navbar variants delegate to the scoped homepage-compatible header",()=>{
 const header=readFileSync("src/components/AppHeader.jsx","utf8");
 const headerCss=readFileSync("src/components/site-header.css","utf8");
 assert.ok(nav.includes('<AppHeader />'));
 assert.ok(nav.includes('import "@/pages/Home.css"'));
 assert.ok(header.includes('import "@/components/site-header.css"'));
 assert.ok(headerCss.includes('.sh-site'));
 assert.ok(header.includes('authed ? "/helm" : "/login?returnTo=%2Fhelm"'));
});
test("dashboard cleanup retains payment closure, admin gate and accessible profile actions",()=>{
 const editor=readFileSync("src/pages/EditProfile.jsx","utf8");
 const app=readFileSync("src/App.jsx","utf8");
 assert.ok(dashboard.includes('HELM_NAME'));
 assert.ok(dashboard.includes('user?.role === "admin"'));
 assert.ok(dashboard.includes('Checkout not available yet'));
 assert.ok(dashboard.includes('No payment will be taken'));
 assert.ok(!dashboard.includes('checkoutAvailable={true}'));
 assert.ok(dashboard.includes('/edit-profile'));
 for(const route of ['/questionnaire?reset=1','/profile-interview','/helm']) assert.ok(editor.includes(route),route);
 assert.ok(app.includes('/ownership-calculator'));
 assert.ok(dashboard.includes('sh-helm-page'));
 assert.ok(dashboard.includes('id="helm-tools"'));
 assert.ok(!dashboard.includes('Next step'));
});

test("routes missing a Navbar receive one wrapper without moving protected boundaries",()=>{
 const app=readFileSync("src/App.jsx","utf8");
 for(const component of ['Login','Register','ForgotPassword','ResetPassword','OAuthConsent','MatchEntry','AdminRelabel','AdminTestProfiles','AdminGradeTrends','AdminFeedbackAnalytics','AdminMatchQA','AdminResearchMonitor','AdminPrivateMatchTrial','AdminJourneyTrial','PageNotFound']) {
  assert.ok(app.includes(`element={<SharedHeaderPage><${component} /></SharedHeaderPage>}`),component);
  const path=component==='PageNotFound' ? 'src/lib/PageNotFound.jsx' : `src/pages/${component}.jsx`;
  assert.ok(!readFileSync(path,'utf8').includes('<Navbar'),component+' must not duplicate headers');
 }
 for(const component of ['Home','Dashboard','Questionnaire','AdminQuestionConfig']) assert.ok(app.includes(`element={<${component} />}`));
 const protectedBlock=app.slice(app.indexOf('<Route element={<ProtectedRoute />}>'),app.indexOf('      </Route>'));
 for(const component of ['AdminRelabel','AdminTestProfiles','AdminGradeTrends','AdminFeedbackAnalytics','AdminMatchQA','AdminResearchMonitor','AdminPrivateMatchTrial','AdminJourneyTrial']) assert.ok(protectedBlock.includes(`<${component} />`));
 assert.ok(css.includes('.shared-header-content > .min-h-screen{min-height:0;flex:1}'));
});
