import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
const source = fs.readFileSync("src/pages/EditProfile.jsx", "utf8");
function luminance(hex) {
 const c=hex.replace("#","").match(/../g).map(v=>parseInt(v,16)/255).map(v=>v<=0.04045?v/12.92:((v+0.055)/1.055)**2.4);
 return .2126*c[0]+.7152*c[1]+.0722*c[2];
}
function contrast(a,b) {const x=luminance(a),y=luminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
test("navy exterior has explicit legible action controls in default hover disabled and focus states",()=>{
 assert.match(source,/min-h-screen bg-\[#071f32\]/);
 assert.equal((source.match(/className=\{PROFILE_ACTION_STYLE\}/g)||[]).length,3);
 for(const token of ["bg-white","text-[#071f32]","hover:bg-slate-100","hover:text-[#071f32]","disabled:opacity-100","disabled:bg-slate-200","disabled:text-slate-600","focus-visible:ring-white","focus-visible:ring-offset-[#071f32]","min-h-11","w-full sm:w-auto"]) assert.ok(source.includes(token),token);
 for(const [fg,bg] of [["071f32","ffffff"],["071f32","f1f5f9"],["475569","e2e8f0"]]) assert.ok(contrast(fg,bg)>=4.5);
 assert.ok(contrast("ffffff","071f32")>=3,"focus ring contrast");
});
