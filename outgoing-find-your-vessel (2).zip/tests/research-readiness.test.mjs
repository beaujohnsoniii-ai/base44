import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

test('Research Monitor warns when no verified model catalog is published', () => {
  const page = readFileSync(new URL('../src/pages/AdminResearchMonitor.jsx', import.meta.url), 'utf8');
  assert.match(page, /Launch gate — model evidence/);
  assert.match(page, /BoatModelCatalog\.filter\(\{ verification_status: "published" \}, "-created_date", 1\)/);
  assert.match(page, /stats\.hasPublishedCatalogRecord === false/);
  assert.match(page, /stats\.hasPublishedCatalogRecord === null/);
  assert.match(page, /model-data integration and end-to-end QA/);
});

test('provider proof cost is never presented as zero when cost is not verified', () => {
  const ui = readFileSync(new URL('../src/pages/AdminResearchMonitor.jsx', import.meta.url), 'utf8');
  assert.match(ui, /API cost not independently verified/);
  assert.match(ui, /job\.estimated_cost_usd > 0/);
  assert.doesNotMatch(ui, /Number\(job\.estimated_cost_usd \|\| 0\)\.toFixed\(4\)/);
});

test('manufacturer research trial expiration is shown on the monitor', () => {
  const ui = readFileSync(new URL('../src/pages/AdminResearchMonitor.jsx', import.meta.url), 'utf8');
  assert.match(ui, /manufacturerTrialClosed/);
  assert.match(ui, /The one-time research trial has ended/);
});

test('buyer suggestion records use server-enforced owner-or-admin access', () => {
  const schema = JSON.parse(readFileSync(new URL('../base44/entities/SuggestedBoat.jsonc', import.meta.url), 'utf8'));
  for (const operation of ['read', 'create', 'update', 'delete']) {
    assert.deepEqual(schema.rls[operation].$or, [
      {created_by_id: '{{user.id}}'},
      {user_condition: {role: 'admin'}},
    ]);
  }
});

test('generated MATCH results explicitly require independent model-identity verification', () => {
  const engine = readFileSync(new URL('../base44/shared/suggest-engine.ts', import.meta.url), 'utf8');
  assert.match(engine, /verificationRequired\.push\("Confirm model identity, generation and production year against an independent manufacturer or archival source/);
  assert.match(engine, /verification_required: dedupeFlags\(\[\.\.\.evidenceFlags\.blockers, \.\.\.verificationRequired, \.\.\.evidenceFlags\.verification\]\)/);
});

test('xAI provider activity is recorded as xAI, not a mixed research job', () => {
  const schema = JSON.parse(readFileSync(new URL('../base44/entities/ResearchJob.jsonc', import.meta.url), 'utf8'));
  const fn = readFileSync(new URL('../base44/functions/run-provider-proof/entry.ts', import.meta.url), 'utf8');
  assert.ok(schema.properties.provider.enum.includes('xai'));
  assert.match(fn, /provider:task === "claude" \? "anthropic" : "xai"/);
});