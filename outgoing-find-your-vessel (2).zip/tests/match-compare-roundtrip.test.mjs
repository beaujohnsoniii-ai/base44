import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { matchResultLink, compareResultLink } from "../src/lib/matchResultLink.js";
import { saveMatchCandidate, loadCompareCandidates } from "../src/lib/matchCompareHandoff.js";
function fixture(saved = [], suggestions = []) {
 const rows = {SavedBoat: structuredClone(saved), SuggestedBoat: structuredClone(suggestions)};
 const queries = [];
 const entities = Object.fromEntries(Object.keys(rows).map(name => [name, {
   async filter(query, sort, limit, skip) {
     queries.push({name,query});
     assert.equal(query.created_by_id,"buyer");
     return structuredClone(rows[name].filter(b=>Object.entries(query).every(([k,v])=>b[k]===v)).slice(skip,skip+limit));
   },
   async create(data) { const row={...structuredClone(data),id:"saved-"+rows[name].length,created_by_id:"buyer"}; rows[name].push(row); return structuredClone(row); },
   async update(id,data) { const row=rows[name].find(b=>b.id===id); assert.equal(row.created_by_id,"buyer"); Object.assign(row,structuredClone(data)); return structuredClone(row); }
 }]));
 return {client:{entities},rows,queries};
}
const result = {id:"result-1",created_by_id:"buyer",title:"Example 28",make:"Example",model:"28",year:2027,link:"https://example.com/model/28?reference=original",liked:true,match:{summary:"Original fit"},asking_price:123456};
test("Match title to Save to reloaded Compare retains exact result and href",async()=>{
 const f=fixture([], [result]);
 const candidate=await saveMatchCandidate(f.client,result,"buyer");
 assert.equal(candidate.source_suggestion_id,result.id);
 assert.equal(candidate.original_match_url,matchResultLink(result));
 assert.equal(candidate.url,"");
 assert.equal(candidate.asking_price,null);
 const reloaded=await loadCompareCandidates(f.client,"buyer");
 assert.equal(reloaded.length,1);
 assert.equal(reloaded[0].title,result.title);
 assert.equal(reloaded[0].match.summary,result.match.summary);
 assert.equal(compareResultLink(reloaded[0]),matchResultLink(result));
 await saveMatchCandidate(f.client,result,"buyer");
 assert.equal(f.rows.SavedBoat.length,1);
});
test("MATCH refresh reuses the original saved model despite a new suggestion ID",async()=>{
 const prior={...result,id:"result-old",link:"https://example.com/original"};
 const refreshed={...result,id:"result-new",link:"https://example.com/new"};
 const f=fixture([], [prior]);
 const saved=await saveMatchCandidate(f.client,prior,"buyer");
 f.rows.SavedBoat[0].listing_urls=["https://seller.example/boat-123"];
 f.rows.SavedBoat[0].notes="Inspect deck before offer";
 f.rows.SuggestedBoat.splice(0,1,refreshed);
 const reused=await saveMatchCandidate(f.client,refreshed,"buyer");
 const compare=await loadCompareCandidates(f.client,"buyer");
 assert.equal(reused.id,saved.id);
 assert.equal(f.rows.SavedBoat.length,1);
 assert.equal(compare.length,1);
 assert.equal(compare[0].original_match_url,prior.link);
 assert.deepEqual(compare[0].listing_urls,["https://seller.example/boat-123"]);
 assert.equal(compare[0].notes,"Inspect deck before offer");
});
test("a refreshed Like does not silently duplicate an already-saved model",async()=>{
 const stale={...result,id:"result-old",link:"https://example.com/original"};
 const refreshed={...result,id:"result-new",link:"https://example.com/new",liked:true};
 const f=fixture([{id:"saved-0",created_by_id:"buyer",...{
  title:stale.title,make:stale.make,model:stale.model,year:stale.year,
  source_suggestion_id:stale.id,original_match_url:stale.link,
  listing_urls:["https://seller.example/older"]
 }}],[refreshed]);
 const reloaded=await loadCompareCandidates(f.client,"buyer");
 assert.equal(reloaded.length,1);
 assert.equal(f.rows.SavedBoat.length,1);
 assert.equal(reloaded[0].original_match_url,stale.link);
 assert.deepEqual(reloaded[0].listing_urls,["https://seller.example/older"]);
});
test("different documented model years remain independently savable",async()=>{
 const f=fixture([],[]);
 await saveMatchCandidate(f.client,{...result,id:"2018",year:2018},"buyer");
 await saveMatchCandidate(f.client,{...result,id:"2027",year:2027},"buyer");
 assert.equal(f.rows.SavedBoat.length,2);
});
test("a buyer-entered listing is not swallowed by a MATCH save for the same model/year",async()=>{
 const manual={id:"manual-listing",created_by_id:"buyer",title:result.title,make:result.make,
  model:result.model,year:result.year,url:"https://seller.example.com/actual-boat",
  asking_price:99000,notes:"Check this specific used boat"};
 const f=fixture([manual],[result]);
 const saved=await saveMatchCandidate(f.client,result,"buyer");
 assert.notEqual(saved.id,manual.id);
 assert.equal(saved.source_suggestion_id,result.id);
 assert.equal(saved.asking_price,null);
 assert.equal(f.rows.SavedBoat.length,2);
 const compare=await loadCompareCandidates(f.client,"buyer");
 assert.equal(compare.length,2);
 assert.equal(f.rows.SavedBoat.length,2);
 assert.equal(compare.find(b=>b.id===manual.id).url,manual.url);
 assert.equal(compare.find(b=>b.id===manual.id).asking_price,manual.asking_price);
 assert.equal(compare.find(b=>b.id===saved.id).original_match_url,result.link);
});
test("a liked MATCH model does not overwrite an unsourced user listing when Compare first loads",async()=>{
 const manual={id:"manual-listing",created_by_id:"buyer",title:result.title,make:result.make,
  model:result.model,year:result.year,url:"https://seller.example.com/actual-boat"};
 const f=fixture([manual],[result]);
 const loaded=await loadCompareCandidates(f.client,"buyer");
 assert.equal(loaded.length,2);
 assert.equal(f.rows.SavedBoat.length,2);
 assert.equal(loaded.find(b=>b.id===manual.id).url,manual.url);
 assert.ok(loaded.some(b=>b.source_suggestion_id===result.id));
});
test("older Likes become saved Compare results; other owners and QA records stay excluded",async()=>{
 const f=fixture([], [result,{...result,id:"other",created_by_id:"someone-else"},{...result,id:"qa",test_profile_id:"qa-profile"}]);
 const first=await loadCompareCandidates(f.client,"buyer");
 const second=await loadCompareCandidates(f.client,"buyer");
 assert.equal(first.length,1); assert.equal(second.length,1);
 assert.equal(compareResultLink(second[0]),result.link);
 assert.ok(f.queries.every(q=>q.query.created_by_id==="buyer"));
});
test("older saved records with the same documented year recover original research URLs without touching pasted links",async()=>{
 const old={id:"legacy",created_by_id:"buyer",title:result.title,make:result.make,model:result.model,year:result.year,listing_urls:["https://seller.com/my-boat"]};
 const f=fixture([old],[{...result,liked:false}]);
 const [recovered]=await loadCompareCandidates(f.client,"buyer");
 assert.equal(compareResultLink(recovered),result.link);
 assert.deepEqual(recovered.listing_urls,old.listing_urls);
 const original={...old,url:"https://old-seller.com/exact-boat"};
 const g=fixture([original],[result]);
 const [preserved]=await loadCompareCandidates(g.client,"buyer");
 assert.equal(compareResultLink(preserved),original.url);
 assert.equal(preserved.original_match_url,undefined);
});
test("unknown-year MATCH records never absorb a documented model year or its listing links",async()=>{
 const f=fixture([],[]);
 const unknown={...result,id:"unknown",year:null};
 const saved=await saveMatchCandidate(f.client,unknown,"buyer");
 f.rows.SavedBoat[0].listing_urls=["https://seller.example/boat-from-unknown-year"];
 const documented=await saveMatchCandidate(f.client,{...result,id:"documented",year:2027},"buyer");
 assert.notEqual(saved.id,documented.id);
 assert.equal(f.rows.SavedBoat.length,2);
 assert.deepEqual(f.rows.SavedBoat[0].listing_urls,["https://seller.example/boat-from-unknown-year"]);
 const compare=await loadCompareCandidates(f.client,"buyer");
 assert.equal(compare.length,2);
});
test("a legacy unknown-year record cannot borrow an unverified year-specific research link",async()=>{
 const old={id:"legacy",created_by_id:"buyer",title:result.title,make:result.make,model:result.model,listing_urls:["https://seller.example/exact-boat"]};
 const f=fixture([old],[{...result,liked:false}]);
 const [candidate]=await loadCompareCandidates(f.client,"buyer");
 assert.equal(candidate.original_match_url,undefined);
 assert.deepEqual(candidate.listing_urls,old.listing_urls);
});
test("ambiguous or lost old source never substitutes a guessed research URL",async()=>{
 const old={id:"legacy",created_by_id:"buyer",title:result.title,make:result.make,model:result.model};
 const f=fixture([old],[{...result,liked:false},{...result,id:"second",link:"https://different.com",liked:false}]);
 const [unchanged]=await loadCompareCandidates(f.client,"buyer");
 assert.equal(unchanged.original_match_url,undefined);
 assert.equal(new URL(compareResultLink(unchanged)).hostname,"www.google.com");
 assert.equal(compareResultLink({original_match_url:result.link,url:"https://seller.com"}),result.link);
});
test("original Google href is retained; unsafe source falls back; normal Like saves before preference call; test Like remains isolated",()=>{
 const google="https://www.google.com/search?q=exact+original+query";
 assert.equal(matchResultLink({...result,link:google}),google);
 assert.equal(compareResultLink({original_match_url:google}),google);
 assert.equal(new URL(matchResultLink({...result,link:"javascript:alert(1)"})).hostname,"www.google.com");
 const panel=readFileSync("src/components/SuggestedBoatsPanel.jsx","utf8");
 assert.ok(panel.indexOf("if (onToggleLike)")<panel.indexOf("await onAddCandidate(b)"));
 assert.ok(panel.indexOf("await onAddCandidate(b)")<panel.indexOf('functions.invoke("toggle-like"'));
 assert.match(readFileSync("src/lib/utils.js","utf8"),/return matchResultLink\(boat\)/);
});
