import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const load = (path) => readFileSync(new URL(path, import.meta.url), "utf8");

test("production and MATCH QA share the same paginated published model reader", () => {
  const production = load("../base44/shared/suggest-boats-handler.ts").replaceAll('from "./', 'from "../../shared/');
  const qa = load("../base44/functions/run-match-qa/entry.ts");
  const loader = load("../base44/shared/catalog-loader.ts");
  for (const consumer of [production, qa]) {
    assert.match(consumer, /import \{ loadPublishedMatchCatalog \} from "\.\.\/\.\.\/shared\/catalog-loader\.ts"/);
    assert.match(consumer, /await loadPublishedMatchCatalog\(/);
  }
  assert.doesNotMatch(qa, /BoatModelCatalog\.filter\(\s*\{ verification_status: "published" \},\s*"-created_date",\s*500/);
  assert.match(loader, /pageIndex \* CATALOG_PAGE_SIZE/);
  assert.match(loader, /truncated: true/);
});
