import test from "node:test";
import assert from "node:assert/strict";
import { extractIndexedListingExcerpt, searchExactListingExcerpt } from "../base44/shared/indexed-listing-fallback.mjs";
import { resolveApprovedListing } from "../base44/shared/approved-listing-resolver.mjs";

const url = "https://www.boattrader.com/boat/2027-sailfish-245-dc-10171515/";
const input = { url, expected_make: "Sailfish", expected_model: "245 DC" };
const realExcerpt = {
  title: "New 2027 Sailfish 245 DC, 28560 New Bern",
  content: "In-Stock listing. Beam: 8.5 ft. Room for 12 passengers. This 2027 Sailfish 245 DC is currently on order and available for purchase.",
};

test("indexed excerpt parser keeps exact listing identity and bounded labeled facts", () => {
  const extraction = extractIndexedListingExcerpt(realExcerpt, input);
  assert.equal(extraction.page_kind, "listing");
  const facts = Object.fromEntries(extraction.facts.map(f => [f.field, f]));
  assert.equal(facts.make.value, "Sailfish");
  assert.equal(facts.model.value, "245 DC");
  assert.equal(facts.year.value, 2027);
  assert.match(facts.year.quote, /2027 Sailfish 245 DC/);
  assert.equal(facts.beam_ft.value, 8.5);
  assert.equal(facts.passenger_capacity.value, 12);
});

test("BlackJack indexed title establishes 2012 with a source quote, not saved model 2026", () => {
  const listing = {title: "Used 2012 BlackJack 224, 70118 New Orleans", content: "2012 BlackJack 224 boat for sale at The Boat Yard, 290 hours, featuring Suzuki engine."};
  const result = extractIndexedListingExcerpt(listing, {expected_make: "Blackjack", expected_model: "224"});
  const year = result.facts.find(f => f.field === "year");
  assert.equal(year.value, 2012);
  assert.equal(year.quote, listing.title);
});

test("year elsewhere in excerpt or multiple title years does not establish a listing year", () => {
  const i = {expected_make: "Blackjack", expected_model: "224"};
  assert.ok(!extractIndexedListingExcerpt({title: "BlackJack 224 at the Boat Yard",content: "Another boat was sold in 2018."}, i).facts.some(f => f.field === "year"));
  assert.ok(!extractIndexedListingExcerpt({title: "2012 or 2018 BlackJack 224",content: "Uncertain year."}, i).facts.some(f => f.field === "year"));
});

test("indexed search accepts only the original listing URL, not a dealer mirror", async () => {
  const originalDeno = globalThis.Deno;
  globalThis.Deno = { env: { get: () => "test-key" } };
  const request = async () => new Response(JSON.stringify({ results: [
    { url: "https://dealer.example/boats/245-dc", ...realExcerpt },
  ] }), { status: 200, headers: { "content-type": "application/json" } });
  try {
    const result = await searchExactListingExcerpt(url, input, null, request);
    assert.equal(result.ok, false);
    assert.match(result.error, /No exact indexed result/);
  } finally {
    if (originalDeno === undefined) delete globalThis.Deno;
    else globalThis.Deno = originalDeno;
  }
});

test("one blocked direct fetch can fall back to exact indexed evidence", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response("", { status: 403 });
  try {
    const result = await resolveApprovedListing(
      { passenger_count: 6 },
      input,
      null,
      {
        searchExactListingExcerpt: async () => ({
          ok: true,
          text: realExcerpt.title + "\n" + realExcerpt.content,
          extraction: extractIndexedListingExcerpt(realExcerpt, input),
          evidence: {
            provider: "tavily",
            provenance: "indexed_search_excerpt",
            source_url: url,
            title: realExcerpt.title,
            excerpt: realExcerpt.content,
            retrieved_at: "2026-10-20T01:45:00.000Z",
          },
        }),
      },
    );
    assert.equal(result.status, "partial_evidence");
    assert.equal(result.facts.year.value, 2027);
    assert.equal(result.facts.make.value, "Sailfish");
    assert.equal(result.facts.make.provenance, "indexed_search_excerpt");
    assert.equal(result.resolution.transport, "indexed_search");
    assert.equal(result.source_evidence.source_url, url);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
