import test from 'node:test';
import assert from 'node:assert/strict';
import { parseFeet, parseRiggedOverallLengthFt, screenPhysicalCandidate, formatPassengerCapacitySpec } from '../base44/shared/physical-specs.ts';

const screen = (boat, buyer) => screenPhysicalCandidate(boat, buyer);
const verified = (boat, ...fields) => ({ ...boat, __catalog_verified_fields: fields });

test('feet and inches are parsed correctly', () => {
  assert.equal(parseFeet("29' 6\""), 29.5);
  assert.equal(parseFeet('18 inches'), 1.5);
  assert.equal(parseRiggedOverallLengthFt('Length 29 ft · Overall length 30 ft'), 30);
});

test('known rigged overall length above a hard limit is excluded', () => {
  const r = screen(verified({ overall_length_ft: 31, length: '29 ft' }, 'rigged_overall_length_ft'), { boat_size_range: '25_30', hard_max_overall_length_ft: 30 });
  assert.equal(r.excluded, true);
  assert.match(r.reasons.join(' '), /overall length/);
});

test('only source-verified model ratings are described as published passenger limits', () => {
  assert.match(formatPassengerCapacitySpec(12, true), /Published passenger limit 12.*source-verified/);
  assert.match(formatPassengerCapacitySpec(12, false), /Unverified passenger limit 12.*confirm manufacturer/);
  assert.equal(formatPassengerCapacitySpec(null, false), '');
  assert.equal(formatPassengerCapacitySpec(12.5, true), '');
});

test('conservative passenger screening never mislabels a provisional limit as manufacturer-published', () => {
  const buyer = { passenger_count: 8, occasional_passenger_count: 10 };
  const provisional = screen({ passenger_capacity: 6 }, buyer);
  assert.equal(provisional.excluded, false);
  assert.match(provisional.verification_required.join(' '), /safe passenger capacity for normal group/i);
  assert.match(provisional.verification_required.join(' '), /occasional group of 10 exceeds the unverified reported 6-person limit/i);

  const verified = screen({
    passenger_capacity: 6,
    __catalog_verified_fields: ['passenger_capacity'],
  }, buyer);
  assert.equal(verified.excluded, true);
  assert.match(verified.reasons.join(' '), /source-verified published maximum 6/i);
  assert.match(verified.verification_required.join(' '), /source-verified 6-person limit/i);
});

test('unknown and provisional sufficient passenger ratings still require confirmation', () => {
  const buyer = { passenger_count: 5, occasional_passenger_count: 7 };
  assert.match(screen({}, buyer).verification_required.join(' '), /safe passenger capacity for normal group/i);
  assert.match(screen({ passenger_capacity: 9 }, buyer).verification_required.join(' '), /safe passenger capacity for normal group/i);
});

test('preferred length alone is not an absolute limit', () => {
  assert.equal(screen({ overall_length_ft: 31 }, { boat_size_range: '25_30' }).excluded, false);
});

test('hull length cannot establish rigged overall compliance', () => {
  const r = screen({ length: '29 ft' }, { hard_max_overall_length_ft: 30 });
  assert.equal(r.excluded, false);
  assert.match(r.verification_required.join(' '), /rigged overall length/i);
});

test('known beam and draft violations are excluded', () => {
  const r = screen(verified({ beam_ft: 10, draft_ft: 2.5 }, 'beam_ft', 'draft_ft'), { hard_max_beam_ft: 9, hard_max_draft_ft: 2 });
  assert.equal(r.excluded, true);
  assert.equal(r.reasons.length, 2);
});

test('bridge clearance does not establish storage height', () => {
  const r = screen({ specs: 'Bridge clearance 8 ft' }, { hard_max_height_ft: 9 });
  assert.equal(r.excluded, false);
  assert.match(r.verification_required.join(' '), /storage height/i);
});

test('dry weight is not loaded storage weight', () => {
  const unknown = screen({ specs: 'Dry weight 4,500 lb' }, { hard_max_storage_weight_lb: 6000 });
  assert.equal(unknown.excluded, false);
  assert.match(unknown.verification_required.join(' '), /loaded storage weight/i);
  assert.equal(screen(verified({ loaded_storage_weight_lb: 6500 }, 'storage_weight_lb'), { hard_max_storage_weight_lb: 6000 }).excluded, true);
});

test('trailered weight is compared only with an actual buyer-supplied tow rating', () => {
  const unknown = screen({ specs: 'Dry weight 2,500 lb' }, { storage: 'trailer', towing: 'pickup', tow_capacity_lb: 3500 });
  assert.equal(unknown.excluded, false);
  assert.match(unknown.verification_required.join(' '), /trailered weight/i);
  assert.equal(screen(verified({ trailered_weight_lb: 4000 }, 'trailered_weight_lb'), { storage: 'trailer', tow_capacity_lb: 3500 }).excluded, true);
  assert.equal(screen({ trailered_weight_lb: 4000 }, { storage: 'trailer', towing: 'pickup' }).excluded, false);
});

test('tow limit does not apply to a slip-kept boat', () => {
  assert.equal(screen({ trailered_weight_lb: 7000 }, { storage: 'marina_slip', tow_capacity_lb: 3500 }).excluded, false);
});

test('v1 excludes known vessels over 65 ft regardless of buyer preferences', () => {
  assert.equal(screen({ length: '66 ft' }, {}).excluded, true);
  assert.equal(screen({ overall_length_ft: 66 }, {}).excluded, true);
  assert.equal(screen({ overall_length_ft: 65 }, {}).excluded, false);
});

test('explicit out-of-scope boat types are excluded without blocking Sailfish boats', () => {
  assert.equal(screen({ title: 'RIB 750', length: '25 ft' }, {}).excluded, true);
  assert.equal(screen({ title: 'RIB 750', boat_type: 'center_console', length: '25 ft' }, {}).excluded, true);
  assert.equal(screen({ title: 'R.I.B. 750', category: 'offshore', length: '25 ft' }, {}).excluded, true);
  assert.equal(screen({ title: 'Jon boat 18', length: '18 ft' }, {}).excluded, true);
  assert.equal(screen({ title: 'Sailfish 245 DC', length: '24 ft' }, {}).excluded, false);
});

test('explicit marina overall-length cap in notes is enforced on verified facts only', () => {
  const profile = { storage: 'marina_slip', storage_capacity: 'Marina maximum 30 ft' };
  assert.equal(screen(verified({ overall_length_ft: 32 }, 'rigged_overall_length_ft'), profile).excluded, true);
  const unverified = screen({ overall_length_ft: 32 }, profile);
  assert.equal(unverified.excluded, false);
  assert.match(unverified.verification_required.join(' '), /rigged overall length/i);
});
