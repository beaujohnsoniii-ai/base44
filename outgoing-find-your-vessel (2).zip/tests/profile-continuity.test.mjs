import {saveBuyerProfile} from "../base44/shared/save-buyer-profile.mjs";
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
function page(path, sdk, query = "") {
 const source=fs.readFileSync(path,"utf8");
 const js=ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 let states=[],cursor=0,effects=[],toasts=[],navigations=[];
 const React={createElement:(type,props,...children)=>({type,props:{...props,children}})};
 const useState=initial=>{const i=cursor++;if(!(i in states))states[i]=typeof initial==="function"?initial():initial;return [states[i],v=>states[i]=typeof v==="function"?v(states[i]):v];};
 const exports={};
 new Function("exports","require","localStorage","window",js)(exports,name=>{
 if(name==="react")return {__esModule:true,default:React,useState,useEffect:fn=>effects.push(fn),useRef:v=>({current:v})};
 if(name.includes("base44Client"))return {base44:sdk};
 if(name==="react-router-dom")return {useNavigate:()=>url=>navigations.push(url),useSearchParams:()=>[new URLSearchParams(query)]};
 if(name.includes("use-toast"))return {useToast:()=>({toast:t=>toasts.push(t)})};
 if(name.includes("/stages"))return {isPaidPlan:p=>p!=="free",normalizePlan:p=>p};
 return new Proxy({__esModule:true,default:name.split("/").at(-1)},{get:(o,k)=>k in o?o[k]:String(k)});
 },{getItem:()=>null,setItem:()=>{},removeItem:()=>{}},{location:{search:query},confirm:()=>true});
 const render=()=>{cursor=0;return exports.default();};
 const walk=n=>!n?[]:Array.isArray(n)?n.flatMap(walk):typeof n==="object"?[n,...walk(n.props?.children)]:[];
 render();const pending=effects.splice(0).map(fn=>fn());
 return {ready:async()=>{await Promise.all(pending);await new Promise(r=>setImmediate(r));},form:()=>walk(render()).find(n=>n.type==="IntroQuestionnaire"),button:label=>walk(render()).find(n=>n.props?.children?.includes(label)),toasts,navigations};
}
test("restart updates the current owner profile and preserves Likes and notes when matching is refused",async()=>{
 const stored={id:"owner-profile",created_by_id:"buyer",liked_models:[{make:"A",model:"B"}],research_notes:"Keep surveyor notes",must_haves:"original"};
 let creates=0,updates=[];
 const sdk={auth:{isAuthenticated:async()=>true,me:async()=>({id:"buyer",plan:"match_plus"})},entities:{BuyerProfile:{filter:async filter=>{assert.equal(filter.created_by_id,"buyer");return [stored];},create:async()=>{creates++;return {id:"duplicate"};},update:async(id,data)=>{updates.push(id);Object.assign(stored,data);return stored;}}},functions:{invoke:async (name,payload)=>{if(name==="question-tiers")return {data:{field_tiers:{}}};if(name==="save-matching-profile")return {data:{profile:await saveBuyerProfile({asServiceRole:{entities:sdk.entities}},{id:"buyer"},payload.profile,{resetContext:payload.reset_context===true}),profile_save_version:"profile-save-v1",matching_context_version:"fresh-context-v2",reset_context_applied:payload.reset_context===true}};throw new Error("updates exhausted");}}};
 const h=page("src/pages/Questionnaire.jsx",sdk,"reset=1");await h.ready();
 await h.form().props.onComplete({activities:["Fishing"],activity_weights:{Fishing:100},must_haves:"new",match_question_tier:"match_plus"});
 assert.equal(creates,0,"restart must never strand preferences on a new profile");
 assert.deepEqual(updates,["owner-profile"]);assert.equal(stored.must_haves,"new");assert.deepEqual(stored.activity_weights,{Fishing:100});
 assert.deepEqual(stored.liked_models,[{make:"A",model:"B"}]);assert.equal(stored.research_notes,"Keep surveyor notes");
 assert.ok(h.toasts.some(t=>t.title==="Profile saved; matches were not updated"));
});
test("questionnaire waits for the authenticated profile and plan before mounting the form",async()=>{
 let resolve;const pending=new Promise(r=>resolve=r);
 const sdk={auth:{isAuthenticated:async()=>true,me:()=>pending},entities:{BuyerProfile:{filter:async()=>[{id:"p",activities:["Fishing"]}]}},functions:{invoke:async()=>({data:{field_tiers:{}}})}};
 const h=page("src/pages/Questionnaire.jsx",sdk);
 assert.equal(h.form(),undefined);
 resolve({id:"buyer",plan:"market_match"});await h.ready();
 assert.equal(h.form().props.plan,"market_match");assert.deepEqual(h.form().props.initialProfile.activities,["Fishing"]);
});

test("explicit reset rotates only context, retaining answers, likes, notes and accounting",async()=>{
 const original={id:"p",created_by_id:"buyer",match_context_id:"old",activities:["Fishing"],activity_weights:{Fishing:100},liked_models:[{make:"A",profile_input_fingerprint:"old"}],research_notes:"Keep",advisor_credit:29};
 let stored=structuredClone(original),patch;
 const client={asServiceRole:{entities:{BuyerProfile:{filter:async()=>[stored],update:async(id,data)=>{assert.equal(id,"p");patch=data;stored={...stored,...data};return stored;}}}}};
 await saveBuyerProfile(client,{id:"buyer"},{},{resetContext:true});
 assert.deepEqual(Object.keys(patch),["match_context_id"]);
 assert.notEqual(stored.match_context_id,original.match_context_id);
 assert.deepEqual({...stored,match_context_id:"old"},original);
 const first=stored.match_context_id;
 await saveBuyerProfile(client,{id:"buyer"},{activities:["Fishing"],activity_weights:{Fishing:100}},{resetContext:true});
 assert.notEqual(stored.match_context_id,first,"same answers after Reset still start fresh");
});
test("Reset waits for persistence, ignores repeated clicks and never generates",async()=>{
 let resolve;const pending=new Promise(r=>resolve=r);let calls=[];
 const sdk={auth:{me:async()=>({id:"buyer",plan:"free"})},entities:{BuyerProfile:{filter:async()=>[calls.length?{id:"p",created_by_id:"buyer",match_context_id:calls[0].payload.request_id}:{id:"p",created_by_id:"buyer",match_context_id:"old"}]}},functions:{invoke:async(name,payload)=>{if(name==="question-tiers")return {data:{field_tiers:{}}};calls.push({name,payload});return pending;}}};
 const h=page("src/pages/EditProfile.jsx",sdk);await h.ready();const button=h.button("Reset profile");
 const first=button.props.onClick();await button.props.onClick();
 assert.equal(calls.length,1);assert.equal(calls[0].name,"reset-matching-context");assert.equal(calls[0].payload.buyer_profile_id,"p");assert.equal(calls[0].payload.expected_context_id,"old");assert.ok(calls[0].payload.request_id);assert.deepEqual(h.navigations,[]);
 resolve({data:{profile:{id:"p",created_by_id:"buyer",match_context_id:calls[0].payload.request_id},matching_context_version:"reset-matching-context-v1",reset_context_applied:true,request_id:calls[0].payload.request_id}});await first;assert.deepEqual(h.navigations,["/questionnaire?reset=1"]);
});
test("unconfirmed Reset stays on profile and asks for readback before retry",async()=>{
 const sdk={auth:{me:async()=>({id:"buyer",plan:"free"})},entities:{BuyerProfile:{filter:async()=>[{id:"p"}]}},functions:{invoke:async name=>{if(name==="question-tiers")return {data:{field_tiers:{}}};throw Error("transport");}}};
 const h=page("src/pages/EditProfile.jsx",sdk);await h.ready();await h.button("Reset profile").props.onClick();assert.deepEqual(h.navigations,[]);assert.ok(h.toasts.some(t=>t.title==="Reset could not be confirmed"));
});

test("legacy backend success cannot masquerade as a completed Reset",async()=>{
 const sdk={auth:{me:async()=>({id:"buyer",plan:"free"})},entities:{BuyerProfile:{filter:async()=>[{id:"p",created_by_id:"buyer",match_context_id:"old"}]}},functions:{invoke:async name=>name==="question-tiers"?{data:{field_tiers:{}}}:{data:{profile:{id:"p",match_context_id:"old"}}}}};
 const h=page("src/pages/EditProfile.jsx",sdk);await h.ready();await h.button("Reset profile").props.onClick();assert.deepEqual(h.navigations,[]);assert.ok(h.toasts.some(t=>t.title==="Reset could not be confirmed"));
});
test("Reset rejects an acknowledgement that fails independent persisted readback",async()=>{
 const sdk={auth:{me:async()=>({id:"buyer",plan:"free"})},entities:{BuyerProfile:{filter:async()=>[{id:"p",created_by_id:"buyer",match_context_id:"old"}]}},functions:{invoke:async name=>name==="question-tiers"?{data:{field_tiers:{}}}:{data:{profile:{id:"p",created_by_id:"buyer",match_context_id:"new"},matching_context_version:"fresh-context-v2",reset_context_applied:true}}}};
 const h=page("src/pages/EditProfile.jsx",sdk);await h.ready();await h.button("Reset profile").props.onClick();assert.deepEqual(h.navigations,[]);assert.ok(h.toasts.some(t=>t.title==="Reset could not be confirmed"));
});
test("reset questionnaire never generates after an unverified legacy save response",async()=>{
 let generated=0;
 const sdk={auth:{isAuthenticated:async()=>true,me:async()=>({id:"buyer",plan:"market_match"})},entities:{BuyerProfile:{filter:async()=>[{id:"p",created_by_id:"buyer",match_context_id:"old"}]}},functions:{invoke:async name=>{if(name==="question-tiers")return {data:{field_tiers:{}}};if(name==="suggest-boats")generated++;return {data:{profile:{id:"p",match_context_id:"old"}}};}}};
 const h=page("src/pages/Questionnaire.jsx",sdk,"reset=1");await h.ready();await h.form().props.onComplete({experience_level:"experienced"});assert.equal(generated,0);assert.deepEqual(h.navigations,[]);assert.ok(h.toasts.some(t=>t.title==="Profile save could not be confirmed"));
});
