import test from "node:test";import assert from "node:assert/strict";
import {resolveListing} from "../base44/shared/listing-resolver.mjs";
const original="https://www.boattrader.com/boat/2012-blackjack-224-10159597/";
const first="https://dealer.com/boat/a",second="https://dealer.com/boat/b";
const input={url:original,expected_make:"Blackjack",expected_model:"224"};
function node(url,extra={}){return {"@type":"Vehicle",url,brand:"Blackjack",model:"224",vehicleModelDate:"2012",sku:"RIGHT3928",sameAs:original,offers:{price:43995,priceCurrency:"USD"},...extra};}
function runtime(documents){
 return {provider:{kind:"approved_listing_provider",safe_transport:"base44_custom_integration_proxy",downstream_public_egress_verified:true,redirects_permission_checked:true,search_authorized:true,usage_authorized:true,approval_reference:"SYNTHETIC ONLY",
 discover:async()=>({candidates:documents.map(d=>({url:d.url}))}),
 read:async({url})=>{const d=documents.find(d=>d.url===url);return {url,final_url:url,retrieved_at:new Date().toISOString(),html:'<body>'+d.text+'</body><script type="application/ld+json">'+JSON.stringify(d.entity)+'</script>'};}},
 source_permissions:[{hostname:"dealer.com",automated_read:true,approval_reference:"SYNTHETIC ONLY",valid_until:"2099-01-01"}]};
}
function noPrice(result){
 assert.equal(result.nullable_facts.asking_price,null);assert.equal(result.nullable_facts.asking_price_currency,null);
 assert.equal(result.structured_checks_complete,false);assert.equal(result.evidence_coverage,0);assert.equal(result.eligible,false);
 assert.equal(result.checks.find(c=>c.criterion==="Asking-price budget").status,"unknown");
 assert.ok(!result.concerns.some(x=>/budget|price/i.test(x)));
 assert.ok(!result.field_evidence.some(x=>["asking_price","asking_price_currency"].includes(x.field)));
}
test("related-footer exact URL and URL-prefix substring cannot bind another boat",async()=>{
 for(const mention of [original,original+"unrelated/"]){
 const result=await resolveListing({purchase_budget_max:85000},input,runtime([{url:first,entity:node(first,{sameAs:null,sku:"WRONG123"}),text:"For sale | Price: USD 43,995 | Stock #: WRONG123 | Related listing: "+mention}]));
 assert.equal(result.status,"no_verified_source");assert.equal(result.source_metadata,undefined);assert.equal(result.eligible,false);
 }
});
test("sameAs URL prefix and identifier prefix cannot bind a selected entity",async()=>{
 for(const entity of [node(first,{sameAs:original+"unrelated/"}),node(first,{sameAs:null,identifier:{propertyID:"BoatTrader",value:"101595970"}})]){
 const result=await resolveListing({},input,runtime([{url:first,entity,text:"An individually advertised boat offered for sale with seller claims requiring confirmation."}]));
 assert.equal(result.status,"no_verified_source");
 }
});
test("entity-bound exact sameAs supports association and only entity stock is returned",async()=>{
 const r=await resolveListing({},input,runtime([{url:first,entity:node(first),text:"For sale | Stock #: WRONG123 | Footer contains an unrelated boat."}]));
 assert.equal(r.resolution.status,"resolved");assert.equal(r.source_metadata.stock_number.value,"RIGHT3928");
 assert.equal(r.resolution.association.kind,"entity_bound_exact_url");
});
test("single-page price conflict recomputes coverage, completeness, concerns and evidence at both budgets",async()=>{
 for(const budget of [85000,40000]){
 const r=await resolveListing({purchase_budget_max:budget},input,runtime([{url:first,entity:node(first),text:"For sale | Price: USD 43,995 | Former Price: USD 47,995 | Seller details."}]));
 assert.equal(r.resolution.status,"resolved");noPrice(r);
 }
});
test("cross-source differing prices recompute every derived field",async()=>{
 for(const budget of [85000,40000]){
 const r=await resolveListing({purchase_budget_max:budget},input,runtime([
 {url:first,entity:node(first),text:"Individual listing for sale. Current seller claims must be verified."},
 {url:second,entity:node(second,{offers:{price:47995,priceCurrency:"USD"}}),text:"Individual listing for sale. Current seller claims must be verified."}]));
 noPrice(r);
 }
});
test("equal numbers in USD and EUR are a conflict, not USD budget fit",async()=>{
 for(const budget of [85000,40000]){
 const r=await resolveListing({purchase_budget_max:budget},input,runtime([
 {url:first,entity:node(first,{offers:{price:70000,priceCurrency:"USD"}}),text:"Individual listing for sale. Current seller claims must be verified."},
 {url:second,entity:node(second,{offers:{price:70000,priceCurrency:"EUR"}}),text:"Individual listing for sale. Current seller claims must be verified."}]));
 noPrice(r);assert.ok(r.unknowns.some(x=>/currencies conflict/.test(x)));
 }
});

test("visible price disagreeing with structured price also clears all derived price state",async()=>{
 const r=await resolveListing({purchase_budget_max:40000},input,runtime([{url:first,entity:node(first),text:"For sale | Price: USD 47,995 | Current displayed seller price."}]));
 noPrice(r);
});
