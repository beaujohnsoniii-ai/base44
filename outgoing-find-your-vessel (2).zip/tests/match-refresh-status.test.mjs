import assert from "node:assert/strict";
import test from "node:test";
import { paidMatchRefreshStatus } from "../src/lib/matchRefreshStatus.js";

const NOW = Date.parse("2026-10-17T20:00:00Z");

test("admin QA alone has unlimited matching updates", () => {
  const status = paidMatchRefreshStatus({ adminTesting: true, updatesUsed: 30, updatesLimit: 0, planExpires: "2020-01-01", now: NOW });
  assert.equal(status.canRefresh, true);
  assert.match(status.message, /Admin testing.*Unlimited/);
});

test("paying customers see the actual update count, never unlimited", () => {
  const status = paidMatchRefreshStatus({ updatesUsed: 2, updatesLimit: 5, now: NOW });
  assert.equal(status.canRefresh, true);
  assert.equal(status.message, "Updates: 2 of 5 used · 3 left");
  assert.doesNotMatch(status.message, /Unlimited|testing/i);
});

test("exhausted paid updates disable refresh, not read-only results", () => {
  const status = paidMatchRefreshStatus({ updatesUsed: 5, updatesLimit: 5, now: NOW });
  assert.equal(status.canRefresh, false);
  assert.match(status.message, /limit reached/);
});

test("first paid generation is free even before any update allowance", () => {
  const status = paidMatchRefreshStatus({ firstPaidGenerationAvailable: true, updatesUsed: 0, updatesLimit: 0, now: NOW });
  assert.equal(status.canRefresh, true);
  assert.match(status.title, /initial matches/);
});

test("expired or malformed explicit dates block new paid refreshes", () => {
  for (const planExpires of ["2026-10-17T19:59:59Z", "not-a-date"]) {
    const status = paidMatchRefreshStatus({ planExpires, firstPaidGenerationAvailable: true, updatesLimit: 5, now: NOW });
    assert.equal(status.canRefresh, false);
    assert.match(status.message, /expired/);
  }
});

test("missing expiry retains legacy paid entitlement", () => {
  const status = paidMatchRefreshStatus({ planExpires: null, updatesLimit: 3, now: NOW });
  assert.equal(status.canRefresh, true);
});
