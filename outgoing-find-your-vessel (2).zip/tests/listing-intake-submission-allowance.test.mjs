import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { loadIntakeContext, runIntakeAction, intakePublicView, allowedOwnerTrialCaller } from '../base44/shared/listing-intake-service.mjs';
import { SINGLE_SCREENSHOT_POLICY, intakeAllowance, withIntakeAllowance, orderedMatchResults, topMatchResults, submissionUsage } from '../base44/shared/listing-intake-allowance.mjs';
import { newListing, resetListing } from '../base44/shared/listing-intake.mjs';
import { profileInputFingerprint } from '../base44/shared/profile-input-fingerprint.mjs';
import { harness, OWNER, POLICY, NOW, screenshot, pngBytes, clone, completedUpload, deferred } from './listing-intake-fixtures.mjs';

const policy = {...POLICY, workspace_kind:'owner-production',workspace_label:'synthetic-single-screenshot',submission_policy:SINGLE_SCREENSHOT_POLICY,max_uploads:9,max_extractions:9};
const empty = () => ({listings:[],operations:[]});
async function setup(data=empty()) {
  const h=await harness({data});
  Object.assign(h.state.record,{stage_fixture:false,fixture_label:policy.workspace_label});
  h.rows=Array.from({length:4},(_,i)=>({id:'current_result_0'+(i+1),created_by_id:OWNER.id,buyer_profile_id:h.state.profile.id,profile_input_fingerprint:h.state.record.profile_fingerprint,rank:i+1,created_date:NOW,make:'Synthetic',model:'Model'+i,title:'Synthetic Result '+i,year:2025}));
  h.client.entities.SuggestedBoat={get:async id=>clone(h.rows.find(row=>row.id===id)),filter:async()=>{if(h.hooks.resultRead)await h.hooks.resultRead();return clone(h.rows);}};
  h.context=()=>loadIntakeContext(h.client,OWNER,policy);
  let serial=0;
  h.action=async(action,fields={})=>runIntakeAction(await h.context(),{action,revision:h.state.record.revision,operation_id:'single_operation_'+(++serial),...fields});
  h.add=async(index=0,listingId='single_listing_'+(++serial))=>{await h.action('add_listing',{listing_id:listingId,model_type:'suggestion',model_id:h.rows[index].id});return listingId;};
  h.upload=async(listingId,fields={})=>h.action('upload',{listing_id:listingId,upload_id:'single_upload_'+(++serial),file:screenshot(),...fields});
  h.read=async(listingId)=>h.action('read_screenshot',{listing_id:listingId,upload_id:h.state.record.data.listings.find(l=>l.id===listingId).uploads[0].id});
  return h;
}
const rejected=status=>e=>e.status===status;
function fixtureListing(row,id,uploads=[]) {
 const model={source_type:'suggestion',source_id:row.id,model_key:row.make+':'+row.model,make:row.make,model:row.model,title:row.title};
 const listing=newListing(empty(),model,id,'',NOW).listings[0];listing.uploads=uploads;return listing;
}

test('exact top-three current results each accept three single screenshots, never a tenth',async()=>{
 const h=await setup();
 for(let result=0;result<3;result++)for(let slot=0;slot<3;slot++){const id=await h.add(result);await h.upload(id);await h.read(id);}
 const allowance=intakeAllowance(await h.context());
 assert.equal(h.calls.uploads.length,9);assert.equal(h.calls.extracts.length,9);assert.equal(allowance.screenshots_remaining,0);
 assert.deepEqual(allowance.by_result.map(x=>x.listing_slots_used),[3,3,3]);
 await assert.rejects(h.add(0),rejected(409));await assert.rejects(h.add(3),rejected(409));
 assert.equal(h.calls.uploads.length,9);assert.deepEqual(h.calls.forbidden,[]);
});

test('one screenshot per listing rejects second image and reset without spending a second call',async()=>{
 const h=await setup(),id=await h.add();await h.upload(id);await h.read(id);
 const before=clone(h.state.record);
 await assert.rejects(h.upload(id,{file:screenshot({bytes:pngBytes(1,1,4)})}),rejected(409));
 await assert.rejects(h.action('reset_listing',{listing_id:id,reset_confirmed:true}),rejected(409));
 assert.deepEqual(h.state.record,before);assert.equal(h.calls.uploads.length,1);
 assert.equal(withIntakeAllowance(await h.context(),intakePublicView(h.state.record)).listings[0].submission.upload_available,false);
});

test('invalid file is rejected before reservation and corrected file can use same untouched slot',async()=>{
 const h=await setup(),id=await h.add(),before=clone(h.state.record);
 await assert.rejects(h.upload(id,{file:screenshot({type:'text/plain'})}),rejected(400));
 assert.deepEqual(h.state.record,before);assert.equal(h.calls.uploads.length,0);
 await h.upload(id);assert.equal(h.calls.uploads.length,1);
});

test('replay of upload and extraction is idempotent with original request',async()=>{
 const h=await setup(),id=await h.add();
 const upload={action:'upload',revision:h.state.record.revision,operation_id:'idempotent_upload_01',listing_id:id,upload_id:'idempotent_source_01',file:screenshot()};
 await runIntakeAction(await h.context(),upload);await runIntakeAction(await h.context(),upload);
 const read={action:'read_screenshot',revision:h.state.record.revision,operation_id:'idempotent_read_01',listing_id:id,upload_id:'idempotent_source_01'};
 await runIntakeAction(await h.context(),read);await runIntakeAction(await h.context(),read);
 assert.equal(h.calls.uploads.length,1);assert.equal(h.calls.extracts.length,1);
});

test('actual acceptance shape: old three plus current Back Cove two/Tug one leaves Albemarle eligible',async()=>{
 const h=await setup();
 const oldRows=[0,1,2].map(i=>fixtureListing({...h.rows[0],id:'old_result_0'+i},'old_listing_0'+i,[completedUpload('old_upload_0'+i)]));
 const historical={id:'old_context_01',buyer_profile_id:'old_profile_01',profile_fingerprint:'old_fp',listings:oldRows};
 h.state.record.data.context_history=[historical];
 h.state.record.data.operations=oldRows.flatMap((l,i)=>[{id:'old_operation_u'+i,action:'upload',listing_id:l.id,status:'complete'},{id:'old_operation_r'+i,action:'read_screenshot',listing_id:l.id,status:'complete'}]);
 for(const r of [0,0,1]){const id=await h.add(r);await h.upload(id);await h.read(id);}
 const alb=await h.add(2),view=withIntakeAllowance(await h.context(),intakePublicView(h.state.record));
 assert.equal(view.allowance.screenshots_remaining,6);
 assert.deepEqual(view.allowance.by_result.map(r=>r.screenshots_remaining),[1,2,3]);
 assert.equal(view.listings.find(l=>l.id===alb).submission.upload_available,true);
 await h.upload(alb);assert.equal(h.calls.uploads.length,4);assert.deepEqual(h.state.record.data.context_history,[historical]);
 assert.equal(h.state.record.data.operations.filter(o=>o.action==='upload').length,7);
});

test('forged/non-top-three/superseded/wrong-owner/test/wrong-profile result never reserves a slot',async()=>{
 for(const change of [{index:3},{created_by_id:'someone_else'},{test_profile_id:'fake_test_profile'},{superseded:true},{buyer_profile_id:'other_profile'},{profile_input_fingerprint:'other_fingerprint'}]){
  const h=await setup();const index=change.index??0;Object.assign(h.rows[index],change);
  await assert.rejects(h.add(index),e=>[403,409].includes(e.status));
  assert.equal(h.calls.commits.length,0);assert.equal(h.calls.uploads.length,0);
 }
 const h=await setup();
 for(const fields of [{rank:1},{eligible_result_ids:[h.rows[3].id]},{owner_id:OWNER.id},{profile_fingerprint:h.state.record.profile_fingerprint}])
  await assert.rejects(h.action('add_listing',{listing_id:'forged_listing_01',model_type:'suggestion',model_id:h.rows[3].id,...fields}),rejected(400));
 assert.equal(allowedOwnerTrialCaller({...OWNER,id:'other_owner'},policy,'prod'),false);
});

test('stable rank/tie order is shared and top-three list fails closed when incomplete',async()=>{
 const h=await setup();h.rows[1].rank=1;h.rows[1].created_date='2026-10-25';h.rows[2].rank=1;h.rows[2].created_date='2026-10-25';
 assert.deepEqual(orderedMatchResults([...h.rows].reverse()).map(r=>r.id),[h.rows[1].id,h.rows[2].id,h.rows[0].id,h.rows[3].id]);
 assert.deepEqual((await h.context()).topResults.map(r=>r.id),orderedMatchResults(h.rows).slice(0,3).map(r=>r.id));
 h.rows=Array.from({length:100},(_,i)=>({...h.rows[0],id:'bulk_result_'+i}));
 const bounded=await h.context();assert.match(bounded.resultOrderError,/order could not be verified/);
 assert.equal((await runIntakeAction(bounded,{action:'read'})).record_id,h.state.record.id);
 await assert.rejects(h.add(),rejected(409));
 const dashboard=await readFile('src/pages/Dashboard.jsx','utf8'),panel=await readFile('src/components/SuggestedBoatsPanel.jsx','utf8');
 assert.match(dashboard,/orderedMatchResults\(allSb.filter\(isCurrent\)\)/);assert.match(panel,/topMatchResults\(suggestions\)/);
});

test('same model identity in different exact result IDs gets independent slots',async()=>{
 const h=await setup();h.rows[1].make=h.rows[0].make;h.rows[1].model=h.rows[0].model;h.rows[1].year=h.rows[0].year;
 for(const r of [0,0,0,1,1,1])await h.add(r);
 assert.equal(h.state.record.data.listings.length,6);assert.deepEqual(intakeAllowance(await h.context()).by_result.map(r=>r.listing_slots_remaining),[0,0,3]);
});

test('abandoned empty drafts release no used screenshot and restore obeys three-slot cap',async()=>{
 const h=await setup(),id=await h.add();await h.action('abandon_empty',{listing_id:id});
 for(let i=0;i<3;i++)await h.add();
 await assert.rejects(h.action('restore_empty',{listing_id:id}),rejected(409));
 assert.equal(intakeAllowance(await h.context()).by_result[0].listing_slots_remaining,0);assert.equal(h.calls.uploads.length,0);
});

test('earlier result and legacy multiple screenshots remain read-only, do not block current slots',async()=>{
 const h=await setup();
 h.state.record.data.listings=[fixtureListing(h.rows[3],'earlier_listing_01',[completedUpload('earlier_upload_01')])];
 const before=clone(h.state.record.data.listings[0]);for(const r of [0,1,2])await h.add(r);
 await assert.rejects(h.action('reset_listing',{listing_id:before.id,reset_confirmed:true}),rejected(409));
 assert.deepEqual(h.state.record.data.listings[0],before);
 const current=h.state.record.data.listings[1];current.uploads=[completedUpload('legacy_upload_01'),completedUpload('legacy_upload_02')];
 const view=withIntakeAllowance(await h.context(),intakePublicView(h.state.record));
 assert.equal(view.listings[0].submission.read_only,true);assert.equal(view.listings[1].submission.read_only,true);
 await assert.rejects(h.action('confirm',{listing_id:current.id}),rejected(409));
});

test('same exact result historical screenshots retain slots even if listing is reset/archive-only',async()=>{
 const h=await setup();
 const old=fixtureListing(h.rows[0],'prior_listing_01',[completedUpload('prior_upload_01')]);
 const cleared=resetListing({listings:[old],operations:[]},old.id,true,NOW).listings[0];
 h.state.record.data.context_history=[{id:'prior_context_01',listings:[cleared]}];
 for(let i=0;i<2;i++)await h.add();
 await assert.rejects(h.add(),rejected(409));
 assert.equal(submissionUsage(h.state.record.data,h.rows[0].id).uploads.size,1);
});

test('profile Reset alone cannot refill; new genuine current result transition retains old evidence/ledger',async()=>{
 const h=await setup(),id=await h.add();await h.upload(id);await h.read(id);
 const oldListing=clone(h.state.record.data.listings[0]),ops=clone(h.state.record.data.operations);
 for(let round=0;round<2;round++){
  h.state.profile.match_context_id='rotated_context_'+round;
  await assert.rejects(h.action('start_current_context',{listing_id:'new_listing_'+round,model_type:'suggestion',model_id:h.rows[0].id}),rejected(409));
  const fp=await profileInputFingerprint(h.state.profile);
  h.rows=h.rows.map((row,i)=>({...row,id:'rotated_result_'+round+'_'+i,profile_input_fingerprint:fp}));
  await h.action('start_current_context',{listing_id:'new_listing_'+round,model_type:'suggestion',model_id:h.rows[0].id});
  assert.equal(intakeAllowance(await h.context()).screenshots_remaining,9);
 }
 assert.deepEqual(h.state.record.data.context_history[0].listings,[oldListing]);
 assert.deepEqual(h.state.record.data.operations.slice(0,ops.length),ops);
 assert.equal(h.state.record.data.context_history.length,2);
 await assert.rejects(h.action('model',{model_type:'suggestion',model_id:oldListing.model.source_id}),e=>[403,409].includes(e.status));
});

test('superseded result between load and action or before reservation never launches provider',async()=>{
 const h=await setup(),id=await h.add(),ctx=await h.context();h.rows[0].superseded=true;
 await assert.rejects(runIntakeAction(ctx,{action:'upload',revision:h.state.record.revision,operation_id:'stale_upload_01',listing_id:id,upload_id:'stale_source_01',file:screenshot()}),rejected(409));
 assert.equal(h.calls.uploads.length,0);
 h.rows[0].superseded=false;let n=0;h.hooks.resultRead=()=>{if(++n===3)h.rows[0].superseded=true;};
 await assert.rejects(h.upload(id),rejected(409));assert.equal(h.calls.uploads.length,0);
});

test('simultaneous double clicks only reserve one image; late same-operation replay does not spend twice',async()=>{
 const h=await setup(),id=await h.add(),one=await h.context(),two=await h.context();
 const body={action:'upload',revision:h.state.record.revision,listing_id:id,file:screenshot(),upload_id:'double_source_01',operation_id:'double_operation_01'};
 const results=await Promise.allSettled([runIntakeAction(one,body),runIntakeAction(two,{...body,operation_id:'double_operation_02',upload_id:'double_source_02'})]);
 assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal(h.calls.uploads.length,1);
});

test('unknown upload outcome remains fail-closed and does not turn into a free retry',async()=>{
 const h=await setup(),id=await h.add();h.hooks.upload=()=>{throw Error('synthetic lost receipt');};
 const body={action:'upload',revision:h.state.record.revision,listing_id:id,file:screenshot(),upload_id:'unknown_source_01',operation_id:'unknown_operation_01'};
 await assert.rejects(runIntakeAction(await h.context(),body),rejected(503));
 const replay=await runIntakeAction(await h.context(),body);assert.equal(replay.operation_status,'uncertain');
 await assert.rejects(h.upload(id),rejected(409));await assert.rejects(h.add(1),rejected(409));
 assert.equal(h.calls.uploads.length,1);assert.equal(intakeAllowance(await h.context()).screenshots_remaining,8);
});

test('unknown extraction retains uploaded evidence, precise saved status and no new provider attempt',async()=>{
 const h=await setup(),id=await h.add();await h.upload(id);h.hooks.extract=()=>{throw Error('synthetic outcome unknown');};
 await assert.rejects(h.read(id),rejected(503));
 assert.equal(h.state.record.data.listings[0].uploads.length,1);
 assert.equal(h.state.record.data.listings[0].uploads[0].status,'uncertain');
 await assert.rejects(h.read(id),rejected(409));assert.equal(h.calls.extracts.length,1);
});

test('UI one-file rule and exact result counters/history are explicit',async()=>{
 const source=await readFile('src/components/ListingIntakePanel.jsx','utf8');
 assert.match(source,/multiple=\{imageLimit > 1\}/);assert.match(source,/Choose one screenshot for this listing submission/);
 assert.match(source,/source_id === boat.id/);assert.match(source,/of 9 remaining across your top three/);
 assert.match(source,/listing.submission\?\.upload_available === false/);
 assert.match(source,/listing_slots_remaining === 0/);
 const start=source.indexOf('  const uploads ='),end=source.indexOf('  const reconcilePending',start);
 const errors=[],requests=[];
 const fn=new Function('setError','request',`
 const inFlight={current:false},imageLimit=1,stateRef={current:{allowance:{screenshots_remaining:9}}};
 ${source.slice(start,end)}
 return uploads;
 `)(message=>errors.push(message),body=>requests.push(body));
 await fn({uploads:[]},[screenshot(),screenshot()]);
 assert.equal(requests.length,0);assert.match(errors[0],/one screenshot/);
});

test('missing/invalid ranks stay displayed but cannot grant submission slots',async()=>{
 const h=await setup();h.rows[0].rank=null;h.rows[1].rank=-2;h.rows[2].rank='bad';
 assert.equal(orderedMatchResults(h.rows).length,4);
 assert.deepEqual(topMatchResults(h.rows).map(r=>r.id),[h.rows[3].id]);
 await assert.rejects(h.add(0),rejected(409));await h.add(3);
});

test('result transition during external call stays fail-closed without rebinding or repeating provider',async()=>{
 for(const action of ['upload','read_screenshot']){
  const h=await setup(),id=await h.add();if(action==='read_screenshot')await h.upload(id);
  const gate=deferred(),started=deferred();
  h.hooks[action==='upload'?'upload':'extract']=async()=>{started.resolve();await gate.promise;return action==='upload'?{file_uri:'mp/private/'+POLICY.app_id+'/synthetic-delayed.png'}:{asking_price:100};};
  const pending=action==='upload'?h.upload(id):h.read(id);
  await started.promise;h.rows[0].superseded=true;gate.resolve();
  await assert.rejects(pending,rejected(503));
  const saved=h.state.record.data.listings[0];assert.equal(saved.model.source_id,'current_result_01');
  assert.equal(h.state.record.data.operations.at(-1).status,'reserved');
  await assert.rejects(h.upload(id),rejected(409));assert.equal(h.calls.uploads.length,1);
  assert.equal(h.calls.extracts.length,action==='read_screenshot'?1:0);
 }
});
