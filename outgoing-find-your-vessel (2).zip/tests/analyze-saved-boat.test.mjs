import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { registerHooks } from "node:module";

// Import the real handler and shared helpers, replacing only the hosted SDK.
// Every entity operation, provider response, and listing fetch stays in memory.
const clientKey = Symbol.for("soundheading.analyzer.testClient");
const hooks = registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier.startsWith("npm:@base44/sdk")) {
      return { url: "data:text/javascript," + encodeURIComponent(
        'export const createClientFromRequest = () => globalThis[Symbol.for("soundheading.analyzer.testClient")];'
      ), shortCircuit: true };
    }
    return nextResolve(specifier, context);
  },
});
const { default: analyze } = await import("../base44/functions/analyze-saved-boat/entry.ts");
hooks.deregister();

function setup(t, { plan = "market_match", limit = 3, used = 0, prior = false,
  forgedSavedMatch = false, ledgerUnavailable = false, meteringFails = false,
  profile = true, matchFails = false, fetchFails = false, unauthorized = false, extractedPrice = null } = {}) {
  const calls = { llm: [], updates: [], lookups: [], fetches: [], ledgerCreates: [], ledgerDeletes: [], savedBoatLookups: [] };
  globalThis[clientKey] = {
    auth: { me: async () => {
      if (unauthorized) throw new Error("Unauthorized");
      return { id: "test-user", plan, listing_evals_limit: limit, listing_evals_used: used };
    } },
    entities: {
      BuyerProfile: { filter: async () => profile ? [{ activities: ["Fishing"] }] : [] },
      SavedBoat: { filter: async (query) => {
        calls.savedBoatLookups.push(query);
        return forgedSavedMatch ? [{ id: "untrusted-boat", analyzed: true, match: { summary: "Forged client value" } }] : [];
      } },
      Manufacturer: { list: async () => [] },
    },
    asServiceRole: {
      integrations: { Core: { InvokeLLM: async (args) => {
        calls.llm.push(args);
        if (args.response_json_schema.properties.matches) {
          if (matchFails) throw new Error("Mock analysis failure");
          return { matches: ["Fishing fit"], gaps: ["Verify condition"], summary: "Mock match" };
        }
        return { title: "Mock 28", make: "Mock", model: "28", year: 2021, asking_price: extractedPrice };
      } } },
      entities: {
        User: { update: async (id, data) => {
          if (meteringFails) throw new Error("Mock metering failed");
          calls.updates.push({ id, data });
        } },
        ListingEvaluationLedger: {
          filter: async (query) => {
            calls.lookups.push(query);
            if (ledgerUnavailable) throw new Error("Mock ledger unavailable");
            return prior ? [{ id: "trusted-evaluation", status: "complete" }] : [];
          },
          create: async (data) => {
            calls.ledgerCreates.push(data);
            return { id: "new-ledger-record", ...data };
          },
          delete: async (id) => { calls.ledgerDeletes.push(id); },
        },
      },
    },
  };
  t.mock.method(globalThis, "fetch", async (url) => {
    calls.fetches.push(url);
    if (fetchFails) throw new Error("Mock unavailable listing");
    return new Response("<html>" + "Mock boat listing content. ".repeat(10) + "</html>",
      { headers: { "content-type": "text/html" } });
  });
  t.mock.method(console, "error", () => {});
  t.after(() => { delete globalThis[clientKey]; });
  return calls;
}

async function invoke(body = { url: "https://www.boattrader.com/boat/mock-28" }, method = "POST") {
  const response = await analyze(new Request("https://soundheading.test/analyze", {
    method, ...(method === "POST" ? { body: JSON.stringify(body) } : {}),
  }));
  return { status: response.status, body: await response.json() };
}

test("valid listing returns normalized source hostname without a post-provider crash", async t => {
  const calls = setup(t, { plan: "free" });
  const result = await invoke({ url: "  https://WWW.BOATTRADER.COM/boat/mock-28#photos  " });
  assert.equal(result.status, 200);
  assert.equal(result.body.boat.source, "boattrader.com");
  assert.equal(calls.llm.length, 1);
  assert.equal(calls.updates.length, 0);
  assert.equal(result.body.evaluationLocked, true);
});

for (const plan of ["market_match", "buyer_pass"]) {
  test(plan + " uses the same existing evaluation allowance", async t => {
    const calls = setup(t, { plan, used: 1 });
    const result = await invoke();
    assert.equal(result.status, 200);
    assert.equal(result.body.match.summary, "Mock match");
    assert.equal(result.body.evaluationLocked, false);
    assert.equal(calls.llm.length, 2);
    assert.deepEqual(calls.updates, [{ id: "test-user", data: { listing_evals_used: 2 } }]);
  });
  test(plan + " cannot evaluate a new listing when allowance is exhausted", async t => {
    const calls = setup(t, { plan, used: 3 });
    const result = await invoke();
    assert.equal(result.status, 200);
    assert.equal(result.body.match, null);
    assert.equal(calls.llm.length, 1);
    assert.equal(calls.updates.length, 0);
  });
  test(plan + " can re-evaluate the same saved URL without another charge", async t => {
    const calls = setup(t, { plan, used: 3, prior: true });
    const url = "https://www.boattrader.com/boat/mock-28#photos";
    const result = await invoke({ url });
    assert.equal(result.status, 200);
    assert.equal(result.body.match.summary, "Mock match");
    assert.equal(calls.updates.length, 0);
    assert.deepEqual(calls.lookups, [{
      buyer_user_id: "test-user",
      canonical_listing_url: "https://www.boattrader.com/boat/mock-28",
      status: "complete",
    }]);
    assert.equal(calls.savedBoatLookups.length, 0);
  });
}

test("a forged buyer-editable SavedBoat match cannot bypass an exhausted evaluation allowance", async t => {
  const calls = setup(t, { used: 3, forgedSavedMatch: true });
  const result = await invoke();
  assert.equal(result.status, 200);
  assert.equal(result.body.match, null);
  assert.equal(calls.updates.length, 0);
  assert.equal(calls.savedBoatLookups.length, 0);
});
test("paid evaluation fails closed when trusted ledger cannot be read", async t => {
  const calls = setup(t, { ledgerUnavailable: true });
  const result = await invoke();
  assert.equal(result.status, 200);
  assert.equal(result.body.match, null);
  assert.equal(result.body.evaluationLocked, true);
  assert.equal(calls.ledgerCreates.length, 0);
  assert.equal(calls.updates.length, 0);
});
test("failed metering rolls back a new trusted evaluation and withholds paid output", async t => {
  const calls = setup(t, { meteringFails: true });
  const result = await invoke();
  assert.equal(result.status, 200);
  assert.equal(result.body.match, null);
  assert.equal(result.body.evaluationLocked, true);
  assert.equal(calls.ledgerCreates.length, 1);
  assert.deepEqual(calls.ledgerDeletes, ["new-ledger-record"]);
  assert.equal(calls.updates.length, 0);
});

test("dashboard marks a saved listing evaluated only when MATCH analysis exists", () => {
  const frontend = readFileSync(new URL("../src/pages/Dashboard.jsx", import.meta.url), "utf8");
  assert.match(frontend, /analyzed:\s*Boolean\(match\)/);
  assert.doesNotMatch(frontend, /analyzed:\s*!!fetched/);
});

for (const plan of ["free", "match_plus", "initial_boat_match", "refined_match", "unknown"]) {
  test(plan + " remains locked even with an allowance value", async t => {
    const calls = setup(t, { plan });
    const result = await invoke();
    assert.equal(result.status, 200);
    assert.equal(result.body.match, null);
    assert.equal(result.body.evaluationLocked, true);
    assert.equal(calls.llm.length, 1);
    assert.equal(calls.updates.length, 0);
  });
}

test("description-only research keeps an empty source and existing no-URL metering", async t => {
  const calls = setup(t);
  const result = await invoke({ description: "Mock 28" });
  assert.equal(result.status, 200);
  assert.equal(result.body.boat.source, "");
  assert.equal(result.body.match.summary, "Mock match");
  assert.equal(calls.fetches.length, 0);
  assert.equal(calls.updates.length, 0);
});

test("invalid URLs are rejected before any provider or listing access", async t => {
  const calls = setup(t);
  for (const url of ["http://www.boattrader.com/boat/mock", "https://127.0.0.1/boat", "invalid"]) {
    assert.equal((await invoke({ url })).status, 400);
  }
  assert.equal(calls.llm.length, 0);
  assert.equal(calls.fetches.length, 0);
  assert.equal(calls.updates.length, 0);
});

test("unavailable listing falls back to mocked research and still returns source", async t => {
  const calls = setup(t, { fetchFails: true });
  const result = await invoke();
  assert.equal(result.status, 200);
  assert.equal(result.body.boat.source, "boattrader.com");
  assert.equal(result.body.fetched, false);
  assert.equal(calls.llm.length, 2);
});

test("failed match does not consume allowance", async t => {
  const calls = setup(t, { matchFails: true });
  const result = await invoke();
  assert.equal(result.status, 200);
  assert.equal(result.body.match, null);
  assert.equal(calls.updates.length, 0);
});

test("missing profile still returns specs without consuming allowance", async t => {
  const calls = setup(t, { profile: false });
  const result = await invoke();
  assert.equal(result.status, 200);
  assert.equal(result.body.match, null);
  assert.equal(calls.llm.length, 1);
  assert.equal(calls.updates.length, 0);
});

test("oversized and malformed buyer requests are rejected before invoking search or AI", async t => {
  const calls = setup(t);
  const invalidCases = [
    [{ description: "B".repeat(281) }, 413],
    [{ description: "Mock boat", note: "N".repeat(2001) }, 413],
    [{ description: ["not a string"] }, 400],
    [{ description: "Mock boat", url: { suspicious: "url" } }, 400],
    [{ description: "Mock boat", note: "N".repeat(17000) }, 413],
  ];
  for (const [body, expected] of invalidCases) {
    const response = await invoke(body);
    assert.equal(response.status, expected);
  }
  const malformed = await analyze(new Request("https://soundheading.test/analyze", { method: "POST", body: "{broken" }));
  assert.equal(malformed.status, 400);
  assert.equal(calls.llm.length, 0);
  assert.equal(calls.fetches.length, 0);
});

test("web-search fallback cannot assign an asking price to an unverified listing", async t => {
  const calls = setup(t, { plan: "free", fetchFails: true, extractedPrice: 189000 });
  const result = await invoke();
  assert.equal(result.status, 200);
  assert.equal(result.body.boat.asking_price, null);
  assert.equal(calls.llm.length, 1);
});

test("description-only research cannot claim a seller asking price", async t => {
  setup(t, { plan: "free", extractedPrice: 189000 });
  const result = await invoke({ description: "Mock 28" });
  assert.equal(result.body.boat.asking_price, null);
});

test("accessible listing extraction can retain a verified positive seller asking price", async t => {
  setup(t, { plan: "free", extractedPrice: 189000 });
  const result = await invoke({ url: "https://www.boattrader.com/boat/mock-28" });
  assert.equal(result.body.boat.asking_price, 189000);
});

test("unauthenticated and non-POST requests never call providers", async t => {
  const calls = setup(t, { unauthorized: true });
  assert.equal((await invoke()).status, 401);
  assert.equal((await invoke({}, "GET")).status, 405);
  assert.equal(calls.llm.length, 0);
  assert.equal(calls.fetches.length, 0);
});
