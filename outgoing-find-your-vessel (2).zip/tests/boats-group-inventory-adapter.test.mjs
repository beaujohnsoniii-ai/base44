import test from "node:test";
import assert from "node:assert/strict";
import {BOATS_GROUP_API_RUNTIME,identifyBoatsGroupListing,planBoatsGroupLookup,
 normalizeBoatsGroupInventoryRow} from "../base44/shared/boats-group-inventory-adapter.mjs";

const cases=[
 ["https://www.boattrader.com/boat/2012-blackjack-224-10159597/","BtolID","10159597",2012],
 ["https://www.boattrader.com/boat/2024-shoalwater-21-catamaran-10364889/","BtolID","10364889",2024],
 ["https://www.boattrader.com/boat/2018-dorado-23-se-10187560/","BtolID","10187560",2018],
 ["https://www.boats.com/power-boats/2027-sailfish-245-dc-10171515/","BcnaID","10171515",2027],
 ["https://www.yachtworld.com/yacht/2019-key-west-239-dfs-10260699/","YachtWorldID","10260699",2019]
];
test("official API planning identifies only one exact marketplace record from a URL",()=>{
 for(const [url,parameter,id,year] of cases){
  const r=identifyBoatsGroupListing(url);
  assert.equal(r.query_field,parameter);assert.equal(r.listing_id,id);assert.equal(r.url_year_hint,year);
  const plan=planBoatsGroupLookup(url);
  assert.equal(plan.executable,false);assert.equal(plan.search_parameters[parameter],id);
  assert.equal(plan.search_parameters.rows,1);assert.ok(!JSON.stringify(plan).includes("key="));
 }
 assert.equal(BOATS_GROUP_API_RUNTIME.enabled,false);
});
test("dangerous, broad, ambiguous and unrelated links cannot produce an API lookup",()=>{
 for(const url of [
  "http://www.boattrader.com/boat/2012-blackjack-224-10159597/",
  "https://www.boattrader.com.evil.example/boat/2012-blackjack-224-10159597/",
  "https://www.boattrader.com/boats-for-sale/",
  "https://www.boattrader.com/boat/2012-blackjack-224-10159597/?ref=x",
  "https://www.boattrader.com/boat/2012-blackjack-224-10159597/extra",
  "https://localhost/boat/2012-blackjack-224-10159597/"
 ]){assert.equal(identifyBoatsGroupListing(url),null);assert.equal(planBoatsGroupLookup(url).executable,false);}
});
test("offline fake API row retains explicit ID, source year, price currency and quoted raw fields",()=>{
 const url=cases[0][0];
 const row={BtolID:"10159597",MakeString:"BlackJack",Model:"224",ModelYear:2012,
  Price:"65,500 USD",LengthOverall:"22.0 ft",BeamMeasure:"8.5 ft",
  MaximumNumberOfPassengersNumeric:7,MaxDraft:"1.5 ft",TotalEngineHoursNumeric:290,
  TotalPrice:"68,500 USD"};
 const r=normalizeBoatsGroupInventoryRow(row,url,{expected_make:"Blackjack",expected_model:"224",expected_year:2026});
 assert.equal(r.status,"offline_normalized_unlicensed");assert.equal(r.exact_listing,true);
 assert.equal(r.nullable_facts.year,2012);assert.equal(r.nullable_facts.asking_price,65500);
 assert.equal(r.nullable_facts.asking_price_currency,"USD");assert.equal(r.nullable_facts.beam_ft,8.5);
 assert.equal(r.nullable_facts.engine_hours,null);assert.equal(r.nullable_facts.draft_ft,null);
 assert.equal(r.facts.overall_length_ft.basis,"unspecified");
 assert.equal(r.eligible,false);assert.equal(r.production_approved,false);
 assert.ok(r.warnings.some(w=>/saved Match model's year/i.test(w)));
 assert.ok(r.evidence.some(e=>e.raw_field==="Price"&&e.raw_value==="65,500 USD"));
});
test("wrong API ID, wrong year and another marketplace ID cannot establish source",()=>{
 const url=cases[0][0];
 for(const row of [
  {BtolID:"10159598",ModelYear:2012},
  {BcnaID:"10159597",ModelYear:2012},
  {BtolID:"10159597",ModelYear:2026},
  {BtolID:"10159597"}
 ]){
  const r=normalizeBoatsGroupInventoryRow(row,url);
  assert.equal(r.exact_listing,false);assert.deepEqual(r.facts,{});assert.equal(r.eligible,false);
 }
});
test("unknown currency, measurement definitions and private price stay unknown",()=>{
 const row={BcnaID:"10171515",ModelYear:2027,MakeString:"Sailfish",Model:"245 DC",
  Price:"$115000",TotalPrice:"115000 USD",LengthOverall:"7.4 m",
  BeamMeasure:"8.5 ft",PriceHideInd:true,MaxDraft:"2 ft"};
 const r=normalizeBoatsGroupInventoryRow(row,cases[3][0]);
 assert.equal(r.nullable_facts.asking_price,null);assert.equal(r.nullable_facts.overall_length_ft,null);
 assert.equal(r.nullable_facts.draft_ft,null);assert.equal(r.nullable_facts.beam_ft,8.5);
 assert.ok(r.warnings.some(w=>/price not be shown/i.test(w)));
});
