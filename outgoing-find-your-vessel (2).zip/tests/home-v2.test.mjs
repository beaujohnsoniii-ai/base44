import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { HEADING_TYPES, scoreHeading } from "../src/lib/headingQuiz.js";

// The site v2 homepage: the design's own markup, assets and demo quiz, wired as a page.

const SECTIONS = ["Hero", "Premise", "HowItWorks", "Waters", "StatementBand", "SiteFooter"];
const src = (name) => fs.readFileSync(`src/components/home-v2/${name}.jsx`, "utf8");
const PAGE = fs.readFileSync("src/pages/Home.jsx", "utf8");
const ANCHORS = ["top", "premise", "how", "waters", "pricing", "account"];

test("the homepage composes every design section in the design's order", () => {
  const order = SECTIONS.map((name) => {
    const at = PAGE.indexOf(`import ${name === "Promise" ? "PromiseSection" : name} from "@/components/home-v2/`);
    assert.ok(at > -1, `${name} is not imported by the homepage`);
    return at;
  });
  assert.deepEqual([...order].sort((a, b) => a - b), order, "sections must be imported in the design's order");
  const rendered = ANCHORS.map((id) => SECTIONS.some((name) => src(name).includes(`id="${id}"`)));
  assert.deepEqual(rendered, rendered.map(() => true), "every anchor the design links to must exist on the page");
});

test("the design stylesheet and motion are loaded by the page and removed with it", () => {
  const styles = fs.readFileSync("src/hooks/useSiteV2Styles.js", "utf8");
  assert.match(styles, /"\/site-v2\/assets\/css\/fonts\.css"/);
  assert.match(styles, /"\/site-v2\/assets\/css\/site\.css"/);
  assert.match(styles, /links\.forEach\(\(link\) => link\.remove\(\)\)/, "other pages must not inherit the design stylesheet");
  const motion = fs.readFileSync("src/hooks/useSiteV2Motion.js", "utf8");
  for (const behaviour of ["is-solid", "is-hidden", "data-reveal", "#needle", "#hdgval"]) {
    assert.ok(motion.includes(behaviour), `${behaviour} motion missing`);
  }
  assert.match(motion, /prefers-reduced-motion/, "reduced-motion visitors must be respected");
  assert.match(PAGE, /useSiteV2Styles\(\)/);
  assert.match(PAGE, /useSiteV2Motion\(rootRef, ready\)/);
});

test("every image the homepage uses exists in the installed assets", () => {
  const markup = SECTIONS.map((name) => src(name)).join("\n");
  const literal = [...markup.matchAll(/"(\/site-v2\/assets\/img\/[^"]+)"/g)].map((match) => match[1]);
  assert.ok(literal.length > 0);
  for (const path of literal) assert.ok(fs.statSync(`public${path}`).size > 1000, `${path} is missing`);
  const files = fs.readdirSync("public/site-v2/assets/img");
  assert.ok(files.filter((name) => name.endsWith(".jpg")).length >= 14, "the design's photography is missing");
  assert.ok(files.includes("logo_v16.webp") && files.includes("logo_v16.svg"));
  assert.ok(fs.statSync("public/site-v2/assets/img/sprite.svg").size > 20000, "the icon sprite is missing");
  assert.ok(fs.statSync("public/site-v2/assets/css/site.css").size > 10000);
});

test("the header switches between Log Out and Sign In on real account state", () => {
  const header = src("SiteHeader");
  assert.match(header, /"hdr hdr--white"/);
  assert.match(header, /\/login\?returnTo=%2Fhelm/);
  assert.match(header, /"hdr__out auth-in"/, "signed-in visitors get Log Out");
  assert.match(header, /"hdr__out auth-out"/, "signed-out visitors get Sign In");
  assert.match(PAGE, /documentElement\.dataset\.auth/, "the design keys the account slot off html data-auth");
  assert.match(PAGE, /base44\.auth\.logout\(\)/);
});

test("the demo quiz scores the three answers exactly as the design does", () => {
  assert.equal(scoreHeading({}), null, "no sample match before all three answers are in");
  assert.equal(scoreHeading({ water: "icw", crew: "duo" }), null);
  const offshore = scoreHeading({ water: "off", crew: "anglers", day: "overnight" });
  assert.equal(offshore.type.name, "Convertible Sportfish");
  assert.equal(offshore.alt.name, "Offshore Center Console");
  assert.equal(offshore.why.length, 3);
  assert.ok(offshore.why.every((reason) => reason.length > 20));
  const sandbar = scoreHeading({ water: "sandbar", crew: "family", day: "anchor" });
  assert.equal(sandbar.type.name, "Dual Console");
  assert.equal(sandbar.alt.name, "Power Catamaran");
  assert.equal(sandbar.type.deg, HEADING_TYPES.dual.deg);
});

test("the demo, sample and draft labels the design carries are kept", () => {
  assert.ok(src("HeadingQuiz").includes("Illustrative results only"));
  assert.ok(src("Journal").includes("Sample article"));
  assert.ok(src("Promise").includes("Commitment wording for SoundHeading to confirm before launch"));
  assert.ok(src("Pricing").includes("DISPLAY_TIERS.map"));
  assert.ok(src("Pricing").includes("Four illustrative example results"));
  assert.ok(src("Pricing").includes("Checkout is not open"));
  assert.ok(!src("Pricing").includes("Pricing coming soon"));
});