import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { planGrantsReport as serverGrants } from '../base44/shared/stages.ts';
import { planGrantsReport as clientGrants } from '../src/lib/stages.js';

test('paid report entitlement is cumulative and identical in client and server', () => {
  const cases = [
    ['free', false, false],
    ['match_plus', false, false],
    ['refined_match', true, false],
    ['market_match', true, true],
    ['initial_boat_match', false, false],
    ['buyer_pass', true, true],
    ['unrecognized', false, false],
  ];
  for (const [plan, topPick, topThree] of cases) {
    for (const [type, expected] of [['top_pick', topPick], ['top_three', topThree], ['survey_review', false]]) {
      assert.equal(serverGrants(plan, type), expected, `server ${plan} ${type}`);
      assert.equal(clientGrants(plan, type), expected, `client ${plan} ${type}`);
    }
  }
});

test('no client-supplied dev bypass can unlock paid reports', () => {
  const server = readFileSync(new URL('../base44/functions/generate-advisory/entry.ts', import.meta.url), 'utf8');
  const client = readFileSync(new URL('../src/pages/Report.jsx', import.meta.url), 'utf8');
  assert.doesNotMatch(server, /body\.dev_bypass|body\.test_mode/);
  assert.doesNotMatch(client, /payload\.dev_bypass|isTestMode/);
  assert.match(server, /!purchased\.includes\(type\) && !planGrants/);
});
