import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {freshJourney,journeyReducer} from "../src/lib/journey-trial.mjs";
import {journeyDemoResults,demoReportRecord,DEMO_COUNTS} from "../src/lib/journey-demo.mjs";
test("complete fictional journey Free4 to MATCH+10 to Refined5 to Market3 with tier-specific reports",()=>{
 let s=journeyReducer(freshJourney(),{type:"answers",profile:{activities:["Fishing","Day cruising"],experience_level:"experienced",purchase_budget_max:200000,hard_max_overall_length_ft:26}});
 assert.equal(journeyDemoResults(s).length,4);
 for(const product of ["match_plus","upgrade_match_plus_to_refined","upgrade_refined_to_market"]){
  s=journeyReducer(s,{type:"purchase",product});s=journeyReducer(s,{type:"confirm_purchase"});s=journeyReducer(s,{type:"answers",profile:s.profile});
  const rows=journeyDemoResults(s);assert.equal(rows.length,DEMO_COUNTS[s.plan]);assert.equal(new Set(rows.map(b=>b.id)).size,rows.length);
  for(const row of rows){
   assert.match(row.title,/FICTIONAL DEMO/);assert.equal(row.is_demo,true);assert.ok(row.match.matches.length>0);assert.ok(row.match.gaps.length>0);
   const report=demoReportRecord(row,s.profile,s.plan);
   assert.ok(report.key_specs.length>=4);assert.ok(report.fit_reasons.length>=3);assert.ok(report.compromises.length>=2);assert.ok(report.seller_questions.length>=3);assert.ok(report.evidence_gaps.length>=2);
   assert.equal(!!report.cost_analysis,s.plan==="market_match");
  }
 }
 assert.deepEqual(journeyReducer(s,{type:"reset"}),freshJourney());
});
test("Likes survive fictional tier upgrades; all prices and costs explicitly fictional",()=>{
 let s=journeyReducer(freshJourney(),{type:"answers",profile:{purchase_budget_max:100000,activities:["Day cruising"]}});
 s=journeyReducer(s,{type:"like",id:"fictional-demo-4",liked:true});
 s=journeyReducer(s,{type:"purchase",product:"market_match"});s=journeyReducer(s,{type:"confirm_purchase"});
 const first=journeyDemoResults(s)[0];assert.equal(first.fixture_id,"fictional-demo-4");assert.match(first.price_range_context,/Invented UI/);
 assert.match(demoReportRecord(first,s.profile,s.plan).cost_analysis.annual_ownership_range,/FICTIONAL/);
});
test("fictional report keeps real links and paid calls disabled; three evaluation slots are in-memory",()=>{
 const page=readFileSync("src/pages/AdminJourneyTrial.jsx","utf8");
 const report=readFileSync("src/components/JourneyDemoReport.jsx","utf8");
 const demo=readFileSync("src/lib/journey-demo.mjs","utf8");
 assert.match(page,/<SuggestedBoatsPanel disableExternalLinks/);assert.match(page,/journeyDemoResults\(state\)/);
 assert.match(report,/<BoatMatchCard[^\n]* simulation/);assert.match(report,/useState\(\["","",""\]\)/);
 assert.match(report,/disabled=\{!entry.trim\(\) \|\| !!evaluations\[i\]\}/);
 assert.doesNotMatch(report+demo,/base44Client|\.entities\.|\.invoke\(|fetch\(|localStorage|sessionStorage/);
 assert.match(report,/does not assess the entered listing/);
});
test("browser harness is isolated with mocked auth and API side-effect rejection",()=>{
 const api=readFileSync("tests/browser-fixture/api.js","utf8");
 assert.match(api,/blocks external side effects/);assert.match(api,/functions:\{invoke:fail\}/);
 const config=readFileSync("tests/browser-fixture.config.mjs","utf8");assert.match(config,/browser-fixture\/auth/);assert.match(config,/browser-fixture\/api/);
});
