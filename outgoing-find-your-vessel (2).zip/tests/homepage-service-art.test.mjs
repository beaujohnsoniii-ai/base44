import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {createHash} from "node:crypto";
const journeyNav=readFileSync("src/components/JourneyHeader.jsx","utf8");
const dashboard=readFileSync("src/pages/Dashboard.jsx","utf8");
const css=readFileSync("src/pages/Home.css","utf8");
test("service artwork is the exact supplied PNG, unchanged",()=>{
 const bytes=readFileSync("public/images/nautical-service-icons-original.png");
 assert.equal(createHash("sha256").update(bytes).digest("hex"),"a377c72e9866be96a803e617f068af88bf36b4061b0a73d73ab6eb03694f334b");
 assert.equal(bytes.readUInt32BE(16),960);assert.equal(bytes.readUInt32BE(20),400);
});
test("five stage icons retain their original artwork indexes",async()=>{
 const {journeyStages,journeyIconIndexes}=await import('../src/lib/journey.js');
 assert.deepEqual(journeyStages.map(x=>journeyIconIndexes[x]),[0,2,3,1,5]);
 assert.ok(journeyNav.includes('className="sh-icon-art"'));
 assert.ok(journeyNav.includes('"/images/journey/"+x.toLowerCase()+".webp"'));
 assert.ok(dashboard.includes('<HelmTools plan={plan} />')); // Dashboard tools use the newly approved compact nautical controls.
 for(const stage of journeyStages) assert.ok(readFileSync('public/images/journey/'+stage.toLowerCase()+'.webp').length>1000);
});
test("sprite viewports contain original icons and exclude baked labels at responsive sizes",()=>{
 const bounds=[[120,37,200,118],[444,44,524,118],[759,45,841,118],[119,241,201,325],[440,251,520,314],[761,238,840,325]];
 for(let i=0;i<6;i++){
  const x=110+(i%3)*320,y=25+Math.floor(i/3)*205;
  const [left,top,right,bottom]=bounds[i];
  assert.ok(left>=x&&right<=x+100&&top>=y&&bottom<=y+100);
  assert.ok(y+100<(i<3?150:350));
 }
 assert.match(css,/background-size:calc\(var\(--nautical-size\) \* 9\.6\) calc\(var\(--nautical-size\) \* 4\)/);
 assert.match(css,/--nautical-size:72px/);
 assert.match(css,/--nautical-size:88px/);
});
test("artwork itself is the control, without redundant panels or invented routes",()=>{
 const nav=journeyNav.slice(journeyNav.indexOf('sh-journey-nav'));
 assert.ok(!nav.includes('coastal-card'),'the artwork must stay the control, without a panel wrapper');
 assert.match(nav,/to=\{journeyPaths\[x\]\}/);
 assert.match(nav,/className="sh-icon-art" src=\{"\/images\/journey\/"\+x\.toLowerCase\(\)\+"\.webp"\}/);
 assert.ok(dashboard.includes('<HelmTools plan={plan} />'));
 const tools=readFileSync('src/components/HelmTools.jsx','utf8');
 for(const icon of ['ShipWheel','ScrollText','Gauge']) assert.ok(tools.includes(icon));
 assert.ok(tools.includes('disabled aria-disabled="true"'));
 for(const title of ["MATCH","COMPARE","OWNERSHIP","ANALYZE","GUIDE","DEAL"]){
  assert.ok(readFileSync(`public/images/journey/${title.toLowerCase()}.webp`).length>1000,`${title} artwork missing`);
 }
 assert.match(css,/min-width:44px;min-height:44px;border:0;padding:0;margin:0;box-shadow:none/);
 assert.match(css,/\.coastal-home a:focus-visible\{outline:3px solid/);
 assert.match(css,/\.coastal-service\{display:flex[^}]+text-align:center\}/);
});
test("landscape refinement tightens and raises only the service group",()=>{
 const refinement=css.slice(css.indexOf("/* Landscape-only refinement"),css.indexOf("/* Portrait phones and tablets"));
 assert.match(refinement,/@media\(orientation:landscape\) and \(min-width:761px\)/);
 assert.match(refinement,/top:calc\(var\(--scene-frame\) \* \.095 - 16px\);bottom:76px/);
 assert.match(refinement,/width:calc\(26\.8% - 48px\)/);
 assert.match(refinement,/column-gap:6px/);
 assert.match(refinement,/@media\(orientation:landscape\) and \(max-width:760px\)/);
 assert.match(refinement,/margin-top:251px/);
 assert.ok(!refinement.includes(".coastal-scene{"));
 assert.ok(!refinement.includes(".coastal-header{"));
 for(const width of [761,800,1024,1100,1101,1280,1440,1920,2560]){
  const oldH=Math.min(1000,Math.max(width<=1100?670:720,width*.555));
  const imageH=Math.max(oldH,width*996/1578);
  const sceneH=oldH-Math.max(0,140-(imageH-oldH)*.475);
  const column=(width*(width<=1100?.32:.268)-(width<=1100?32:48)-6)/2;
  assert.ok(column >= (width<=1100?72:88), "landscape icon fits at "+width);
  const row=(sceneH-76-(oldH*.095-16)-2*(width<=1100?8:10))/3;
  const content=width<=1100?72+2*14*1.15+11*1.2+8:88+2*Math.min(20,Math.max(14,width*.0115))*1.15+12*1.2+8;
  assert.ok(row>=content,"room for icon, two-line title and status at "+width);
 }
});
test("portrait phones and tablets show six controls in three columns and two rows below introduction",()=>{
 const portrait=css.slice(css.indexOf("/* Portrait phones and tablets"),css.indexOf("/* Advisory line belongs"));
 assert.match(portrait,/@media\(orientation:portrait\)/);
 assert.match(portrait,/\.coastal-scene\{height:auto;min-height:0;max-height:none;padding:32px 20px\}/);
 assert.match(portrait,/\.coastal-intro\{position:relative;top:auto;left:auto/);
 assert.match(portrait,/\.coastal-services\{position:relative;inset:auto;width:100%;margin:24px 0 0;grid-template-columns:repeat\(3,minmax\(0,1fr\)\);grid-template-rows:repeat\(2,auto\);gap:12px\}/);
 assert.match(portrait,/@media\(orientation:portrait\) and \(max-width:480px\)/);
 assert.match(portrait,/font-size:12px;overflow-wrap:anywhere/);
 for(const width of [320,360,375,390,480,768,1024]){
  const column=(width-40-2*(width<=480?8:12))/3;
  assert.ok(column >= (width<=480?72:88), "icon fits portrait column at "+width);
 }
 assert.match(portrait,/\.coastal-service\{min-height:150px\}/);
 assert.ok(!portrait.includes("background-position"));
 assert.ok(!portrait.includes("coastal-header"));
});