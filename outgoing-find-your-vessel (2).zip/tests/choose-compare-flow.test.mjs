import test from "node:test";import assert from "node:assert/strict";import fs from "node:fs";
import {chooseMatchCandidate,loadCompareCandidates} from "../src/lib/matchCompareHandoff.js";
const google="https://www.google.com/search?q=exact+original+query";
function fixture(){
 const saved=[],spaces=[],suggestions=[1,2,3,4,5,6].map(i=>({id:"s"+i,created_by_id:"buyer",title:"Mock "+i+" 2026",make:"Mock",model:String(i),year:2026,link:google}));
 const writes=[];let n=0;
 const entity=(rows,type)=>({filter:async(q,s,limit,skip=0)=>rows.filter(r=>Object.entries(q).every(([k,v])=>r[k]===v)).slice(skip,skip+limit),
 get:async id=>{const row=rows.find(r=>r.id===id);if(!row)throw Error("Missing");return {...row};},
 create:async d=>{writes.push(type+".create");const row={...d,id:type+(++n),created_by_id:"buyer"};rows.push(row);return {...row};},
 update:async(id,d)=>{writes.push(type+".update");const row=rows.find(r=>r.id===id);Object.assign(row,d);return {...row};}});
 const client={entities:{SavedBoat:entity(saved,"boat"),SuggestedBoat:entity(suggestions,"suggestion"),CompareWorkspace:entity(spaces,"workspace")},
 functions:{invoke:()=>{throw Error("Choosing/loading must never generate matches or consume paid services");}}};
 return {client,saved,spaces,suggestions,writes};
}
test("one choose saves original Google href, selects and survives reloaded Compare",async()=>{
 const f=fixture();const a=await chooseMatchCandidate(f.client,{id:"s1"},"buyer");
 assert.equal(a.selected,true);assert.equal(f.saved[0].original_match_url,google);
 const loaded=await loadCompareCandidates(f.client,"buyer");assert.equal(loaded[0].id,a.candidate.id);
 assert.deepEqual(f.spaces[0].selected_ids,[a.candidate.id]);
});
test("rapid repeat choose and later retry do not duplicate candidate, selection or pasted URLs",async()=>{
 const f=fixture();const [a,b]=await Promise.all([chooseMatchCandidate(f.client,{id:"s1"},"buyer"),chooseMatchCandidate(f.client,{id:"s1"},"buyer")]);
 assert.equal(a.candidate.id,b.candidate.id);assert.equal(f.saved.length,1);assert.equal(f.spaces.length,1);
 f.saved[0].listing_urls=["https://dealer.com/real"];await chooseMatchCandidate(f.client,{id:"s1"},"buyer");
 assert.deepEqual(f.saved[0].listing_urls,["https://dealer.com/real"]);assert.equal(f.saved.length,1);
});
test("three explicit choices persist in order; fourth saves for later without replacing shortlist",async()=>{
 const f=fixture();for(const id of ["s1","s2","s3"])await chooseMatchCandidate(f.client,{id},"buyer");
 const ids=[...f.spaces[0].selected_ids];const fourth=await chooseMatchCandidate(f.client,{id:"s4"},"buyer");
 assert.equal(fourth.selected,false);assert.equal(fourth.selection_full,true);assert.deepEqual(f.spaces[0].selected_ids,ids);assert.equal(f.saved.length,4);
});
test("another account and QA records cannot enter the customer shortlist",async()=>{
 const f=fixture();f.suggestions[0].created_by_id="other";f.suggestions[1].test_profile_id="qa";
 await assert.rejects(chooseMatchCandidate(f.client,{id:"s1"},"buyer"),/unavailable/);
 await assert.rejects(chooseMatchCandidate(f.client,{id:"s2"},"buyer"),/unavailable/);assert.equal(f.saved.length,0);
});
test("choosing observes existing five-candidate cap while retaining recovery/reselection",async()=>{
 const f=fixture();for(const id of ["s1","s2","s3","s4","s5"])await chooseMatchCandidate(f.client,{id},"buyer");
 await assert.rejects(chooseMatchCandidate(f.client,{id:"s6"},"buyer"),/limit/);
 await chooseMatchCandidate(f.client,{id:"s1"},"buyer");assert.equal(f.saved.length,5);
});
test("normal UI retains free saved candidates/tier routes and duplicate-save guards",()=>{
 const dashboard=fs.readFileSync("src/pages/Dashboard.jsx","utf8");assert.match(dashboard,/!isPaid && <section id="saved-candidates"/);assert.match(dashboard,/FreeMatchPreview/);assert.match(dashboard,/onChooseCompare=\{handleChooseCompare\}/);assert.match(dashboard,/Use Find inside Match to look for boats for sale/);
 const matchPanel=fs.readFileSync("src/components/SuggestedBoatsPanel.jsx","utf8");
 assert.match(matchPanel,/Save model & open Compare/);
 assert.match(matchPanel,/Use Find to look for boats for sale, then save your favorite models to Compare/);
 const compareResults=fs.readFileSync("src/components/CurrentMatchResults.jsx","utf8");
 assert.match(compareResults,/Save to Compare/);
 assert.match(compareResults,/compare the research already in SoundHeading/);
 for(const p of ["Questionnaire","EditProfile"]){const s=fs.readFileSync("src/pages/"+p+".jsx","utf8");assert.match(s,/if\(saveInFlight.current\)return/);assert.match(s,/isPaidPlan\(effectivePlan\)/);}
 const compare=fs.readFileSync("src/components/CompareSavedCandidates.jsx","utf8");assert.match(compare,/if\(compareInFlight.current\)return/);assert.match(compare,/CompareImportResults/);assert.match(compare,/compareWithSavedInputs/);assert.doesNotMatch(compare,/We retrieve available details/);
 const link=fs.readFileSync("src/components/ListingLink.jsx","utf8");assert.match(link,/target="_blank"/);assert.doesNotMatch(link,/preventDefault|window.open|clipboard/);
});
