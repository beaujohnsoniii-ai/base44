import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { loadIntakeContext, runIntakeAction, intakePublicView } from '../base44/shared/listing-intake-service.mjs';
import { profileInputFingerprint } from '../base44/shared/profile-input-fingerprint.mjs';
import { harness, OWNER, POLICY, clone, completeData, request, screenshot, LISTING_ID, UPLOAD_ID, statusIs, deferred } from './listing-intake-fixtures.mjs';

const policy = { ...POLICY, workspace_kind: 'owner-production', workspace_label: 'owner-reset-fixture', max_uploads: 6, max_extractions: 6 };
async function setup(data = completeData()) {
  const h = await harness({ data });
  h.state.record.stage_fixture = false;
  h.state.record.fixture_label = policy.workspace_label;
  h.context = () => loadIntakeContext(h.client, OWNER, policy);
  return h;
}
async function rotate(h, index, replaceProfile = false) {
  h.state.profile.match_context_id = 'reset_context_' + index;
  if (replaceProfile) h.state.profile.id = 'replacement_profile_' + index;
  Object.assign(h.state.suggested, { id: 'current_suggestion_' + index, buyer_profile_id: h.state.profile.id, profile_input_fingerprint: await profileInputFingerprint(h.state.profile) });
}
const transition = (h, index) => request('start_current_context', { operation_id: 'transition_operation_' + index, listing_id: 'current_listing_' + index, model_type: 'suggestion', model_id: h.state.suggested.id, revision: h.state.record.revision });
const add = (h, index) => request('add_listing', { operation_id: 'add_operation_' + index, listing_id: 'added_listing_' + index, model_type: 'suggestion', model_id: h.state.suggested.id, revision: h.state.record.revision });
const protectedUnchanged = h => assert.deepEqual(h.calls.forbidden, []);
const noExternalWork = h => assert.equal(h.calls.uploads.length + h.calls.signs.length + h.calls.extracts.length, 0);

test('current model offers one integrated action after Reset, without mutating on open', async () => {
  const h = await setup(), original = clone(h.state.record);
  await rotate(h, 1);
  const result = await runIntakeAction(await h.context(), { action: 'model', model_type: 'suggestion', model_id: h.state.suggested.id });
  assert.equal(result.context_stale, true); assert.equal(result.context_transition_available, true);
  assert.deepEqual(h.state.record, original); noExternalWork(h); protectedUnchanged(h);
});

test('Reset transition binds first listing to exact current owner profile/result and archives all original evidence unchanged', async () => {
  const data = completeData();
  data.listings.push({ ...clone(data.listings[0]), id: 'empty_draft_history', uploads: [], versions: [] });
  const h = await setup(data), original = clone(h.state.record);
  await rotate(h, 1);
  const result = await runIntakeAction(await h.context(), transition(h, 1));
  assert.equal(result.context_stale, false);
  assert.equal(result.buyer_profile_id, h.state.profile.id);
  assert.equal(result.profile_fingerprint, h.state.suggested.profile_input_fingerprint);
  assert.equal(result.listings.length, 1);
  assert.equal(result.listings[0].model.source_id, h.state.suggested.id);
  assert.deepEqual(result.listings[0].uploads, []);
  assert.deepEqual(h.state.record.data.context_history[0].listings, original.data.listings);
  assert.equal(h.state.record.data.context_history[0].profile_fingerprint, original.profile_fingerprint);
  assert.equal(h.calls.commits[0].where.profile_fingerprint, original.profile_fingerprint);
  assert.equal(h.calls.commits[0].where.owner_id, OWNER.id);
  assert.deepEqual(h.state.record.data.operations.slice(0, original.data.operations.length), original.data.operations);
  noExternalWork(h); protectedUnchanged(h);
});

test('repeated Reset and replacement profile preserve each context, do not resurrect drafts or consume external allowance', async () => {
  const h = await setup(), histories = [clone(h.state.record.data.listings)];
  for (let index = 1; index <= 4; index++) {
    await rotate(h, index, index === 3);
    const body = transition(h, index);
    await runIntakeAction(await h.context(), body);
    assert.equal(h.state.record.data.context_history.length, index);
    assert.equal(h.state.record.data.listings.length, 1);
    assert.deepEqual(h.state.record.data.context_history.map(c => c.listings), histories);
    const beforeReplay = clone(h.state.record);
    const replay = await runIntakeAction(await h.context(), body);
    assert.equal(replay.replayed, true); assert.deepEqual(h.state.record, beforeReplay);
    histories.push(clone(h.state.record.data.listings));
  }
  noExternalWork(h); protectedUnchanged(h);
});

test('same current context accepts multiple current result models, enforcing only its 3-model/3-listing slots', async () => {
  const h = await setup(); await rotate(h, 1);
  await runIntakeAction(await h.context(), transition(h, 1));
  for (let index = 2; index <= 3; index++) {
    Object.assign(h.state.suggested, { id: 'current_suggestion_' + index, model: 'Model ' + index });
    await runIntakeAction(await h.context(), add(h, index));
  }
  assert.equal(h.state.record.data.listings.length, 3);
  assert.equal(h.state.record.data.context_history.length, 1);
  h.state.suggested = { ...h.state.suggested, id: 'current_suggestion_four', model: 'Model four' };
  await assert.rejects(runIntakeAction(await h.context(), add(h, 4)), statusIs(409));
  h.state.suggested = { ...h.state.suggested, id: 'current_suggestion_3', model: 'Model 3' };
  for (const index of [5, 6]) await runIntakeAction(await h.context(), add(h, index));
  await assert.rejects(runIntakeAction(await h.context(), add(h, 7)), statusIs(409));
  assert.equal(h.state.record.data.listings.length, 5); noExternalWork(h); protectedUnchanged(h);
});

test('transition rejects stale/foreign/test/superseded/arbitrary results and saved sources without a write', async () => {
  for (const change of [{ profile_input_fingerprint: 'old' }, { buyer_profile_id: 'old_profile' }, { created_by_id: 'someone_else' }, { test_profile_id: 'test_profile' }, { superseded: true }, { id: 'arbitrary_result' }]) {
    const h = await setup(); await rotate(h, 1);
    const body = transition(h, 1); Object.assign(h.state.suggested, change);
    const before = clone(h.state.record);
    await assert.rejects(runIntakeAction(await h.context(), body), e => [403,409].includes(e.status));
    assert.deepEqual(h.state.record, before); noExternalWork(h); protectedUnchanged(h);
  }
  const h = await setup(); await rotate(h, 1);
  await assert.rejects(runIntakeAction(await h.context(), { ...transition(h, 1), model_type: 'saved' }), statusIs(409));
  h.state.record.owner_id = 'other_owner';
  await assert.rejects(h.context(), statusIs(403));
});

test('no browser-supplied profile, fingerprint, owner or archive is accepted as transition authority', async () => {
  for (const field of ['owner_id', 'buyer_profile_id', 'profile_fingerprint', 'context_history']) {
    const h = await setup(); await rotate(h, 1);
    await assert.rejects(runIntakeAction(await h.context(), { ...transition(h, 1), [field]: 'forged' }), statusIs(400));
    assert.equal(h.calls.commits.length, 0);
  }
});

test('concurrent context transitions have one winner; changed payload and stale pending mutation cannot overwrite it', async () => {
  const h = await setup(); await rotate(h, 1);
  const a = await h.context(), b = await h.context(), body = transition(h, 1);
  const second = { ...body, operation_id: 'parallel_transition', listing_id: 'parallel_listing' };
  const results = await Promise.allSettled([runIntakeAction(a, body), runIntakeAction(b, second)]);
  assert.equal(results.filter(r => r.status === 'fulfilled').length, 1);
  assert.equal(h.state.record.data.context_history.length, 1);
  const before = clone(h.state.record);
  const winning = results[0].status === 'fulfilled' ? body : second;
  await assert.rejects(runIntakeAction(await h.context(), { ...winning, listing_id: 'changed_replay_listing' }), statusIs(409));
  await assert.rejects(runIntakeAction(await h.context(), request('save_reference', { reference_url: '' })), statusIs(409));
  await assert.rejects(runIntakeAction(await h.context(), { ...transition(h, 9), model_id: 'old_result' }), e => [403,409].includes(e.status));
  assert.deepEqual(h.state.record, before); noExternalWork(h);
});

test('profile rotation or result supersession during transition validation leaves all history untouched', async () => {
  for (const change of ['profile', 'result']) {
    const h = await setup(); await rotate(h, 1);
    const ctx = await h.context(), before = clone(h.state.record);
    h.hooks.profileRead = async () => { if (change === 'profile') h.state.profile.match_context_id = 'newer_reset'; else h.state.suggested.superseded = true; };
    await assert.rejects(runIntakeAction(ctx, transition(h, 1)), statusIs(409));
    assert.deepEqual(h.state.record, before); assert.equal(h.calls.commits.length, 0);
  }
});

test('archived listing IDs cannot be reused or mutated and private source previews remain registered-only', async () => {
  const h = await setup();
  h.state.record.data.listings[0].uploads[0].file_uri = `mp/private/${POLICY.app_id}/archived-source.png`;
  const original = clone(h.state.record.data.listings);
  await rotate(h, 1);
  await assert.rejects(runIntakeAction(await h.context(), { ...transition(h, 1), listing_id: LISTING_ID }), statusIs(409));
  await runIntakeAction(await h.context(), transition(h, 1));
  await assert.rejects(runIntakeAction(await h.context(), request('reset_listing', { revision: h.state.record.revision, operation_id: 'reset_old_history', reset_confirmed: true })), statusIs(409));
  await assert.rejects(runIntakeAction(await h.context(), { ...add(h, 3), listing_id: LISTING_ID }), statusIs(409));
  const view = intakePublicView(h.state.record);
  assert.ok(!JSON.stringify(view).includes('mp/private/'));
  assert.deepEqual(h.state.record.data.context_history[0].listings, original);
  await runIntakeAction(await h.context(), { action: 'preview_source', listing_id: LISTING_ID, upload_id: UPLOAD_ID });
  assert.equal(h.calls.signs.length, 1);
  await assert.rejects(runIntakeAction(await h.context(), { action: 'preview_source', listing_id: LISTING_ID, upload_id: 'unregistered_upload' }), statusIs(404));
  assert.equal(h.calls.signs.length, 1); protectedUnchanged(h);
});

test('3 remaining uploads stay 3 after repeated Reset; sixth is allowed and seventh rejected across history', async () => {
  const h = await setup();
  h.state.record.data.operations = Array.from({ length: 3 }, (_, i) => ({ id: 'old_upload_' + i, action: 'upload', status: 'complete' }));
  for (let index = 1; index <= 3; index++) {
    await rotate(h, index); await runIntakeAction(await h.context(), transition(h, index));
    assert.equal(h.state.record.data.operations.filter(o => o.action === 'upload').length, 2 + index);
    await runIntakeAction(await h.context(), request('upload', { operation_id: 'new_upload_op_' + index, listing_id: 'current_listing_' + index, upload_id: 'new_upload_' + index, revision: h.state.record.revision, file: screenshot() }));
    await runIntakeAction(await h.context(), request('read_screenshot', { operation_id: 'new_read_op_' + index, listing_id: 'current_listing_' + index, upload_id: 'new_upload_' + index, revision: h.state.record.revision }));
  }
  await rotate(h, 4); await runIntakeAction(await h.context(), transition(h, 4));
  await assert.rejects(runIntakeAction(await h.context(), request('upload', { operation_id: 'seventh_upload_op', listing_id: 'current_listing_4', upload_id: 'seventh_upload', revision: h.state.record.revision, file: screenshot() })), statusIs(409));
  assert.equal(h.calls.uploads.length, 3); assert.equal(h.calls.extracts.length, 3); protectedUnchanged(h);
});

test('failed extraction recovery is read/replay only; Reset cannot hide pending evidence or spend again', async () => {
  const h = await setup(); await rotate(h, 1); await runIntakeAction(await h.context(), transition(h, 1));
  await runIntakeAction(await h.context(), request('upload', { operation_id: 'recovery_upload_op', listing_id: 'current_listing_1', upload_id: 'recovery_upload', revision: h.state.record.revision, file: screenshot() }));
  h.hooks.extract = async () => { throw Error('Synthetic response lost'); };
  const body = request('read_screenshot', { operation_id: 'recovery_read_op', listing_id: 'current_listing_1', upload_id: 'recovery_upload', revision: h.state.record.revision });
  await assert.rejects(runIntakeAction(await h.context(), body), statusIs(503));
  const before = clone(h.state.record);
  assert.equal((await runIntakeAction(await h.context(), body)).operation_status, 'uncertain');
  await runIntakeAction(await h.context(), { action: 'read' });
  await rotate(h, 2);
  await assert.rejects(runIntakeAction(await h.context(), transition(h, 2)), statusIs(409));
  assert.deepEqual(h.state.record, before); assert.equal(h.calls.extracts.length, 1); assert.equal(h.calls.uploads.length, 1);
});

test('late extraction after Reset cannot migrate into new context and blocks transition until reconciled', async () => {
  const h = await setup(); await rotate(h, 1); await runIntakeAction(await h.context(), transition(h, 1));
  await runIntakeAction(await h.context(), request('upload', { operation_id: 'late_upload_op', listing_id: 'current_listing_1', upload_id: 'late_upload', revision: h.state.record.revision, file: screenshot() }));
  const reached = deferred(), response = deferred();
  h.hooks.extract = async () => { reached.resolve(); return response.promise; };
  const pending = runIntakeAction(await h.context(), request('read_screenshot', { operation_id: 'late_read_op', listing_id: 'current_listing_1', upload_id: 'late_upload', revision: h.state.record.revision }));
  await reached.promise; await rotate(h, 2);
  response.resolve({ status: 'success', output: {} }); await assert.rejects(pending, statusIs(503));
  const before = clone(h.state.record);
  await assert.rejects(runIntakeAction(await h.context(), transition(h, 2)), statusIs(409));
  assert.deepEqual(h.state.record, before); assert.equal(h.calls.extracts.length, 1);
});


test('transition save failure before persistence retains original data; ambiguous success reconciles without archiving twice', async () => {
  for (const phase of ['before', 'after', 'readback']) {
    const h = await setup(); await rotate(h, 1);
    const ctx = await h.context(), body = transition(h, 1), before = clone(h.state.record);
    if (phase === 'before') h.hooks.beforeCommit = async () => { throw Error('Synthetic save rejected'); };
    if (phase === 'after') h.hooks.afterCommit = async () => { throw Error('Synthetic acknowledgement lost'); };
    if (phase === 'readback') h.hooks.get = async () => { throw Error('Synthetic readback unavailable'); };
    await assert.rejects(runIntakeAction(ctx, body));
    delete h.hooks.beforeCommit; delete h.hooks.afterCommit; delete h.hooks.get;
    const saved = await runIntakeAction(await h.context(), { action: 'read' });
    if (phase === 'before') {
      assert.deepEqual(h.state.record, before); assert.equal(saved.context_stale, true);
    } else {
      assert.equal(saved.context_stale, false); assert.equal(saved.context_history.length, 1);
      const committed = clone(h.state.record);
      const replay = await runIntakeAction(await h.context(), body);
      assert.equal(replay.replayed, true); assert.deepEqual(h.state.record, committed);
      assert.equal(h.state.record.data.listings.length, 1);
    }
    noExternalWork(h); protectedUnchanged(h);
  }
});


test('actual panel accept callback drops late mutation/reconciliation results without replacing state or counts', async () => {
  const panel = await readFile('src/components/ListingIntakePanel.jsx', 'utf8');
  const expression = panel.slice(panel.indexOf('const accept = ') + 'const accept = '.length, panel.indexOf('\n  const load ='));
  const changes = [], counts = [];
  const env = { mounted: { current: true }, loadSequence: { current: 3 }, pendingRequest: { current: { operation_id: 'pending_id' } }, stateRef: { current: { revision: 9 } }, setState: value => changes.push(value), onCountChange: value => counts.push(value) };
  const accept = Function('env', 'const {mounted,loadSequence,pendingRequest,stateRef,setState,onCountChange}=env; return ' + expression)(env);
  const result = { revision: 10, listings: [], operations: [{ id: 'pending_id', status: 'complete' }] };
  assert.equal(accept(result, 2), null);
  assert.equal(env.stateRef.current.revision, 9); assert.equal(env.pendingRequest.current.operation_id, 'pending_id');
  assert.deepEqual(changes, []); assert.deepEqual(counts, []);
  env.mounted.current = false;
  assert.equal(accept(result, 3), null); assert.deepEqual(changes, []);
  env.mounted.current = true;
  assert.equal(accept(result, 3), result); assert.equal(env.pendingRequest.current, null);
  assert.equal(changes.length, 1); assert.equal(counts.length, 1);
});

test('actual panel upload loop does not read or upload more after its model/history/mode sequence changes', async () => {
  const panel = await readFile('src/components/ListingIntakePanel.jsx', 'utf8');
  const expression = panel.slice(panel.indexOf('const uploads = ') + 'const uploads = '.length, panel.indexOf('\n  const reconcilePending ='));
  const reached = deferred(), response = deferred(), calls = [];
  const env = { inFlight: { current: false }, mounted: { current: true }, loadSequence: { current: 1 }, stateRef: { current: { revision: 1, allowance: { screenshots_remaining: 3 } } }, pendingRequest: { current: null }, setBusy: () => {}, setError: () => {}, INTAKE_LIMITS: { images_per_listing: 6, image_bytes: 6291456 } };
  env.request = async body => { calls.push(body.action); reached.resolve(); return response.promise; };
  env.accept = (_result, sequence) => env.mounted.current && sequence === env.loadSequence.current ? _result : null;
  const uploads = Function('env', 'const {inFlight,mounted,loadSequence,stateRef,pendingRequest,setBusy,setError,INTAKE_LIMITS,request,accept}=env; const imageLimit=6; return ' + expression)(env);
  const pending = uploads({ id: 'listing_fixture', uploads: [] }, [screenshot(), screenshot()]);
  await reached.promise;
  env.loadSequence.current++;
  response.resolve({ revision: 2, listings: [] });
  await pending;
  assert.deepEqual(calls, ['upload']);
  assert.equal(env.inFlight.current, false);
});


test('Reset between validation and record save is reported stale without rebinding or losing history', async () => {
  const h = await setup(); await rotate(h, 1);
  const expectedFingerprint = h.state.suggested.profile_input_fingerprint;
  h.hooks.beforeCommit = async () => { h.state.profile.match_context_id = 'simultaneous_reset'; };
  const result = await runIntakeAction(await h.context(), transition(h, 1));
  assert.equal(result.context_stale, true);
  assert.equal(h.state.record.profile_fingerprint, expectedFingerprint);
  assert.equal(result.listings[0].model.source_id, 'current_suggestion_1');
  assert.equal(result.context_history.length, 1);
  assert.equal((await h.context()).stale, true);
  noExternalWork(h); protectedUnchanged(h);
});

test('UI offers integrated current-Match CTA, read-only history and sequence-guards late model loads', async () => {
  const panel = await readFile('src/components/ListingIntakePanel.jsx', 'utf8');
  assert.match(panel, /Add a listing for this Match/);
  assert.match(panel, /state.context_transition_available && !state.history_only/);
  assert.match(panel, /run\('start_current_context', \{ model_type: sourceType, model_id: boat.id, listing_id: crypto.randomUUID\(\) \}\)/);
  assert.match(panel, /Earlier Match listing history/);
  assert.match(panel, /sequence === loadSequence.current/);
  assert.match(panel, /busy=\{true\} processingEnabled=\{false\}/);
});
