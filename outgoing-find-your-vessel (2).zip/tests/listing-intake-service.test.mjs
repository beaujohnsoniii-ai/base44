import test from 'node:test';
import assert from 'node:assert/strict';
import { INTAKE_LIMITS, IntakeError, normalizeScreenshotExtraction } from '../base44/shared/listing-intake.mjs';
import { allowedStageCaller, loadIntakeContext, assertStillCurrent, intakePublicView, commitIntake, resolveIntakeModel, profileSnapshot, runIntakeAction, validateScreenshot } from '../base44/shared/listing-intake-service.mjs';
import { DEFAULT_FIELD_TIERS } from '../base44/shared/question-tier-defaults.mjs';
import { NOW, OWNER, POLICY, MODEL, LISTING_ID, UPLOAD_ID, clone, output, source, candidate, completedUpload, listingData, completeData, statusIs, pngBytes, screenshot, deferred, harness, request, uploadedData } from './listing-intake-fixtures.mjs';

const privatePrefix = `mp/private/${POLICY.app_id}/`;
const uploadRequest = (extra = {}) => request('upload', { upload_id: UPLOAD_ID, file: screenshot(), ...extra });
const readRequest = (extra = {}) => request('read_screenshot', { upload_id: UPLOAD_ID, ...extra });
const neverMutatedProtectedEntities = h => assert.deepEqual(h.calls.forbidden, []);

test('owner-only staging gate requires enabled dev fixture, exact app/owner and active nonservice admin', () => {
  assert.equal(allowedStageCaller(OWNER, POLICY, 'dev'), true);
  for (const [user, policy, env] of [
    [{ ...OWNER, id: 'another_owner' }, POLICY, 'dev'],
    [{ ...OWNER, app_id: 'another_app' }, POLICY, 'dev'],
    [{ ...OWNER, role: 'user' }, POLICY, 'dev'],
    [{ ...OWNER, is_service: true }, POLICY, 'dev'],
    [{ ...OWNER, disabled: true }, POLICY, 'dev'],
    [null, POLICY, 'dev'], [OWNER, { ...POLICY, enabled: false }, 'dev'],
    [OWNER, { ...POLICY, record_id: '' }, 'dev'], [OWNER, POLICY, 'prod'], [OWNER, POLICY, undefined],
  ]) assert.equal(allowedStageCaller(user, policy, env), false);
});

test('context loading rejects nonowner records, foreign profiles and nonfixtures', async () => {
  for (const record of [{ owner_id: 'not_owner' }, { stage_fixture: false }]) {
    const h = await harness({ record }); await assert.rejects(h.context(), error => [403,409].includes(error.status));
    neverMutatedProtectedEntities(h); assert.equal(h.calls.commits.length, 0);
  }
  const h = await harness(); h.state.profile.created_by_id = 'not_owner';
  await assert.rejects(h.context(), statusIs(409));
  h.state.profile = null; await assert.rejects(h.context(), statusIs(409));
});

test('stale profile context remains readable but cannot be confirmed or mutated', async () => {
  for (const record of [{ buyer_profile_id: 'old_profile_01' }, { profile_fingerprint: 'stale' }]) {
    const h = await harness({ record, data: completeData() }), ctx = await h.context();
    assert.equal(ctx.stale, true);
    const view = await runIntakeAction(ctx, { action: 'read' });
    assert.equal(view.listings.length, 1);
    await assert.rejects(runIntakeAction(ctx, request('save_reference', { reference_url: '' })), statusIs(409));
    await assert.rejects(runIntakeAction(ctx, request('confirm')), statusIs(409));
    assert.equal(h.calls.commits.length, 0); neverMutatedProtectedEntities(h);
  }
});

test('profile snapshot contains sanctioned input fields but not PII or arbitrary fields', () => {
  const profile = { ...Object.fromEntries(Object.keys(DEFAULT_FIELD_TIERS).map(key => [key, `value:${key}`])), email: 'private@example.invalid', name: 'Synthetic buyer', secret: 'not-a-real-secret', hard_max_overall_length_ft: 23, match_context_id: 'context_1' };
  const snapshot = profileSnapshot(profile);
  for (const key of Object.keys(DEFAULT_FIELD_TIERS)) assert.equal(snapshot[key], profile[key]);
  assert.equal(snapshot.hard_max_overall_length_ft, 23); assert.equal(snapshot.match_context_id, 'context_1');
  for (const key of ['email', 'name', 'secret', 'id', 'created_by_id']) assert.ok(!(key in snapshot));
});

test('saved and current suggested models are resolved server-side, never from caller-supplied identity', async () => {
  const h = await harness(), ctx = await h.context();
  assert.equal((await resolveIntakeModel(ctx, 'saved', MODEL.source_id)).model_key, MODEL.model_key);
  assert.equal((await resolveIntakeModel(ctx, 'suggestion', 'suggested_model_01')).model, 'VR5');
  h.state.saved.created_by_id = 'other'; await assert.rejects(resolveIntakeModel(ctx, 'saved', MODEL.source_id), statusIs(403));
  h.state.suggested.superseded = true; await assert.rejects(resolveIntakeModel(ctx, 'suggestion', 'suggested_model_01'), statusIs(409));
  delete h.state.suggested.superseded; h.state.suggested.profile_input_fingerprint = 'old';
  await assert.rejects(resolveIntakeModel(ctx, 'suggestion', 'suggested_model_01'), statusIs(409));
  await assert.rejects(resolveIntakeModel(ctx, 'other', MODEL.source_id), statusIs(400));
  neverMutatedProtectedEntities(h);
});

test('public review strips storage URIs without modifying saved data or enabling assessment', async () => {
  const h = await harness({ data: uploadedData() }), original = clone(h.state.record), view = intakePublicView(h.state.record);
  assert.equal(view.assessment_enabled, false); assert.equal(view.staging, true);
  assert.ok(!('file_uri' in view.listings[0].uploads[0])); assert.deepEqual(h.state.record, original);
  assert.ok(!JSON.stringify(view).includes(privatePrefix));
});

test('compare-and-swap allows exactly one winner and retains the first committed data', async () => {
  const h = await harness(), first = await h.context(), second = await h.context();
  const a = clone(first.record.data), b = clone(second.record.data);
  a.listings[0].reference_url = 'https://seller.example/listing/first-caller'; b.listings[0].reference_url = 'https://seller.example/listing/second-caller';
  const outcomes = await Promise.allSettled([commitIntake(first, a), commitIntake(second, b)]);
  assert.equal(outcomes.filter(x => x.status === 'fulfilled').length, 1);
  assert.equal(outcomes.filter(x => x.status === 'rejected').length, 1);
  assert.equal(outcomes.find(x => x.status === 'rejected').reason.status, 409);
  const winner = [a, b][outcomes.findIndex(outcome => outcome.status === 'fulfilled')];
  assert.equal(h.state.record.revision, 2); assert.equal(h.state.record.data.listings[0].reference_url, winner.listings[0].reference_url);
  assert.equal(h.calls.commits[0].where.owner_id, OWNER.id);
  assert.equal(h.calls.commits[0].where.buyer_profile_id, h.state.profile.id);
  assert.equal(h.calls.commits[0].where.profile_fingerprint, h.state.record.profile_fingerprint);
  assert.equal(h.calls.commits[0].where.revision, 1); neverMutatedProtectedEntities(h);
});

test('profile changes between load and commit block all writes', async () => {
  const h = await harness(), ctx = await h.context(); h.state.profile.match_context_id = 'changed_context';
  await assert.rejects(assertStillCurrent(ctx), statusIs(409));
  await assert.rejects(commitIntake(ctx, ctx.record.data), statusIs(409));
  assert.equal(h.calls.commits.length, 0); assert.equal(h.state.record.revision, 1); neverMutatedProtectedEntities(h);
});

test('stale caller revision and missing/malformed operation IDs reject before mutation', async () => {
  const h = await harness(), ctx = await h.context();
  await assert.rejects(runIntakeAction(ctx, request('save_reference', { revision: 0, reference_url: '' })), statusIs(409));
  await assert.rejects(runIntakeAction(ctx, request('save_reference', { operation_id: 'x', reference_url: '' })), statusIs(400));
  assert.equal(h.calls.commits.length, 0); assert.equal(h.calls.uploads.length, 0);
});

test('operation replay returns original completion without reapplying; input mismatch is rejected', async () => {
  const h = await harness(), ctx = await h.context();
  const body = request('save_reference', { reference_url: 'https://seller.example/listing/changed' });
  await runIntakeAction(ctx, body); const committed = clone(h.state.record);
  const replay = await runIntakeAction(await h.context(), { ...body, revision: 1 });
  assert.equal(replay.replayed, true); assert.equal(replay.operation_status, 'complete');
  assert.deepEqual(h.state.record, committed); assert.equal(h.calls.commits.length, 1);
  await assert.rejects(runIntakeAction(await h.context(), { ...body, reference_url: 'https://seller.example/listing/different' }), statusIs(409));
  assert.equal(h.calls.commits.length, 1); neverMutatedProtectedEntities(h);
});

test('forged client URI, extraction, owner or profile fields are rejected rather than used', async () => {
  const h = await harness(), ctx = await h.context();
  for (const extra of [{ file_uri: `${privatePrefix}forged.png` }, { file_url: 'https://attacker.invalid/file.png' }, { extraction: { engine_hours: 1 } }, { owner_id: 'other' }, { profile_fingerprint: 'forged' }, { make: 'Forged' }]) {
    await assert.rejects(runIntakeAction(ctx, { ...readRequest(), ...extra }), statusIs(400));
  }
  assert.equal(h.calls.uploads.length, 0); assert.equal(h.calls.signs.length, 0); assert.equal(h.calls.extracts.length, 0); assert.equal(h.calls.commits.length, 0);
});

test('upload stores one authenticated private receipt, returns no URI and exact replay never reuploads', async () => {
  const h = await harness(), body = uploadRequest(), ctx = await h.context();
  const view = await runIntakeAction(ctx, body);
  assert.equal(h.calls.uploads.length, 1); assert.equal(h.calls.signs.length, 0); assert.equal(h.calls.extracts.length, 0);
  assert.equal(h.state.record.data.listings[0].uploads[0].status, 'uploaded');
  assert.ok(h.state.record.data.listings[0].uploads[0].file_uri.startsWith(privatePrefix));
  assert.ok(!('file_uri' in view.listings[0].uploads[0]));
  const replay = await runIntakeAction(await h.context(), body); assert.equal(replay.replayed, true); assert.equal(h.calls.uploads.length, 1);
  await assert.rejects(runIntakeAction(await h.context(), { ...body, file: screenshot({ bytes: pngBytes(1, 1, 42) }) }), statusIs(409));
  assert.equal(h.calls.uploads.length, 1); neverMutatedProtectedEntities(h);
});

test('duplicate image digest and duplicate upload ID reject before any provider call', async () => {
  const h = await harness(); await runIntakeAction(await h.context(), uploadRequest());
  const revision = h.state.record.revision;
  await assert.rejects(runIntakeAction(await h.context(), uploadRequest({ operation_id: 'operation_second_01', revision, upload_id: 'upload_second_01' })), statusIs(409));
  await assert.rejects(runIntakeAction(await h.context(), uploadRequest({ operation_id: 'operation_third_01', revision, file: screenshot({ bytes: pngBytes(1, 1, 9) }) })), statusIs(409));
  assert.equal(h.calls.uploads.length, 1); assert.equal(h.state.record.data.listings[0].uploads.length, 1);
});

test('six-source upload cap blocks seventh before external work', async () => {
  const data = listingData(); data.listings[0].uploads = Array.from({ length: INTAKE_LIMITS.images_per_listing }, (_, i) => ({ ...source(`existing_upload_${i}`), status: 'complete', sha256: `hash_${i}` }));
  const h = await harness({ data });
  await assert.rejects(runIntakeAction(await h.context(), uploadRequest()), statusIs(409));
  assert.equal(h.calls.uploads.length, 0); assert.equal(h.calls.commits.length, 0);
});

test('cross-app, public or missing upload receipt is uncertain with no fallback or automatic retry', async () => {
  for (const receipt of [{ file_uri: 'mp/private/other_app/file.png' }, { file_uri: 'https://public.invalid/file.png' }, {}]) {
    const h = await harness(); h.hooks.upload = async () => receipt;
    await assert.rejects(runIntakeAction(await h.context(), uploadRequest()), statusIs(503));
    assert.equal(h.calls.uploads.length, 1); assert.equal(h.calls.signs.length, 0);
    assert.equal(h.state.record.data.operations[0].status, 'uncertain');
    assert.equal(h.state.record.data.listings[0].uploads[0].status, 'uncertain');
    const replay = await runIntakeAction(await h.context(), uploadRequest()); assert.equal(replay.replayed, true); assert.equal(replay.operation_status, 'uncertain');
    assert.equal(h.calls.uploads.length, 1);
  }
});

test('unknown upload outcome blocks new operations, replays status, and never repeats external work', async () => {
  const h = await harness(); h.hooks.upload = async () => { throw new Error('Synthetic transport dropped after upload may have succeeded'); };
  const body = uploadRequest(); await assert.rejects(runIntakeAction(await h.context(), body), statusIs(503));
  assert.equal(h.state.record.data.operations[0].status, 'uncertain');
  await runIntakeAction(await h.context(), body);
  await assert.rejects(runIntakeAction(await h.context(), request('save_reference', { operation_id: 'operation_new_01', revision: h.state.record.revision, reference_url: '' })), statusIs(409));
  assert.equal(h.calls.uploads.length, 1); assert.equal(h.calls.extracts.length, 0); neverMutatedProtectedEntities(h);
});

test('late upload receipt cannot attach to a newer listing revision', async () => {
  const h = await harness(), reached = deferred(), result = deferred();
  h.hooks.upload = async () => { reached.resolve(); return result.promise; };
  const pending = runIntakeAction(await h.context(), uploadRequest());
  await reached.promise; h.state.record.data.listings[0].revision += 1; h.state.record.revision += 1;
  result.resolve({ file_uri: `${privatePrefix}late-result.png` });
  await assert.rejects(pending, statusIs(503));
  assert.equal(h.calls.uploads.length, 1); assert.ok(!h.state.record.data.listings[0].uploads[0].file_uri);
  assert.equal(h.state.record.data.operations[0].status, 'uncertain');
});

test('late upload after profile change leaves saved old context reserved and does not attach receipt', async () => {
  const h = await harness(), reached = deferred(), result = deferred();
  h.hooks.upload = async () => { reached.resolve(); return result.promise; };
  const pending = runIntakeAction(await h.context(), uploadRequest()); await reached.promise;
  h.state.profile.match_context_id = 'new_context'; result.resolve({ file_uri: `${privatePrefix}late-profile-result.png` });
  await assert.rejects(pending, statusIs(503));
  assert.equal(h.calls.uploads.length, 1); assert.equal(h.state.record.data.operations[0].status, 'reserved');
  assert.ok(!h.state.record.data.listings[0].uploads[0].file_uri);
});

test('reading signs only stored owner source and normalizes evidence once without private URI leakage', async () => {
  const h = await harness({ data: uploadedData() }), body = readRequest();
  const view = await runIntakeAction(await h.context(), body);
  assert.equal(h.calls.signs.length, 1); assert.equal(h.calls.signs[0].file_uri, h.state.record.data.listings[0].uploads[0].file_uri);
  assert.equal(h.calls.extracts.length, 1); assert.equal(h.calls.extracts[0].file_url, 'https://signed.invalid/synthetic-fixture-only');
  assert.ok(h.calls.extracts[0].json_schema.description.includes('Do not browse'));
  assert.equal(view.listings[0].uploads[0].status, 'complete');
  assert.equal(view.listings[0].evidence.fields.asking_price.value, 42900);
  assert.equal(view.listings[0].evidence.fields.engine_hours.value, null);
  assert.equal(view.listings[0].evidence.fields.currency_code.value, null);
  assert.ok(!JSON.stringify(view).includes(privatePrefix)); assert.ok(!JSON.stringify(view).includes('signed.invalid'));
  await runIntakeAction(await h.context(), body); assert.equal(h.calls.signs.length, 1); assert.equal(h.calls.extracts.length, 1);
  neverMutatedProtectedEntities(h);
});

test('reading rejects foreign stored URI before signing or extraction', async () => {
  const data = uploadedData(); data.listings[0].uploads[0].file_uri = 'mp/private/other_app/source.png';
  const h = await harness({ data });
  await assert.rejects(runIntakeAction(await h.context(), readRequest()), statusIs(409));
  assert.equal(h.calls.signs.length, 0); assert.equal(h.calls.extracts.length, 0); assert.equal(h.calls.commits.length, 0);
});

test('late extraction cannot overwrite a newer listing revision or prior immutable snapshots', async () => {
  const h = await harness({ data: uploadedData() }), reached = deferred(), result = deferred();
  h.state.record.data.listings[0].versions = [{ version: 1, digest: 'immutable_fixture_digest', fields: { engine_hours: { value: 10 } } }];
  const prior = clone(h.state.record.data.listings[0].versions);
  h.hooks.extract = async () => { reached.resolve(); return result.promise; };
  const pending = runIntakeAction(await h.context(), readRequest()); await reached.promise;
  h.state.record.data.listings[0].revision += 1; h.state.record.revision += 1;
  result.resolve(output({ engine_hours: 999 }, [{ field: 'engine_hours', quote: 'Engine hours 999' }]));
  await assert.rejects(pending, statusIs(503));
  assert.equal(h.calls.extracts.length, 1); assert.ok(!h.state.record.data.listings[0].uploads[0].extraction);
  assert.deepEqual(h.state.record.data.listings[0].versions, prior); assert.equal(h.state.record.data.operations[0].status, 'uncertain');
});

test('extraction failure is uncertain, never retried, and does not invent missing evidence', async () => {
  const h = await harness({ data: uploadedData() }); h.hooks.extract = async () => { throw new Error('Synthetic provider timeout'); };
  const body = readRequest(); await assert.rejects(runIntakeAction(await h.context(), body), statusIs(503));
  const view = await runIntakeAction(await h.context(), body);
  assert.equal(view.operation_status, 'uncertain'); assert.equal(h.calls.extracts.length, 1); assert.equal(h.calls.signs.length, 1);
  assert.equal(view.listings[0].evidence.fields.engine_hours.value, null);
  await assert.rejects(runIntakeAction(await h.context(), readRequest({ operation_id: 'different_read_01', revision: h.state.record.revision })), statusIs(409));
  assert.equal(h.calls.extracts.length, 1);
});

test('save failure after successful extraction never invokes provider a second time', async () => {
  const h = await harness({ data: uploadedData() });
  h.hooks.beforeCommit = async (_where, patch) => {
    if (patch.$set.data.operations[0]?.status === 'complete') throw new Error('Synthetic database timeout after external result');
  };
  const body = readRequest(); await assert.rejects(runIntakeAction(await h.context(), body), statusIs(503));
  await runIntakeAction(await h.context(), body);
  assert.equal(h.calls.extracts.length, 1); assert.equal(h.calls.signs.length, 1);
  assert.equal(h.state.record.data.operations[0].status, 'uncertain');
});

test('preview accepts only saved listing upload, signs briefly, and does not mutate state', async () => {
  const h = await harness({ data: uploadedData() }), ctx = await h.context(), before = clone(h.state.record);
  const result = await runIntakeAction(ctx, { action: 'preview_source', listing_id: LISTING_ID, upload_id: UPLOAD_ID });
  assert.equal(result.expires_in, 60); assert.equal(h.calls.signs[0].expires_in, 60); assert.deepEqual(h.state.record, before);
  await assert.rejects(runIntakeAction(ctx, { action: 'preview_source', listing_id: LISTING_ID, upload_id: 'missing_upload_01' }), statusIs(404));
  assert.equal(h.calls.signs.length, 1);
});

test('disabled integrations prevent upload, signing and extraction', async () => {
  const h = await harness({ data: uploadedData() }), ctx = await h.context(); ctx.policy.integrations_enabled = false;
  await assert.rejects(runIntakeAction(ctx, uploadRequest()), statusIs(409));
  await assert.rejects(runIntakeAction(ctx, readRequest()), statusIs(409));
  assert.equal(h.calls.uploads.length + h.calls.signs.length + h.calls.extracts.length, 0);
});

test('only recognized image types, magic bytes, bounded dimensions and sane sizes pass', async () => {
  const good = await validateScreenshot(screenshot());
  assert.equal(good.mime, 'image/png'); assert.equal(good.width, 1); assert.equal(good.height, 1); assert.match(good.sha256, /^[a-f0-9]{64}$/);
  for (const file of [
    screenshot({ type: 'image/gif' }), screenshot({ type: 'image/jpeg' }),
    screenshot({ bytes: Buffer.alloc(64, 1) }), screenshot({ bytes: pngBytes(0, 1) }),
    screenshot({ bytes: pngBytes(1, 0) }), screenshot({ bytes: pngBytes(16001, 1) }),
    screenshot({ bytes: pngBytes(6000, 4001) }), screenshot({ size: 31 }),
    screenshot({ size: INTAKE_LIMITS.image_bytes + 1 }), null,
  ]) await assert.rejects(validateScreenshot(file), statusIs(400));
  const cleaned = await validateScreenshot(screenshot({ name: ' <test>\u0000.png ' }));
  assert.ok(!/[<>\u0000]/.test(cleaned.name));
});

test('regression: actual bytes, not attacker-reported file.size, enforce screenshot limit', async () => {
  const large = Buffer.alloc(INTAKE_LIMITS.image_bytes + 1); pngBytes().copy(large);
  await assert.rejects(validateScreenshot(screenshot({ bytes: large, size: 64 })), statusIs(400));
  await assert.rejects(validateScreenshot(screenshot({ bytes: pngBytes().subarray(0, 8), size: 64 })), statusIs(400));
});

test('file byte count must agree with declared size rather than silently truncating or extending evidence', async () => {
  const bytes = pngBytes();
  await assert.rejects(validateScreenshot(screenshot({ bytes, size: bytes.length + 1 })), statusIs(400));
});

test('resolve, confirm, reopen and reconfirm maintain old source and profile snapshots without protected mutations', async () => {
  const data = completeData(); data.listings[0].uploads.push(completedUpload('second_upload_01', [candidate('asking_price', 39900, 'second_upload_01', { quote: '$39,900' })]));
  const h = await harness({ data });
  await assert.rejects(runIntakeAction(await h.context(), request('resolve_field', { field: 'asking_price', choice: 'forged:candidate' })), statusIs(400));
  await runIntakeAction(await h.context(), request('resolve_field', { field: 'asking_price', choice: 'second_upload_01:asking_price', note: 'Newer screenshot.' }));
  await runIntakeAction(await h.context(), request('confirm', { operation_id: 'confirm_operation_01', revision: h.state.record.revision }));
  const first = clone(h.state.record.data.listings[0].versions[0]);
  assert.equal(first.fields.asking_price.value, 39900); assert.equal(first.profile_snapshot.match_context_id, h.state.profile.match_context_id);
  await assert.rejects(runIntakeAction(await h.context(), request('save_reference', { operation_id: 'save_frozen_01', revision: h.state.record.revision, reference_url: '' })), statusIs(409));
  await runIntakeAction(await h.context(), request('reopen', { operation_id: 'reopen_operation_01', revision: h.state.record.revision }));
  await runIntakeAction(await h.context(), request('confirm', { operation_id: 'confirm_operation_02', revision: h.state.record.revision }));
  assert.equal(h.state.record.data.listings[0].versions.length, 2); assert.deepEqual(h.state.record.data.listings[0].versions[0], first);
  assert.equal(h.state.record.data.listings[0].versions[1].parent_version, 1); neverMutatedProtectedEntities(h);
  assert.equal(h.calls.uploads.length + h.calls.signs.length + h.calls.extracts.length, 0);
});

test('ambiguous database response after completion reconciles saved completion without reuploading', async () => {
  const h = await harness(); let dropped = false;
  h.hooks.afterCommit = async (_where, patch) => {
    if (!dropped && patch.$set.data.operations[0]?.status === 'complete') { dropped = true; throw new Error('Synthetic response lost after database commit'); }
  };
  const body = uploadRequest(); await assert.rejects(runIntakeAction(await h.context(), body), statusIs(503));
  assert.equal(h.state.record.data.operations[0].status, 'complete');
  assert.equal(h.state.record.data.listings[0].uploads[0].status, 'uploaded');
  const replay = await runIntakeAction(await h.context(), body);
  assert.equal(replay.replayed, true); assert.equal(replay.operation_status, 'complete');
  assert.equal(h.calls.uploads.length, 1);
});

test('concurrent same-operation uploads reserve only once and call external upload once', async () => {
  const h = await harness(), first = await h.context(), second = await h.context(), body = uploadRequest();
  const results = await Promise.allSettled([runIntakeAction(first, body), runIntakeAction(second, body)]);
  assert.equal(results.filter(result => result.status === 'fulfilled').length, 1);
  const error = results.find(result => result.status === 'rejected')?.reason;
  assert.equal(error?.status, 409); assert.equal(h.calls.uploads.length, 1);
  assert.equal(h.state.record.data.operations.length, 1); assert.equal(h.state.record.data.listings[0].uploads.length, 1);
});

test('JPEG dimension parser accepts a valid synthetic image and rejects mismatched MIME or oversized SOF dimensions', async () => {
  const bytes = Buffer.from('/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAABAAEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3+iiigD//2Q==', 'base64');
  const got = await validateScreenshot(screenshot({ bytes, type: 'image/jpeg', name: 'synthetic.jpg' }));
  assert.equal(got.width, 1); assert.equal(got.height, 1); assert.equal(got.mime, 'image/jpeg');
  await assert.rejects(validateScreenshot(screenshot({ bytes, type: 'image/png' })), statusIs(400));
  const oversize = Buffer.from(bytes), marker = oversize.indexOf(Buffer.from([255, 192]));
  assert.ok(marker > 0); oversize.writeUInt16BE(4001, marker + 5); oversize.writeUInt16BE(6000, marker + 7);
  await assert.rejects(validateScreenshot(screenshot({ bytes: oversize, type: 'image/jpeg' })), statusIs(400));
});
