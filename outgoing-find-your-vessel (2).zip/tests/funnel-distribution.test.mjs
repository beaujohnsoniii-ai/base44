import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { funnelDistribution, tierRowShape, FUNNEL_TIERS } from "../src/lib/funnelDistribution.js";
import { TIER_RESULT_COUNTS } from "../src/lib/tier-results.js";

const caseFor = (tier, generated, marked, extra = {}) => ({
  tier,
  suggestions: Array.from({ length: generated }, (_, i) => ({ title: `Model ${i + 1}`, rank: i + 1, highlighted: i < marked })),
  ...extra,
});

test("all four tiers are shown with their intended shape, even with no cases", () => {
  const distribution = funnelDistribution([]);
  assert.deepEqual(distribution.tiers.map((tier) => tier.tier), FUNNEL_TIERS);
  for (const tier of distribution.tiers) {
    assert.equal(tier.cases, 0);
    assert.equal(tier.generated.typical, 0);
    assert.equal(tier.generated.total, 0);
    assert.equal(tier.marks.total, 0);
    assert.deepEqual(tier.policy, {
      min: TIER_RESULT_COUNTS[tier.tier].minCount,
      max: TIER_RESULT_COUNTS[tier.tier].suggestCount,
      marks: TIER_RESULT_COUNTS[tier.tier].highlightCount,
    });
  }
  assert.deepEqual(distribution.totals, { cases: 0, generated: 0, marks: 0, offPolicy: 0 });
  assert.deepEqual(distribution.deviations, []);
});

test("generated and marked counts are reported per tier and in total", () => {
  const distribution = funnelDistribution([
    caseFor("free", 4, 0),
    caseFor("match_plus", 12, 0),
    caseFor("refined_match", 12, 7),
    caseFor("market_match", 14, 3),
  ]);
  const byTier = Object.fromEntries(distribution.tiers.map((tier) => [tier.tier, tier]));
  assert.equal(byTier.free.generated.typical, 4);
  assert.equal(byTier.free.marks.typical, 0);
  assert.equal(byTier.match_plus.generated.typical, 12);
  assert.equal(byTier.match_plus.marks.total, 0, "MATCH+ marks nothing and the view must say so");
  assert.equal(byTier.refined_match.marks.typical, 7);
  assert.equal(byTier.market_match.generated.typical, 14);
  assert.equal(byTier.market_match.marks.typical, 3);
  assert.deepEqual(distribution.totals, { cases: 4, generated: 42, marks: 10, offPolicy: 0 });
  assert.deepEqual(distribution.deviations, []);
});

test("a wide pool is kept wide: a full paid pool is not treated as a deviation", () => {
  const distribution = funnelDistribution([caseFor("market_match", 14, 3), caseFor("refined_match", 11, 7)]);
  assert.equal(distribution.totals.offPolicy, 0);
  assert.equal(distribution.tiers.find((tier) => tier.tier === "refined_match").marks.typical, 7);
});

test("a short pool and a misplaced mark are listed, never averaged into a pass", () => {
  const distribution = funnelDistribution([
    caseFor("refined_match", 6, 6),
    caseFor("market_match", 16, 5),
  ]);
  assert.equal(distribution.totals.offPolicy, 2);
  const short = distribution.deviations.find((deviation) => deviation.tier === "refined_match");
  assert.deepEqual(short.problems, ["generated 6, below the 10-14 pool"]);
  const wrong = distribution.deviations.find((deviation) => deviation.tier === "market_match");
  assert.deepEqual(wrong.problems, [
    "generated 16, above the 14 ceiling",
    "5 marked, expected 3",
  ]);
  // The short tier still reports the marks it recorded rather than a target it missed.
  assert.equal(distribution.tiers.find((tier) => tier.tier === "refined_match").marks.total, 6);
});

test("recorded QA measurements win over re-counting the stored array", () => {
  const shape = tierRowShape({
    tier: "match_plus",
    suggestions: Array.from({ length: 14 }, (_, i) => ({ title: `M${i}`, highlighted: i < 4 })),
    programmatic_checks: { count_actual: 12, highlight_actual: 0, highlight_expected: 0 },
  });
  assert.equal(shape.generated, 12);
  assert.equal(shape.marks, 0);
  assert.deepEqual(shape.problems, []);
});

test("an unrecognised tier is preserved rather than folded into a real one", () => {
  const distribution = funnelDistribution([{ tier: "legacy_pool", suggestions: [] }]);
  const legacy = distribution.tiers.find((tier) => tier.tier === "legacy_pool");
  assert.ok(legacy, "unknown tier dropped from the distribution");
  assert.equal(legacy.policy, null, "a retired tier must not inherit another tier's intended shape");
  assert.equal(legacy.cases, 1);
  assert.equal(distribution.totals.cases, 1);
  assert.deepEqual(distribution.deviations, [], "a retired tier is reported, not graded against a shape it never had");
});

test("missing records are reported as zero, never filled in with an assumed count", () => {
  const shape = tierRowShape({ tier: "market_match" });
  assert.equal(shape.generated, 0);
  assert.equal(shape.marks, 0);
  assert.ok(shape.problems.some((problem) => problem.startsWith("generated 0,")));
});

test("the admin page reads the funnel from the Test database and shows what it recorded", () => {
  const page = fs.readFileSync("src/pages/AdminFunnelDistribution.jsx", "utf8");
  assert.match(page, /from "@\/lib\/base44TestClient"/);
  assert.match(page, /refreshTestToken\(\)/);
  assert.match(page, /base44Test\.entities\.QATierResult\.filter\(\{ run_id: runId \}/);
  assert.match(page, /base44Test\.entities\.QATestRun\.list\("-created_date", 20\)/);
  assert.match(page, /funnelDistribution\(tierResults\)/);
  assert.match(page, /<FunnelTierBar /);
  assert.match(page, /<FunnelDeviationList deviations=\{distribution\.deviations\} \/>/);
  assert.match(page, /No MATCH QA runs exist in the Test database yet/);
  assert.match(page, /not a finished pass/, "an incomplete run must not read as a clean result");
  assert.doesNotMatch(page, /from "@\/api\/base44Client"/, "the funnel view must read the Test database only");
});

test("the funnel view is reachable and the tier bars do not invent a figure", () => {
  const app = fs.readFileSync("src/App.jsx", "utf8");
  assert.match(app, /import AdminFunnelDistribution from '@\/pages\/AdminFunnelDistribution';/);
  assert.match(app, /<Route path="\/admin\/funnel-distribution" element=\{<SharedHeaderPage><AdminFunnelDistribution \/><\/SharedHeaderPage>\} \/>/);
  const qa = fs.readFileSync("src/pages/AdminMatchQA.jsx", "utf8");
  assert.match(qa, /href="\/admin\/funnel-distribution"/);
  const bar = fs.readFileSync("src/components/admin/FunnelTierBar.jsx", "utf8");
  assert.match(bar, /No cases for this tier in the selected run\./);
  for (const field of ["generated.typical", "marks.typical", "generated.total", "marks.total"]) {
    assert.ok(bar.includes(field), `${field} is not shown on the tier bar`);
  }
  assert.doesNotMatch(bar, /\+\s*[1-9]\d*\s*;/, "a tier bar must not pad a count");
});