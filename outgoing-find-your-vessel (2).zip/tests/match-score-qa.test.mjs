import test from "node:test";
import assert from "node:assert/strict";
import { runProgrammaticChecks } from "../base44/shared/qa-programmatic.ts";
import { MATCH_SCORE_CAPS, normalizeMatchScore, hasCompleteScoreBreakdown, selectTopModelCandidates } from "../base44/shared/suggest-engine.ts";

const base = () => ({
  title: "QA Scored Boat", make: "QA", model: "Scored",
  specs: "Overall length 29 ft", asking_price: 30000,
  score_breakdown: { ...MATCH_SCORE_CAPS },
  suitability_score: Object.values(MATCH_SCORE_CAPS).reduce((a,b) => a+b, 0),
  verification_required: [],
});
const checks = (boat) => runProgrammaticChecks([boat], {}, "free", []);

test("incomplete LLM scoring is not silently treated as a real numeric fit", () => {
  assert.equal(hasCompleteScoreBreakdown(undefined), false);
  assert.equal(hasCompleteScoreBreakdown({ activities_use: 20 }), false);
  assert.equal(hasCompleteScoreBreakdown({ ...MATCH_SCORE_CAPS, preferences: null }), false);
  assert.equal(hasCompleteScoreBreakdown({ ...MATCH_SCORE_CAPS }), true);
});
test("complete fit scores rank ahead of missing scoring inputs", () => {
  const a = { ...base(), model: "Incomplete", score_breakdown: { activities_use: 25 } };
  const b = { ...base(), model: "Complete" };
  assert.deepEqual(selectTopModelCandidates([a,b],2).map(s => s.model), ["Complete","Incomplete"]);
});
test("the scoring rubric sums to exactly 100 points", () => {
  assert.equal(base().suitability_score, 100);
  assert.equal(checks(base()).checks.score_violations.length, 0);
});
test("out-of-range component is a red score integrity failure", () => {
  const b = base();
  b.score_breakdown.activities_use = 26;
  const result = checks(b);
  assert.equal(result.concern_level, "red");
  assert.ok(result.checks.score_violations.some(x => x.includes("activities_use")));
});
test("score must equal the sum of components", () => {
  const b = base();
  b.suitability_score = 98;
  assert.equal(checks(b).concern_level, "red");
});
test("non-finite total is rejected", () => {
  const b = base();
  b.suitability_score = Number.NaN;
  assert.equal(checks(b).concern_level, "red");
});
test("fractional component scores normalize without a false QA failure", () => {
  const normalized = normalizeMatchScore({
    activities_use: 12.345, operating_environment: 8.234,
    family_layout: 5.555, physical_compatibility: 6.789,
    preferences: 2.333,
  });
  const b = { ...base(), suitability_score: normalized.score, score_breakdown: normalized.breakdown };
  assert.equal(normalized.score, 35.2);
  assert.equal(checks(b).checks.score_violations.length, 0);
});
test("normalization clamps non-finite and over-cap values", () => {
  const normalized = normalizeMatchScore({
    activities_use: Infinity, operating_environment: 999,
    family_layout: -20, physical_compatibility: Number.NaN,
  });
  assert.equal(normalized.breakdown.activities_use, 0);
  assert.equal(normalized.breakdown.operating_environment, 15);
  assert.equal(normalized.breakdown.family_layout, 0);
  assert.equal(normalized.breakdown.physical_compatibility, 0);
  assert.equal(normalized.score, 15);
  assert.equal(checks({ ...base(), suitability_score: normalized.score, score_breakdown: normalized.breakdown }).checks.score_violations.length, 0);
});
