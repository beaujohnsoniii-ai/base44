import test from "node:test";import assert from "node:assert/strict";import fs from "node:fs";
import {requestDeadline} from "../src/lib/requestDeadline.js";
test("stalled request terminates the UI wait with a marked timeout and no retry",async()=>{
 let calls=0;await assert.rejects(requestDeadline(()=>{calls++;return new Promise(()=>{});},10,"timed out"),e=>e.code==="REQUEST_TIMEOUT");
 assert.equal(calls,1);
});
test("successful and failed requests preserve their actual outcome",async()=>{
 assert.equal(await requestDeadline(async()=>42,100,"timeout"),42);
 await assert.rejects(requestDeadline(async()=>{throw Error("HTTP 401");},100,"timeout"),/HTTP 401/);
});
test("late success cannot replace the already reported timeout",async()=>{
 let finish;const work=new Promise(resolve=>finish=resolve);
 await assert.rejects(requestDeadline(()=>work,10,"uncertain"),/uncertain/);finish("late provider response");
 await Promise.resolve();
});
test("admin health uses single-flight guard and never automatically retries a timed-out paid call",()=>{
 const s=fs.readFileSync("src/pages/AdminResearchMonitor.jsx","utf8");
 assert.match(s,/healthInFlight.current \|\| healthUncertain/);assert.match(s,/disabled=\{checking \|\| healthUncertain\}/);
 assert.match(s,/30000/);assert.match(s,/No automatic retry was made/);
 assert.match(s,/map\(read => requestDeadline/);
});
