import test from 'node:test';
import assert from 'node:assert/strict';
import { INTAKE_FIELDS, INTAKE_LIMITS, SCREENSHOT_SCHEMA, IntakeError, stableJson, digest, exactListingReference, knownListingReference, normalizeScreenshotExtraction, mergedListingEvidence, assertCurrentContext, newListing, draftListing, confirmListing, reopenListing, confirmedEvidenceForComparison, safeRecordData } from '../base44/shared/listing-intake.mjs';
import { NOW, OWNER, MODEL, LISTING_ID, UPLOAD_ID, clone, output, source, candidate, completedUpload, listingData, completeData, statusIs } from './listing-intake-fixtures.mjs';

const evidenceFor = entries => Object.entries(entries).map(([field, quote]) => ({ field, quote }));

test('extraction keeps purchase price separate from finance, preserves quotes and source provenance', () => {
  const quote = 'Price: $42,900  (seller advertised)';
  const result = normalizeScreenshotExtraction(output({ asking_price: 42900, financing_monthly_payment: 329, price_symbol: '$', engine_hours: null }, evidenceFor({ asking_price: quote, financing_monthly_payment: '$329 / mo', price_symbol: '$42,900' })), source());
  assert.deepEqual(result.rejected, []);
  const price = result.candidates.find(c => c.field === 'asking_price');
  assert.equal(price.value, 42900); assert.equal(price.quote, quote);
  assert.equal(price.source_id, UPLOAD_ID); assert.equal(price.source_name, `${UPLOAD_ID}.png`); assert.equal(price.uploaded_at, NOW);
  assert.equal(price.provenance, 'user_supplied_screenshot'); assert.equal(price.verification, 'unverified_seller_claim');
  assert.equal(result.candidates.find(c => c.field === 'financing_monthly_payment').value, 329);
  assert.ok(!result.candidates.some(c => c.field === 'engine_hours' || c.field === 'currency_code'));
});

test('monthly payment, deposit, missing currency and condition language cannot create asking price or hours', () => {
  for (const quote of ['$329 / mo', 'Monthly payment $329', 'Finance from $329', '$329 deposit']) {
    const got = normalizeScreenshotExtraction(output({ asking_price: 329 }, evidenceFor({ asking_price: quote })), source());
    assert.deepEqual(got.candidates, [], quote); assert.deepEqual(got.rejected, ['asking_price']);
  }
  const got = normalizeScreenshotExtraction(output({ engine_hours: 0, currency_code: 'USD', asking_price: 42900 }, evidenceFor({ engine_hours: 'New engine, excellent condition, low hours', currency_code: '$42,900', asking_price: 'Price 42,900' })), source());
  assert.deepEqual(got.candidates, []); assert.deepEqual(new Set(got.rejected), new Set(['asking_price', 'currency_code', 'engine_hours']));
});

test('numeric facts require visible units and matching explicit values; currency must be explicit', () => {
  const got = normalizeScreenshotExtraction(output({ year: 2022, length_ft: 20.5, engine_hours: 184, engine_count: 1, total_power_hp: 150, currency_code: 'CAD' }, evidenceFor({ year: '2022 Bayliner VR5', length_ft: 'Length 20.5 ft', engine_hours: 'Engine hours: 184', engine_count: 'Single engine', total_power_hp: '150 hp', currency_code: 'Asking CAD 42,900' })), source());
  assert.equal(got.candidates.length, 6);
  assert.equal(got.candidates.find(c => c.field === 'length_ft').basis, 'displayed_length');
  const bad = normalizeScreenshotExtraction(output({ year: 1800, length_ft: 20.5, engine_hours: 184, total_power_hp: 150, passenger_capacity: 4.5 }, evidenceFor({ year: '1800', length_ft: 'Length 20.5 m', engine_hours: 'Mileage 184', total_power_hp: '150 kW', passenger_capacity: 'Capacity 4.5' })), source());
  assert.deepEqual(bad.candidates, []);
});

test('absent, illegible, unsupported and unknown fields remain absent rather than inferred', () => {
  const got = normalizeScreenshotExtraction(output({ make: 'Bayliner', model: 'VR5', engine_hours: null, arbitrary_fact: 'ignored' }, [{ field: 'make', quote: 'Another manufacturer' }]), source());
  assert.deepEqual(got.candidates, []); assert.deepEqual(got.rejected, ['make', 'model']);
  assert.throws(() => normalizeScreenshotExtraction({ status: 'error', output: {} }, source()), statusIs(422));
  assert.throws(() => normalizeScreenshotExtraction({ status: 'success', output: [] }, source()), statusIs(422));
  assert.ok(SCREENSHOT_SCHEMA.description.includes('untrusted'));
  assert.ok(SCREENSHOT_SCHEMA.required.includes('engine_hours'));
});

test('features and seller claims are separate, visibly supported, unverified source evidence', () => {
  const got = normalizeScreenshotExtraction(output({ features: ['Garmin fishfinder', 'Swim platform'], unverified_claims: ['Excellent condition', 'Family friendly'] }, [{ field: 'features', quote: 'Garmin fishfinder' }, { field: 'unverified_claims', quote: 'Seller says: Excellent condition' }]), source());
  assert.deepEqual(got.features.map(x => x.text), ['Garmin fishfinder']);
  assert.deepEqual(got.claims.map(x => x.text), ['Excellent condition']);
  assert.equal(got.features[0].verification, 'unverified_seller_claim');
  assert.equal(got.claims[0].quote, 'Seller says: Excellent condition');
});

test('regression: short evidence cannot justify invented suffixes in features or seller claims', () => {
  const got = normalizeScreenshotExtraction(output({ features: ['Fishfinder and brand-new engine'], unverified_claims: ['Excellent condition and independently surveyed as safe'] }, [{ field: 'features', quote: 'Fishfinder' }, { field: 'unverified_claims', quote: 'Excellent condition' }]), source());
  assert.deepEqual(got.features, [], 'The whole feature must be present in the supporting quote.');
  assert.deepEqual(got.claims, [], 'The whole claim must be present in the supporting quote.');
});

test('three models times three listings fit, fourth model or fourth listing does not', () => {
  let data = { listings: [], operations: [] };
  for (let m = 1; m <= 3; m++) for (let l = 1; l <= 3; l++) data = newListing(data, { ...MODEL, model_key: `model:${m}`, model: `Model ${m}` }, `listing_${m}_${l}`, `https://seller.example/listing/${m}/${l}`, NOW);
  assert.equal(data.listings.length, 9);
  assert.throws(() => newListing(data, { ...MODEL, model_key: 'model:4' }, 'listing_4_1', '', NOW), statusIs(409));
  assert.throws(() => newListing(data, { ...MODEL, model_key: 'model:1' }, 'listing_1_4', '', NOW), statusIs(409));
  assert.equal(data.listings.length, 9);
});

test('listing IDs and exact references cannot collide and caller data is not mutated', () => {
  const first = listingData(), copy = clone(first);
  assert.throws(() => newListing(first, MODEL, LISTING_ID, '', NOW), statusIs(409));
  assert.throws(() => newListing(first, MODEL, 'another_listing', first.listings[0].reference_url, NOW), statusIs(409));
  const second = newListing(first, MODEL, 'another_listing', '', NOW);
  assert.equal(second.listings.length, 2); assert.deepEqual(first, copy);
});

test('all independent screenshots remain distinct even when values agree', () => {
  const listing = completeData().listings[0];
  listing.uploads.push(completedUpload('upload_second_01', [candidate('asking_price', 42900, 'upload_second_01', { quote: 'Asking $42,900' })]));
  const merged = mergedListingEvidence(listing);
  assert.deepEqual(merged.conflicts, []); assert.equal(merged.fields.asking_price.value, 42900);
  assert.equal(merged.fields.asking_price.candidates.length, 2);
  assert.deepEqual(merged.fields.asking_price.candidates.map(c => c.source_id), [UPLOAD_ID, 'upload_second_01']);
});

test('conflicts remain unknown until exact source selection or explicit Not provided resolution', async () => {
  const data = completeData(), listing = data.listings[0];
  listing.uploads.push(completedUpload('upload_second_01', [candidate('asking_price', 39900, 'upload_second_01', { quote: '$39,900' })]));
  let merged = mergedListingEvidence(listing);
  assert.deepEqual(merged.conflicts, ['asking_price']); assert.equal(merged.fields.asking_price.value, null);
  await assert.rejects(confirmListing(data, LISTING_ID, {}, 'fingerprint_1', NOW), statusIs(409));
  listing.resolutions.asking_price = { choice: 'upload_second_01:asking_price', note: 'Use newer screenshot.' };
  merged = mergedListingEvidence(listing); assert.deepEqual(merged.conflicts, []); assert.equal(merged.fields.asking_price.value, 39900);
  assert.equal(merged.fields.asking_price.selected.quote, '$39,900'); assert.equal(merged.fields.asking_price.candidates.length, 2);
  listing.resolutions.asking_price = { choice: 'unknown' };
  merged = mergedListingEvidence(listing); assert.equal(merged.fields.asking_price.value, null); assert.deepEqual(merged.conflicts, []);
  listing.resolutions.asking_price = { choice: 'missing_source:asking_price' };
  assert.deepEqual(mergedListingEvidence(listing).conflicts, ['asking_price']);
});

test('only completed uploads can contribute accepted evidence', () => {
  const listing = completeData().listings[0];
  listing.uploads.push(completedUpload('upload_unsettled_01', [candidate('asking_price', 1, 'upload_unsettled_01')], { status: 'uncertain', extraction: { candidates: [candidate('asking_price', 1, 'upload_unsettled_01')], features: [{ text: 'Unsettled feature' }], claims: [{ text: 'Unsettled claim' }] } }));
  const merged = mergedListingEvidence(listing);
  assert.equal(merged.fields.asking_price.candidates.length, 1);
  assert.deepEqual(merged.features, [], 'Unsettled features must not enter confirmed evidence.');
  assert.deepEqual(merged.claims, [], 'Unsettled claims must not enter confirmed evidence.');
});

test('a different advertised year is retained without requiring a free-text identity essay', async () => {
  const data = completeData(); data.listings[0].uploads[0].extraction.candidates.push(candidate('year', 2020));
  const evidence = mergedListingEvidence(data.listings[0]);
  assert.deepEqual(evidence.identity_conflicts, []); assert.equal(evidence.year_difference, true);
  const saved = (await confirmListing(data, LISTING_ID, {}, 'profile_fp', NOW)).listings[0];
  assert.equal(saved.status, 'confirmed'); assert.equal(saved.versions[0].fields.year.value, 2020);
  assert.equal(saved.versions[0].model.year, 2022); assert.equal(saved.identity_resolution, null);
});

test('freeze stores detached source and profile snapshot with stable digest; reopen preserves history', async () => {
  const original = completeData(), profile = { budget: 50000, preferences: { use: 'family' } };
  const confirmed = await confirmListing(original, LISTING_ID, profile, 'fingerprint_a', NOW);
  const snapshot = clone(confirmed.listings[0].versions[0]);
  assert.equal(original.listings[0].status, 'draft'); assert.equal(original.listings[0].versions.length, 0);
  assert.equal(confirmed.listings[0].status, 'confirmed'); assert.equal(snapshot.version, 1); assert.equal(snapshot.parent_version, null);
  const { digest: hash, ...payload } = snapshot; assert.match(hash, /^[a-f0-9]{64}$/); assert.equal(hash, await digest(payload));
  profile.preferences.use = 'offshore'; original.listings[0].uploads[0].extraction.candidates[0].value = 1;
  assert.deepEqual(confirmed.listings[0].versions[0], snapshot);
  assert.throws(() => draftListing(confirmed, LISTING_ID), statusIs(409));
  const reopened = reopenListing(confirmed, LISTING_ID); reopened.listings[0].uploads[0].extraction.candidates[0].value = 39900;
  assert.equal(reopened.listings[0].revision, 2); assert.equal(reopened.listings[0].status, 'draft'); assert.equal(reopened.listings[0].identity_resolution, null);
  assert.deepEqual(reopened.listings[0].versions[0], snapshot); assert.deepEqual(confirmed.listings[0].versions[0], snapshot);
  const twice = await confirmListing(reopened, LISTING_ID, { budget: 50000 }, 'fingerprint_a', '2026-10-25T12:00:00.000Z');
  assert.equal(twice.listings[0].versions.length, 2); assert.equal(twice.listings[0].versions[1].version, 2); assert.equal(twice.listings[0].versions[1].parent_version, 1);
  assert.deepEqual(twice.listings[0].versions[0], snapshot); assert.notEqual(twice.listings[0].versions[1].digest, hash);
});

test('confirmation blocks missing sources, pending stages and exceeding immutable version cap', async () => {
  await assert.rejects(confirmListing(listingData(), LISTING_ID, {}, 'fp', NOW), statusIs(400));
  for (const status of ['reserved', 'uploading', 'uploaded', 'reading', 'uncertain']) {
    const data = completeData(); data.listings[0].uploads.push({ ...source('second_upload_01'), status });
    await assert.rejects(confirmListing(data, LISTING_ID, {}, 'fp', NOW), statusIs(409));
  }
  const data = completeData(); data.listings[0].versions = Array.from({ length: INTAKE_LIMITS.versions_per_listing }, (_, i) => ({ version: i + 1 }));
  await assert.rejects(confirmListing(data, LISTING_ID, {}, 'fp', NOW), statusIs(409));
});

test('comparison adapter rejects stale context/tampering and excludes finance and unverified comfort claims', async () => {
  const data = completeData(); data.listings[0].uploads[0].extraction.candidates.push(candidate('financing_monthly_payment', 329), candidate('length_ft', 20.5, UPLOAD_ID, { basis: 'displayed_length', unit: 'ft', quote: 'Length 20.5 ft' }));
  const snapshot = (await confirmListing(data, LISTING_ID, { budget: 50000 }, 'current_fp', NOW)).listings[0].versions[0];
  const adapted = await confirmedEvidenceForComparison(snapshot, 'current_fp');
  assert.equal(adapted.facts.asking_price.value, 42900); assert.equal(adapted.facts.overall_length_ft.value, 20.5);
  assert.ok(!('financing_monthly_payment' in adapted.facts)); assert.ok(!('engine_hours' in adapted.facts)); assert.ok(!('asking_price_currency' in adapted.facts));
  assert.equal(adapted.source_kind, 'buyer_confirmed_screenshots');
  await assert.rejects(confirmedEvidenceForComparison(snapshot, 'different_fp'), statusIs(409));
  const tampered = clone(snapshot); tampered.fields.asking_price.value = 1;
  await assert.rejects(confirmedEvidenceForComparison(tampered, 'current_fp'), statusIs(409));
  const alteredProfile = clone(snapshot); alteredProfile.profile_snapshot.budget = 1;
  await assert.rejects(confirmedEvidenceForComparison(alteredProfile, 'current_fp'), statusIs(409));
});

test('profile owner and fingerprint are both necessary', () => {
  const profile = { id: 'profile_001', created_by_id: OWNER.id }, record = { owner_id: OWNER.id, buyer_profile_id: profile.id, profile_fingerprint: 'same' };
  assert.doesNotThrow(() => assertCurrentContext(record, OWNER, profile, 'same'));
  assert.throws(() => assertCurrentContext(record, { id: 'someone_else' }, profile, 'same'), statusIs(403));
  assert.throws(() => assertCurrentContext(record, OWNER, { ...profile, created_by_id: 'other' }, 'same'), statusIs(403));
  assert.throws(() => assertCurrentContext(record, OWNER, { ...profile, id: 'new_profile' }, 'same'), statusIs(409));
  assert.throws(() => assertCurrentContext(record, OWNER, profile, 'changed'), statusIs(409));
});

test('exact listing URL is preserved without normalizing or substituting a search', () => {
  const url = 'https://seller.example/listing/Boat-123?ref=Saved%20Link&x=1#photos';
  assert.equal(exactListingReference(url), url); assert.equal(exactListingReference(''), '');
  assert.equal(knownListingReference({ listing_urls: [url] }), url);
  assert.equal(knownListingReference({ source_suggestion_id: 'suggestion', url }), '');
  assert.equal(knownListingReference({ original_match_url: url, url }), '');
  assert.equal(knownListingReference({ listing_urls: ['https://google.com/search?q=boat'] }), '');
  for (const invalid of ['http://seller.example/listing/1', 'javascript:alert(1)', 'https://name:password@seller.example/listing/1', 'https://localhost/listing/1', 'https://127.0.0.1/listing/1', 'https://10.0.0.1/listing/1', 'https://google.com/search?q=boat', 'https://bing.com/search?q=boat', 'https://seller.example/search?q=boat', 'https://seller.example/inventory', 'https://seller.example/boats-for-sale', 'Look here https://seller.example/listing/1']) assert.throws(() => exactListingReference(invalid), IntakeError, invalid);
});

test('regression: search and inventory descendants are not exact listing references', () => {
  for (const url of ['https://seller.example/boats-for-sale/type-power/', 'https://seller.example/search/bayliner/', 'https://seller.example/inventory/used/']) assert.throws(() => exactListingReference(url), IntakeError, url);
});

test('stable hashing is key-order independent; bounded records are detached and oversized records fail', async () => {
  assert.equal(stableJson({ b: 2, a: { y: 2, x: 1 } }), stableJson({ a: { x: 1, y: 2 }, b: 2 }));
  assert.equal(await digest({ b: 2, a: 1 }), await digest({ a: 1, b: 2 }));
  const data = listingData(), safe = safeRecordData(data); safe.listings[0].reference_url = '';
  assert.notEqual(data.listings[0].reference_url, '');
  assert.throws(() => safeRecordData({ text: 'x'.repeat(INTAKE_LIMITS.record_bytes + 1) }), statusIs(409));
  assert.equal(Object.keys(INTAKE_FIELDS).length > 10, true);
});

test('regression: absent hours cannot borrow a year or asking-price number from the same quote', () => {
  for (const [hours, quote] of [[2022, '2022 Bayliner VR5. Low hours, excellent condition.'], [42900, 'Engine hours: Not provided. Asking $42,900.']]) {
    const got = normalizeScreenshotExtraction(output({ engine_hours: hours }, [{ field: 'engine_hours', quote }]), source());
    assert.deepEqual(got.candidates, [], quote); assert.deepEqual(got.rejected, ['engine_hours']);
  }
});
