import test from "node:test";
import assert from "node:assert/strict";
import { registerHooks } from "node:module";

import { profileInputFingerprint } from "../base44/shared/profile-input-fingerprint.mjs";
const fingerprint = await profileInputFingerprint({});
const clientKey = Symbol.for("soundheading.toggleLike.testClient");
const hooks = registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier.startsWith("npm:@base44/sdk")) {
      return { url: "data:text/javascript," + encodeURIComponent(
        'export const createClientFromRequest = () => globalThis[Symbol.for("soundheading.toggleLike.testClient")];'
      ), shortCircuit: true };
    }
    return nextResolve(specifier, context);
  },
});
const { default: toggleLike } = await import("../base44/functions/toggle-like/entry.ts");
hooks.deregister();

function setup(t, { owner = "buyer-1", profile = true, testRecord = false, suggestionLiked = false, profileUpdateFails = false, previousLikes = [] } = {}) {
  const writes = { suggestion: [], profile: [] };
  const suggestion = {
    buyer_profile_id: "profile-1", profile_input_fingerprint: fingerprint, id: "boat-1", created_by_id: owner, make: "Parker", model: "2520 XL",
    title: "Parker 2520 XL Sport Cabin", liked: suggestionLiked,
    ...(testRecord ? { test_profile_id: "qa-profile" } : {}),
  };
  const buyerProfile = { id: "profile-1", liked_models: previousLikes.map(like=>({...like,profile_input_fingerprint:fingerprint})) };
  globalThis[clientKey] = {
    auth: { me: async () => ({ id: "buyer-1", plan: "match_plus" }) },
    entities: {
      SuggestedBoat: {
        get: async id => id === suggestion.id ? suggestion : null,
        update: async (id, data) => { writes.suggestion.push({ id, data }); Object.assign(suggestion, data); },
      },
      BuyerProfile: {
        filter: async () => profile ? [buyerProfile] : [],
        update: async (id, data) => {
          writes.profile.push({ id, data });
          if (profileUpdateFails) throw new Error("Simulated persistence failure");
          Object.assign(buyerProfile, data);
        },
      },
    },
  };
  t.mock.method(console, "error", () => {});
  t.after(() => { delete globalThis[clientKey]; });
  return { writes, suggestion, buyerProfile };
}

async function invoke(body) {
  const response = await toggleLike(new Request("https://soundheading.test/toggle-like", {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  }));
  return { status: response.status, data: await response.json() };
}

test("Like history uses stored model identity, not spoofed client fields", async t => {
  const { writes } = setup(t);
  const result = await invoke({
    suggestionId: "boat-1", liked: true,
    make: "Injected", model: "1000", title: "Fabricated",
  });
  assert.equal(result.status, 200);
  assert.deepEqual(result.data.liked_models, [
    { make: "Parker", model: "2520 XL", title: "Parker 2520 XL Sport Cabin", liked_at_tier: "match_plus", profile_input_fingerprint: fingerprint },
  ]);
  assert.deepEqual(writes.suggestion, [{ id: "boat-1", data: { liked: true } }]);
});

test("Unliking removes the stored model identity from durable preferences", async t => {
  const old = { make: "Parker", model: "2520 XL", title: "Parker 2520 XL Sport Cabin", liked_at_tier: "free" };
  setup(t, { previousLikes: [old], suggestionLiked: true });
  const result = await invoke({ suggestionId: "boat-1", liked: false, make: "Other", model: "Model" });
  assert.equal(result.status, 200);
  assert.deepEqual(result.data.liked_models, []);
});

test("Reliking preserves original tier for the same model", async t => {
  setup(t, { previousLikes: [{ make: "Parker", model: "2520 XL", title: "Parker 2520", liked_at_tier: "free" }] });
  const result = await invoke({ suggestionId: "boat-1", liked: true });
  assert.equal(result.status, 200);
  assert.equal(result.data.liked_models.length, 1);
  assert.equal(result.data.liked_models[0].liked_at_tier, "free");
});

test("Other buyers' and test suggestions cannot update Like history", async t => {
  const { writes } = setup(t, { owner: "buyer-2" });
  assert.equal((await invoke({ suggestionId: "boat-1", liked: true })).status, 404);
  assert.equal(writes.suggestion.length, 0);
  assert.equal(writes.profile.length, 0);
});

test("Admin test-profile suggestions remain outside buyer preference history", async t => {
  const { writes } = setup(t, { testRecord: true });
  assert.equal((await invoke({ suggestionId: "boat-1", liked: true })).status, 404);
  assert.equal(writes.suggestion.length, 0);
});

test("Missing suggestion ID or Like state cannot mutate preferences", async t => {
  const { writes } = setup(t);
  for (const body of [{ liked: true }, { suggestionId: "boat-1" }, { suggestionId: "boat-1", liked: "yes" }]) {
    assert.equal((await invoke(body)).status, 400);
  }
  assert.equal(writes.profile.length, 0);
  assert.equal(writes.suggestion.length, 0);
});

test("Like refuses to mutate if the buyer has no saved profile", async t => {
  const { writes } = setup(t, { profile: false });
  assert.equal((await invoke({ suggestionId: "boat-1", liked: true })).status, 400);
  assert.equal(writes.profile.length, 0);
  assert.equal(writes.suggestion.length, 0);
});

test("Failed profile persistence reverts immediate suggestion Like flag", async t => {
  const { writes, suggestion } = setup(t, { profileUpdateFails: true });
  const result = await invoke({ suggestionId: "boat-1", liked: true });
  assert.equal(result.status, 500);
  assert.equal(suggestion.liked, false);
  assert.deepEqual(writes.suggestion.map(x => x.data.liked), [true, false]);
});

test("a stale result cannot reintroduce preferences after profile edits", async t => {
 const h=setup(t);h.suggestion.profile_input_fingerprint="earlier-context";
 assert.equal((await invoke({suggestionId:"boat-1",liked:true})).status,409);
 assert.equal(h.writes.profile.length,0);assert.equal(h.writes.suggestion.length,0);
});
test("historical explicit Likes remain saved when a model is liked in a fresh context", async t => {
 const h=setup(t,{previousLikes:[{make:"Parker",model:"2520 XL",title:"Old explicit Like",liked_at_tier:"free"}]});
 h.buyerProfile.liked_models[0].profile_input_fingerprint="earlier-context";
 const result=await invoke({suggestionId:"boat-1",liked:true});assert.equal(result.status,200);
 assert.equal(result.data.liked_models.length,2);assert.equal(result.data.liked_models[0].profile_input_fingerprint,"earlier-context");
 assert.equal(result.data.liked_models[1].profile_input_fingerprint,fingerprint);
});
