import test from "node:test";import assert from "node:assert/strict";import {registerHooks} from "node:module";
import {BROKER_TEST_URL,BROKER_APPROVAL,BASIC_OPTIONS,FIRECRAWL_ENDPOINT,scrapeApprovedBroker,summarizeBrokerResponse} from "../base44/shared/firecrawl-broker-test.mjs";
const markdown="# 2012 BlackJack 224 CC\nStock #: 3928\nSale Price $39,995\nRegular Price $47,995\nSuzuki 250 outboard\n290 hrs\n";
const payload=()=>({success:true,data:{markdown,metadata:{sourceURL:BROKER_TEST_URL,url:BROKER_TEST_URL,statusCode:200}}});
test("fixed basic options and single request never allow retries, enhanced, credentials-to-target or cache",async()=>{
 let calls=0;const r=await scrapeApprovedBroker("test-key",null,async(url,o)=>{
 calls++;assert.equal(url,FIRECRAWL_ENDPOINT);assert.equal(o.redirect,"error");assert.equal(o.method,"POST");
 assert.deepEqual(JSON.parse(o.body),BASIC_OPTIONS);assert.equal(JSON.parse(o.body).proxy,"basic");assert.equal(JSON.parse(o.body).maxAge,0);assert.equal(JSON.parse(o.body).storeInCache,false);assert.deepEqual(JSON.parse(o.body).formats,["markdown"]);assert.equal(JSON.parse(o.body).skipTlsVerification,false);
 return Response.json(payload());});
 assert.equal(calls,1);assert.equal(r.facts.stock_number,"3928");assert.equal(r.facts.engine_hours,290);
 assert.equal(r.facts.asking_price,null);assert.equal(r.price_conflict,true);assert.equal(r.provenance.requested_url,BROKER_TEST_URL);
});
test("wrong final URL or wrong stock never produces broker facts",()=>{
 const p=payload();p.data.metadata.url="https://other.com/";assert.equal(summarizeBrokerResponse(p).facts,null);
 const q=payload();q.data.markdown=markdown.replace("3928","WRONG123");assert.equal(summarizeBrokerResponse(q).facts,null);
});
test("HTTP failure and oversized response consume no fallback attempts",async()=>{
 for(const response of [()=>new Response("",{status:403}),()=>new Response("x".repeat(524289))]){
 let n=0;await assert.rejects(scrapeApprovedBroker("test-key",null,async()=>{n++;return response();}));assert.equal(n,1);
 }
});
const K=Symbol.for("firecrawl.broker.tests");
const h=registerHooks({resolve(s,c,next){
 if(s.startsWith("npm:@base44/sdk"))return {url:"data:text/javascript,"+encodeURIComponent('export const createClientFromRequest=()=>globalThis[Symbol.for("firecrawl.broker.tests")].client;'),shortCircuit:true};
 if(s==="base44:runtime")return {url:"data:text/javascript,"+encodeURIComponent('export const secrets={get:name=>{const x=globalThis[Symbol.for("firecrawl.broker.tests")];x.secretReads++;return x.key;}};'),shortCircuit:true};
 return next(s,c);
}});
const {default:handler}=await import("../base44/functions/firecrawl-broker-test/entry.ts");h.deregister();
function fixture(role="admin",key="dummy-test-key"){
 const slot={id:"slot",approval_id:BROKER_APPROVAL,status:"ready",approved_url:BROKER_TEST_URL,max_calls:1};
 const c={key,secretReads:0,slot,fetches:0};
 const ledger={filter:async()=>[{...slot}],get:async()=>({...slot}),updateMany:async(q,d)=>{if(slot.status!==q.status)return {success:true,updated:0};Object.assign(slot,d.$set);return {success:true,updated:1};},update:async(id,d)=>Object.assign(slot,d)};
 c.client={auth:{me:async()=>role?{id:"admin-test",role}:null},asServiceRole:{entities:{FirecrawlBrokerTest:ledger}}};
 globalThis[K]=c;return c;
}
const req=action=>new Request("https://app.com/test",{method:"POST",body:JSON.stringify(action)});
test("anonymous and non-admin are rejected before secret reads or provider work",async()=>{
 for(const role of [null,"user"]){const c=fixture(role);assert.ok([401,403].includes((await handler(req({action:"run_basic_test"}))).status));assert.equal(c.secretReads,0);assert.equal(c.slot.status,"ready");}
});
test("status is presence-only; missing key and request scope tampering cannot spend approval",async()=>{
 const c=fixture("admin",undefined);c.key=undefined;
 let res=await handler(req({action:"status"}));const data=await res.json();assert.equal(data.key_configured,false);assert.equal(data.test_status,"ready");assert.ok(!Object.hasOwn(data,"key"));
 assert.equal((await handler(req({action:"run_basic_test"}))).status,503);assert.equal(c.slot.status,"ready");
 assert.equal((await handler(req({action:"run_basic_test",url:"https://other.com"}))).status,400);assert.equal(c.slot.status,"ready");
});
test("concurrent admin run requests reserve one slot and perform exactly one mocked provider call",async t=>{
 const c=fixture();const old=globalThis.fetch;t.after(()=>globalThis.fetch=old);
 globalThis.fetch=async()=>{c.fetches++;return Response.json(payload());};
 const responses=await Promise.all([handler(req({action:"run_basic_test"})),handler(req({action:"run_basic_test"}))]);
 assert.deepEqual(responses.map(r=>r.status).sort(),[200,409]);assert.equal(c.fetches,1);assert.equal(c.slot.status,"complete");
 assert.equal((await handler(req({action:"run_basic_test"}))).status,409);assert.equal(c.fetches,1);
});
test("sanitized diagnostics distinguish HTTP, parse, transport and ledger failures without retaining secrets",async t=>{
 const old=globalThis.fetch;t.after(()=>globalThis.fetch=old);
 for(const [response,expectedStage,expectedCode,status] of [
  [async()=>new Response("secret-provider-body",{status:401}),"provider_response","PROVIDER_HTTP_ERROR",401],
  [async()=>new Response("secret-provider-body",{status:402}),"provider_response","PROVIDER_HTTP_ERROR",402],
  [async()=>new Response("secret-provider-body",{status:422}),"provider_response","PROVIDER_HTTP_ERROR",422],
  [async()=>new Response("secret-provider-body"),"provider_parse","FIRECRAWL_INVALID_JSON",200],
  [async()=>{throw Error("Bearer secret-key https://secret.invalid");},"provider_fetch","UNCLASSIFIED_RUNTIME_ERROR",null]
 ]){
  const c=fixture();globalThis.fetch=async()=>{c.fetches++;return response();};
  const r=await handler(req({action:"run_basic_test"}));const data=await r.json();
  assert.equal(r.status,502);assert.equal(c.slot.diagnostic.stage,expectedStage);assert.equal(c.slot.diagnostic.code,expectedCode);assert.equal(c.slot.diagnostic.http_status,status);
  assert.equal(c.slot.diagnostic.billing_confirmed,false);assert.ok(!JSON.stringify(data).includes("secret"));assert.equal(c.fetches,1);
  assert.equal((await handler(req({action:"status"}))).status,200);assert.equal(c.fetches,1);
  assert.equal((await handler(req({action:"run_basic_test"}))).status,409);assert.equal(c.fetches,1);
 }
 const c=fixture();const update=c.client.asServiceRole.entities.FirecrawlBrokerTest.update;
 c.client.asServiceRole.entities.FirecrawlBrokerTest.update=async(id,d)=>{if(d.status==="complete")throw Error("secret ledger error");return update(id,d);};
 globalThis.fetch=async()=>{c.fetches++;return Response.json(payload());};
 assert.equal((await handler(req({action:"run_basic_test"}))).status,502);
 assert.equal(c.slot.diagnostic.stage,"ledger_complete");assert.equal(c.slot.diagnostic.code,"LEDGER_WRITE_FAILED");assert.equal(c.fetches,1);
});
test("failed provider attempt stays spent and cannot automatically retry",async t=>{
 const c=fixture();const old=globalThis.fetch;t.after(()=>globalThis.fetch=old);
 globalThis.fetch=async()=>{c.fetches++;throw Error("network");};
 assert.equal((await handler(req({action:"run_basic_test"}))).status,502);assert.equal(c.slot.status,"uncertain");
 assert.equal((await handler(req({action:"run_basic_test"}))).status,409);assert.equal(c.fetches,1);
});
test("captured independent broker discovery survives escaped stock Markdown without inferring price or currency",async()=>{
 const {readFileSync}=await import('node:fs');
 const observation=JSON.parse(readFileSync(new URL('./fixtures/blackjack-broker-discovery-observation.json',import.meta.url),'utf8'));
 const r=summarizeBrokerResponse(observation.payload);
 assert.equal(r.status,'retrieved_for_admin_review');assert.equal(r.facts.stock_number,'3928');assert.equal(r.facts.year,2012);assert.equal(r.facts.engine_hours,290);
 assert.equal(r.facts.asking_price,null);assert.equal(r.facts.currency,null);assert.equal(r.currency_unconfirmed,true);assert.equal(r.price_conflict,true);
 assert.deepEqual(r.evidence.price_claims.map(p=>p.value),[47995,39995]);assert.match(r.facts.engine_description,/Suzuki 250HP/);
 assert.equal(observation.search_context.relation,'model_family_candidate_only');assert.equal(observation.search_context.existing_saved_listing_identity,'not_established');
 assert.equal(observation.cost_receipt.total_net_credits,4);
});
test("dollar symbol alone is not USD and unrelated recommendation prices cannot fill the selected boat",()=>{
 const p=payload();p.data.markdown='# 2012 BlackJack 224 CC\nStock #: 3928\nPrice $39,995\n290 hours\n## You May Also Like\nOther boat USD $99,999\n100 hours';
 const r=summarizeBrokerResponse(p);assert.equal(r.facts.asking_price,null);assert.equal(r.facts.currency,null);assert.equal(r.currency_unconfirmed,true);assert.equal(r.price_conflict,false);assert.equal(r.facts.engine_hours,290);
 p.data.markdown=p.data.markdown.replace('Price $39,995','Price USD $39,995');assert.equal(summarizeBrokerResponse(p).facts.asking_price,39995);
});
