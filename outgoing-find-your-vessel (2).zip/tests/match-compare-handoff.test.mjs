import test from 'node:test';
import assert from 'node:assert/strict';
import {saveMatchCandidate} from '../src/lib/matchCompareHandoff.js';

test('MATCH save reuses a saved model when model year round-trips as a string', async()=>{
 const existing = {id:'saved',created_by_id:'buyer-a',make:'Parker',model:'2520',year:'2025',
   original_match_url:'https://example.com/search',listing_urls:['https://example.com/listing']};
 const rows=[existing];
 const client={entities:{SavedBoat:{
   async filter(){return rows;},
   async create(row){rows.push(row);return row;},
   async update(id,patch){Object.assign(existing,patch);return existing;}
 }}};
 const returned=await saveMatchCandidate(client,
   {id:'new',make:'Parker',model:'2520',year:2025,link:'https://example.com/new'},'buyer-a');
 assert.equal(returned.id,'saved');
 assert.equal(rows.length,1);
 assert.deepEqual(existing.listing_urls,['https://example.com/listing']);
 assert.equal(existing.original_match_url,'https://example.com/search');
});
