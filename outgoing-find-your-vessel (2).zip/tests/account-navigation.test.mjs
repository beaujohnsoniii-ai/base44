import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { safeReturnTo } from "../src/lib/authReturnTo.js";

const navbar = fs.readFileSync(new URL("../src/components/AppHeader.jsx", import.meta.url), "utf8");
test("My Account opens the protected My Helm dashboard for signed-in users", () => {
  assert.ok(navbar.includes('authed ? "/helm" : "/login?returnTo=%2Fhelm"'));
  assert.ok(navbar.includes('to={accountHref}>My Account'));
  const app = fs.readFileSync(new URL("../src/App.jsx", import.meta.url), "utf8");
  assert.match(app, /<Route element=\{<ProtectedRoute \/>\}>[\s\S]*path="\/dashboard" element=\{<Dashboard \/>\}/);
  assert.match(app, /<Route element=\{<ProtectedRoute \/>\}>[\s\S]*path="\/helm" element=\{<Dashboard \/>\}/);
});
test("signed-out My Account preserves the My Helm destination through login", () => {
  assert.ok(navbar.includes('/login?returnTo=%2Fhelm'));
  const previous = globalThis.window;
  try {
    globalThis.window = { location: { search: "?returnTo=%2Fhelm", origin: "https://soundheading.example" } };
    assert.equal(safeReturnTo(), "/helm");
  } finally {
    if (previous === undefined) delete globalThis.window;
    else globalThis.window = previous;
  }
});
test("account shortcut leaves general signup and shared auth defaults unchanged", () => {
  const app = fs.readFileSync(new URL("../src/App.jsx", import.meta.url), "utf8");
  assert.ok(app.includes('path="/register"'));
  const previous = globalThis.window;
  try {
    globalThis.window = { location: { search: "", origin: "https://soundheading.example" } };
    assert.equal(safeReturnTo(), "/tools");
  } finally {
    if (previous === undefined) delete globalThis.window;
    else globalThis.window = previous;
  }
});
