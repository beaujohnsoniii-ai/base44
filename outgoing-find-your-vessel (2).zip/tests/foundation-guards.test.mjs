import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
import { DEFAULT_FIELD_TIERS, fieldTiersFromSets } from "../base44/shared/question-tier-defaults.mjs";
import { loadQuestionTiers } from "../base44/shared/question-tiers.ts";
import { profileInputFingerprint } from "../base44/shared/profile-input-fingerprint.mjs";
test("frontend and backend defaults and admin overrides resolve identically, including overlapping overrides",async()=>{
 const defaults=await loadQuestionTiers({asServiceRole:{entities:{QuestionConfig:{list:async()=>[]}}}});
 assert.deepEqual(fieldTiersFromSets(defaults),DEFAULT_FIELD_TIERS);
 const tiers=await loadQuestionTiers({asServiceRole:{entities:{QuestionConfig:{list:async()=>[{match_plus_fields:["family_use"],refined_match_fields:["family_use"],market_match_fields:["activities"]}]}}}});
 const visible=fieldTiersFromSets(tiers);assert.equal(visible.family_use,"refined_match");assert.equal(visible.activities,"market_match");assert.equal(visible.passenger_count,"free");
});
test("profile fingerprint changes for matching inputs and context but not Likes, research notes or contradiction bookkeeping",async()=>{
 const p={activities:["Fishing"],activity_weights:{Fishing:100},liked_models:[{make:"A",model:"B"}]};
 const base=await profileInputFingerprint(p);
 assert.equal(await profileInputFingerprint({...p,research_notes:"new",updated_date:"later",contradiction_flag:{flagged:true}}),base);
 assert.notEqual(await profileInputFingerprint({...p,activities:["Day cruising"]}),base);
 assert.equal(await profileInputFingerprint({...p,liked_models:[]}),base);
 assert.notEqual(await profileInputFingerprint({...p,match_context_id:"new"}),base);
});
function adminRoute(state){
 const source=fs.readFileSync("src/components/AdminRoute.jsx","utf8");
 const js=ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.CommonJS}}).outputText;
 const exports={};const React={createElement:(type,props,...children)=>({type,props,children})};
 new Function("exports","require",js)(exports,name=>name==="react"?{default:React,__esModule:true}:name==="react-router-dom"?{Navigate:"Navigate",Outlet:"Outlet"}:{useAuth:()=>state});
 return exports.default();
}
test("admin route refuses ordinary users, anonymous users, failed auth and pending identity checks",()=>{
 const state={user:{role:"user"},isAuthenticated:true,isLoadingAuth:false,authChecked:true};
 assert.equal(adminRoute(state).type,"Navigate");
 assert.equal(adminRoute({...state,user:{role:"admin"},isAuthenticated:false}).type,"Navigate");
 assert.equal(adminRoute({...state,user:{role:"admin"},authError:{type:"unknown"}}).type,"Navigate");
 assert.equal(adminRoute({...state,user:{role:"admin"},isLoadingAuth:true}).props.role,"status");
 assert.equal(adminRoute({...state,user:{role:"admin"}}).type,"Outlet");
});
test("every admin URL is inside the role guard; removed Reports surface is absent on both dashboard variants",()=>{
 const app=fs.readFileSync("src/App.jsx","utf8");
 const group=app.slice(app.indexOf("<Route element={<AdminRoute />}>"),app.indexOf('      </Route>',app.indexOf('path="/admin/journey-trial"')));
 assert.equal((app.match(/path="\/admin\//g)||[]).length,12);assert.equal((group.match(/path="\/admin\//g)||[]).length,12);
 assert.match(group, /path="\/admin\/listing-intake-stage"/);
 const dash=fs.readFileSync("src/pages/Dashboard.jsx","utf8");
 assert.doesNotMatch(dash,/ResearchNotesPanel|PreliminaryFeedback|DiscoveryPanel|#research-notes/);
 assert.match(dash,/aria-label="Question-set testing"/);assert.match(dash,/aria-label="Internal research and testing tools"/);
 assert.match(dash,/user\?\.role === "admin" && \([\s\S]*id="admin"/);
 assert.match(app,/path="\/my-matches" element=\{<Dashboard matchOnly/);assert.match(app,/path="\/dashboard" element=\{<Dashboard/);
});
