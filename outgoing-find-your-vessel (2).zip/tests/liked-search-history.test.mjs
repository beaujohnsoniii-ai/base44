import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {pastLikedBoats} from "../src/lib/pastLikedBoats.js";
import {pastLikesEnabled, matchingLikes, applyPastLikeChoice} from "../base44/shared/liked-preferences.mjs";
import {profileInputFingerprint} from "../base44/shared/profile-input-fingerprint.mjs";
import {saveBuyerProfile} from "../base44/shared/save-buyer-profile.mjs";
test("past history contains only owned explicitly liked models, never QA or another owner", () => {
 const rows = [{id:"a",created_by_id:"one",liked:true,make:"A",model:"1"},{id:"b",created_by_id:"two",liked:true},{id:"c",created_by_id:"one",liked:false},{id:"d",created_by_id:"one",liked:true,test_profile_id:"qa"},{id:"e",created_by_id:"one",liked:true,make:"A",model:"1"}];
 assert.deepEqual(pastLikedBoats(rows,"one").map(r=>r.id),["a"]);
 assert.deepEqual(pastLikedBoats(rows,null),[]);
 assert.deepEqual(pastLikedBoats([],"one"),[]);
 assert.deepEqual(pastLikedBoats(rows,"two").map(r=>r.id),["b"]);
});
test("old Likes are opt-in, deduplicated and bounded independently of repetition or tier", () => {
 for(const tier of ["free","match_plus","refined_match","market_match"]){
 const p={match_context_id:"now",liked_models:Array.from({length:200},()=>({make:"A",model:"One",profile_input_fingerprint:"old",liked_at_tier:tier}))};
 assert.deepEqual(matchingLikes(p,"current"),[]);
 p.past_likes_context_id="now";assert.equal(matchingLikes(p,"current").length,1);
 p.match_context_id="reset";assert.equal(pastLikesEnabled(p),false);assert.deepEqual(matchingLikes(p,"current"),[]);
 assert.equal(p.liked_models.length,200);
 }
 assert.deepEqual(matchingLikes({},"current"),[]);
});
test("current context Likes remain available without past opt-in, and input cannot inject a weight", () => {
 assert.equal(matchingLikes({liked_models:[{title:"Current",profile_input_fingerprint:"fp"},{title:"Old",profile_input_fingerprint:"old"}]},"fp").length,1);
 const patch={match_context_id:"new"};applyPastLikeChoice({match_context_id:"old"},patch,{use_past_likes:true,weight:999});
 assert.deepEqual(patch,{match_context_id:"new",past_likes_context_id:"new"});
});
test("fingerprint preserves legacy results until opted in; Reset invalidates the opt-in",async()=>{
 const p={match_context_id:"old",experience_level:"beginner"};
 const base=await profileInputFingerprint(p);
 assert.equal(await profileInputFingerprint({...p,past_likes_context_id:null}),base);
 assert.notEqual(await profileInputFingerprint({...p,past_likes_context_id:"old"}),base);
 const reset={...p,match_context_id:"new",past_likes_context_id:"old"};
 assert.equal(await profileInputFingerprint(reset),await profileInputFingerprint({...reset,past_likes_context_id:null}));
});
test("saved preference is owner-scoped; edits without renewed choice disable past influence without erasing history",async()=>{
 let p={id:"p",created_by_id:"owner",experience_level:"beginner",match_context_id:"old",past_likes_context_id:"old",liked_models:[{title:"Keep"}]};
 const profiles={filter:async q=>{assert.deepEqual(q,{created_by_id:"owner"});return [p];},update:async(id,patch)=>{assert.equal(id,"p");p={...p,...patch};return p;}};
 const client={asServiceRole:{entities:{BuyerProfile:profiles}}};
 await saveBuyerProfile(client,{id:"owner"},{purchase_budget_max:90000});
 assert.equal(pastLikesEnabled(p),false);assert.equal(p.liked_models.length,1);
 await saveBuyerProfile(client,{id:"owner"},{use_past_likes:true});
 assert.equal(pastLikesEnabled(p),true);
 const context=p.match_context_id;
 await saveBuyerProfile(client,{id:"owner"},{use_past_likes:true});
 assert.equal(p.match_context_id,context);
 await saveBuyerProfile(client,{id:"owner"},{use_past_likes:false});
 assert.equal(pastLikesEnabled(p),false);
});
test("UI has one compact history trigger, empty and close states, no current-result history block",()=>{
 const dialog=fs.readFileSync("src/components/match/LikedSearchHistory.jsx","utf8");
 assert.match(dialog,/Liked boats from your past searches/);assert.match(dialog,/DialogClose/);assert.match(dialog,/no liked boats/);
 const showcase=fs.readFileSync("src/components/match/MatchResultsShowcase.jsx","utf8");
 assert.doesNotMatch(showcase,/previousSuggestions|MatchRankingOverview/);
 const panel=fs.readFileSync("src/components/SuggestedBoatsPanel.jsx","utf8");
 assert.doesNotMatch(panel,/Update My Matches|Previous directions|Access through/);
 assert.match(panel,/Model guidance, not verified live listings/);
});
