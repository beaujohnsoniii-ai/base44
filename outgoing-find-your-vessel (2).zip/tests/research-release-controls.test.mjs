import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
import {ReleaseService,payloadDigest} from '../base44/shared/release-runtime.mjs';
import {releaseRepository} from '../base44/shared/release-repository.mjs';
let client;
globalThis.__releaseClient=()=>client;
let source=readFileSync(new URL('../base44/functions/research-release/entry.ts',import.meta.url),'utf8')
 .replace("import {createClientFromRequest} from 'npm:@base44/sdk@0.8.52';","const createClientFromRequest=globalThis.__releaseClient;")
 .replaceAll("'../../shared/release-runtime.mjs'",JSON.stringify(new URL('../base44/shared/release-runtime.mjs',import.meta.url).href))
 .replaceAll("'../../shared/release-repository.mjs'",JSON.stringify(new URL('../base44/shared/release-repository.mjs',import.meta.url).href));
const handler=(await import('data:text/javascript;base64,'+Buffer.from(stripTypeScriptTypes(source)).toString('base64'))).default;
for(const [label,user,status] of [['anonymous',null,401],['ordinary',{id:'isolated',role:'user'},403]]){
 test(label+' is rejected before service-role access',async()=>{let reads=0;client={auth:{me:async()=>user},get asServiceRole(){reads++;throw Error('must not access');}};const r=await handler(new Request('https://isolated.test',{method:'POST',body:'{"action":"stage"}'}));assert.equal(r.status,status);assert.equal(reads,0);});
}
test('GET cannot invoke release controls',async()=>{const r=await handler(new Request('https://isolated.test'));assert.equal(r.status,405);});
test('unknown authenticated admin action is rejected',async()=>{client={auth:{me:async()=>({id:'admin-fixture',role:'admin'})},asServiceRole:{entities:{}}};const r=await handler(new Request('https://isolated.test',{method:'POST',body:'{"action":"unknown"}'}));assert.equal(r.status,400);});
test('repository refuses unverified pointer write semantics',async()=>{const entity={filter:async()=>[{id:'pointer',key:'active',activation_enabled:true,revision:0}]};const repo=releaseRepository({entities:{ResearchRelease:{},ResearchReleaseRecord:{},ResearchReleasePointer:entity}});await assert.rejects(repo.swapPointer(0,{release_id:'anything'}),/not verified/);});
test('partial dataset cannot seal',async()=>{const record={generation_id:'g',make:'Builder',model:'23',observations:[]};let sealed=false;const repo={getRelease:async()=>({manifest:{release_id:'partial',source_sha256:'a'.repeat(64),validation_sha256:'b'.repeat(64),payload_sha256:payloadDigest([record]),record_count:2,observation_count:0}}),listRecords:async()=>[record],sealRelease:async()=>{sealed=true;}};await assert.rejects(new ReleaseService(repo).seal({role:'admin'},'partial'),/Incomplete/);assert.equal(sealed,false);});

test('sealed but unapproved release cannot reach pointer writes',async()=>{
 const record={generation_id:'g',make:'Builder',model:'23',observations:[]};
 const manifest={release_id:'not-approved',source_sha256:'a'.repeat(64),validation_sha256:'b'.repeat(64),payload_sha256:payloadDigest([record]),record_count:1,observation_count:0};
 let pointerReads=0;let pointerWrites=0;
 const repo={getRelease:async()=>({manifest,sealed:true,approved:false}),listRecords:async()=>[record],getPointer:async()=>{pointerReads++;return {revision:0};},swapPointer:async()=>{pointerWrites++;}};
 await assert.rejects(new ReleaseService(repo).promote({id:'admin',role:'admin'},manifest.release_id,0),/Release approval required/);
 assert.equal(pointerReads,0);assert.equal(pointerWrites,0);
});

test('rollback also refuses a previously active but now unapproved release',async()=>{
 const record={generation_id:'g',make:'Builder',model:'23',observations:[]};
 const manifest={release_id:'former',source_sha256:'a'.repeat(64),validation_sha256:'b'.repeat(64),payload_sha256:payloadDigest([record]),record_count:1,observation_count:0};
 let writes=0;
 const repo={getRelease:async()=>({manifest,sealed:true,approved:false}),listRecords:async()=>[record],getPointer:async()=>({release_id:'current',previous_release_id:'former',revision:8}),swapPointer:async()=>{writes++;}};
 await assert.rejects(new ReleaseService(repo).rollback({id:'admin',role:'admin'},8),/Release approval required/);
 assert.equal(writes,0);
});
