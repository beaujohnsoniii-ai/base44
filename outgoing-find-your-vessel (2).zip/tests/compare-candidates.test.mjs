import test from 'node:test';
import assert from 'node:assert/strict';
import {listingUrls, selectionFor, confirmedFinalists, modelSearch} from '../src/lib/compareCandidates.js';
test('three defaults preserve all extra candidates and explicit empty selection', () => {
 const boats = ['a','b','c','d'].map(id=>({id}));
 assert.deepEqual(selectionFor(boats), ['a','b','c']);
 assert.equal(boats.length,4);
 assert.deepEqual(selectionFor(boats,{selected_ids:[]}),[]);
 assert.deepEqual(selectionFor(boats,{selected_ids:['d','missing','d','b']}),['d','b']);
});
test('downstream journey requires explicit Compare shortlist and preserves user ordering',()=>{
 const boats=['a','b','c'].map(id=>({id,title:'Model '+id}));
 assert.deepEqual(confirmedFinalists(boats,null),[]);
 assert.deepEqual(confirmedFinalists(boats,{selected_ids:[]}),[]);
 assert.deepEqual(confirmedFinalists(boats,{selected_ids:['c','absent','a','c']} ).map(b=>b.id),['c','a']);
 assert.equal(boats.length,3);
});
test('listing validation normalizes, deduplicates, clears and rejects unsafe or excessive input',()=>{
 assert.deepEqual(listingUrls([' https://example.com/boat ','https://example.com/boat','']),['https://example.com/boat']);
 assert.deepEqual(listingUrls(['  ']),[]);
 for(const value of ['javascript:alert(1)','ftp://example.com','not a link','https://user:pass@example.com']) assert.throws(()=>listingUrls([value]));
 assert.throws(()=>listingUrls(['https://a.com','https://b.com','https://c.com','https://d.com']));
});
test('mobile listing Share text and bare site links normalize for Compare', () => {
 assert.deepEqual(listingUrls(['See this listing on Boat Trader!\nhttps://www.boattrader.com/boat/12345?src=share\nSent from my phone']), ['https://www.boattrader.com/boat/12345?src=share']);
 assert.deepEqual(listingUrls(['www.yachtworld.com/yacht/98765','boats.com/power-boats/2025-abc-5555']), ['https://www.yachtworld.com/yacht/98765', 'https://boats.com/power-boats/2025-abc-5555']);
 assert.deepEqual(listingUrls(['Take a look (https://www.boats.com/boat/123).']), ['https://www.boats.com/boat/123']);
 assert.throws(() => listingUrls(['Boat A https://www.boats.com/a and B https://www.boats.com/b']), /one listing link/);
 assert.throws(() => listingUrls(['http://www.boats.com/boat/123']), /HTTPS/);
});
test('Google search uses model identity and encodes it',()=>{
 const u=new URL(modelSearch({make:'A & B',model:'24/CC',title:'unrelated'}));
 assert.equal(u.hostname,'www.google.com');
 assert.equal(u.searchParams.get('q'),'A & B 24/CC boats for sale');
});
