import test from "node:test";
import assert from "node:assert/strict";
import { makeHybridResolver } from "../base44/shared/hybrid-generation.ts";
import { generateRecommendations } from "../base44/shared/suggest-engine.ts";

test("missing workbook entry preserves candidate explanation without blanket warnings or online calls", async () => {
 const db={entities:{ResearchDataset:{filter:async()=>[]},DataReviewIssue:{filter:async()=>[]}}};
 const candidate={make:"Parker",model:"2520",why_suggested:"Protected helm for the buyer's weather exposure."};
 const out=await makeHybridResolver(db,[])([candidate]);
 assert.equal(out.candidates[0].why_suggested,candidate.why_suggested);
 assert.equal(out.candidates[0].__hybrid_pending,false);
 assert.deepEqual(out.candidates[0].verification_required,[]);
});
test("stored conflicts remain explicit in reference-only matching", async()=>{
 const db={entities:{ResearchDataset:{filter:async()=>[]},DataReviewIssue:{filter:async()=>[{status:"open",kind:"conflict",field:"Beam"}]}}};
 const out=await makeHybridResolver(db,[])([{make:"Example",model:"28"}]);
 assert.equal(out.candidates[0].__hybrid_conflict,true);
 // The dispute stays explicit as field-level evidence rather than as a raw
 // record field name shown to the buyer. Buyer-facing wording is built later,
 // where the buyer's own stated limits are known.
 assert.equal(out.candidates[0].__hybrid_fields.find(f=>f.field==="Beam").status,"conflict");
 assert.equal(out.candidates[0].__hybrid_fields.find(f=>f.field==="Beam").status,"conflict");
 assert.deepEqual(out.candidates[0].verification_required,[]);
});
test("AI candidates survive both empty and unrelated workbook references",async()=>{
 const client={asServiceRole:{integrations:{Core:{InvokeLLM:async()=>({suggestions:[{make:"Parker",model:"2520",why_suggested:"Protected helm",length:"25 ft"}]})}}}};
 for(const datasetCandidates of [[],[{manufacturer:"Other",model:"30"}]]){
 const result=await generateRecommendations(client,{
 profile:{purchase_budget_max:100000},plan:"market_match",
 tierFields:{matchPlus:new Set(),refinedMatch:new Set(),marketMatch:new Set()},
 manufacturerMap:{brief:"",list:[]},likedModels:[],savedBoats:[],existingSuggestions:[],
 isFirstPaidGeneration:false,hadContradiction:false,refresh:true,contradictionRerunCount:0,datasetCandidates
 });
 assert.equal(result.suggestions[0].model,"2520");
 assert.match(result.suggestions[0].why_suggested,/Protected helm/);
 assert.ok(result.suggestions[0].verification_required.some(v=>/price/i.test(v)));
 }
});