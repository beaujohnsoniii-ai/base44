import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const dashboard = readFileSync(new URL("../src/pages/Dashboard.jsx", import.meta.url), "utf8");
const tierCard = readFileSync(new URL("../src/components/PlanTierCard.jsx", import.meta.url), "utf8");

test("browser checkout cannot grant itself paid User fields", () => {
  assert.doesNotMatch(dashboard, /auth\.updateMe\s*\(/, "Never mutate entitlements from browser auth.updateMe");
  assert.doesNotMatch(dashboard, /DEV PURCHASE BYPASS/i);
  assert.match(dashboard, /Checkout not available yet/);
});

test("no browser checkout is offered while payment verification is pending", () => {
  // The tier card remains fail-closed if it is ever rendered in the dashboard.
  assert.match(tierCard, /checkoutAvailable\s*=\s*false/);
  assert.match(tierCard, /disabled=\{!checkoutAvailable\s*\|\|\s*purchasing === purchaseId\}/);
  assert.match(tierCard, /Checkout unavailable/);
  // The current dashboard intentionally uses question-set previews rather than
  // rendering three obsolete purchase cards. Assert its actual security policy.
  assert.match(dashboard, /Checkout not available yet/);
  assert.match(dashboard, /No payment will be taken/);
  assert.doesNotMatch(dashboard, /functions\.invoke\(\s*["']create-checkout/);
  assert.doesNotMatch(dashboard, /checkoutAvailable=\{true\}/);
});
