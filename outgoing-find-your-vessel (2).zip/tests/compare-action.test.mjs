import test from "node:test";
import assert from "node:assert/strict";
import {compareWithSavedInputs} from "../src/lib/compareAction.js";
function fixture(){
 const boat={id:"b",created_by_id:"u",listing_urls:["https://dealer.com/old"],notes:"keep"};
 let space=null;const events=[],invocations=[];
 const client={auth:{me:async()=>({id:"u"})},entities:{
 SavedBoat:{get:async()=>({...boat}),update:async(id,data)=>{events.push("save");Object.assign(boat,data);}},
 CompareWorkspace:{create:async data=>(events.push("selection"),space={...data,id:"w",created_by_id:"u"}),
 get:async()=>({...space}),update:async(id,data)=>(space={...space,...data})}},
 functions:{invoke:async(name,body)=>{events.push("compare");invocations.push({name,body});return {data:{results:[],mode:"approved_source_import"}};}}};
 return {client,boat,events,invocations,args:{boats:[boat],selected:["b"],drafts:{b:["https://dealer.com/new"]},workspace:null}};
}
test("single Compare saves and verifies pasted draft and default selection before invoking",async()=>{
 const f=fixture();const out=await compareWithSavedInputs(f.client,f.args);
 assert.deepEqual(f.events,["save","selection","compare"]);assert.deepEqual(f.boat.listing_urls,["https://dealer.com/new"]);
 assert.equal(f.boat.notes,"keep");assert.equal(out.comparison.mode,"approved_source_import");
});
test("transient capture is URL-bound, sent once, and never persisted",async()=>{
 const f=fixture();const copied="2027 Test 23 for sale. Dealer listing with stock 44, location Harbor, length 23 ft, beam 8 ft, and visible seller details.";
 f.args.captures={b:[copied]};
 await compareWithSavedInputs(f.client,f.args);
 assert.deepEqual(f.invocations[0],{name:"compare-listings",body:{captures:[{url:"https://dealer.com/new",text:copied}]}});
 assert.equal(Object.hasOwn(f.boat,"captures"),false);assert.equal(Object.hasOwn(f.boat,"captured_text"),false);
});
test("oversize capture is rejected before authentication, writes, or invocation",async()=>{
 const f=fixture();let authenticated=false;f.client.auth.me=async()=>{authenticated=true;return {id:"u"};};
 f.args.captures={b:["x".repeat(16001)]};
 await assert.rejects(compareWithSavedInputs(f.client,f.args),/too long/);
 assert.equal(authenticated,false);assert.deepEqual(f.events,[]);assert.deepEqual(f.invocations,[]);
});
test("invalid drafts are rejected before any write or invocation",async()=>{
 const f=fixture();f.args.drafts.b=["javascript:alert(1)"];
 await assert.rejects(compareWithSavedInputs(f.client,f.args));assert.deepEqual(f.events,[]);
});
test("failed save never invokes Compare or drops original in-memory draft",async()=>{
 const f=fixture();f.client.entities.SavedBoat.update=async()=>{throw Error("save failed");};
 await assert.rejects(compareWithSavedInputs(f.client,f.args),/save failed/);
 assert.deepEqual(f.args.drafts.b,["https://dealer.com/new"]);assert.deepEqual(f.events,[]);
});
test("another owner's boat is rejected before saving even for an admin-shaped client",async()=>{
 const f=fixture();f.boat.created_by_id="other";
 await assert.rejects(compareWithSavedInputs(f.client,f.args),/unavailable/);assert.deepEqual(f.events,[]);
});test("stalled write times out, retains draft, and late completion cannot continue or clear it",async()=>{
 const f=fixture();let finish,callback=0;
 f.client.entities.SavedBoat.update=()=>new Promise(resolve=>finish=resolve);
 await assert.rejects(compareWithSavedInputs(f.client,f.args,()=>callback++,{milliseconds:10}),e=>e.code==="REQUEST_TIMEOUT"&&e.save_uncertain===true);
 finish({});await new Promise(resolve=>setTimeout(resolve,0));
 assert.equal(callback,0);assert.deepEqual(f.events,[]);assert.deepEqual(f.args.drafts.b,["https://dealer.com/new"]);
});
test("stalled authentication times out without writes, including after a late response",async()=>{
 const f=fixture();let finish;f.client.auth.me=()=>new Promise(resolve=>finish=resolve);
 await assert.rejects(compareWithSavedInputs(f.client,f.args,()=>{},{milliseconds:10}),e=>e.code==="REQUEST_TIMEOUT"&&e.save_uncertain===false);
 finish({id:"u"});await new Promise(resolve=>setTimeout(resolve,0));assert.deepEqual(f.events,[]);
});
test("read-only Compare timeout retains confirmed saves and does not retry invocation",async()=>{
 const f=fixture();let calls=0;f.client.functions.invoke=()=>{calls++;return new Promise(()=>{});};
 await assert.rejects(compareWithSavedInputs(f.client,f.args,()=>{},{milliseconds:10}),e=>e.code==="REQUEST_TIMEOUT"&&e.save_uncertain===false);
 assert.equal(calls,1);assert.deepEqual(f.boat.listing_urls,["https://dealer.com/new"]);
});
