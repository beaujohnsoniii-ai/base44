import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";

function setup({role="admin",hasKey=true,prior=[],status=200,clock="2026-10-14T12:00:00Z"}={}) {
  // The real pilot authorization expired 2026-10-15 UTC. Freeze tests within
  // its original approval window, and test expiration separately below.
  const FixedDate = class extends Date {
    constructor(...args) { super(...(args.length ? args : [clock])); }
    static now() { return Date.parse(clock); }
  };
  const records=[],calls=[];
  const entity={
    filter:async()=>prior,
    create:async data=>{records.push({id:"job-test",...data});return records[0];},
    update:async(id,data)=>{Object.assign(records[0],data);return records[0];}
  };
  const client={auth:{me:async()=>{if(role===null)throw Error("unauthorized");return {role};}},entities:{ResearchJob:entity}};
  const fetcher=async(url,options)=>{
    calls.push({url,options});
    if(url.endsWith("/models"))return Response.json({data:[{id:"claude-sonnet-4-6"},{id:"grok-4.3"}]},{status});
    return Response.json({id:"response-test",content:[{type:"text",text:"Useful review"}],choices:[{message:{content:"Useful brief"},finish_reason:"stop"}],usage:{input_tokens:100,output_tokens:200,prompt_tokens:100,completion_tokens:200},stop_reason:"end_turn"});
  };
  const source=fs.readFileSync("base44/functions/run-provider-proof/entry.ts","utf8").replace(/import \{ createClientFromRequest \} from [^;]+;/,"");
  const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
  const exports={};
  new Function("exports","createClientFromRequest","Deno","fetch","Date",js)(exports,()=>client,{env:{get:()=>hasKey?"mock-test-key":undefined}},fetcher,FixedDate);
  return {handler:exports.default,records,calls};
}
function request(task="claude",method="POST") {return new Request("https://example.test",{method,...(method==="POST"?{headers:{"content-type":"application/json"},body:JSON.stringify({task})}:{})});}
test("admin provider-proof buttons expire at the same UTC deadline as the backend",()=>{
  const backend=fs.readFileSync("base44/functions/run-provider-proof/entry.ts","utf8");
  const ui=fs.readFileSync("src/pages/AdminResearchMonitor.jsx","utf8");
  const expiration="2026-10-15T00:00:00Z";
  assert.ok(backend.includes(expiration));
  assert.ok(ui.includes(expiration));
  assert.match(ui, /disabled=\{!!runningProof \|\| proofWindowClosed\}/);
});

test("provider pilot denies anonymous and non-admin access without external calls",async()=>{
  for(const role of [null,"user"]) {const s=setup({role});assert.equal((await s.handler(request())).status,role===null?401:403);assert.equal(s.calls.length,0);}
});
test("provider pilot rejects unsupported method and task before external calls",async()=>{
  const s=setup();assert.equal((await s.handler(request("claude","GET"))).status,405);assert.equal((await s.handler(request("unknown"))).status,400);assert.equal(s.calls.length,0);
});
test("expired provider proof refuses generation or job creation",async()=>{
  const s=setup({clock:"2026-10-15T00:00:00Z"});
  const response=await s.handler(request());
  assert.equal(response.status,410);
  assert.equal(s.calls.length,0);
  assert.equal(s.records.length,0);
});
test("provider pilot missing keys and recorded jobs never trigger generation",async()=>{
  const a=setup({hasKey:false});assert.equal((await a.handler(request())).status,503);assert.equal(a.calls.length,0);
  const b=setup({prior:[{id:"old",status:"needs_review"}]});assert.equal((await (await b.handler(request())).json()).already_recorded,true);assert.equal(b.calls.length,0);
});
test("provider pilot retains bounded Claude and xAI outputs with evidence",async()=>{
  for(const task of ["claude","grok"]) {
    const s=setup();const result=await (await s.handler(request(task))).json();
    assert.equal(result.verified_generation,true);assert.equal(s.calls.length,2);assert.equal(s.records[0].status,"needs_review");
    const payload=JSON.parse(s.calls[1].options.body);
    assert.equal(payload.max_tokens,1600);assert.ok(new TextEncoder().encode(payload.messages[0].content).length<=6000);
    assert.ok(!s.calls[1].options.body.includes("mock-test-key"));assert.ok(s.records[0].estimated_cost_usd<0.05);
    assert.equal(JSON.parse(s.records[0].last_message).response_id,"response-test");
    assert.equal(payload.model,task==="claude"?"claude-sonnet-4-6":"grok-4.3");
    if(task==="grok")assert.equal(payload.reasoning_effort,"none");
  }
});
test("provider pilot records failed model access without a generation request",async()=>{
  const s=setup({status:401});assert.equal((await s.handler(request())).status,502);assert.equal(s.calls.length,1);assert.equal(s.records[0].calls,0);assert.equal(s.records[0].status,"failed");
});
