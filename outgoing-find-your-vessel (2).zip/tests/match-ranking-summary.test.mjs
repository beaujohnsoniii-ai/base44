import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { MATCH_SCORE_COMPONENTS, MATCH_SCORE_TOTAL, splitScoreComponents } from "../src/lib/matchScoreComponents.js";

test("the frontend scoring mirror matches the server's component caps", () => {
  const engine = fs.readFileSync("base44/shared/suggest-engine.ts", "utf8");
  const block = engine.match(/MATCH_SCORE_CAPS: Record<string, number> = \{([\s\S]*?)\};/);
  assert.ok(block, "MATCH_SCORE_CAPS not found in the suggest engine");
  const caps = Object.fromEntries([...block[1].matchAll(/([a-z_]+):\s*(\d+)/g)].map((m) => [m[1], Number(m[2])]));
  assert.deepEqual(
    MATCH_SCORE_COMPONENTS.map((c) => c.key).sort(),
    Object.keys(caps).sort(),
    "the displayed components must be exactly the ones the server scores",
  );
  for (const component of MATCH_SCORE_COMPONENTS) {
    assert.equal(component.max, caps[component.key], `${component.key} cap drifted from the server`);
  }
  assert.equal(MATCH_SCORE_TOTAL, 100);
});

test("data points are presented as points earned out of the component maximum", () => {
  const { earned, zeroed, scored } = splitScoreComponents({
    activities_use: 25,
    operating_environment: 12,
    family_layout: 6,
    comfort_overnight: 0,
    preferences: 0,
  });
  assert.equal(scored, true);
  assert.deepEqual(earned.map((row) => `${row.key}=${row.value}/${row.max}`), [
    "activities_use=25/25",
    "operating_environment=12/15",
    "family_layout=6/12",
  ], "strongest components must lead and unrecorded ones must not appear as zero");
  assert.deepEqual(zeroed, ["Comfort and overnight use", "Stated preferences"]);
});

test("a model with no stored breakdown reports no score instead of zeros", () => {
  const empty = splitScoreComponents(null);
  assert.equal(empty.scored, false);
  assert.deepEqual(empty.earned, []);
  assert.deepEqual(empty.zeroed, []);
});

test("component labels are buyer-facing, never raw field keys", () => {
  for (const component of MATCH_SCORE_COMPONENTS) {
    assert.ok(component.label && component.label !== component.key, `${component.key} needs a readable label`);
    assert.ok(component.max > 0);
  }
  assert.equal(new Set(MATCH_SCORE_COMPONENTS.map((c) => c.label)).size, MATCH_SCORE_COMPONENTS.length);
});

test("the ranking summary states the position, its basis, fit reasons and data points", () => {
  const src = fs.readFileSync("src/components/match/MatchRankingSummary.jsx", "utf8");
  for (const phrase of [
    "Why this ranks #",
    "SoundHeading Fit",
    "Ranking order applies your hard limits first",
    "Ranking note",
    "Why it fits",
    "Trade-offs to weigh",
    "Data points used (of",
    "match-critical fields confirmed",
  ]) {
    assert.ok(src.includes(phrase), `${phrase} missing from the ranking summary`);
  }
  // Everything shown must come from the stored record.
  assert.match(src, /const fitReasons = boat\.match\?\.matches \|\| \[\];/);
  assert.match(src, /const tradeoffs = boat\.match\?\.gaps \|\| \[\];/);
  assert.match(src, /const score = typeof boat\.suitability_score === "number"/);
  assert.match(src, /splitScoreComponents\(boat\.score_breakdown\)/);
  assert.match(src, /boat\.why_suggested/);
  assert.doesNotMatch(src, /Math\.random/, "a placement must never be invented in the UI");
  // A tier that marks nothing must say so rather than imply the model lost a ranking.
  assert.match(src, /Nothing is marked at this level/);
});

test("each card shows the ranking summary with its pool size", () => {
  const showcase = fs.readFileSync("src/components/match/MatchResultsShowcase.jsx", "utf8");
  assert.match(showcase, /const total = suggestions\.length;/);
  assert.match(showcase, /card\(leader, "best", 1, total\)/);
  assert.match(showcase, /card\(boat, "alternative", i \+ 2, total\)/);
  assert.match(showcase, /card\(boat, leader \? "compact" : "pool", i \+ 1, total\)/);
  assert.doesNotMatch(showcase, /previousSuggestions/);
});