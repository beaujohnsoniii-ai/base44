import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { MATCH_SCORE_TOTAL } from "../src/lib/matchScoreComponents.js";

// The pool-wide ranking summary is the section a buyer reads first, so it must
// state the position, the fit reasons and the stored data points — and nothing
// that was not stored with the result.

const SOURCE = fs.readFileSync("src/components/match/MatchRankingOverview.jsx", "utf8");

test("the ranking summary section states its basis, position and marks", () => {
  for (const phrase of [
    "How these models were ranked",
    "screened against your hard limits first",
    "SoundHeading Fit",
    "Fit reasons",
    "Data points behind this position",
    "trade-off",
    "none marked as a recommendation",
  ]) {
    assert.ok(SOURCE.includes(phrase), `${phrase} missing from the ranking summary section`);
  }
});

test("every figure shown comes from the stored record", () => {
  assert.match(SOURCE, /const fit = typeof boat\.suitability_score === "number"/);
  assert.match(SOURCE, /const reasons = Array\.isArray\(boat\.match\?\.matches\) \? boat\.match\.matches : \[\];/);
  assert.match(SOURCE, /const gaps = Array\.isArray\(boat\.match\?\.gaps\) \? boat\.match\.gaps : \[\];/);
  assert.match(SOURCE, /splitScoreComponents\(boat\.score_breakdown\)/);
  assert.match(SOURCE, /Number\(boat\.rank\) \|\| i \+ 1/);
  assert.match(SOURCE, /boat\.highlighted === true \? markChip : null/);
  assert.doesNotMatch(SOURCE, /Math\.random|estimate|recompute/i, "a placement must never be invented in the UI");
});

test("unrecorded data is reported as missing, not as a good result", () => {
  assert.match(SOURCE, /No fit score stored/);
  assert.match(SOURCE, /No scoring breakdown was stored for this model/);
});

test("the section is capped so each row stays scannable", () => {
  assert.match(SOURCE, /const REASONS_SHOWN = 3;/);
  assert.match(SOURCE, /const POINTS_SHOWN = 3;/);
  assert.match(SOURCE, /earned\.slice\(0, POINTS_SHOWN\)/);
  assert.match(SOURCE, /reasons\.slice\(0, REASONS_SHOWN\)/);
  assert.match(SOURCE, /more fit reason/);
});

test("the total the section quotes is the full match score", () => {
  assert.equal(MATCH_SCORE_TOTAL, 100);
  assert.match(SOURCE, /MATCH_SCORE_TOTAL\}`|MATCH_SCORE_TOTAL\}/);
});

test("current results omit the redundant pool-wide ranking summary", () => {
  const showcase = fs.readFileSync("src/components/match/MatchResultsShowcase.jsx", "utf8");
  assert.doesNotMatch(showcase, /MatchRankingOverview|How these models were ranked|previousSuggestions/);
  assert.match(showcase, /MatchResultCard/);
});

test("the summary is styled in the navy and teak result theme", () => {
  const css = fs.readFileSync("src/components/match-results.css", "utf8");
  assert.match(css, /\.sh-match-overview \{/);
  assert.match(css, /\.sh-match-overview__row \{/);
  assert.match(css, /@media \(max-width:860px\) \{\s*\.sh-match-overview__row \{grid-template-columns:1fr;\}/);
});