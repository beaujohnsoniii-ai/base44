import test from "node:test";
import assert from "node:assert/strict";
import { normalizePriceStep, roundPrice, zoomPriceWindow } from "../src/lib/price-range.js";

test("budget slider honors requested $5,000 increments", () => {
  assert.equal(normalizePriceStep(5000), 5000);
  assert.equal(roundPrice(12345, 5000), 10000);
  assert.equal(roundPrice(12750, 5000), 15000);
  assert.equal(roundPrice(12750, 500), 13000);
});

test("invalid slider steps fall back to a positive default", () => {
  assert.equal(normalizePriceStep(0), 500);
  assert.equal(normalizePriceStep(NaN), 500);
  assert.equal(roundPrice(1250, 0), 1500);
});

test("the zoom window respects the questionnaire increment and selection", () => {
  const view = zoomPriceWindow(35000, 85000, 0, 20000000, 5000);
  assert.ok(view.lo <= 35000 && view.hi >= 85000);
  assert.equal(view.lo % 5000, 0);
  assert.equal(view.hi % 5000, 0);
  const fullNearLimit = zoomPriceWindow(19990000, 20000000, 0, 20000000, 5000);
  assert.equal(fullNearLimit.hi, 20000000);
  assert.ok(fullNearLimit.lo < fullNearLimit.hi);
});
