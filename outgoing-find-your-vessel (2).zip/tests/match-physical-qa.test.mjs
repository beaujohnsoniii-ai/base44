import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { runProgrammaticChecks } from "../base44/shared/qa-programmatic.ts";

function check(specs, profile = {}, verification_required = [], title = "QA Boat", tier = "free") {
  const boat = {
    title, make: "QA", model: "Boat", specs,
    asking_price: 30000, verification_required,
  };
  return runProgrammaticChecks([boat], profile, tier, []).checks;
}
function hard(specs, profile, verify = []) {
  return check(specs, profile, verify).hard_constraint_violations;
}

test("preferred length is not a hard maximum", () => {
  const c = check("Overall length 28 ft", { boat_size_range: "30_40" });
  assert.equal(c.hard_constraint_violations.length, 0);
  assert.ok(c.size_violations.length > 0);
});
test("rigged overall length is required to prove a facility fit", () => {
  assert.ok(hard("Hull length 29 ft", { hard_max_overall_length_ft: 30 }).length > 0);
  assert.equal(hard("Hull length 29 ft", { hard_max_overall_length_ft: 30 }, ["verify overall length including engines"]).length, 0);
  assert.ok(hard("Overall length 29 ft", { hard_max_overall_length_ft: 30 }).length > 0); // An LLM claim alone cannot clear the hard limit.
  assert.equal(hard("Overall length 29 ft", { hard_max_overall_length_ft: 30 }, ["Verify rigged overall length against source"]).length, 0);
  assert.ok(hard("Overall length 31 ft", { hard_max_overall_length_ft: 30 }).length > 0);
});
test("draft is parsed in feet and inches", () => {
  assert.equal(hard("Draft 12 inches", { hard_max_draft_ft: 1 }, ["Verify operating draft"]).length, 0);
  assert.ok(hard("Draft 16 inches", { hard_max_draft_ft: 1 }).length > 0);
});
test("beam handles feet and inches", () => {
  assert.equal(hard("Beam 9 ft 6 in", { hard_max_beam_ft: 9.5 }, ["Verify beam"]).length, 0);
  assert.ok(hard("Beam 9 ft 6 in", { hard_max_beam_ft: 9.4 }).length > 0);
});
test("bridge clearance cannot prove storage height", () => {
  assert.ok(hard("Bridge clearance 8 ft", { hard_max_height_ft: 9 }).length > 0);
  assert.equal(hard("Storage height 8 ft", { hard_max_height_ft: 9 }, ["Verify storage height"]).length, 0);
});
test("dry weight cannot prove loaded storage or towing fit", () => {
  assert.ok(hard("Dry weight 4000 lb", { hard_max_storage_weight_lb: 5000 }).length > 0);
  assert.ok(hard("Loaded weight 6000 lb", { hard_max_storage_weight_lb: 5000 }).length > 0);
  assert.equal(hard("Loaded weight 4800 lb", { hard_max_storage_weight_lb: 5000 }, ["Verify loaded storage weight"]).length, 0);
  assert.ok(hard("Dry weight 3000 lb", { storage: "trailer", tow_capacity_lb: 3500 }).length > 0);
  assert.ok(hard("Trailer weight 3800 lb", { storage: "trailer", tow_capacity_lb: 3500 }).length > 0);
  assert.equal(hard("Trailer weight 3300 lb", { storage: "trailer", tow_capacity_lb: 3500 }, ["Verify trailered weight"]).length, 0);
  assert.equal(hard("Dry weight 4000 lb", {}).length, 0);
});
test("storage notes only create a hard limit when explicitly stated", () => {
  assert.equal(hard("Overall length 41 ft", { storage_capacity: "40 ft slip, dimensions need confirming" }).length, 0);
  assert.ok(hard("Overall length 31 ft", { storage_capacity: "max length 30 ft" }).length > 0);
});
test("out-of-scope vessel types and >65 ft models are hard QA failures", () => {
  const rib = check("Length 25 ft", {}, [], "RIB 750");
  assert.ok(rib.scope_violations.length > 0);
  assert.ok(rib.hard_constraint_violations.some(x => x.startsWith("Scope:")));
  const oversized = check("Overall length 66 ft", {}, [], "Coastal Cruiser 66");
  assert.ok(oversized.scope_violations.length > 0);
  const sailfish = check("Length 24 ft", {}, [], "Sailfish 245 DC");
  assert.equal(sailfish.scope_violations.length, 0);
});
test("an independently supported model price lower bound entirely above budget is a hard failure", () => {
  const boat = {
    title: "QA Boat", make: "QA", model: "Boat", specs: "Overall length 28 ft",
    price_range_min: 30000, price_range_max: 42000, verification_required: [],
  };
  // A separate trusted-source review must supply this bound. The LLM range
  // and self-declared confidence are never sufficient evidence for exclusion.
  const result = runProgrammaticChecks([boat], { purchase_budget_max: 25000 }, "free", [], () => 30000);
  assert.ok(result.checks.hard_constraint_violations.some(x => x.includes("Budget")));
});

test("a single approximate asking price does not prove a model exceeds the buyer budget", () => {
  const c = check("Overall length 28 ft", { purchase_budget_max: 25000 });
  assert.equal(c.budget_violations.length, 0);
});

test("an estimated model price band overlapping the budget is not an automatic rejection", () => {
  const boat = {
    title: "QA Boat", make: "QA", model: "Boat", specs: "Overall length 28 ft",
    price_range_min: 20000, price_range_max: 42000, verification_required: ["Verify actual market price against purchase budget"],
  };
  const result = runProgrammaticChecks([boat], { purchase_budget_max: 25000 }, "free", []);
  assert.equal(result.checks.budget_violations.length, 0);
});
test("unknown model price requires verification rather than an invented hard rejection", () => {
  const boat = {
    title: "Unknown price model", make: "QA", model: "Unknown", specs: "Overall length 28 ft",
    verification_required: [],
  };
  const result = runProgrammaticChecks([boat], { purchase_budget_max: 50000 }, "free", []);
  assert.equal(result.checks.budget_violations.length, 0);
  assert.equal(result.checks.price_verification_gaps.length, 1);
  assert.ok(result.flag_reasons.some(reason => /price verification gap/i.test(reason)));
});

test("price band overlapping budget must be flagged for verification", () => {
  const boat = {
    title: "Overlapping model", make: "QA", model: "Overlap", specs: "Overall length 28 ft",
    price_range_min: 40000, price_range_max: 70000, verification_required: [],
  };
  const result = runProgrammaticChecks([boat], { purchase_budget_max: 50000 }, "free", []);
  assert.equal(result.checks.budget_violations.length, 0);
  assert.equal(result.checks.price_verification_gaps.length, 1);
  const flagged = runProgrammaticChecks([{ ...boat, price_range_context: "2019–2023 model years, US used market broad estimate", verification_required: ["Verify market price against buyer budget"] }], { purchase_budget_max: 50000 }, "free", []);
  assert.equal(flagged.checks.price_verification_gaps.length, 0);
});

test("in-budget model price band needs independent verification, even with generation/year/market context", () => {
  const boat = {
    title: "In-budget model", make: "QA", model: "Budget", specs: "Overall length 28 ft",
    price_range_min: 25000, price_range_max: 40000, verification_required: [],
  };
  const missingContext = runProgrammaticChecks([boat], { purchase_budget_max: 50000 }, "free", []);
  assert.equal(missingContext.checks.price_verification_gaps.length, 1);
  assert.ok(missingContext.flag_reasons.some(reason => /price verification gap/i.test(reason)));
  const withContext = runProgrammaticChecks([
    { ...boat, price_range_context: "2019–2023 model years, US used market broad estimate" },
  ], { purchase_budget_max: 50000 }, "free", []);
  assert.equal(withContext.checks.price_verification_gaps.length, 1);
  assert.ok(withContext.checks.price_verification_gaps[0].includes("independent market-verification"));
  const flagged = runProgrammaticChecks([
    { ...boat, price_range_context: "2019–2023 model years, US used market broad estimate", verification_required: ["Verify model price range and market context"] },
  ], { purchase_budget_max: 50000 }, "free", []);
  assert.equal(flagged.checks.price_verification_gaps.length, 0);
});

test("unqualified model-level fuel or speed claims are flagged for review", () => {
  const boat = {
    title: "QA Boat", make: "QA", model: "Boat", specs: "Overall length 28 ft",
    why_suggested: "This model cruises at 32 mph and burns 12 gph.",
    verification_required: [],
  };
  const result = runProgrammaticChecks([boat], {}, "free", []);
  assert.equal(result.checks.performance_claim_review.length, 1);
  assert.notEqual(result.concern_level, "green");
  assert.ok(result.flag_reasons.some(x => /performance claim/i.test(x)));
});

test("configuration-specific sourced test figures do not trigger performance review", () => {
  const boat = {
    title: "QA Boat", make: "QA", model: "Boat", specs: "Overall length 28 ft",
    why_suggested: "Manufacturer published test data with twin 200 hp engines recorded 32 mph.",
    verification_required: [],
  };
  const result = runProgrammaticChecks([boat], {}, "free", []);
  assert.equal(result.checks.performance_claim_review.length, 0);
});

test("optional equipment presented as standard triggers model-vs-listing review", () => {
  const boat = {
    title: "QA Boat", make: "QA", model: "Boat", specs: "Overall length 28 ft",
    why_suggested: "This model comes with a joystick and includes radar.",
    verification_required: [],
  };
  const result = runProgrammaticChecks([boat], {}, "free", []);
  assert.equal(result.checks.optional_equipment_review.length, 1);
  assert.ok(result.flag_reasons.some(x => /optional-equipment/i.test(x)));
});

test("factory-standard phrasing of optional accessories still requires verification", () => {
  for (const statement of [
    "Comes standard with a bow thruster.",
    "Factory-installed Seakeeper for every model.",
    "Fitted with windlass for easy anchoring.",
    "Features integrated joystick controls.",
  ]) {
    const boat = { title: "QA Boat", make: "QA", model: "Boat", specs: "Overall length 28 ft",
      why_suggested: statement, verification_required: [] };
    const result = runProgrammaticChecks([boat], {}, "free", []);
    assert.equal(result.checks.optional_equipment_review.length, 1, statement);
  }
});

test("optional equipment explicitly qualified is not treated as inherent", () => {
  const boat = {
    title: "QA Boat", make: "QA", model: "Boat", specs: "Overall length 28 ft",
    why_suggested: "Includes a joystick if equipped; verify the actual boat. Bow thruster is an optional package.",
    verification_required: ["Verify joystick on listing"],
  };
  const result = runProgrammaticChecks([boat], {}, "free", []);
  assert.equal(result.checks.optional_equipment_review.length, 0);
});

test("model-level structural layout is not mistaken for an accessory", () => {
  const boat = {
    title: "QA Boat", make: "QA", model: "Boat", specs: "Overall length 28 ft",
    why_suggested: "Has a pilothouse and sleeps two in the enclosed berth.",
    verification_required: [],
  };
  assert.equal(runProgrammaticChecks([boat], {}, "free", []).checks.optional_equipment_review.length, 0);
});

test("general capability language is not mistaken for a numeric performance promise", () => {
  const boat = {
    title: "QA Boat", make: "QA", model: "Boat", specs: "Overall length 28 ft",
    why_suggested: "Moderate cruising capability; verify engine options before purchase.",
    verification_required: [],
  };
  const result = runProgrammaticChecks([boat], {}, "free", []);
  assert.equal(result.checks.performance_claim_review.length, 0);
});

test("production MATCH persists the screened published passenger limit", () => {
  const entry = readFileSync(new URL("../base44/shared/suggest-boats-handler.ts", import.meta.url), "utf8");
  assert.match(entry, /passenger_capacity:\s*s\.passenger_capacity/);
});

test("occasional overnight preference does not create a hard berth requirement", () => {
  assert.equal(hard("Overall length 28 ft", { overnight_requirements: "Occasional overnight preference" }).length, 0);
  // Overnight requirements unlock only in Market Match. Earlier tiers must not fail
  // based on a requirement they have not collected from this buyer.
  const free = check("Overall length 28 ft", { overnight_requirements: "Need to sleep 4" }, [], "Open center console");
  assert.equal(free.overnight_violations.length, 0);
  const c = check("Overall length 28 ft", { overnight_requirements: "Need to sleep 4" }, [], "Open center console", "market_match");
  assert.ok(c.overnight_violations.length > 0);
  assert.ok(c.hard_constraint_violations.some(x => x.includes("Overnight")));
});
