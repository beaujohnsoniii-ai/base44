import test from "node:test";
import assert from "node:assert/strict";
import {registerHooks} from "node:module";
import {saveBuyerProfile} from "../base44/shared/save-buyer-profile.mjs";
import {profileInputFingerprint} from "../base44/shared/profile-input-fingerprint.mjs";
import {currentMatchResults} from "../src/lib/currentMatchResults.js";
const key=Symbol.for("fresh.context.test");
const stubs={
 "advisor-reasoning.ts":"export const loadManufacturerMap=async()=>({brief:'',list:[]});",
 "credits.ts":"export const issueAdvisorCredit=async()=>{};",
 "question-tiers.ts":"export const loadQuestionTiers=async()=>({});",
 "suggest-engine.ts":'export const generateRecommendations=async(c,args)=>globalThis[Symbol.for("fresh.context.test")].engine(args);',
 "catalog-loader.ts":"export const loadPublishedMatchCatalog=async()=>({records:[]});",
 "dataset-candidates.mjs":"export const loadDatasetCandidates=async()=>[];",
 "hybrid-generation.ts":"export const makeHybridResolver=()=>undefined;"
};
const hook=registerHooks({resolve(s,c,next){
 const source=s.startsWith("npm:@base44/sdk")?'export const createClientFromRequest=()=>globalThis[Symbol.for("fresh.context.test")].client;':(c.parentURL?.includes("/suggest-boats/") || c.parentURL?.endsWith("/suggest-boats-handler.ts"))?stubs[s.split("/").at(-1)]:null;
 if(source)return {url:"data:text/javascript,"+encodeURIComponent(source),shortCircuit:true};return next(s,c);
}});
const {default:generate}=await import("../base44/functions/suggest-boats/entry.ts");
hook.deregister();
function fixture(){
 const profile={id:"p",created_by_id:"buyer",experience_level:"beginner",activities:["Fishing"],purchase_budget_max:40000,hard_max_overall_length_ft:22,liked_models:[{title:"Old favorite"}],research_notes:"Keep notes"};
 let rows=[],counter=0,calls=[],onEngine=null,onCreate=null;
 const user={id:"buyer",role:"admin",plan:"match_plus",paid_pool_generated:true};
 const entities={
 BuyerProfile:{filter:async()=>[structuredClone(profile)],update:async(id,patch)=>{Object.assign(profile,patch);return structuredClone(profile);}},
 SuggestedBoat:{
 filter:async query=>structuredClone(rows.filter(r=>query.superseded?r.superseded!==true:true)),
 create:async data=>{const row={...data,id:"row-"+(++counter),created_by_id:"buyer",created_date:new Date().toISOString()};rows.push(row);if(onCreate)await onCreate(row);return structuredClone(row);},
 update:async(id,patch)=>Object.assign(rows.find(r=>r.id===id),patch),
 delete:async id=>{rows=rows.filter(r=>r.id!==id);}
 },
 SavedBoat:{filter:async()=>{throw Error("Saved account candidates must not be read as preferences");}}
 };
 const client={auth:{me:async()=>user},entities,asServiceRole:{entities}};
 const h={profile,user,client,rows:()=>rows,calls,seed:row=>rows.push(row),setEngine:fn=>onEngine=fn,setCreate:fn=>onCreate=fn,
 engine:async args=>{calls.push(structuredClone({...args,resolveHybrid:undefined}));if(onEngine)await onEngine(args);return {suggestions:[{make:"Synthetic",model:profile.activities[0],title:profile.activities[0],rank:1}],newContradictionRerunCount:0};},
 save:patch=>saveBuyerProfile(client,user,patch),
 run:async(refresh=true)=>{globalThis[key]=h;const res=await generate(new Request("https://test.invalid",{method:"POST",body:JSON.stringify({refresh})}));return {status:res.status,data:await res.json()};}
 };return h;
}
test("one account, sharply different sequential profiles have fresh inputs and retained history",async()=>{
 const h=fixture();const first=await h.run();assert.equal(first.status,200);
 const fpA=first.data.profile_input_fingerprint;
 h.profile.liked_models.push({title:"A preference",profile_input_fingerprint:fpA});
 await h.save({activities:["Overnight cruising"],purchase_budget_max:800000,hard_max_overall_length_ft:null});
 const contextB=h.profile.match_context_id;
 const second=await h.run(false);assert.equal(second.status,200);
 assert.notEqual(second.data.profile_input_fingerprint,fpA);
 assert.deepEqual(h.calls[1].likedModels,[]);assert.deepEqual(h.calls[1].savedBoats,[]);assert.deepEqual(h.calls[1].existingSuggestions,[]);
 assert.equal(h.calls[1].profile.hard_max_overall_length_ft,null);
 assert.equal(h.profile.liked_models.length,2);assert.equal(h.profile.research_notes,"Keep notes");
 assert.equal(h.rows().find(r=>r.id===first.data.suggestions[0].id).superseded,true);
 assert.equal(second.data.suggestions[0].profile_input_fingerprint,second.data.profile_input_fingerprint);
 assert.ok(second.data.suggestions[0].generation_id);
 const repeated=await h.run(false);assert.equal(repeated.status,200);assert.equal(h.calls.length,2);
 await h.save({activities:["Overnight cruising"],purchase_budget_max:800000});assert.equal(h.profile.match_context_id,contextB);
 await h.save({activities:["Fishing"],purchase_budget_max:40000});assert.notEqual(h.profile.match_context_id,contextB);
 await h.run();assert.deepEqual(h.calls[2].likedModels,[],"A-B-A cannot revive old preferences");
});
test("profile edits during engine work retain previous rows and reject obsolete output",async()=>{
 const h=fixture();await h.run();const ids=h.rows().map(r=>r.id);
 h.setEngine(()=>h.save({activities:["Liveaboard"]}));
 const res=await h.run();assert.equal(res.status,409);assert.deepEqual(h.rows().map(r=>r.id),ids);assert.ok(h.rows().every(r=>!r.superseded));
});
test("profile edits during persistence roll back only the obsolete request rows",async()=>{
 const h=fixture();await h.run();const ids=h.rows().map(r=>r.id);
 h.setCreate(()=>h.save({activities:["Diving"]}));
 const res=await h.run();assert.equal(res.status,409);assert.deepEqual(h.rows().map(r=>r.id),ids);assert.ok(h.rows().every(r=>!r.superseded));
});
test("overlapping generations do not both replace a pool",async()=>{
 const h=fixture();await h.run();
 let release,entered;const gate=new Promise(r=>release=r),arrived=new Promise(r=>entered=r);let count=0;
 h.setEngine(async()=>{if(++count===1){entered();await gate;}});
 const older=h.run();await arrived;const newer=await h.run();release();const stale=await older;
 assert.equal(newer.status,200);assert.equal(stale.status,409);
 assert.equal(h.rows().filter(r=>!r.superseded).length,1);
});
test("navigation marks fingerprint mismatch stale even if timestamps match; bookkeeping does not stale current results",async()=>{
 const h=fixture();const result=await h.run();const fp=result.data.profile_input_fingerprint;
 assert.equal(currentMatchResults(h.rows(),h.profile,"buyer",fp).status,"linked");
 h.profile.research_notes="new note";assert.equal(await profileInputFingerprint(h.profile),fp);
 await h.save({purchase_budget_max:900000});
 assert.equal(currentMatchResults(h.rows(),h.profile,"buyer",await profileInputFingerprint(h.profile)).status,"saved_before_profile_update");
});
test("exhausted allowance cannot silently serve stale results as a fresh load",async()=>{
 const h=fixture();await h.run();await h.save({activities:["Liveaboard"]});h.user.role="user";h.user.updates_limit=0;
 assert.equal((await h.run(false)).status,403);assert.equal(h.calls.length,1);assert.ok(h.rows().length);
});
