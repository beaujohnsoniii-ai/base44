# SoundHeading Compare — 2026-10-20 diagnostic handoff

## Scope / constraints
Compare listing import only. Model/manufacturer research stays paused. Do not change dataset, workbook, release approval, activation, research jobs, or paid worker settings. Do not deploy or publish without separate authorization. No paid retrieval calls made in this diagnostic session.

## Evidence from user screenshots (Oct 19, ~10:08 PM ET)
- Saved Match model label "Blackjack 224 2026", listing URL `https://www.boattrader.com/boat/2012-blackjack-224-10159597/`. The exact-URL indexed excerpt is headed "Used 2012 BlackJack 224, 70118 New Orleans" and contains "2012 BlackJack 224 ... 290 hours ... Suzuki engine". Before the fix, the field Year was "Not verified" and the card showed a green "evaluated" badge based only on make and model.
- "Shoalwater 21 Catamaran 2026" has BoatTrader URL `https://www.boattrader.com/boat/2024-shoalwater-21-catamaran-10364889/`; HTTP 403 fetch_failed.
- "Dorado Custom Boats 23 Pro Guide 2026" has BoatTrader URL `https://www.boattrader.com/boat/2018-dorado-23-se-10187560/`; HTTP 403 fetch_failed. Model name also appears different from the saved Match candidate and requires buyer confirmation, not inferred equivalence.
- Two HTTP 403 results demonstrate blocked server fetching, not browser feasibility, listing completeness, or successful import.
- These are user-supplied screenshots, not a newly deployed endpoint test.

## Changes made in Base44 main sandbox
1. `base44/shared/indexed-listing-fallback.mjs`: require a unique four-digit year in the same indexed result title as the expected make/model. Quote the title as evidence; do not infer model year from bare URL or a year mentioned elsewhere.
2. `base44/shared/listing-comparison.mjs`: rename data status to `partial_evidence`, carry saved model year separately as `expected_year`, and emit a generation/model-year conflict concern where independently quoted listing year differs. Never borrow saved model specifications or promote eligible finalists.
3. `src/components/CompareImportResults.jsx`: distinguish saved Match model from individual listing year, surface evidence-vs-URL mismatch warnings (URL labels are unverified hints), replace misleading green "evaluated" with "Partial evidence — not verified" (including legacy response status), and avoid adding USD $ symbol to amounts in other currencies.
4. `src/pages/JourneyWorkspace.jsx`: replace promise of automatic successful listing retrieval with accurate attempts/blocked-source wording.
5. Added regression tests for BlackJack 2012, conflicting years, partial status. Updated 3 outdated assertions that expected the former disabled Compare resolver or old UI copy.

## Verification (no network scraping)
- `npm run test:match`: 506 tests, 506 pass, 0 fail.
- `npm run build`: exit 0.
- No actual production Compare request was executed in this session; no new paid Tavily / Firecrawl / Apify credits used.
- Earlier user-authorized Firecrawl attempt on Blackfin BoatTrader URL failed with WAF HTTP 403 (creditsUsed=1), as previously documented. Do not repeat.

## Remaining blocker and decision points
1. Verify Base44 deployment status separately. Code edits/checkpoint are not proof that the live mobile Compare UI has updated.
2. Run one authenticated, explicit Compare click using exact saved URLs to confirm the deployed resolver and Tavily fallback; only with user awareness of possible bounded paid Tavily usage. Do not infer success from unit tests.
3. Until retrieval succeeds for representative URLs, classify URL import as PARTIAL: BlackJack indexed excerpt is limited and may be stale; two other pages still HTTP 403.
4. Evaluate user-invoked paste/upload or authorized browser extension/capture, or directly authorized dealer listing sources, for better data completeness. A normal open browser tab does not expose its cross-origin DOM to Base44.
5. Measure data completeness, costs, latency, and reliability for 1 / 3 / 9 distinct user-provided listing URLs. Do not generalize dollar cost from plan prices or run unbounded crawling.
6. Keep listing evidence tied to exact URL, source, timestamp, unit/currency and quote; no web-search substitute from a similar boat.

## Research freeze
Still in effect; untouched.
