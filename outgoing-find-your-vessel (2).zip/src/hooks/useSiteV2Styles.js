import { useEffect, useState } from "react";

// Site v2 ships as a complete document stylesheet — it styles html, body and the fixed
// white header bar. It is therefore loaded only while this page is mounted and removed on
// unmount, so every other page in the app keeps the styling it has today.
const HREFS = ["/site-v2/assets/css/fonts.css", "/site-v2/assets/css/site.css"];

export default function useSiteV2Styles() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const links = HREFS.map((href) => {
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = href;
      document.head.appendChild(link);
      return link;
    });
    const last = links[links.length - 1];
    const done = () => setReady(true);
    if (last.sheet) done(); else last.addEventListener("load", done);
    return () => {
      last.removeEventListener("load", done);
      links.forEach((link) => link.remove());
    };
  }, []);
  return ready;
}