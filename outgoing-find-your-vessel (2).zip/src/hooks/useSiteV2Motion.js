import { useEffect } from "react";

// Port of the design's site.js motion: the white bar solidifies and hides on scroll down,
// sections reveal as they enter, and the parallax images, the premise rose, and the compass
// dial with its live heading track the scroll position. Reduced-motion visitors and ?static
// keep everything still.
export default function useSiteV2Motion(rootRef, active = true) {
  useEffect(() => {
    const root = rootRef.current;
    if (!active || !root) return;
    const still = matchMedia("(prefers-reduced-motion: reduce)").matches || new URLSearchParams(location.search).has("static");
    const hdr = root.querySelector("#hdr");
    const heroMedia = root.querySelector("#hero-image");
    const parallax = [...root.querySelectorAll("[data-parallax]")];
    const needle = root.querySelector("#needle");
    const headingValue = root.querySelector("#hdgval");
    const rose = root.querySelector("#rose");
    let lastY = scrollY;
    let ticking = false;

    const onHeader = () => {
      if (!hdr) return;
      const y = scrollY;
      hdr.classList.toggle("is-solid", y > 40);
      hdr.classList.toggle("is-hidden", !root.classList.contains("menu-open") && y > 640 && y > lastY + 2);
      if (y < lastY - 2 || y < 640) hdr.classList.remove("is-hidden");
      lastY = y;
    };

    const frame = () => {
      ticking = false;
      const y = scrollY;
      const vh = innerHeight;
      onHeader();
      if (still) return;
      if (heroMedia && y < vh * 1.2) heroMedia.style.transform = `translate3d(0,${y * 0.28}px,0)`;
      for (const el of parallax) {
        const box = el.parentElement.getBoundingClientRect();
        if (box.bottom < -100 || box.top > vh + 100) continue;
        const k = parseFloat(el.dataset.parallax) || 0.1;
        const off = ((box.top + box.height / 2) - vh / 2) * -k;
        const lim = Math.max(0, (el.offsetHeight - el.parentElement.offsetHeight) / 2);
        el.style.transform = `translate3d(0,${Math.max(-lim, Math.min(lim, off)).toFixed(1)}px,0)`;
      }
      const max = document.documentElement.scrollHeight - vh;
      const deg = Math.round((y / Math.max(1, max)) * 360) % 360;
      if (needle) needle.style.transform = `rotate(${deg}deg)`;
      if (headingValue) headingValue.textContent = `${String(deg).padStart(3, "0")}°`;
      if (rose) rose.style.transform = `rotate(${(y * 0.03).toFixed(2)}deg)`;
    };

    const onScroll = () => {
      if (!ticking) { ticking = true; requestAnimationFrame(frame); }
    };

    const io = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add("in"); io.unobserve(entry.target); }
    }), { rootMargin: "0px 0px -10% 0px", threshold: 0.08 });
    root.querySelectorAll("[data-reveal]").forEach((el) => io.observe(el));

    addEventListener("scroll", onScroll, { passive: true });
    addEventListener("resize", frame);
    frame();
    return () => {
      io.disconnect();
      removeEventListener("scroll", onScroll);
      removeEventListener("resize", frame);
    };
  }, [rootRef, active]);
}