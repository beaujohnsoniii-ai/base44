import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
const money = n => n === null || n === undefined ? "Unknown" : new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:0}).format(n);
const words = s => String(s || "").replaceAll("_"," ");
export default function AdminPrivateMatchTrial() {
  const { user, isLoadingAuth } = useAuth();
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  if (isLoadingAuth) return <main className="p-8">Checking access…</main>;
  if (user?.role !== "admin") return <main className="p-8">Admin access required.</main>;
  async function run() {
    setLoading(true); setError("");
    try {
      const response = await base44.functions.invoke("private-match-trial",{});
      setResult(response.data);
    } catch(e) { setError(e?.response?.data?.error || e.message || "Trial did not complete."); }
    finally { setLoading(false); }
  }
  return <main className="max-w-5xl mx-auto p-5 md:p-10 space-y-6">
    <Link to="/admin/research-monitor" className="text-blue-700 underline">Research monitor</Link>
    <header><p className="text-sm font-semibold text-amber-800">PRIVATE • RECORDED-EVIDENCE DIAGNOSTIC</p>
      <h1 className="text-3xl font-bold mt-2">26 ft MATCH trial</h1>
      <p className="mt-3">Four source-rechecked model candidates from the evaluated 12-record sample. None is a complete boat file. This checks physical evidence and current advertised asking prices; it does not produce a full suitability recommendation.</p>
    </header>
    <section className="rounded-xl border bg-slate-50 p-5 space-y-2">
      <p>Uses your selected October 13 buyer profile unchanged: 18–24 ft preference, 26 ft hard overall maximum.</p>
      <p>Recorded October 15, 2026 evidence. National US asking-price sample; taxes, fees, delivery and transport are excluded. Availability is advertised, not seller-confirmed.</p>
      <p>Read-only trial: no paid AI calls, no customer-data writes and no changes to your normal MATCH results.</p>
      <button onClick={run} disabled={loading} className="rounded-lg bg-slate-900 text-white px-5 py-3 disabled:opacity-50">{loading ? "Checking recorded evidence…" : "Run private evidence trial"}</button>
      {error && <p role="alert" className="text-red-700">{error}</p>}
    </section>
    {result && <>
      <section className="border rounded-xl p-5 space-y-2">
        <h2 className="text-xl font-semibold">Trial result</h2>
        <p>{result.summary.boats} candidates · {result.summary.physical_exclusions} verified physical exclusions · {result.summary.provisional_market} provisional market assessments</p>
        <p>Budget {money(result.profile.purchase_budget_min)}–{money(result.profile.purchase_budget_max)}. {result.ranking_basis}</p>
        <p className="text-amber-800">An in-limit model measurement does not certify the actual boat, engine configuration, offshore safety, passenger comfort, or all must-haves. Unknown prices never become an automatic rejection.</p>
        <details><summary className="cursor-pointer font-medium">Buyer requirements used</summary><pre className="text-xs whitespace-pre-wrap mt-3">{JSON.stringify(result.profile,null,2)}</pre></details>
      </section>
      {result.results.map(boat => <article key={boat.id} className="border rounded-xl p-5 space-y-4">
        <header><p className="text-sm text-slate-500">Review position {boat.review_order} · model year {boat.year}</p>
          <h2 className="text-2xl font-semibold">{boat.make} {boat.model}</h2>
          <p className="font-medium text-amber-800">Provisional candidate; incomplete file</p></header>
        <section><h3 className="font-semibold">Physical evidence: {words(boat.physical.status)}</h3>
          {boat.physical.checks.map(check=><p key={check.field} className="mt-2">{words(check.field)}: {check.evidence?.value ?? "Unknown"} {check.unit}, maximum {check.limit} {check.unit}. {words(check.state)}. {check.reason}</p>)}
          {boat.physical.notes.map((note,i)=><p key={i} className="text-sm mt-2 text-slate-600">{note}</p>)}
        </section>
        <section><h3 className="font-semibold">Current advertised asking prices</h3>
          <p className="text-lg">{boat.market.comparable_count === 1 ? money(boat.market.low)+" — single observation, not an established range" : boat.market.low === null ? "No verified priced comparable" : money(boat.market.low)+"–"+money(boat.market.high)}</p>
          <p>{boat.market.comparable_count} matched independent listings · {words(boat.market.budget_state)} · {boat.market.provisional ? "Provisional" : "Bounded sample"}</p>
          <p className="text-sm">Low endpoint vs budget maximum: {money(boat.market.low_relative_to_budget_max)}. High endpoint vs budget maximum: {money(boat.market.high_relative_to_budget_max)}.</p>
          {boat.market.notes.map((note,i)=><p key={i} className="text-sm mt-2 text-slate-600">{note}</p>)}
          <details className="mt-3"><summary className="cursor-pointer font-medium">Comparable listing evidence, including exclusions</summary>
            {boat.market.comparables.map((comp,i)=><div key={i} className="mt-3 border-t pt-3 text-sm">
              <a href={comp.source_url} target="_blank" rel="noreferrer" className="text-blue-700 underline">{comp.seller || "Listing source"} · {comp.location}</a>
              <p>{money(comp.asking_price)} {comp.currency} · {comp.year} · {comp.engine} · {comp.condition}</p>
              <p>{comp.configuration}</p><p>{comp.included_in_range ? "Included in observed endpoints" : "Excluded: "+comp.exclusion_reason}</p>
              <p>{comp.match_notes}</p><p>Checked {comp.retrieved_at} · dedup key {comp.dedup_key}</p>
            </div>)}
          </details>
        </section>
        <details><summary className="cursor-pointer font-medium">Field-level sources and remaining gaps</summary>
          {Object.entries(boat.field_evidence || {}).map(([field,e])=><div key={field} className="mt-3 text-sm border-t pt-3">
            <p className="font-semibold">{words(field)}: {e.value === null ? "Unknown" : String(e.value)} {e.unit || ""} · {e.status} · {e.applicability}</p>
            <p>Basis: {words(e.measurement_basis)} · {e.configuration}</p>
            {e.source_url && <a className="text-blue-700 underline" href={e.source_url} target="_blank" rel="noreferrer">Source</a>}
            <p>{e.source_quote || e.source_excerpt || "No independently checked excerpt."}</p><p>Checked {e.verified_at || "not established"}</p>
          </div>)}
        </details>
        <ul className="list-disc pl-5 text-sm">{boat.manual_review.map((note,i)=><li key={i}>{note}</li>)}</ul>
      </article>)}
    </>}
  </main>;
}
