import React, { useCallback, useEffect, useMemo, useState } from "react";
import { base44Test, refreshTestToken } from "@/lib/base44TestClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, BarChart3, AlertCircle, FlaskConical } from "lucide-react";
import FunnelTierBar from "@/components/admin/FunnelTierBar";
import FunnelDeviationList from "@/components/admin/FunnelDeviationList";
import { funnelDistribution } from "@/lib/funnelDistribution";

// Admin view of the funnel as it really ran in the Test database: how many model
// results each tier generated and how many it marked, read from the stored MATCH QA
// tier results. Nothing is displayed that a run did not record.
export default function AdminFunnelDistribution() {
  const [runs, setRuns] = useState([]);
  const [runId, setRunId] = useState(null);
  const [tierResults, setTierResults] = useState([]);
  const [loadingRuns, setLoadingRuns] = useState(true);
  const [loadingResults, setLoadingResults] = useState(false);
  const [error, setError] = useState(null);

  const loadRuns = useCallback(async () => {
    setError(null);
    try {
      refreshTestToken();
      const allRuns = await base44Test.entities.QATestRun.list("-created_date", 20);
      setRuns(allRuns || []);
      setRunId((current) => current || (allRuns || [])[0]?.id || null);
    } catch (e) {
      console.error("Funnel distribution: run load failed", e);
      setError(e?.message || "Could not load QA runs from the Test database.");
    } finally {
      setLoadingRuns(false);
    }
  }, []);

  useEffect(() => { loadRuns(); }, [loadRuns]);

  useEffect(() => {
    if (!runId) return;
    let active = true;
    setLoadingResults(true);
    setError(null);
    refreshTestToken();
    base44Test.entities.QATierResult.filter({ run_id: runId }, "rank", 500)
      .then((rows) => { if (active) setTierResults(rows || []); })
      .catch((e) => {
        console.error("Funnel distribution: tier result load failed", e);
        if (active) setError(e?.message || "Could not load tier results for this run.");
      })
      .finally(() => { if (active) setLoadingResults(false); });
    return () => { active = false; };
  }, [runId]);

  const distribution = useMemo(() => funnelDistribution(tierResults), [tierResults]);
  const selectedRun = runs.find((run) => run.id === runId) || null;
  const scaleMax = Math.max(...distribution.tiers.map((tier) => tier.generated.max), 1);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-semibold flex items-center gap-2">
              <BarChart3 className="w-6 h-6" /> Funnel distribution
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              How many model results each tier generates and how many it marks, measured from MATCH QA runs in the Test database.
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0 text-sm">
            <a href="/admin/match-qa" className="text-muted-foreground hover:text-foreground flex items-center gap-1.5">
              <FlaskConical className="w-4 h-4" /> MATCH QA
            </a>
            <a href="/admin/test-profiles" className="text-muted-foreground hover:text-foreground">Test Profiles</a>
          </div>
        </div>

        {error && (
          <Card className="border-destructive/50">
            <CardContent className="p-4">
              <p className="text-sm text-destructive flex items-center gap-2">
                <AlertCircle className="w-4 h-4" /> {error}
              </p>
            </CardContent>
          </Card>
        )}

        {loadingRuns ? (
          <div className="grid place-items-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : runs.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              No MATCH QA runs exist in the Test database yet. Run a QA batch from{" "}
              <a href="/admin/match-qa" className="text-accent underline">MATCH QA</a> and its funnel distribution will appear here.
            </CardContent>
          </Card>
        ) : (
          <>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Run</CardTitle>
                <CardDescription>The funnel starts at 4 broad directions, widens to the full pool for Bosun, then keeps that pool and sharpens which models it marks.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex flex-wrap items-center gap-3">
                  <Select value={runId || ""} onValueChange={setRunId}>
                    <SelectTrigger className="w-full sm:w-96">
                      <SelectValue placeholder="Select a QA run" />
                    </SelectTrigger>
                    <SelectContent>
                      {runs.map((run) => (
                        <SelectItem key={run.id} value={run.id}>
                          {new Date(run.created_date).toLocaleString()} · {run.run_type} · {run.profile_count || 0} profiles · {run.status}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {loadingResults && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
                </div>
                {selectedRun && (
                  <div className="flex flex-wrap items-center gap-2 text-sm">
                    <Badge variant={selectedRun.status === "complete" ? "secondary" : selectedRun.status === "failed" ? "destructive" : "default"}>
                      {selectedRun.status}
                    </Badge>
                    <span className="text-muted-foreground tabular-nums">
                      {selectedRun.profile_count || 0} profiles · {selectedRun.tier_results_count || 0} tier cases ·{" "}
                      {new Date(selectedRun.created_date).toLocaleString()}
                    </span>
                    {selectedRun.status !== "complete" && (
                      <span className="text-amber-700 text-xs">
                        This run is not marked complete. Counts below are what it recorded, not a finished pass.
                      </span>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Tier cases analysed</p>
                  <span className="text-2xl font-semibold tabular-nums">{distribution.totals.cases}</span>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Results generated</p>
                  <span className="text-2xl font-semibold tabular-nums">{distribution.totals.generated}</span>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Results marked</p>
                  <span className="text-2xl font-semibold tabular-nums">{distribution.totals.marks}</span>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Cases off shape</p>
                  <span className="text-2xl font-semibold tabular-nums">{distribution.totals.offPolicy}</span>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Results generated and marked, per tier</CardTitle>
                <CardDescription>
                  Bar length is the typical pool for the tier; the teak segment is the share that carries the tier's recommendation mark.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {distribution.tiers.map((tier) => (
                  <FunnelTierBar key={tier.tier} tier={tier} scaleMax={scaleMax} />
                ))}
              </CardContent>
            </Card>

            <FunnelDeviationList deviations={distribution.deviations} />

            <p className="text-xs text-muted-foreground">
              Figures are read from this run's stored tier results in the Test database. A tier with no cases shows its intended shape only,
              and no count is filled in for a case that did not record one.
            </p>
          </>
        )}
      </div>
    </div>
  );
}