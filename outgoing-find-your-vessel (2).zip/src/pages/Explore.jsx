import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import { Image } from "@/components/ui/image";
import HomeBody from "@/components/HomeBody";

const HERO_IMG = "https://media.base44.com/images/public/6abbd00d2cbdcfbf9bef007e/f48819767_generated_image.png";

export default function Explore() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-parchment font-serif text-foreground">
      <Navbar variant="overlay" />

      {/* Hero */}
      <section className="relative overflow-hidden bg-primary text-primary-foreground">
        <Image
          src={HERO_IMG}
          alt=""
          fittingType="fill"
          focalPointX={0.5}
          focalPointY={0.45}
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-primary/85 via-primary/55 to-primary/95" />
        <div className="absolute inset-0 bg-black/15" />

        <div className="relative max-w-3xl mx-auto px-4 pt-24 pb-28 text-center">
          <p className="text-[11px] uppercase tracking-[0.35em] text-brass font-medium">
            Independent Vessel Acquisition Advisory
          </p>

          <h1 className="font-display italic text-4xl md:text-6xl font-semibold mt-6 leading-[1.08] tracking-tight">
            Set Course to your Next Boat,
            <br />
            Tailored to your Lifestyle.
          </h1>

          <div className="mx-auto mt-7 h-px w-16 bg-brass/70" />

          <p className="mt-6 text-lg md:text-xl text-white/85 leading-relaxed font-light max-w-xl mx-auto">
            We help you buy the right boat for your lifestyle. Independent advice, no
            commissions, no bias — just a heading you can trust.
          </p>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <Button size="lg" variant="secondary" onClick={() => navigate("/register?returnTo=/tools")}>
              Get started <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <Button size="lg" variant="outline" className="border-white/50 bg-white/5 text-white hover:bg-white/15" onClick={() => navigate("/tools")}>
              Explore the tools
            </Button>
          </div>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-2 text-[11px] uppercase tracking-[0.25em] text-white/55">
            <span>Free profile</span>
            <span className="text-brass">·</span>
            <span>Save candidates</span>
            <span className="text-brass">·</span>
            <span>Sample report</span>
          </div>
        </div>
      </section>

      <HomeBody />
    </div>
  );
}