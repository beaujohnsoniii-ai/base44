import React, { useReducer, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import IntroQuestionnaire from "@/components/IntroQuestionnaire";
import SuggestedBoatsPanel from "@/components/SuggestedBoatsPanel";
import PlanTierCard from "@/components/PlanTierCard";
import { Button } from "@/components/ui/button";
import { PLAN_TIERS } from "@/lib/stages";
import { freshJourney, journeyReducer } from "@/lib/journey-trial.mjs";
import { journeyDemoResults } from "@/lib/journey-demo.mjs";
import JourneyDemoReport from "@/components/JourneyDemoReport";
// Simulated funnel shape, mirrored from the shared tier policy: the pool stays
// wide and only the recommendation marks change between paid tiers.
const counts={free:"4 starting suggestions in this requested simulation",match_plus:"10–14 models to look around with, none marked",refined_match:"the same 10–14 models re-ranked, leading 5–7 marked",market_match:"the same 10–14 models re-ranked, top 3 marked"};
export default function AdminJourneyTrial(){
 const {user,isLoadingAuth}=useAuth();
 const [state,dispatch]=useReducer(journeyReducer,undefined,freshJourney);
 const [epoch,setEpoch]=useState(0);
 const [notice,setNotice]=useState("");
 if(isLoadingAuth)return <main className="p-8">Checking access…</main>;
 if(user?.role!=="admin")return <main className="p-8">Admin access required.</main>;
 const tier=PLAN_TIERS.find(t=>t.id===state.plan);
 const results=journeyDemoResults(state);
 function reset(){dispatch({type:"reset"});setEpoch(n=>n+1);setNotice("");}
 function purchase(product){dispatch({type:"purchase",product});setNotice("");}
 function add(boat){dispatch({type:"add",boat:{...boat,title:boat.title||boat.description},key:Date.now()+"-"+Math.random().toString(36).slice(2)});return true;}
 return <div className="min-h-screen bg-muted/30">
  <div className="sticky top-0 z-40 border-b border-amber-300 bg-amber-50 px-5 py-3 flex gap-4 justify-between items-center flex-wrap">
   <div><strong>Private journey simulation</strong><p className="text-xs">Temporary memory only · no payment · no real paid access · no saved profile or results</p></div>
   <Button variant="outline" onClick={reset}>Reset to a fresh buyer</Button>
  </div>
  <main className="max-w-6xl mx-auto px-4 py-8 space-y-6">
   <Link to="/admin/research-monitor" className="text-blue-700 underline">Back to Research Monitor</Link>
   <header><h1 className="text-3xl font-heading">Walk through MATCH as a new buyer</h1>
    <p className="mt-2 text-muted-foreground">Uses the real questionnaire, model cards and package cards with simulated transitions. Your normal account and existing Match stay untouched. Closing or reloading this page clears this trial.</p>
    <p className="mt-2 text-sm">Current simulated tier: <strong>{tier?.name || "Deckhand"}</strong>. Configured result allowance: {counts[state.plan]}. Full UI demo: Deckhand 4 → Bosun 10 → First Mate 5 → Captain 3 fictional models. These are deliberately invented examples, not real recommendations.</p>
   </header>
   {state.purchase && <section role="dialog" aria-label="Confirm simulated package" className="border-2 border-amber-400 bg-white rounded-xl p-6 space-y-3">
    <h2 className="text-xl font-semibold">Simulate {PLAN_TIERS.find(t=>t.id===state.purchase.plan)?.name}</h2>
    <p>Displayed upgrade amount: USD {state.purchase.amount}; package total USD {state.purchase.total}. Actual charge: $0. No payment processor opens and no real entitlement changes.</p>
    <Button onClick={()=>{dispatch({type:"confirm_purchase"});setEpoch(n=>n+1);}}>Continue simulated purchase</Button>
    <Button variant="ghost" onClick={()=>dispatch({type:"cancel_purchase"})}>Cancel</Button>
   </section>}
   {state.phase==="questionnaire" ? <section className="max-w-2xl mx-auto">
    <h2 className="text-2xl font-heading mb-3">{state.profile ? "Complete the questions for "+tier?.name : "Intro Questionnaire"}</h2>
    <p className="text-sm text-muted-foreground mb-5">Enter test answers. Nothing is saved. Newly unlocked questions follow the same tier rules as the normal app.</p>
    <IntroQuestionnaire key={epoch+"-"+state.plan} initialProfile={state.profile} plan={state.plan} onComplete={profile=>dispatch({type:"answers",profile})} submitLabel="Show my simulated results" />
   </section> : <>
    <div className="flex gap-3 flex-wrap"><Button variant="outline" onClick={()=>{dispatch({type:"edit"});setEpoch(n=>n+1);}}>Edit temporary answers</Button>
     {tier && <Button variant="outline" onClick={()=>dispatch({type:"report"})}>View simulated {tier.name} summary</Button>}
    </div>
    <p className="border border-amber-200 bg-amber-50 p-4 rounded-lg text-sm">FICTIONAL DEMO DATA: invented models, dimensions and price ranges demonstrate each full package. These are not real boats or recommendations. Likes reorder demo models. Refresh uses only a simulated update.</p>
    <SuggestedBoatsPanel disableExternalLinks key={epoch} suggestions={results} plan={state.plan} loading={false} updatesUsed={state.updates} updatesLimit={tier?.updates || 0}
     onToggleLike={(boat,liked)=>dispatch({type:"like",id:boat.fixture_id,liked})}
     onRefresh={()=>dispatch({type:"refresh"})} onPurchase={purchase}
     onAddCandidate={boat=>{add(boat);setNotice("Candidate added to temporary trial memory only.");}}
     boats={state.candidates} onAddBoat={add} onRemoveBoat={id=>dispatch({type:"remove",id})}
     onUpdateBoat={(id,patch)=>dispatch({type:"update",id,patch})} maxBoats={5} minBoats={3}
     onAnalyze={()=>{dispatch({type:"report"});setNotice("Simulated candidate summary only; submitted listing URLs are not fetched.");}}
     note="Fictional full-count simulation. No live generation, checkout, profile writes or saved Likes. Demo prices are invented, not current market observations." />
    {notice && <p role="status" className="rounded-lg bg-blue-50 p-4">{notice}</p>}
    {state.report && <JourneyDemoReport key={epoch+"-"+state.plan} state={state} results={results} />}
    <section><h2 className="font-heading text-2xl mb-4">Choose how far to take your search</h2>
     <div className="grid md:grid-cols-3 gap-4">{PLAN_TIERS.map(t=><PlanTierCard key={t.id} tier={t} plan={state.plan} simulation checkoutAvailable onPurchase={purchase} updatesUsed={state.updates} updatesLimit={tier?.updates||0} onViewReport={()=>dispatch({type:"report"})} />)}</div>
    </section>
   </>}
  </main>
 </div>;
}