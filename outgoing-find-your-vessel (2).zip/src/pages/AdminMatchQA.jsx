import React, { useState, useEffect, useCallback, useMemo } from "react";
import { base44Test, invokeTestFunction, refreshTestToken } from "@/lib/base44TestClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Play, ListChecks, BarChart3, Sparkles, AlertCircle, FlaskConical, Trash2 } from "lucide-react";
import QAReviewCard from "@/components/qa/QAReviewCard";
import QARunResults from "@/components/qa/QARunResults";

const CONCERN_COLORS = {
  green: "bg-green-100 text-green-800 border-green-300",
  yellow: "bg-amber-100 text-amber-800 border-amber-300",
  red: "bg-red-100 text-red-800 border-red-300",
  uncertain: "bg-blue-100 text-blue-800 border-blue-300",
};

export default function AdminMatchQA() {
  const [runs, setRuns] = useState([]);
  const [latestRun, setLatestRun] = useState(null);
  const [flaggedResults, setFlaggedResults] = useState([]);
  const [allTierResults, setAllTierResults] = useState([]);
  const [grades, setGrades] = useState([]);
  const [goldenCount, setGoldenCount] = useState(0);
  const [running, setRunning] = useState(false);
  const [runStep, setRunStep] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("run");

  const loadAll = useCallback(async () => {
    refreshTestToken();
    try {
      const [allRuns, goldens] = await Promise.all([
        base44Test.entities.QATestRun.list("-created_date", 20),
        base44Test.entities.GoldenProfile.list("-created_date", 100),
      ]);
      setRuns(allRuns || []);
      setGoldenCount((goldens || []).length);

      const latest = (allRuns || [])[0];
      setLatestRun(latest || null);

      if (latest) {
        const [flagged, allTiers, allGrades] = await Promise.all([
          base44Test.entities.QATierResult.filter({ run_id: latest.id, is_flagged: true }, "rank", 200),
          base44Test.entities.QATierResult.filter({ run_id: latest.id }, "rank", 500),
          base44Test.entities.TestGrade.filter({ run_id: latest.id, phase: "qa" }, "-created_date", 500),
        ]);
        setFlaggedResults(flagged || []);
        setAllTierResults(allTiers || []);
        setGrades(allGrades || []);
      } else {
        setFlaggedResults([]);
        setAllTierResults([]);
        setGrades([]);
      }
    } catch (e) {
      console.error("Load QA data error", e);
      setError(e?.message || "Failed to load");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const gradesByTierResult = useMemo(() => {
    const map = new Map();
    for (const g of grades) {
      if (g.tier_result_id) map.set(g.tier_result_id, g);
    }
    return map;
  }, [grades]);

  const runQA = async (mode, batchSize, maxProfiles) => {
    setRunning(true);
    setError(null);
    setRunStep("Running MATCH QA...");
    setActiveTab("run");
    try {
      const response = await invokeTestFunction("run-match-qa", { action: "run", mode, batch_size: batchSize, max_profiles: maxProfiles });
      const result = response?.data || response;
      setRunStep("");
      await loadAll();
      if (result?.status === "failed") {
        setError(`QA run incomplete: ${result.failed_profiles || 0} profile execution error(s), ${result.tier_results_count || 0}/${result.expected_tier_results || 0} expected tier results. This run is NOT a pass; inspect the backend logs.`);
        setActiveTab("run");
      } else {
        setActiveTab("review");
      }
    } catch (e) {
      console.error("Run QA error", e);
      setError(e?.message || "Run failed");
    } finally {
      setRunning(false);
      setRunStep("");
    }
  };

  const seedGolden = async () => {
    setRunning(true);
    setRunStep("Seeding golden profiles...");
    try {
      await invokeTestFunction("run-match-qa", { action: "seed-golden" });
      await loadAll();
    } catch (e) {
      console.error("Seed golden error", e);
      setError(e?.message || "Seed failed");
    } finally {
      setRunning(false);
      setRunStep("");
    }
  };

  const cleanup = async () => {
    setRunning(true);
    setRunStep("Cleaning up old test data...");
    try {
      await invokeTestFunction("run-match-qa", { action: "cleanup" });
      await loadAll();
    } catch (e) {
      console.error("Cleanup error", e);
    } finally {
      setRunning(false);
      setRunStep("");
    }
  };

  // Knowledge pattern detection from expert verdicts
  const verdictPatterns = useMemo(() => {
    const byVerdict = new Map();
    for (const g of grades) {
      if (!g.verdict) continue;
      const key = g.verdict;
      if (!byVerdict.has(key)) byVerdict.set(key, []);
      byVerdict.get(key).push(g);
    }
    return [...byVerdict.entries()].sort((a, b) => b[1].length - a[1].length);
  }, [grades]);

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const flaggedCount = latestRun?.flagged_count || flaggedResults.length;
  const reviewedCount = grades.length;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="font-display text-2xl font-semibold flex items-center gap-2">
              <Sparkles className="w-6 h-6" /> MATCH QA
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Automated MATCH recommendation testing and regression detection.
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0 text-sm">
            <a href="/admin/test-profiles" className="text-muted-foreground hover:text-foreground flex items-center gap-1.5">
              <FlaskConical className="w-4 h-4" /> Test Profiles
            </a>
            <a href="/admin/grade-trends" className="text-muted-foreground hover:text-foreground">
              Grade Trends
            </a>
            <a href="/admin/funnel-distribution" className="text-muted-foreground hover:text-foreground">
              Funnel Distribution
            </a>
          </div>
        </div>

        {error && (
          <Card className="border-destructive/50">
            <CardContent className="p-4">
              <p className="text-sm text-destructive flex items-center gap-2">
                <AlertCircle className="w-4 h-4" /> {error}
              </p>
            </CardContent>
          </Card>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="run" className="gap-1.5">
              <Play className="w-4 h-4" /> Run QA
            </TabsTrigger>
            <TabsTrigger value="review" className="gap-1.5">
              <ListChecks className="w-4 h-4" /> Review ({flaggedCount})
            </TabsTrigger>
            <TabsTrigger value="results" className="gap-1.5">
              <ListChecks className="w-4 h-4" /> View Results
            </TabsTrigger>
            <TabsTrigger value="summary" className="gap-1.5">
              <BarChart3 className="w-4 h-4" /> Summary
            </TabsTrigger>
          </TabsList>

          {/* Run Tab */}
          <TabsContent value="run" className="space-y-4">
            {goldenCount === 0 && (
              <Card className="border-amber-400/50">
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">No golden profiles found</p>
                    <p className="text-xs text-muted-foreground">Seed the 25 benchmark profiles to get started.</p>
                  </div>
                  <Button onClick={seedGolden} disabled={running} size="sm">
                    <Sparkles className="w-4 h-4 mr-1.5" /> Seed Golden Profiles
                  </Button>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Run MATCH QA</CardTitle>
                <CardDescription>Choose a batch type. The system runs automatically and flags cases for expert review.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex flex-wrap gap-2">
                  <Button onClick={() => runQA("golden", 0, 1)} disabled={running || goldenCount === 0} variant="secondary">
                    {running ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FlaskConical className="w-4 h-4 mr-2" />}
                    Validation Run (1 Profile)
                  </Button>
                  <Button onClick={() => runQA("golden")} disabled={running || goldenCount === 0}>
                    {running ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Play className="w-4 h-4 mr-2" />}
                    Golden Only ({goldenCount})
                  </Button>
                  <Button onClick={() => runQA("standard", 50)} disabled={running} variant="outline">
                    Standard Batch (50 synthetic)
                  </Button>
                  <Button onClick={() => runQA("mixed", 50)} disabled={running || goldenCount === 0} variant="outline">
                    Mixed (Golden + 50 synthetic)
                  </Button>
                </div>
                {running && runStep && (
                  <p className="text-sm text-muted-foreground flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" /> {runStep}
                  </p>
                )}
                <div className="flex gap-2 pt-2 border-t border-border">
                  <Button onClick={cleanup} disabled={running} variant="ghost" size="sm">
                    <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Cleanup Old Test Data
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Recent runs */}
            {runs.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Recent Runs</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {runs.map((run) => (
                    <div key={run.id} className="flex items-center justify-between gap-2 text-sm border border-border rounded p-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="capitalize">{run.run_type}</Badge>
                        <Badge variant={run.status === "complete" ? "secondary" : run.status === "failed" ? "destructive" : "default"}>
                          {run.status}
                        </Badge>
                        <span className="text-muted-foreground">{run.profile_count} profiles, {run.tier_results_count} tiers</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {run.green_count > 0 && <Badge className={CONCERN_COLORS.green} variant="outline">{run.green_count} G</Badge>}
                        {run.yellow_count > 0 && <Badge className={CONCERN_COLORS.yellow} variant="outline">{run.yellow_count} Y</Badge>}
                        {run.red_count > 0 && <Badge className={CONCERN_COLORS.red} variant="outline">{run.red_count} R</Badge>}
                        {run.uncertain_count > 0 && <Badge className={CONCERN_COLORS.uncertain} variant="outline">{run.uncertain_count} U</Badge>}
                        {run.flagged_count > 0 && <span className="text-muted-foreground text-xs">{run.flagged_count} flagged</span>}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Review Tab */}
          <TabsContent value="review" className="space-y-3">
            {flaggedResults.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center text-muted-foreground">
                  {latestRun?.status === "failed"
                    ? "Latest QA run failed or was incomplete. No clean result can be inferred; review its notes and rerun after resolving the error."
                    : latestRun?.status === "running"
                      ? "Latest QA run is still in progress. Results are not final."
                      : latestRun
                        ? "No flagged cases in the latest completed run. Check the number of profiles and tiers tested before treating this as a pass."
                        : "Run a QA batch to see flagged cases here."}
                </CardContent>
              </Card>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">
                    {flaggedResults.length} flagged case{flaggedResults.length !== 1 ? "s" : ""} for review. {reviewedCount} reviewed.
                  </p>
                </div>
                {flaggedResults.map((tr) => (
                  <QAReviewCard
                    key={tr.id}
                    tierResult={tr}
                    existingGrade={gradesByTierResult.get(tr.id)}
                    onSaved={loadAll}
                  />
                ))}
              </>
            )}
          </TabsContent>

          {/* View Results Tab */}
          <TabsContent value="results" className="space-y-3">
            <QARunResults run={latestRun} tierResults={allTierResults} />
          </TabsContent>

          {/* Summary Tab */}
          <TabsContent value="summary" className="space-y-4">
            {latestRun ? (
              <>
                {/* Run stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <p className="text-xs text-muted-foreground mb-1">Profiles Tested</p>
                      <span className="text-2xl font-semibold tabular-nums">{latestRun.profile_count}</span>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <p className="text-xs text-muted-foreground mb-1">Tiers Tested</p>
                      <span className="text-2xl font-semibold tabular-nums">{latestRun.tier_results_count}</span>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <p className="text-xs text-muted-foreground mb-1">Flagged</p>
                      <span className="text-2xl font-semibold tabular-nums">{latestRun.flagged_count}</span>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <p className="text-xs text-muted-foreground mb-1">Expert Reviews</p>
                      <span className="text-2xl font-semibold tabular-nums">{reviewedCount}/{latestRun.flagged_count}</span>
                    </CardContent>
                  </Card>
                </div>

                {/* Concern distribution */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Concern Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div className="flex items-center gap-2">
                        <Badge className={CONCERN_COLORS.green} variant="outline">GREEN</Badge>
                        <span className="text-lg font-semibold tabular-nums">{latestRun.green_count}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={CONCERN_COLORS.yellow} variant="outline">YELLOW</Badge>
                        <span className="text-lg font-semibold tabular-nums">{latestRun.yellow_count}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={CONCERN_COLORS.red} variant="outline">RED</Badge>
                        <span className="text-lg font-semibold tabular-nums">{latestRun.red_count}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={CONCERN_COLORS.uncertain} variant="outline">UNCERTAIN</Badge>
                        <span className="text-lg font-semibold tabular-nums">{latestRun.uncertain_count}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Failure breakdown */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Failure Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between"><span>Constraint failures</span><span className="font-medium tabular-nums">{latestRun.constraint_failures}</span></div>
                    <div className="flex justify-between"><span>Progression failures</span><span className="font-medium tabular-nums">{latestRun.progression_failures}</span></div>
                    <div className="flex justify-between"><span>Golden regressions</span><span className="font-medium tabular-nums">{latestRun.golden_regressions}</span></div>
                  </CardContent>
                </Card>

                {/* Knowledge patterns */}
                {verdictPatterns.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Recurring Issue Patterns</CardTitle>
                      <CardDescription>Aggregated expert verdicts — analytics only, does NOT auto-change MATCH.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {verdictPatterns.map(([verdict, items]) => (
                        <div key={verdict} className="flex items-center justify-between text-sm">
                          <span className="capitalize font-medium">{verdict.replace(/_/g, " ")}</span>
                          <div className="flex items-center gap-2">
                            <span className="tabular-nums text-muted-foreground">{items.length} case{items.length !== 1 ? "s" : ""}</span>
                            {items.slice(0, 3).map((g, i) => (
                              <Badge key={i} variant="outline" className="text-xs">{g.tier}</Badge>
                            ))}
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}
              </>
            ) : (
              <Card>
                <CardContent className="p-8 text-center text-muted-foreground">
                  Run a QA batch to see summary stats here.
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}