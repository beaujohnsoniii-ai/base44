import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Calculator, Anchor, TrendingUp, Snowflake } from "lucide-react";
import {
  STORAGE_OPTIONS,
  SIZE_TO_FT,
  ENGINE_OPTIONS,
  estimateOwnershipCosts,
} from "@/lib/ownership-cost";

const STORAGE_LABELS = {
  trailer: "Trailer-kept",
  marina_slip: "Marina slip",
  mooring: "Mooring",
  dry_stack: "Dry stack",
  rack_storage: "Rack storage",
  lift_kept: "Lift-kept",
  private_dock: "Private dock",
  not_sure: "Not sure",
};

export default function OwnershipCalculator() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const [storage, setStorage] = useState("trailer");
  const [lengthFt, setLengthFt] = useState(21);
  const [boatValue, setBoatValue] = useState(30000);
  const [engineType, setEngineType] = useState("outboard");
  const [coldClimate, setColdClimate] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: me.id }, "-created_date", 1);
        const p = profiles?.[0] || null;
        setProfile(p);
        if (p) {
          if (p.storage && p.storage !== "not_sure") setStorage(p.storage);
          if (p.boat_size_range && SIZE_TO_FT[p.boat_size_range]) setLengthFt(SIZE_TO_FT[p.boat_size_range]);
          if (p.purchase_budget_max) setBoatValue(p.purchase_budget_max);
        }
      } catch (e) {
        /* no profile — use defaults */
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const result = useMemo(
    () => estimateOwnershipCosts({ storage, lengthFt, boatValue, engineType, coldClimate }),
    [storage, lengthFt, boatValue, engineType, coldClimate]
  );

  const annualBudget = profile?.annual_ownership_budget || null;
  const budgetDelta = annualBudget ? result.total - annualBudget : null;

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <Navbar />
      <main className="max-w-5xl mx-auto px-4 py-10 space-y-6">
        <div>
          <h1 className="font-heading text-3xl font-semibold flex items-center gap-2">
            <Calculator className="w-7 h-7 text-accent" /> Ownership Cost Calculator
          </h1>
          <p className="text-muted-foreground mt-1">
            Estimate annual maintenance and storage costs based on how you'll keep the boat. Adjust the inputs to compare scenarios.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Inputs */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Anchor className="w-5 h-5" /> Your situation</CardTitle>
              <CardDescription>Pre-filled from your profile when available.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <div>
                <Label>Storage type</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {STORAGE_OPTIONS.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setStorage(s.id)}
                      className={`text-left rounded-md border px-3 py-2 text-sm transition ${
                        storage === s.id ? "border-accent bg-accent/10 text-accent" : "border-border hover:border-accent/50"
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {STORAGE_OPTIONS.find((s) => s.id === storage)?.note}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="len">Boat length (ft)</Label>
                  <Input id="len" type="number" min={8} max={80} value={lengthFt} onChange={(e) => setLengthFt(Number(e.target.value) || 0)} />
                </div>
                <div>
                  <Label htmlFor="val">Boat value ($)</Label>
                  <Input id="val" type="number" min={1000} value={boatValue} onChange={(e) => setBoatValue(Number(e.target.value) || 0)} />
                </div>
              </div>

              <div>
                <Label>Engine type</Label>
                <div className="flex gap-2 mt-2">
                  {ENGINE_OPTIONS.map((e) => (
                    <button
                      key={e.id}
                      type="button"
                      onClick={() => setEngineType(e.id)}
                      className={`rounded-md border px-3 py-2 text-sm transition ${
                        engineType === e.id ? "border-accent bg-accent/10 text-accent" : "border-border hover:border-accent/50"
                      }`}
                    >
                      {e.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <button
                  type="button"
                  onClick={() => setColdClimate((v) => !v)}
                  className={`flex items-center gap-2 rounded-md border px-3 py-2 text-sm transition ${
                    coldClimate ? "border-accent bg-accent/10 text-accent" : "border-border hover:border-accent/50"
                  }`}
                >
                  <Snowflake className="w-4 h-4" />
                  {coldClimate ? "Cold climate — winterization on" : "Year-round boating — no winterization"}
                </button>
                <p className="text-xs text-muted-foreground mt-2">
                  Winterization adds haul-out and engine freeze protection for cold-water regions.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Results */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><TrendingUp className="w-5 h-5" /> Estimated annual cost</CardTitle>
              <CardDescription>Itemized breakdown of recurring ownership costs.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="rounded-lg bg-primary/5 border border-primary/10 p-4">
                <p className="text-sm text-muted-foreground">Total estimated annual cost</p>
                <p className="font-heading text-3xl font-semibold text-primary">
                  ${Math.round(result.total).toLocaleString()}
                </p>
                {budgetDelta != null && (
                  <p className={`text-sm mt-1 ${budgetDelta > 0 ? "text-destructive" : "text-accent"}`}>
                    {budgetDelta > 0
                      ? `$${Math.round(budgetDelta).toLocaleString()} over your stated annual budget`
                      : `$${Math.round(Math.abs(budgetDelta)).toLocaleString()} under your stated annual budget`}
                  </p>
                )}
              </div>

              <ul className="divide-y">
                {result.items.map((it, i) => (
                  <li key={i} className="py-2.5 flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-medium">{it.label}</p>
                      <p className="text-xs text-muted-foreground">{it.note}</p>
                    </div>
                    <span className="text-sm font-medium tabular-nums">${Math.round(it.amount).toLocaleString()}</span>
                  </li>
                ))}
              </ul>

              <p className="text-xs text-muted-foreground pt-2">
                Estimates are planning ranges, not quotes. Actual costs vary by region, marina, boat age, and usage.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}