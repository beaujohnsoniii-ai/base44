import React, { useState, useEffect, useMemo } from "react";
import { base44Test } from "@/lib/base44TestClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, TrendingUp, TrendingDown, Minus, ArrowLeft, Star } from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
} from "recharts";
import moment from "moment";

export default function AdminGradeTrends() {
  const [grades, setGrades] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const all = await base44Test.entities.TestGrade.list("-created_date", 500);
        setGrades(all || []);
      } catch (e) {
        console.error("Load grades error", e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const { last30, dailyData, distribution, avgLast30, avgPrev30, totalComments } = useMemo(() => {
    const now = moment();
    const thirtyDaysAgo = now.clone().subtract(30, "days");
    const sixtyDaysAgo = now.clone().subtract(60, "days");

    const last30 = (grades || []).filter(g => moment(g.created_date).isAfter(thirtyDaysAgo));
    const prev30 = (grades || []).filter(g => {
      const d = moment(g.created_date);
      return d.isAfter(sixtyDaysAgo) && d.isSameOrBefore(thirtyDaysAgo);
    });

    const avg = (arr) => arr.length > 0 ? arr.reduce((s, g) => s + (g.grade || 0), 0) / arr.length : 0;
    const avgLast30 = avg(last30);
    const avgPrev30 = avg(prev30);

    // Daily data for chart — group by day, compute running average.
    const byDay = {};
    for (const g of last30) {
      const day = moment(g.created_date).format("MMM D");
      if (!byDay[day]) byDay[day] = { date: day, grades: [], total: 0, ts: moment(g.created_date).startOf("day").valueOf() };
      byDay[day].grades.push(g.grade || 0);
      byDay[day].total += g.grade || 0;
    }
    const dailyData = Object.values(byDay)
      .map(d => ({
        date: d.date,
        avg: d.grades.length > 0 ? d.total / d.grades.length : 0,
        count: d.grades.length,
        ts: d.ts,
      }))
      .sort((a, b) => a.ts - b.ts);

    // Grade distribution (1-5 stars).
    const distribution = [0, 0, 0, 0, 0, 0];
    for (const g of last30) {
      const grade = g.grade || 0;
      if (grade >= 1 && grade <= 5) distribution[grade]++;
    }

    const totalComments = last30.filter(g => g.comment && g.comment.trim()).length;

    return { last30, dailyData, distribution, avgLast30, avgPrev30, totalComments };
  }, [grades]);

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const trend = avgLast30 > avgPrev30 + 0.01 ? "up" : avgLast30 < avgPrev30 - 0.01 ? "down" : "flat";
  const TrendIcon = trend === "up" ? TrendingUp : trend === "down" ? TrendingDown : Minus;
  const trendColor = trend === "up" ? "text-green-600" : trend === "down" ? "text-red-600" : "text-muted-foreground";
  const trendLabel = trend === "up" ? "Improving" : trend === "down" ? "Declining" : "Stable";

  const recentComments = last30
    .filter(g => g.comment && g.comment.trim())
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
    .slice(0, 10);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl font-semibold">Grade Trends</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Advisor performance over the last 30 days — see if algorithm adjustments are moving the needle.
            </p>
          </div>
          <a href="/admin/test-profiles" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" /> Test Simulator
          </a>
        </div>

        {last30.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              No grades recorded in the last 30 days. Run a test and grade the results to see trends here.
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Summary cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">30-Day Average</p>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-semibold tabular-nums">{avgLast30.toFixed(2)}</span>
                    <span className="text-sm text-muted-foreground">/ 5</span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Trend vs Prev 30</p>
                  <div className={`flex items-center gap-1.5 ${trendColor}`}>
                    <TrendIcon className="w-5 h-5" />
                    <span className="text-sm font-medium">{trendLabel}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Prev: {avgPrev30.toFixed(2)} / 5</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Graded Profiles</p>
                  <span className="text-2xl font-semibold tabular-nums">{last30.length}</span>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">With Comments</p>
                  <span className="text-2xl font-semibold tabular-nums">{totalComments}</span>
                </CardContent>
              </Card>
            </div>

            {/* Trend chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Daily Average Grade</CardTitle>
                <CardDescription>Last 30 days</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={dailyData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} interval="preserveStartEnd" />
                    <YAxis domain={[0, 5]} tick={{ fontSize: 11 }} />
                    <Tooltip
                      formatter={(value) => [`${Number(value).toFixed(2)} / 5`, "Avg Grade"]}
                      contentStyle={{ fontSize: 12 }}
                    />
                    <ReferenceLine y={3} stroke="hsl(var(--muted-foreground))" strokeDasharray="3 3" label={{ value: "Mid", fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                    <Line type="monotone" dataKey="avg" stroke="hsl(var(--accent))" strokeWidth={2} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Grade distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Grade Distribution</CardTitle>
                <CardDescription>How grades are spread across the 30-day window</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[5, 4, 3, 2, 1].map(star => {
                    const count = distribution[star];
                    const pct = last30.length > 0 ? (count / last30.length) * 100 : 0;
                    return (
                      <div key={star} className="flex items-center gap-3">
                        <span className="text-sm font-medium w-8">{star}★</span>
                        <div className="flex-1 h-6 bg-muted rounded overflow-hidden">
                          <div
                            className="h-full bg-accent rounded transition-all"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span className="text-sm text-muted-foreground tabular-nums w-12 text-right">{count}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Recent feedback */}
            {recentComments.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Recent Feedback</CardTitle>
                  <CardDescription>Latest admin comments on advisor output</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {recentComments.map(g => (
                    <div key={g.id} className="border-l-2 border-border pl-3 space-y-1">
                      <div className="flex items-center gap-2">
                        <div className="flex">
                          {Array.from({ length: 5 }, (_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${i < (g.grade || 0) ? "fill-accent text-accent" : "text-muted-foreground/30"}`}
                            />
                          ))}
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {moment(g.created_date).format("MMM D, h:mm a")}
                        </span>
                        {g.phase && g.phase !== "overall" && (
                          <Badge variant="outline" className="text-xs capitalize">{g.phase}</Badge>
                        )}
                      </div>
                      <p className="text-sm leading-relaxed">{g.comment}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
}