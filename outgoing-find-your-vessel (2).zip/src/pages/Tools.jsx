import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Compass } from "lucide-react";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";

const TOOLS = [
  { number: "01", name: "Match", status: "Available now", description: "Find models suited to your needs, experience, and budget.", active: true },
  { number: "02", name: "Compare", status: "Coming soon", description: "Compare your shortlisted boats and understand their tradeoffs." },
  { number: "03", name: "Ownership", status: "Coming soon", description: "Estimate ownership costs and practical requirements." },
  { number: "04", name: "Analyze", status: "Coming soon", description: "Review a specific boat, its records, and available evidence." },
  { number: "05", name: "Guide", status: "Coming soon", description: "Follow the purchase steps, including survey and sea trial." },
  { number: "06", name: "Deal", status: "Coming soon", description: "Track your offer, contingencies, and closing." },
];

export default function Tools() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-parchment font-serif text-foreground">
      <Navbar />
      <main className="max-w-6xl mx-auto px-4 py-12 md:py-20">
        <div className="max-w-2xl">
          <p className="text-[11px] uppercase tracking-[0.3em] text-brass font-medium">Sound Heading</p>
          <h1 className="font-display text-3xl md:text-5xl font-semibold mt-3">Choose your next step</h1>
          <p className="text-muted-foreground mt-4 leading-relaxed">
            Your account is the home for all six tools. Match is ready to use now; the other tools will appear here as they are built.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-10">
          {TOOLS.map((tool) => (
            <section
              key={tool.name}
              className={`flex flex-col bg-background border p-6 md:p-7 ${tool.active ? "border-brass/70 shadow-sm" : "border-brass/25"}`}
              aria-labelledby={`tool-${tool.name.toLowerCase()}`}
            >
              <div className="flex items-center justify-between gap-3">
                <span className="font-display text-2xl text-brass">{tool.number}</span>
                {tool.active ? (
                  <span className="text-[10px] uppercase tracking-[0.18em] text-primary border border-primary/30 px-2.5 py-1">
                    {tool.status}
                  </span>
                ) : (
                  <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground border border-border px-2.5 py-1">
                    {tool.status}
                  </span>
                )}
              </div>
              <h2 id={`tool-${tool.name.toLowerCase()}`} className="font-display text-2xl font-semibold mt-5">
                {tool.name}
              </h2>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed flex-1">{tool.description}</p>
              {tool.active ? (
                <Button className="mt-6 w-full" onClick={() => navigate("/match")}>
                  Open Match <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button className="mt-6 w-full" variant="outline" disabled>
                  Coming soon
                </Button>
              )}
            </section>
          ))}
        </div>

        <div className="mt-12 border-t border-brass/25 pt-6 flex items-start gap-3 text-sm text-muted-foreground">
          <Compass className="w-5 h-5 shrink-0 text-brass mt-0.5" />
          <p>One account and one place to return to. When each tool is ready, it will be added to this menu.</p>
        </div>
      </main>
    </div>
  );
}
