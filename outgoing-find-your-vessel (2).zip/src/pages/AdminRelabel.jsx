import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Check, Loader2, RefreshCw, AlertCircle, Trash2, X } from "lucide-react";
import { CATEGORIES } from "@/lib/category-labels";

export default function AdminRelabel() {
  const [manufacturers, setManufacturers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [filter, setFilter] = useState("unreviewed");
  const [updatingId, setUpdatingId] = useState(null);
  const [selected, setSelected] = useState(new Set());
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [bulkApproving, setBulkApproving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const rows = await base44.entities.Manufacturer.list("name", 600);
      let filtered = rows || [];
      if (filter === "unreviewed") {
        filtered = filtered.filter((m) => !m.category_reviewed);
      } else if (filter === "flagged") {
        filtered = filtered.filter((m) => m.category && !m.category_reviewed);
      }
      setManufacturers(filtered);
      setSelected(new Set());
    } catch (e) {
      console.error("AdminRelabel load error", e);
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => {
    load();
  }, [load]);

  const runRelabel = async () => {
    setRunning(true);
    setResult(null);
    try {
      const res = await base44.functions.invoke("relabel-manufacturers", { reset: false });
      setResult(res.data);
      await load();
    } catch (e) {
      console.error("Relabel run error", e);
      setResult({ error: e?.message || "Failed to run relabeling" });
    } finally {
      setRunning(false);
    }
  };

  const approve = async (m) => {
    setUpdatingId(m.id);
    try {
      await base44.entities.Manufacturer.update(m.id, { category_reviewed: true });
      setManufacturers((prev) => prev.filter((p) => p.id !== m.id));
      setSelected((prev) => {
        const next = new Set(prev);
        next.delete(m.id);
        return next;
      });
    } catch (e) {
      console.error("Approve error", e);
    } finally {
      setUpdatingId(null);
    }
  };

  const changeCategory = async (m, newCategory) => {
    setUpdatingId(m.id);
    try {
      await base44.entities.Manufacturer.update(m.id, {
        category: newCategory,
        category_reviewed: true,
      });
      setManufacturers((prev) => prev.filter((p) => p.id !== m.id));
      setSelected((prev) => {
        const next = new Set(prev);
        next.delete(m.id);
        return next;
      });
    } catch (e) {
      console.error("Change category error", e);
    } finally {
      setUpdatingId(null);
    }
  };

  const removeManufacturer = async (m) => {
    if (!window.confirm(`Remove ${m.name}? This deletes the manufacturer record.`)) return;
    setUpdatingId(m.id);
    try {
      await base44.entities.Manufacturer.delete(m.id);
      setManufacturers((prev) => prev.filter((p) => p.id !== m.id));
      setSelected((prev) => {
        const next = new Set(prev);
        next.delete(m.id);
        return next;
      });
    } catch (e) {
      console.error("Delete manufacturer error", e);
    } finally {
      setUpdatingId(null);
    }
  };

  const toggleSelect = (id) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    setSelected((prev) => {
      if (prev.size === manufacturers.length) return new Set();
      return new Set(manufacturers.map((m) => m.id));
    });
  };

  const clearSelection = () => setSelected(new Set());

  const bulkDelete = async () => {
    if (selected.size === 0) return;
    if (!window.confirm(`Remove ${selected.size} manufacturer${selected.size > 1 ? "s" : ""}? This cannot be undone.`)) return;
    setBulkDeleting(true);
    const ids = [...selected];
    for (const id of ids) {
      try {
        await base44.entities.Manufacturer.delete(id);
      } catch (e) {
        console.error("Bulk delete error for", id, e);
      }
    }
    setManufacturers((prev) => prev.filter((p) => !selected.has(p.id)));
    setSelected(new Set());
    setBulkDeleting(false);
  };

  const bulkApprove = async () => {
    if (selected.size === 0) return;
    setBulkApproving(true);
    const ids = [...selected];
    for (const id of ids) {
      try {
        await base44.entities.Manufacturer.update(id, { category_reviewed: true });
      } catch (e) {
        console.error("Bulk approve error for", id, e);
      }
    }
    setManufacturers((prev) => prev.filter((p) => !selected.has(p.id)));
    setSelected(new Set());
    setBulkApproving(false);
  };

  const confidenceColor = (c) => {
    if (c === "high") return "text-green-600";
    if (c === "medium") return "text-amber-600";
    return "text-red-600";
  };

  const allSelected = manufacturers.length > 0 && selected.size === manufacturers.length;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="font-display text-2xl font-semibold">Manufacturer Relabeling</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Review AI-proposed usage categories. Auto-applied builders are already marked reviewed; the rest need your sign-off.
            </p>
          </div>
          <Button onClick={runRelabel} disabled={running}>
            {running ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            {running ? "Running..." : "Run relabeling"}
          </Button>
        </div>

        {result && (
          <Card>
            <CardContent className="p-4">
              {result.error ? (
                <p className="text-sm text-destructive flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" /> {result.error}
                </p>
              ) : (
                <p className="text-sm">
                  {result.message} — {result.auto_applied} auto-applied, {result.flagged_for_review} flagged for review.
                </p>
              )}
            </CardContent>
          </Card>
        )}

        <div className="flex items-center gap-2">
          <Button variant={filter === "unreviewed" ? "default" : "outline"} size="sm" onClick={() => setFilter("unreviewed")}>
            Needs review
          </Button>
          <Button variant={filter === "flagged" ? "default" : "outline"} size="sm" onClick={() => setFilter("flagged")}>
            Flagged only
          </Button>
          <Button variant={filter === "all" ? "default" : "outline"} size="sm" onClick={() => setFilter("all")}>
            All
          </Button>
        </div>

        {selected.size > 0 && (
          <div className="sticky top-0 z-10 flex items-center justify-between gap-3 rounded-lg border bg-card p-3 shadow-sm">
            <span className="text-sm font-medium">{selected.size} selected</span>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={clearSelection} disabled={bulkDeleting || bulkApproving}>
                <X className="w-4 h-4 mr-1" /> Clear
              </Button>
              <Button variant="default" size="sm" onClick={bulkApprove} disabled={bulkDeleting || bulkApproving}>
                {bulkApproving ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Check className="w-4 h-4 mr-1" />}
                Approve{selected.size > 1 ? ` ${selected.size}` : ""}
              </Button>
              <Button variant="destructive" size="sm" onClick={bulkDelete} disabled={bulkDeleting || bulkApproving}>
                {bulkDeleting ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Trash2 className="w-4 h-4 mr-1" />}
                Remove{selected.size > 1 ? ` ${selected.size}` : ""}
              </Button>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : manufacturers.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              No manufacturers in this view. {filter === "unreviewed" && "All categories have been reviewed."}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <Checkbox
                checked={allSelected}
                onCheckedChange={toggleSelectAll}
              />
              <p className="text-xs text-muted-foreground">
                {manufacturers.length} builders{selected.size > 0 && ` — ${selected.size} selected`}
              </p>
            </div>
            {manufacturers.map((m) => (
              <Card key={m.id} className={selected.has(m.id) ? "border-primary/50 bg-primary/5" : ""}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div className="flex gap-3 flex-1 min-w-0">
                      <Checkbox
                        checked={selected.has(m.id)}
                        onCheckedChange={() => toggleSelect(m.id)}
                        className="mt-1"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">{m.name}</span>
                          {m.country && <span className="text-xs text-muted-foreground">{m.country}</span>}
                          {m.category_confidence && (
                            <span className={`text-xs font-medium ${confidenceColor(m.category_confidence)}`}>
                              {m.category_confidence} confidence
                            </span>
                          )}
                        </div>
                        {m.class_specialty && (
                          <p className="text-xs text-muted-foreground mt-0.5">Specialty: {m.class_specialty}</p>
                        )}
                        {m.notes && <p className="text-xs text-muted-foreground mt-0.5">{m.notes}</p>}
                        {m.category && (
                          <p className="text-xs mt-1">
                            Proposed: <span className="font-medium">{CATEGORIES.find((c) => c.value === m.category)?.label || m.category}</span>
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Select value={m.category || ""} onValueChange={(v) => changeCategory(m, v)}>
                        <SelectTrigger className="w-48">
                          <SelectValue placeholder="Set category" />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map((c) => (
                            <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {m.category && (
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => approve(m)}
                          disabled={updatingId === m.id}
                          title="Approve proposed category"
                        >
                          {updatingId === m.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                        </Button>
                      )}
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() => removeManufacturer(m)}
                        disabled={updatingId === m.id}
                        title="Remove manufacturer"
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}