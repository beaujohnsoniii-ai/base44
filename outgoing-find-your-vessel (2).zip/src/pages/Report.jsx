import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import { STAGE_BY_ID, planGrantsReport } from "@/lib/stages";
import BoatMatchCard from "@/components/reports/BoatMatchCard";
import IntroductionCard from "@/components/reports/IntroductionCard";
import SurveyReviewCard from "@/components/reports/SurveyReviewCard";
import ReportFeedbackForm from "@/components/ReportFeedbackForm";
import { ArrowLeft, Loader2, Lock, Download, Trash2, RefreshCw, Pencil } from "lucide-react";
import { downloadReportPdf } from "@/lib/report-pdf";

export default function Report() {
  const { type } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [surveyFiles, setSurveyFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [regenerationsUsed, setRegenerationsUsed] = useState(0);
  const [regenerating, setRegenerating] = useState(false);

  const stage = STAGE_BY_ID[type];
  const isTopPick = type === "top_pick";
  const isTopThree = type === "top_three";
  const regenCapable = isTopPick || isTopThree;
  const REGEN_LIMIT = isTopPick ? 5 : 10;
  const regenField = isTopPick ? "top_pick_regenerations_used" : "top_three_regenerations_used";

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        setRegenerationsUsed(Number(me[regenField] || 0));
        const existing = await base44.entities.Report.filter({ created_by_id: me.id, type }, "-created_date", 1);
        if (existing?.[0]) {
          setReport(existing[0]);
          setLoading(false);
        } else {
          setLoading(false);
        }
      } catch (e) {
        toast({ title: "Could not load report", variant: "destructive" });
        setLoading(false);
      }
    })();
  }, [type]);

  const generate = async ({ regenerate = false } = {}) => {
    const setter = regenerate ? setRegenerating : setGenerating;
    setter(true);
    try {
      const payload = { type };
      if (type === "survey_review") {
        payload.file_urls = surveyFiles.map((f) => f.signedUrl);
      }
      if (regenerate) payload.regenerate = true;
      const res = await base44.functions.invoke("generate-advisory", payload);
      if (res?.data?.report) {
        setReport(res.data.report);
        if (typeof res.data.regenerations_used === "number") {
          setRegenerationsUsed(res.data.regenerations_used);
        }
      } else {
        toast({ title: res?.data?.error || "Could not generate report", variant: "destructive" });
      }
    } catch (e) {
      const msg = e?.response?.data?.error || "Could not generate report";
      toast({ title: msg, variant: "destructive" });
    } finally {
      setter(false);
    }
  };

  const onSurveyFiles = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setUploading(true);
    try {
      for (const file of files) {
        const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
        const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri, expires_in: 600 });
        setSurveyFiles((prev) => [...prev, { name: file.name, signedUrl: signed_url }]);
      }
    } catch (err) {
      toast({ title: "Upload failed", variant: "destructive" });
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  const removeSurveyFile = (i) => setSurveyFiles((prev) => prev.filter((_, idx) => idx !== i));

  const purchased = Array.isArray(user?.purchased_stages) ? user.purchased_stages : [];
  const plan = user?.plan || "free";
  // Higher packages retain the report benefits of lower packages.
  // Legacy purchasers keep access via purchased_stages.
  const planGrants = planGrantsReport(plan, type);
  const isPurchased = purchased.includes(type) || planGrants;

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!stage) {
    return (
      <div className="min-h-screen bg-muted/30">
        <Navbar />
        <main className="max-w-2xl mx-auto px-4 py-20 text-center">
          <h1 className="font-heading text-2xl font-semibold">Report Not Found</h1>
          <Button className="mt-6" onClick={() => navigate("/dashboard")}>Back to dashboard</Button>
        </main>
      </div>
    );
  }

  if (!isPurchased) {
    return (
      <div className="min-h-screen bg-muted/30">
        <Navbar />
        <main className="max-w-2xl mx-auto px-4 py-20 text-center">
          <Lock className="w-12 h-12 text-muted-foreground mx-auto" />
          <h1 className="font-heading text-2xl font-semibold mt-4">{stage.name} isn't unlocked yet</h1>
          <p className="text-muted-foreground mt-2">Purchase this service to generate your {stage.name.toLowerCase()} report.</p>
          <Button className="mt-6" onClick={() => navigate("/dashboard")}>Go to dashboard</Button>
        </main>
      </div>
    );
  }

  const c = report?.content;
  const isIntroductions = type === "introductions";
  const isSurveyReview = type === "survey_review";
  const introductions = isIntroductions ? (c?.introductions || []) : [];
  const boatMatches = (c?.recommendations || (c?.recommendation ? [c.recommendation] : []));

  return (
    <div className="min-h-screen bg-muted/30">
      <Navbar />
      <main className="max-w-3xl mx-auto px-4 py-10 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Link to="/dashboard" className="text-sm text-muted-foreground hover:underline flex items-center gap-1">
              <ArrowLeft className="w-4 h-4" /> Dashboard
            </Link>
            <h1 className="font-heading text-3xl font-semibold mt-2">{stage.name} Report</h1>
          </div>
          {report && c && (
            <Button variant="outline" onClick={() => downloadReportPdf(stage.name, type, c)}>
              <Download className="w-4 h-4 mr-2" /> Download PDF
            </Button>
          )}
        </div>

        {!report && (
          isSurveyReview ? (
            <Card>
              <CardContent className="p-6 space-y-4">
                <div>
                  <p className="font-medium">Upload your survey and inspection reports</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Commission a marine survey and/or mechanic inspection yourself, then upload the PDFs here. We review the findings impartially — you pay the inspectors directly, and we take no referral fees.
                  </p>
                </div>
                <input
                  type="file"
                  accept="application/pdf,image/*"
                  multiple
                  onChange={onSurveyFiles}
                  className="text-sm"
                />
                {surveyFiles.length > 0 && (
                  <ul className="text-sm space-y-1">
                    {surveyFiles.map((f, i) => (
                      <li key={i} className="flex items-center justify-between gap-2 rounded-md border border-border p-2">
                        <span className="truncate">{f.name}</span>
                        <Button size="icon" variant="ghost" onClick={() => removeSurveyFile(i)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </li>
                    ))}
                  </ul>
                )}
                <Button onClick={() => generate()} disabled={generating || uploading || surveyFiles.length === 0}>
                  {generating ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Reviewing…</>
                  ) : uploading ? (
                    "Uploading…"
                  ) : (
                    "Generate my review"
                  )}
                </Button>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-muted-foreground">Your report hasn't been generated yet.</p>
                <Button className="mt-4" onClick={() => generate()} disabled={generating}>
                  {generating ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating…</>
                  ) : (
                    "Generate my report"
                  )}
                </Button>
              </CardContent>
            </Card>
          )
        )}

        {report && c && (
          <>
            {regenCapable && (
              <Card className="border-accent/30 bg-accent/5">
                <CardContent className="p-5 space-y-3">
                  <div>
                    <p className="font-medium flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 text-accent" /> Refine your profile, refine your {stage.name}
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Every detail in your profile shapes your shortlist — including the order of your priorities.
                      Change your budget, storage, timeline, must-haves, or reorder what matters most, then regenerate
                      your {stage.name}. You can do this up to {REGEN_LIMIT} times after your first report.
                    </p>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <div className="flex-1">
                      <div className="h-2 rounded-full bg-muted overflow-hidden">
                        <div
                          className="h-full bg-accent transition-all"
                          style={{ width: `${Math.min(100, (regenerationsUsed / REGEN_LIMIT) * 100)}%` }}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Regenerations used: {regenerationsUsed}/{REGEN_LIMIT}
                        {regenerationsUsed >= REGEN_LIMIT && " — limit reached. Contact us for further changes."}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => navigate("/edit-profile")}>
                        <Pencil className="w-4 h-4 mr-2" /> Edit profile
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => generate({ regenerate: true })}
                        disabled={regenerating || regenerationsUsed >= REGEN_LIMIT}
                      >
                        {regenerating ? (
                          <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Regenerating…</>
                        ) : (
                          <><RefreshCw className="w-4 h-4 mr-2" /> Regenerate</>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {c.buyer_priorities && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Buyer Priorities Used</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="ml-5 list-disc text-sm space-y-1">
                    {c.buyer_priorities.map((p, i) => <li key={i}>{p}</li>)}
                  </ul>
                </CardContent>
              </Card>
            )}

            {type === "private_advisory" && c.consultation_briefing && (
              <Card>
                <CardHeader><CardTitle className="text-lg">Consultation Briefing</CardTitle></CardHeader>
                <CardContent><p className="text-sm text-muted-foreground">{c.consultation_briefing}</p></CardContent>
              </Card>
            )}

            {isIntroductions ? (
              introductions.length > 0 ? (
                introductions.map((rec, i) => (
                  <IntroductionCard key={i} rec={rec} rank={i + 1} />
                ))
              ) : (
                <Card>
                  <CardContent className="p-6">
                    <p className="text-muted-foreground">No introductions could be prepared. See the remedy note below.</p>
                  </CardContent>
                </Card>
              )
            ) : isSurveyReview ? (
              <SurveyReviewCard content={c} />
            ) : boatMatches.length > 0 ? (
              boatMatches.map((rec, i) => (
                <BoatMatchCard key={i} rec={rec} rank={(type === "top_three" || type === "top_pick") ? i + 1 : undefined} />
              ))
            ) : (
              <Card>
                <CardContent className="p-6">
                  <p className="text-muted-foreground">No recommendations met the requirements. See the remedy note below.</p>
                </CardContent>
              </Card>
            )}

            {type === "top_three" && c.comparison && (
              <Card>
                <CardHeader><CardTitle className="text-lg">How They Compare</CardTitle></CardHeader>
                <CardContent><p className="text-sm text-muted-foreground">{c.comparison}</p></CardContent>
              </Card>
            )}

            {type === "top_three" && c.investigation_priorities?.length > 0 && (
              <Card>
                <CardHeader><CardTitle className="text-lg">Investigation Priorities</CardTitle></CardHeader>
                <CardContent>
                  <ul className="ml-5 list-disc text-sm space-y-1">
                    {c.investigation_priorities.map((p, i) => <li key={i}>{p}</li>)}
                  </ul>
                </CardContent>
              </Card>
            )}

            {type === "private_advisory" && c.discussion_topics?.length > 0 && (
              <Card>
                <CardHeader><CardTitle className="text-lg">Discussion Topics for Your Consultation</CardTitle></CardHeader>
                <CardContent>
                  <ul className="ml-5 list-disc text-sm space-y-1">
                    {c.discussion_topics.map((p, i) => <li key={i}>{p}</li>)}
                  </ul>
                </CardContent>
              </Card>
            )}

            {type === "private_advisory" && c.follow_up_scope && (
              <Card>
                <CardHeader><CardTitle className="text-lg">Follow-Up Scope</CardTitle></CardHeader>
                <CardContent><p className="text-sm text-muted-foreground">{c.follow_up_scope}</p></CardContent>
              </Card>
            )}

            {c.overall_assessment && (
              <Card>
                <CardHeader><CardTitle className="text-lg">Overall Assessment</CardTitle></CardHeader>
                <CardContent><p className="text-sm text-muted-foreground">{c.overall_assessment}</p></CardContent>
              </Card>
            )}

            {c.remedy_note && (
              <Card>
                <CardHeader><CardTitle className="text-lg">If the Shortlist Can't Be Delivered</CardTitle></CardHeader>
                <CardContent><p className="text-sm text-muted-foreground">{c.remedy_note}</p></CardContent>
              </Card>
            )}

            {type !== "preliminary" && (
              <ReportFeedbackForm reportId={report.id} stageName={stage.name} />
            )}

            <p className="text-xs text-muted-foreground">
              These are the strongest matches found within your criteria and the sources reviewed — not a claim of the best boat across the entire market.
              Availability is advertised unless independently confirmed. Remote review cannot establish condition; arrange a survey before purchase.
            </p>
          </>
        )}
      </main>
    </div>
  );
}