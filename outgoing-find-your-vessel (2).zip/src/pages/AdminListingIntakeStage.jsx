import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { canPreviewListingIntake } from '@/lib/listingIntakeAction';
import { useListingIntake } from '@/lib/useListingIntake';
import MatchResultsShowcase from '@/components/match/MatchResultsShowcase';
import ListingIntakePanel from '@/components/ListingIntakePanel';
import { requestDeadline } from '@/lib/requestDeadline';

// Isolated rendering of real DEV records. No generation, Like, profile or Compare writes.
export default function AdminListingIntakeStage() {
  const { user, isLoadingAuth } = useAuth();
  const intake = useListingIntake('dev');
  const [result, setResult] = useState(null), [error, setError] = useState(''), [loading, setLoading] = useState(true);
  const allowed = canPreviewListingIntake(user, 'dev');
  useEffect(() => {
    let mounted = true;
    if (!allowed) return () => { mounted = false; };
    (async () => {
      try {
        const result = await requestDeadline(async signal => {
          const response = await base44.functions.fetch('/listing-intake-stage', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Data-Env': 'dev' }, body: JSON.stringify({ action: 'read' }), signal });
          const data = await response.json(); if (!response.ok) throw Error(data.error || 'Test results could not be loaded.'); return data;
        }, 30000, 'Loading test results timed out. No generation was started.');
        if (mounted) setResult(result);
      } catch (error) { if (mounted) setError(error.message); }
      finally { if (mounted) setLoading(false); }
    })();
    return () => { mounted = false; };
  }, [allowed]);
  if (isLoadingAuth) return <main className="p-8">Checking access…</main>;
  if (!allowed) return <main className="p-8">Private owner test unavailable.</main>;
  return <main className="max-w-6xl mx-auto px-4 py-8 space-y-6">
    <Link className="text-sm underline" to="/helm">Back to My Helm</Link>
    <header><p className="text-sm font-medium text-muted-foreground">Private owner test · DEV data only</p><h1 className="font-heading text-3xl mt-2">Review listings from your test matches</h1><p className="mt-3 text-sm text-muted-foreground">Real generated test models, using the same cards as My Helm. Listing actions cannot change your questionnaire, model ranking or preferences. This page does not generate matches or save Likes.</p></header>
    {loading && <p role="status">Loading saved test matches…</p>}
    {error && <p role="alert" className="rounded-lg border border-destructive/30 p-3">{error}</p>}
    {result && <><p className="text-sm text-muted-foreground">{result.suggestions.length} current test models · {result.suggestions.filter(boat => boat.highlighted).length} marked by the existing Match engine.</p><MatchResultsShowcase plan={result.plan} suggestions={result.suggestions} likedIds={new Set()} onToggleLike={undefined} onReviewListings={intake.openReview} listingCounts={intake.counts} /></>}
    {intake.reviewBoat && <ListingIntakePanel boat={intake.reviewBoat} onClose={intake.closeReview} onCountChange={intake.updateCounts} />}
  </main>;
}
