import React, { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { pastLikesEnabled } from "../../base44/shared/liked-preferences.mjs";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import IntroQuestionnaire from "@/components/IntroQuestionnaire";
import { useToast } from "@/components/ui/use-toast";
import { isPaidPlan } from "@/lib/stages";

// Explicit contrast on the navy page, without changing the white questionnaire card.
const PROFILE_ACTION_STYLE = "min-h-11 w-full sm:w-auto bg-white text-[#071f32] border-slate-300 hover:bg-slate-100 hover:text-[#071f32] focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-[#071f32] disabled:opacity-100 disabled:bg-slate-200 disabled:text-slate-600 disabled:border-slate-300";

export default function EditProfile() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [profile, setProfile] = useState(null);
  const [usePastLikes, setUsePastLikes] = useState(false);
  const [plan, setPlan] = useState("free");
  const [isAdmin, setIsAdmin] = useState(false);
  const [fieldTiers, setFieldTiers] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const rules = await base44.functions.invoke("question-tiers", {});
        setFieldTiers(rules?.data?.field_tiers || null);
        const me = await base44.auth.me();
        setPlan(me?.plan || "free");
        setIsAdmin(me?.role === "admin");
        const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: me.id }, "-created_date", 1);
        setProfile(profiles?.[0] || null);
        setUsePastLikes(pastLikesEnabled(profiles?.[0]));
        if (!profiles?.[0]) {
          toast({ title: "No profile found", description: "Take the questionnaire to create one.", variant: "destructive" });
          navigate("/questionnaire");
        }
      } catch (e) {
        toast({ title: "Could not load profile", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const saveInFlight=useRef(false);
  const handleReset = async () => {
    if (saveInFlight.current) return;
    if (!window.confirm("Start a fresh matching context and open a blank questionnaire? Your saved answers stay until you save replacements. Likes, notes, saved boats and reports are kept as history. Matching updates follow your package allowance.")) return;
    saveInFlight.current = true;
    setSaving(true);
    try {
      // Invalidate matching context immediately, without replacing any buyer answers.
      const requestId = crypto.randomUUID();
      const response = await base44.functions.invoke("reset-matching-context", { buyer_profile_id: profile.id, expected_context_id: profile.match_context_id ?? null, request_id: requestId });
      const saved = response?.data?.profile;
      if (response?.data?.matching_context_version !== "reset-matching-context-v1" || response?.data?.request_id !== requestId || saved?.match_context_id !== requestId || response?.data?.reset_context_applied !== true || saved?.id !== profile.id || !saved?.match_context_id || saved.match_context_id === profile.match_context_id) {
        throw new Error("The active backend did not confirm a fresh matching context.");
      }
      const persisted = await base44.entities.BuyerProfile.filter({ created_by_id: saved.created_by_id }, "-created_date", 1);
      if (persisted?.[0]?.id !== saved.id || persisted[0].match_context_id !== saved.match_context_id) {
        throw new Error("The fresh matching context could not be read back.");
      }
      localStorage.removeItem("soundheading_draft_profile");
      navigate("/questionnaire?reset=1");
    } catch (_) {
      toast({ title: "Reset could not be confirmed", description: "Reload your profile before retrying. Your saved answers and history are retained.", variant: "destructive" });
    } finally {
      saveInFlight.current = false;
      setSaving(false);
    }
  };

  const handleComplete = async (profileData) => {
    if(saveInFlight.current)return;
    saveInFlight.current=true;
    setSaving(true);
    try {
      profileData = { ...profileData, use_past_likes: usePastLikes };
      const baseline = { ...profile, use_past_likes: pastLikesEnabled(profile) };
      const changedFields = Object.keys(profileData).filter(key => JSON.stringify(profileData[key] ?? null) !== JSON.stringify(baseline[key] ?? null));
      // Never spend a paid refresh merely because the buyer pressed Save twice.
      if (!changedFields.length) {
        toast({ title: "No profile changes", description: "Your MATCH update allowance is unchanged." });
        navigate("/my-matches");
        return;
      }
      const savedResponse = await base44.functions.invoke("save-matching-profile", { profile: profileData });
      if (savedResponse?.data?.profile_save_version !== "profile-save-v1") throw new Error("Profile save acknowledgement is missing.");
      // Questionnaire tier is editable form state, not proof of purchase.
      // Only an authenticated admin may use it as a QA tier override.
      const effectivePlan = isAdmin ? (profileData.match_question_tier || plan) : plan;
      // Editable tier tabs and status metadata do not justify consuming a
      // paid update when no actual buyer needs or constraints changed.
      const changedMatchInputs = isAdmin || changedFields.some(key => !["match_question_tier", "status"].includes(key));
      if (isPaidPlan(effectivePlan) && changedMatchInputs) {
        try {
          await base44.functions.invoke("suggest-boats", { refresh: true });
          toast({ title: "Profile saved and matches updated" });
        } catch (error) {
          toast({ title: "Profile saved; matches were not updated", description: error?.response?.data?.error || "Try updating your matches again from your dashboard.", variant: "destructive" });
        }
      } else if (isPaidPlan(effectivePlan)) {
        toast({ title: "Question set saved", description: "No matching inputs changed; your update allowance is unchanged." });
      } else {
        toast({ title: "Profile saved", description: "Your free results will reflect your saved answers." });
      }
      navigate("/my-matches");
    } catch (e) {
      toast({ title: "Could not update profile", variant: "destructive" });
    } finally {
      saveInFlight.current=false;
      setSaving(false);
    }
  };

  if (!loading && !profile) return <div role="alert">Could not load your profile or question rules. Reload to retry.</div>;

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#071f32]">
      <Navbar />
      <main className="max-w-2xl mx-auto px-4 py-10">
        <div className="mb-6">
          <h1 className="font-heading text-3xl font-semibold text-white">Edit Your Profile</h1>
          <p className="text-slate-200 mt-1">
            Update any detail as your situation changes — budget, storage, timeline, priorities, or needs. You can save at any time. Matching updates follow your package allowance. Existing reports remain unchanged until you regenerate them.
          </p>
        </div>
        <label className="mb-5 flex items-start gap-3 rounded-lg border border-slate-600 p-4 text-slate-100">
          <input type="checkbox" className="mt-1" checked={usePastLikes} disabled={saving} onChange={event => setUsePastLikes(event.target.checked)} />
          <span>Use my past Likes for this search<span className="block text-sm text-slate-300">A small preference for similar characteristics, not the same brand. Your current needs and hard limits come first. Reset turns this off. Applies when you save; matching updates follow your package allowance.</span></span>
        </label>
        <IntroQuestionnaire onComplete={handleComplete} initialProfile={profile} plan={plan} fieldTiers={fieldTiers} saving={saving} submitLabel="Save & Update Matches" />
        {saving && <p className="text-sm text-slate-200 mt-4">Saving…</p>}
        <nav className="mt-6 flex flex-wrap gap-2" aria-label="Profile actions">
          <Button type="button" variant="outline" className={PROFILE_ACTION_STYLE} onClick={() => navigate("/helm")}>Back to My Helm</Button>
          <Button type="button" variant="outline" className={PROFILE_ACTION_STYLE} disabled={saving} onClick={handleReset}>Reset profile</Button>
          <Button type="button" variant="outline" className={PROFILE_ACTION_STYLE} onClick={() => navigate("/profile-interview")}>Profile advisor</Button>
        </nav>
      </main>
    </div>
  );
}