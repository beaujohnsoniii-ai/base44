import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import ListingLink from "@/components/ListingLink";
import { boatLink, googleSearchUrl } from "@/lib/utils";
import { ArrowLeft, Lock, Compass, ExternalLink, Search, Check, AlertCircle, RefreshCw, Clock } from "lucide-react";
import { isPaidPlan } from "@/lib/stages";
import { formatModelPriceGuidance } from "@/lib/modelPriceGuidance";

// Report preview for Find My Boat purchasers. The Find My Boat tier's deliverable
// is the ranked model pool (SuggestedBoat records) — this page presents those models
// as a formal advisory report, with the update counter and 90-day access window.
export default function FindMyBoatReport() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [testTier, setTestTier] = useState(null);
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        if (me.role === "admin") {
          const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: me.id }, "-created_date", 1);
          setTestTier(profiles?.[0]?.match_question_tier || null);
        }
        const sb = await base44.entities.SuggestedBoat.filter({ created_by_id: me.id }, "rank", 50);
        setSuggestions((sb || []).filter((s) => !s.superseded));
      } catch (e) {
        toast({ title: "Could not load your report", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const adminTesting = user?.role === "admin";
  const plan = adminTesting && ["match_plus", "refined_match", "market_match"].includes(testTier) ? testTier : (user?.plan || "free");
  const isPaid = isPaidPlan(plan);
  const updatesUsed = Number(user?.updates_used) || 0;
  const updatesLimit = Number(user?.updates_limit) || 0;
  const updatesLeft = Math.max(0, updatesLimit - updatesUsed);
  const planExpires = user?.plan_expires || null;
  const expiryLabel = planExpires
    ? new Date(planExpires).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
    : null;

  const refresh = async () => {
    if (!adminTesting && updatesLeft <= 0) {
      toast({ title: "No updates remaining", description: "You've used all your matching updates for this cycle.", variant: "destructive" });
      return;
    }
    setRefreshing(true);
    try {
      const res = await base44.functions.invoke("suggest-boats", { refresh: true });
      setSuggestions(res?.data?.suggestions || []);
      const me = await base44.auth.me();
      setUser(me);
      toast({ title: "Models refreshed", description: adminTesting ? "Admin test — no payment or matching update charged." : "One matching update used." });
    } catch (e) {
      toast({ title: "Could not refresh models", variant: "destructive" });
    } finally {
      setRefreshing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!isPaid) {
    return (
      <div className="min-h-screen bg-muted/30">
        <Navbar />
        <main className="max-w-2xl mx-auto px-4 py-20 text-center">
          <Lock className="w-12 h-12 text-muted-foreground mx-auto" />
          <h1 className="font-heading text-2xl font-semibold mt-4">Bosun isn't unlocked yet</h1>
          <p className="text-muted-foreground mt-2">Purchase Bosun to unlock your ranked model report.</p>
          <Button className="mt-6" onClick={() => navigate("/dashboard")}>Go to dashboard</Button>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <Navbar />
      <main className="max-w-3xl mx-auto px-4 py-10 space-y-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <Link to="/dashboard" className="text-sm text-muted-foreground hover:underline flex items-center gap-1">
              <ArrowLeft className="w-4 h-4" /> Dashboard
            </Link>
            <h1 className="font-heading text-3xl font-semibold mt-2">Bosun Report</h1>
            <p className="text-sm text-muted-foreground mt-1">
              {suggestions.length} ranked model{suggestions.length !== 1 ? "s" : ""} matching your profile — directional guidance, not live listings.
            </p>
          </div>
          <Button variant="ghost" size="icon" onClick={refresh} disabled={refreshing || (!adminTesting && updatesLeft <= 0)} title="Refresh matches (uses one update)">
            <RefreshCw className={`w-4 h-4 ${refreshing ? "animate-spin" : ""}`} />
          </Button>
        </div>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <RefreshCw className="w-3.5 h-3.5" />
            {adminTesting ? "Admin testing · no payment required" : <>Updates: {updatesUsed} of {updatesLimit} used{updatesLeft === 0 ? " — limit reached" : ` · ${updatesLeft} left`}</>}
          </span>
          {expiryLabel && (
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              Access through {expiryLabel}
            </span>
          )}
        </div>

        {suggestions.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <Compass className="w-10 h-10 text-muted-foreground mx-auto" />
              <p className="text-muted-foreground mt-3">No models have been generated yet.</p>
              <Button className="mt-4" onClick={refresh} disabled={refreshing}>
                {refreshing ? "Generating…" : "Generate my models"}
              </Button>
            </CardContent>
          </Card>
        ) : (
          suggestions.map((b, i) => (
            <Card key={b.id || i}>
              <CardHeader>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    {b.rank != null && <span className="text-xs font-medium text-muted-foreground">#{b.rank}</span>}
                    <CardTitle className="text-lg flex items-center gap-1">
                      <ListingLink href={boatLink(b)} className="hover:underline flex items-center gap-1">
                        {b.title} <ExternalLink className="w-3.5 h-3.5" />
                      </ListingLink>
                    </CardTitle>
                    <CardDescription className="flex flex-wrap gap-x-3 gap-y-1 mt-1">
                      {[b.make, b.model, b.year].filter(Boolean).join(" ")}
                      {` · ${formatModelPriceGuidance(b)}`}
                      {b.source && b.source !== "N/A" ? ` · ${b.source}` : ""}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                {b.engines && <p className="text-muted-foreground">{b.engines}</p>}
                {b.specs && <p className="text-muted-foreground">{b.specs}</p>}
                <div className="flex flex-wrap items-center gap-2">
                  {typeof b.suitability_score === "number" && (
                    <span className="inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold">
                      SoundHeading Fit {Math.round(b.suitability_score)} / 100
                    </span>
                  )}
                  {b.verification_required?.length > 0 && (
                    <span className="text-xs text-muted-foreground">{b.verification_required.length} item{b.verification_required.length === 1 ? "" : "s"} to verify</span>
                  )}
                </div>
                {b.why_suggested && (
                  <p><span className="font-medium">Why this fits: </span>{b.why_suggested}</p>
                )}
                {b.verification_required?.length > 0 && (
                  <details>
                    <summary className="cursor-pointer list-none text-sm text-muted-foreground underline underline-offset-4 hover:text-foreground focus-visible:outline focus-visible:outline-2 [&::-webkit-details-marker]:hidden">Verification details ({b.verification_required.length})</summary>
                    <ul className="mt-1 space-y-1">
                      {b.verification_required.map((item, j) => (
                        <li key={j} className="flex items-start gap-2 text-foreground/80">
                          <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" /> {item}
                        </li>
                      ))}
                    </ul>
                  </details>
                )}
                {b.match?.summary && (
                  <div className="rounded-lg bg-accent/5 border border-accent/20 p-3 space-y-2">
                    <p className="text-foreground/90">{b.match.summary}</p>
                    {b.match.matches?.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Matches</p>
                        <ul className="mt-1 space-y-1">
                          {b.match.matches.map((m, j) => (
                            <li key={j} className="flex items-start gap-2 text-foreground/80">
                              <Check className="w-3.5 h-3.5 text-accent mt-0.5 shrink-0" /> {m}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {b.match.gaps?.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mt-2">Gaps</p>
                        <ul className="mt-1 space-y-1">
                          {b.match.gaps.map((g, j) => (
                            <li key={j} className="flex items-start gap-2 text-foreground/80">
                              <AlertCircle className="w-3.5 h-3.5 text-destructive mt-0.5 shrink-0" /> {g}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" onClick={() => window.open(googleSearchUrl(b), "_blank")}>
                    <Search className="w-3.5 h-3.5 mr-1.5" /> Find listings
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}

        <p className="text-xs text-muted-foreground">
          These are the strongest matches found within your criteria and the sources reviewed — not a claim of the best boat across the entire market.
          Availability is advertised unless independently confirmed. Remote review cannot establish condition; arrange a survey before purchase.
        </p>
      </main>
    </div>
  );
}