import React, { useEffect, useState, useRef } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import "@/components/dashboard.css";
import "@/components/journey-icons.css";
import { tierInfo, HELM_NAME } from "@/lib/tiers";
import TierLadder from "@/components/TierLadder";
import HelmTools from "@/components/HelmTools";
import CandidatesCollapsible from "@/components/CandidatesCollapsible";

import SuggestedBoatsPanel from "@/components/SuggestedBoatsPanel";
import LikedSearchHistory from "@/components/match/LikedSearchHistory";
import FreeMatchPreview from "@/components/FreeMatchPreview";
import ContradictionBanner from "@/components/ContradictionBanner";
import { normalizePlan, isPaidPlan, PLAN_TIERS } from "@/lib/stages";
import { FileText, ArrowRight, Sparkles, Download, FlaskConical, Home, BarChart3 } from "lucide-react";
import { downloadReportPdf } from "@/lib/report-pdf";
import { saveMatchCandidate, chooseMatchCandidate, ownerRecords } from "@/lib/matchCompareHandoff";
import { profileInputFingerprint } from "../../base44/shared/profile-input-fingerprint.mjs";
import { orderedMatchResults } from "../../base44/shared/listing-intake-allowance.mjs";
import { requestDeadline } from "@/lib/requestDeadline";

const MAX_BOATS = 5;
const MIN_BOATS = 3;

export default function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  useEffect(() => { if (location.hash === "#buyer-profile") navigate("/edit-profile", { replace: true }); }, [location.hash, navigate]);
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [boats, setBoats] = useState([]);
  const [reports, setReports] = useState([]);
  const [suggestedBoats, setSuggestedBoats] = useState([]);
  const [previousSuggestions, setPreviousSuggestions] = useState([]);
  const [suggestionNote, setSuggestionNote] = useState(null);
  const [suggesting, setSuggesting] = useState(false);
  const [refreshingSuggestions, setRefreshingSuggestions] = useState(false);
  const refreshInFlight = useRef(false);
  const resultRequest = useRef(0);
  const [loading, setLoading] = useState(true);
  const purchasing = null; // No checkout attempts until payment security is approved.
  const [prefillBoat, setPrefillBoat] = useState(null);

  const purchased = Array.isArray(user?.purchased_stages) ? user.purchased_stages : [];
  // Display the same entitlement the server enforces. An editable profile
  // questionnaire tier may override it only for an authenticated admin in QA.
  const plan = user?.role === "admin" && profile?.match_question_tier
    ? profile.match_question_tier : (user?.plan || "free");
  const planExpires = user?.plan_expires || null;
  const updatesUsed = Number(user?.updates_used) || 0;
  const updatesLimit = Number(user?.updates_limit) || 0;
  const hasActivation = purchased.includes("activate");
  const isPaid = isPaidPlan(plan);
  const isMarketMatch = normalizePlan(plan) === "market_match";
  const listingEvalsLimit = Number(user?.listing_evals_limit) || 0;
  const listingEvalsUsed = Number(user?.listing_evals_used) || 0;
  const legacyReportStages = ["top_pick", "top_three", "private_advisory", "introductions", "survey_review"];
  const hasLegacyReport = purchased.some((s) => legacyReportStages.includes(s));
  const matchPlusTier = PLAN_TIERS.find((t) => t.id === "match_plus");
  const refinedTier = PLAN_TIERS.find((t) => t.id === "refined_match");
  const marketMatchTier = PLAN_TIERS.find((t) => t.id === "market_match");

  useEffect(() => {
    const request = ++resultRequest.current;
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: me.id }, "-created_date", 1);
        let p = profiles?.[0] || null;
        if (!p) {
          const draft = localStorage.getItem("soundheading_draft_profile");
          if (draft) {
            try {
              const data = JSON.parse(draft);
              data.status = "active";
              const saved = await base44.functions.invoke("save-buyer-profile", { profile: data, only_if_missing: true });
              p = saved?.data?.profile;
              if (!p?.id) throw new Error("Profile save was not confirmed");
              localStorage.removeItem("soundheading_draft_profile");
            } catch (e) {
              /* ignore */
            }
          }
        }
        setProfile(p || null);
        const b = await base44.entities.SavedBoat.filter({ created_by_id: me.id }, "-created_date", 50);
        setBoats(b || []);
        const r = await base44.entities.Report.filter({ created_by_id: me.id }, "-created_date", 50);
        setReports(r || []);

        const sb = await ownerRecords(base44.entities.SuggestedBoat, me.id);
        const allSb = sb || [];
        const fingerprint = p ? await profileInputFingerprint(p) : null;
        const isCurrent = s => !s.superseded && !s.test_profile_id && s.buyer_profile_id === p?.id && s.profile_input_fingerprint === fingerprint;
        const currentSb = orderedMatchResults(allSb.filter(isCurrent));
        const previousSb = allSb.filter(s => !s.test_profile_id && s.created_by_id === me.id && !isCurrent(s));
        if (request !== resultRequest.current) return;
        setSuggestionNote(previousSb.length && !currentSb.length ? "Your profile changed. Your history is retained. Save your current questionnaire to generate matching results." : null);
        setSuggestedBoats(currentSb);
        setPreviousSuggestions(previousSb);
        // Viewing the account never generates matches. Only the explicit update action does.

      } catch (e) {
        toast({ title: "Could not load your data", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    })();
    return () => { resultRequest.current += 1; };
  }, []);

  // Checkout stays closed until payment fulfillment and entitlement security are
  // verified end-to-end. Never mutate paid User fields from the browser, even
  // for admin testing: that would leave a reusable client-side purchase bypass.
  // Isolated admin MATCH QA remains available through /admin/match-qa.
  const handlePurchase = (tier) => {
    if (["match_plus", "refined_match", "market_match"].includes(tier)) {
      navigate("/edit-profile?tier=" + tier);
      return;
    }
    toast({
      title: "Checkout not available yet",
      description: "Payment and account-access security are being validated. No payment has been taken.",
      variant: "destructive",
    });
  };

  const addBoat = async ({ description, url, note }) => {
    if (boats.length >= MAX_BOATS) {
      toast({ title: `Limit reached`, description: `You can save up to ${MAX_BOATS} candidate boats per search.`, variant: "destructive" });
      return false;
    }
    try {
      const res = await requestDeadline(() => base44.functions.invoke("analyze-saved-boat", { description, url, note }), 120000, "Listing research timed out. Your entry was kept. The server may still be processing it; no automatic retry was made.");
      const data = res?.data || {};
      const boat = data.boat || {};
      const match = data.match || null;
      const created = await base44.entities.SavedBoat.create({
        title: boat.title || description,
        url: url || "",
        source: boat.source || "",
        make: boat.make || "",
        model: boat.model || "",
        year: boat.year || null,
        asking_price: boat.asking_price || null,
        engines: boat.engines || "",
        specs: boat.specs || "",
        attraction_comment: note || "",
        match: match || null,
        // A fetched listing is not a paid MATCH evaluation. Set this only
        // when the server actually returned the buyer-specific comparison.
        analyzed: Boolean(match),
      });
      setBoats((prev) => [created, ...prev]);
      if (match) {
        toast({ title: `${boat.title || description} — analyzed`, description: match.summary?.slice(0, 120) || "Match analysis ready." });
      } else {
        toast({ title: `${boat.title || description} — saved`, description: "We researched the boat and saved it." });
      }
      return true;
    } catch (err) {
      toast({
        title: "Could not save boat",
        description: err?.response?.data?.error || err?.message || "Your entry was kept so you can correct it and retry.",
        variant: "destructive",
      });
      return false;
    }
  };

  const removeBoat = async (id) => {
    await base44.entities.SavedBoat.delete(id);
    setBoats((prev) => prev.filter((b) => b.id !== id));
  };

  const updateBoat = async (id, data) => {
    const updated = await base44.entities.SavedBoat.update(id, data);
    setBoats((prev) => prev.map((b) => (b.id === id ? { ...b, ...updated } : b)));
  };

  const handleAddCandidate = async (boat) => {
    if (boats.length >= MAX_BOATS) {
      toast({ title: `Limit reached`, description: `You can save up to ${MAX_BOATS} candidate boats.`, variant: "destructive" });
      return false;
    }
    try {
      const me = await base44.auth.me();
      const created = await saveMatchCandidate(base44, boat, me.id);
      setBoats((prev) => [created, ...prev.filter(b => b.id !== created.id)]);
      toast({ title: `${created.title} saved`, description: "Added to your saved candidates and available in Compare." });
      return true;
    } catch (e) {
      toast({ title: "Could not save suggestion", variant: "destructive" });
      return false;
    }
  };

  const handleChooseCompare = async boat => {
    try {
      const me=await base44.auth.me();
      const result=await chooseMatchCandidate(base44,boat,me.id);
      setBoats(current=>[result.candidate,...current.filter(b=>b.id!==result.candidate.id)]);
      toast({title:result.selected?"Saved to Compare":"Saved for later",description:result.selection_full?"Three models are already selected. Change your shortlist in Compare.":"Your model and original Match link are saved to Compare. Use Find inside Match to look for boats for sale."});
      navigate("/compare"); return true;
    } catch {toast({title:"Could not confirm Compare selection",description:"Your saved candidates are retained. Retry choosing the model.",variant:"destructive"});return false;}
  };

  const refreshSuggestions = async () => {
    if (refreshInFlight.current) return;
    refreshInFlight.current = true;
    const request = ++resultRequest.current;
    setRefreshingSuggestions(true);
    try {
      const res = await base44.functions.invoke("suggest-boats", { refresh: true });
      if (request !== resultRequest.current) return;
      if (!Array.isArray(res?.data?.suggestions)) throw new Error("The server did not confirm a saved match pool.");
      setSuggestedBoats(res.data.suggestions);
      setSuggestionNote(res?.data?.note || null);
      toast({ title: "Your matches are updated" });
      // Refresh the server-owned allowance and archived results without generating again.
      try {
        const me = await base44.auth.me();
        const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: me.id }, "-created_date", 1);
        if (request !== resultRequest.current) return;
        setUser(me);
        setProfile(profiles?.[0] || null);
        const currentFingerprint = profiles?.[0] ? await profileInputFingerprint(profiles[0]) : null;
        if (currentFingerprint !== res.data.profile_input_fingerprint) {
          setSuggestedBoats([]);
          setSuggestionNote("Your profile changed after generation. These saved results belong to the previous answers; update matches again.");
        }
        const allSb = await ownerRecords(base44.entities.SuggestedBoat, me.id);
        if (request !== resultRequest.current) return;
        setPreviousSuggestions((allSb || []).filter(s => s.created_by_id === me.id && !s.test_profile_id && (s.superseded || s.buyer_profile_id !== profiles?.[0]?.id || s.profile_input_fingerprint !== currentFingerprint)));
      } catch {
        toast({ title: "Matches updated; account details could not refresh", description: "Reload the dashboard to see your latest allowance and previous results." });
      }
    } catch (e) {
      toast({ title: "Could not update your matches", description: e?.response?.data?.error || "Your existing results are still available. Please try again.", variant: "destructive" });
    } finally {
      refreshInFlight.current = false;
      if (request === resultRequest.current) setRefreshingSuggestions(false);
    }
  };

  const tier = tierInfo(plan);
  const tierId = normalizePlan(plan);
  const expiryLabel = planExpires
    ? new Date(planExpires).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
    : null;
  const helmLead = !profile
    ? "Answer a few questions and your matches appear here."
    : tierId === "free" ? "Your boat types to explore, your buyer profile and your saved boats."
    : tierId === "market_match" ? "Your finalists, your buyer profile and your saved boats."
    : "Your match report, your buyer profile and your saved boats.";

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="sh-helm-page min-h-screen">
      <Navbar />
      <main className="max-w-6xl mx-auto px-4 pt-0 pb-6 md:pb-8 space-y-6">
        <section className="sh-dashboard-customer space-y-5">
        <header className="sh-dashboard-hero">
          <div>
          <p className="sh-status__eyebrow">{tier.name} · {tier.priceLabel}{isPaid && expiryLabel ? ` · access through ${expiryLabel}` : ""}</p>
          <h1 className="font-display text-3xl md:text-4xl">{HELM_NAME}</h1>
          <p className="text-sm leading-relaxed">{helmLead} We work for the buyer. No dealer pays to rank higher in your matches.</p>
          {profile && <nav className="sh-helm-banner-tools" aria-label="My Helm shortcuts">
            <Link to="/edit-profile" aria-label="View or edit buyer profile">Profile</Link>
            <a href="#helm-tools">Tools</a>
          </nav>}
          </div>
        </header>
        <div id="journey-match" className="space-y-5">

        {/* No profile yet: the one thing to do is the questionnaire. */}
        {!profile && (
        <section className="rounded-xl border bg-background p-5 md:p-6" aria-label="Where you are">
          <div className="sh-status">
            <div>
              <h2 className="sh-status__title">Start with a few questions</h2>
              <p className="text-sm text-muted-foreground mt-2">Tell us how you'll use the boat, where, and with whom. It takes a few minutes and you can change any answer later. Your matches appear right here.</p>
            </div>
            <div className="sh-status__actions">
              <Button onClick={() => navigate("/questionnaire")}>Start the questionnaire <ArrowRight className="w-4 h-4 ml-2" /></Button>
            </div>
          </div>
        </section>
        )}

        {profile?.contradiction_flag?.flagged && (
          <ContradictionBanner
            profile={profile}
            onResolved={(suggestions) => {
              setSuggestedBoats(suggestions);
              (async () => {
                try {
                  const me = await base44.auth.me();
                  const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: me.id }, "-created_date", 1);
                  if (profiles?.[0]) setProfile(profiles[0]);
                  const allSb = await ownerRecords(base44.entities.SuggestedBoat, me.id);
                  setPreviousSuggestions((allSb || []).filter((s) => s.superseded));
                } catch (e) { /* ignore */ }
              })();
            }}
          />
        )}

        {profile && <section id="match-results" className={isPaid ? "" : "sh-helm-surface"} aria-label={tier.resultLabel}>
        {!isPaid ? <FreeMatchPreview key={JSON.stringify(profile)} testing={user?.role === "admin"} profile={profile} onChoose={handlePurchase} onEdit={() => navigate("/edit-profile")} /> : <SuggestedBoatsPanel
          listingIntakeDataEnv="owner-prod"
          suggestions={suggestedBoats}
          previousSuggestions={previousSuggestions}
          loading={suggesting}
          plan={plan}
          adminTesting={user?.role === "admin"}
          updatesUsed={updatesUsed}
          updatesLimit={updatesLimit}
          planExpires={planExpires}
          firstPaidGenerationAvailable={user?.paid_pool_generated === false}
          note={suggestionNote}
          onPurchase={handlePurchase}
          purchasing={purchasing}
          onRefresh={refreshSuggestions}
          refreshing={refreshingSuggestions}
          onAddCandidate={handleAddCandidate}
          onChooseCompare={handleChooseCompare}
          boats={boats}
          onAddBoat={addBoat}
          onRemoveBoat={removeBoat}
          onUpdateBoat={updateBoat}
          maxBoats={MAX_BOATS}
          minBoats={MIN_BOATS}
          onAnalyze={() => navigate("/boat-analysis")}
          prefillBoat={prefillBoat}
        />}
        <LikedSearchHistory suggestions={previousSuggestions} ownerId={user?.id} />
        </section>}

        {/* Paid tiers carry saved boats inside the results panel; Deckhand keeps them here. */}
        {profile && !isPaid && <section id="saved-candidates" className="sh-helm-surface" aria-label="Saved candidates">
          <CandidatesCollapsible boats={boats} onAdd={addBoat} onRemove={removeBoat} onUpdate={updateBoat} maxBoats={MAX_BOATS} minBoats={MIN_BOATS} onAnalyze={() => navigate("/boat-analysis")} prefill={prefillBoat} />
        </section>}

        {profile && (
        <section className="sh-helm-surface rounded-xl border bg-background p-5" aria-label="Save listings you find">
          <h2 className="font-heading text-lg font-semibold">Found a listing?</h2>
          <p className="text-sm text-muted-foreground mt-2 max-w-2xl">Paste listing URLs in Compare (up to three per saved boat). Links save to your account when you choose Compare. Page-text paste is optional backup if import fails — we never invent scrape success.</p>
          <div className="mt-4">
            <Button variant="outline" onClick={() => navigate("/compare")}>Open Compare <ArrowRight className="w-4 h-4 ml-2" /></Button>
          </div>
        </section>
        )}

        {profile && <section id="helm-tools" className="sh-helm-tools" aria-label="Tools">
          <HelmTools plan={plan} />
        </section>}

        {user?.role !== "admin" && <TierLadder plan={plan} />}

        {/* Legacy reports — access preserved for buyers who purchased before the redesign */}
        {hasLegacyReport && (
          <div className="sh-helm-surface">
            <h2 className="font-heading text-lg font-semibold mb-1">Your reports</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Reports from your earlier purchase remain available here.
            </p>
            <div className="flex flex-wrap gap-2">
              {legacyReportStages.filter((id) => purchased.includes(id)).map((id) => {
                const r = reports.find((x) => x.type === id);
                const name = id === "top_pick" ? "Find My Boat"
                  : id === "top_three" ? "Top Four Comparison"
                  : id === "private_advisory" ? "Private Advisory"
                  : id === "introductions" ? "Introductions"
                  : "Survey Review";
                return (
                  <div key={id} className="flex gap-2">
                    <Button variant="outline" onClick={() => navigate(`/report/${id}`)}>
                      <FileText className="w-4 h-4 mr-2" /> {name} <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                    {r?.content && (
                      <Button variant="outline" size="icon" onClick={() => downloadReportPdf(name, id, r.content)} title="Download PDF">
                        <Download className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        </div>
        </section>

        {user?.role === "admin" && (
          <Card id="admin" className="border-primary/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base"><Sparkles className="w-4 h-4 text-primary" /> Admin</CardTitle>
              <CardDescription>Internal research and testing tools.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <section aria-label="Question-set testing">
                <h3 className="font-heading font-semibold mb-3">Question-set testing</h3>
        <section id="admin-question-sets" className="rounded-xl border bg-background p-6">
          <h2 className="font-heading text-xl font-semibold">Choose a question set</h2>
          <p className="text-sm text-muted-foreground mt-2 mb-4">{user?.role === "admin" ? "Admin-only testing: all four question sets are available. Test generations do not require payment." : "You can review the four question sets as we prepare to launch. Paid model generation and checkout are not available for new purchases yet. No payment will be taken."}</p>
          <div className="flex flex-wrap gap-3">
            {[["free", "Deckhand · Free"], ["match_plus", "Bosun · $9"], ["refined_match", "First Mate · $29"], ["market_match", "Captain · $99"]].map(([id, label]) => (
              <Button key={id} variant={plan === id ? "default" : "outline"} onClick={() => navigate("/edit-profile?tier=" + id)}>{label}</Button>
            ))}
          </div>
        </section>
              </section>
              <section aria-label="Internal research and testing tools">
                <h3 className="font-heading font-semibold mb-3">Internal research and testing tools</h3>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" onClick={() => navigate("/admin/buyer-launch-test")}>First-time buyer test · no payment</Button>
                <Button variant="outline" onClick={() => navigate("/admin/research-monitor")}>
                  <ArrowRight className="w-4 h-4 mr-2" /> Research Monitor
                </Button>
                <Button variant="outline" onClick={() => navigate("/admin/question-config")}> 
                  <ArrowRight className="w-4 h-4 mr-2" /> Paid-only questions
                </Button>
                <Button variant="outline" onClick={() => navigate("/admin/relabel")}>
                  <ArrowRight className="w-4 h-4 mr-2" /> Review flagged manufacturers
                </Button>
                <Button variant="outline" onClick={() => navigate("/admin/test-profiles")}>
                  <FlaskConical className="w-4 h-4 mr-2" /> Test profile simulator
                </Button>
                <Button variant="outline" onClick={() => navigate("/admin/funnel-distribution")}>
                  <BarChart3 className="w-4 h-4 mr-2" /> Funnel distribution
                </Button>
                <Button variant="secondary" onClick={() => navigate("/")}>
                  <Home className="w-4 h-4 mr-2" /> Exit to home
                </Button>
              </div>
              </section>
            </CardContent>
          </Card>
        )}

        <p className="text-xs text-muted-foreground">
          Sound Heading’s strongest coverage is recreational and coastal powerboats. Prices are pilot pricing for testing, not settled rates.
        </p>
      </main>
    </div>
  );
}