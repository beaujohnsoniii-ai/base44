import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowLeft, MessageSquareWarning, ThumbsDown, ThumbsUp, Clock, BarChart3 } from "lucide-react";
import moment from "moment";

const REASON_LABELS = {
  doesnt_fit_profile: "Doesn't fit my profile",
  missed_my_answers: "Missed how I answered",
  inaccurate_specs: "Inaccurate specifications",
  missing_info: "Missing information",
  other: "Other",
};

const REPORT_TYPE_LABELS = {
  top_pick: "Find My Boat",
  top_three: "Model Shortlist",
  preliminary: "Preliminary Feedback",
  private_advisory: "Private Advisory",
  introductions: "Introductions",
  survey_review: "Survey Review",
};

const STATUS_STYLES = {
  pending: "bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-950/30 dark:text-amber-500 dark:border-amber-800/50",
  reviewing: "bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-950/30 dark:text-blue-500 dark:border-blue-800/50",
  resolved: "bg-green-100 text-green-700 border-green-200 dark:bg-green-950/30 dark:text-green-500 dark:border-green-800/50",
};

export default function AdminFeedbackAnalytics() {
  const [feedback, setFeedback] = useState([]);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [fb, reps] = await Promise.all([
          base44.entities.ReportFeedback.list("-created_date", 500),
          base44.entities.Report.list("-created_date", 500),
        ]);
        setFeedback(fb || []);
        setReports((reps || []).filter((r) => !r.test_profile_id));
      } catch (e) {
        console.error("Load feedback analytics error", e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const stats = useMemo(() => {
    const totalReports = reports.length;
    const totalFeedback = feedback.length;
    const rejectionRate = totalReports > 0 ? (totalFeedback / totalReports) * 100 : 0;
    const pending = feedback.filter((f) => f.status === "pending").length;

    const reasonCounts = {};
    for (const f of feedback) {
      reasonCounts[f.reason] = (reasonCounts[f.reason] || 0) + 1;
    }

    const reportTypeStats = {};
    for (const r of reports) {
      const type = r.type || "unknown";
      if (!reportTypeStats[type]) reportTypeStats[type] = { total: 0, feedback: 0 };
      reportTypeStats[type].total++;
    }
    for (const f of feedback) {
      const type = f.report_type || "unknown";
      if (!reportTypeStats[type]) reportTypeStats[type] = { total: 0, feedback: 0 };
      reportTypeStats[type].feedback++;
    }

    return { totalReports, totalFeedback, rejectionRate, pending, reasonCounts, reportTypeStats };
  }, [feedback, reports]);

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const acceptedCount = stats.totalReports - stats.totalFeedback;
  const sortedReasons = Object.entries(stats.reasonCounts).sort((a, b) => b[1] - a[1]);
  const sortedReportTypes = Object.entries(stats.reportTypeStats).sort((a, b) => b[1].feedback - a[1].feedback);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="font-display text-2xl font-semibold flex items-center gap-2">
              <BarChart3 className="w-6 h-6" /> Feedback Analytics
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              How often buyers accept or reject advisory reports, and what they say is wrong — so you can keep refining the logic.
            </p>
          </div>
          <a href="/admin/test-profiles" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground shrink-0">
            <ArrowLeft className="w-4 h-4" /> Test Simulator
          </a>
        </div>

        {stats.totalReports === 0 && stats.totalFeedback === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              No reports or feedback yet. Once buyers start receiving reports and submitting feedback, acceptance and rejection patterns will appear here.
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Summary cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <ThumbsUp className="w-4 h-4 text-green-600" />
                    <p className="text-xs text-muted-foreground">Implicit Acceptance</p>
                  </div>
                  <span className="text-2xl font-semibold tabular-nums">{(100 - stats.rejectionRate).toFixed(1)}%</span>
                  <p className="text-xs text-muted-foreground mt-1">{acceptedCount} of {stats.totalReports} reports</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <ThumbsDown className="w-4 h-4 text-red-600" />
                    <p className="text-xs text-muted-foreground">Rejection Rate</p>
                  </div>
                  <span className="text-2xl font-semibold tabular-nums">{stats.rejectionRate.toFixed(1)}%</span>
                  <p className="text-xs text-muted-foreground mt-1">{stats.totalFeedback} feedback submissions</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <MessageSquareWarning className="w-4 h-4 text-muted-foreground" />
                    <p className="text-xs text-muted-foreground">Total Reports</p>
                  </div>
                  <span className="text-2xl font-semibold tabular-nums">{stats.totalReports}</span>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Clock className="w-4 h-4 text-amber-600" />
                    <p className="text-xs text-muted-foreground">Pending Review</p>
                  </div>
                  <span className="text-2xl font-semibold tabular-nums">{stats.pending}</span>
                </CardContent>
              </Card>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {/* Reason breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Rejection Reasons</CardTitle>
                  <CardDescription>What buyers say is wrong with the reports</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {sortedReasons.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No feedback submitted yet.</p>
                  ) : (
                    sortedReasons.map(([reason, count]) => {
                      const pct = stats.totalFeedback > 0 ? (count / stats.totalFeedback) * 100 : 0;
                      return (
                        <div key={reason} className="space-y-1">
                          <div className="flex items-center justify-between text-sm">
                            <span className="font-medium">{REASON_LABELS[reason] || reason}</span>
                            <span className="text-muted-foreground tabular-nums">{count} ({pct.toFixed(0)}%)</span>
                          </div>
                          <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                            <div className="h-full bg-accent rounded-full transition-all" style={{ width: `${pct}%` }} />
                          </div>
                        </div>
                      );
                    })
                  )}
                </CardContent>
              </Card>

              {/* Report type breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Rejection Rate by Report Type</CardTitle>
                  <CardDescription>Which report tiers get the most pushback</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {sortedReportTypes.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No reports generated yet.</p>
                  ) : (
                    sortedReportTypes.map(([type, data]) => {
                      const rate = data.total > 0 ? (data.feedback / data.total) * 100 : 0;
                      return (
                        <div key={type} className="flex items-center justify-between text-sm border-b border-border last:border-0 pb-2 last:pb-0">
                          <span className="font-medium">{REPORT_TYPE_LABELS[type] || type}</span>
                          <div className="flex items-center gap-3">
                            <span className="text-muted-foreground tabular-nums text-xs">
                              {data.feedback}/{data.total}
                            </span>
                            <Badge
                              variant="outline"
                              className={`tabular-nums text-xs ${rate > 0 ? "border-red-200 text-red-700 dark:border-red-800/50 dark:text-red-500" : "border-green-200 text-green-700 dark:border-green-800/50 dark:text-green-500"}`}
                            >
                              {rate.toFixed(0)}%
                            </Badge>
                          </div>
                        </div>
                      );
                    })
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Recent feedback */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Recent Feedback</CardTitle>
                <CardDescription>What buyers are telling you — read these to refine the advisor logic</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {feedback.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No feedback submitted yet.</p>
                ) : (
                  feedback.slice(0, 15).map((f) => (
                    <div key={f.id} className="border-l-2 border-border pl-3 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="text-xs">
                          {REASON_LABELS[f.reason] || f.reason}
                        </Badge>
                        {f.report_type && (
                          <Badge variant="secondary" className="text-xs">
                            {REPORT_TYPE_LABELS[f.report_type] || f.report_type}
                          </Badge>
                        )}
                        <Badge variant="outline" className={`text-xs ${STATUS_STYLES[f.status] || ""}`}>
                          {f.status}
                        </Badge>
                        <span className="text-xs text-muted-foreground ml-auto">
                          {moment(f.created_date).format("MMM D, h:mm a")}
                        </span>
                      </div>
                      {f.details && <p className="text-sm leading-relaxed">{f.details}</p>}
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}