import React, { useEffect, useRef, useState } from "react";
import JourneyHeader from "@/components/JourneyHeader";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Navbar from "@/components/Navbar";
import MessageBubble from "@/components/agents/MessageBubble";
import { Send, Loader2 } from "lucide-react";

const AGENT_NAME = "stage_guide";

export default function StageGuide() {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [starting, setStarting] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    let unsubscribe = null;
    (async () => {
      try {
        await base44.auth.me();
        const existing = await base44.agents.listConversations({ q: { agent_name: AGENT_NAME }, sort: "-updated_date", limit: 1 });
        let conv = Array.isArray(existing) && existing.length > 0 ? existing[0] : null;
        if (!conv) {
          conv = await base44.agents.createConversation({
            agent_name: AGENT_NAME,
            metadata: { name: "Stage guide" },
          });
        } else {
          conv = await base44.agents.getConversation(conv.id);
        }
        setConversation(conv);
        setMessages(conv.messages || []);
        setError("");
        setStarting(false);
        unsubscribe = base44.agents.subscribeToConversation(conv.id, (data) => {
          setMessages(data.messages || []);
          setSending(false);
        });
      } catch (e) {
        setError("Unable to start the journey guide. Check your connection and sign-in, then reload to retry.");
        setStarting(false);
      }
    })();
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || sending || !conversation) return;
    setInput("");
    setSending(true);
    setError("");
    try {
      const updated = await base44.agents.addMessage(conversation, { role: "user", content: text });
      setConversation(updated);
    } catch (e) {
      setInput(text);
      setError("Message could not be sent. Your text has been restored; try again.");
      setSending(false);
    }
  };

  const assistantBusy = sending || messages.some(
    (m) => m.role === "assistant" && (m.tool_calls?.some((tc) => ["pending", "running", "in_progress"].includes(tc.status)))
  );

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col sh-journey-shell sh-dashboard-customer">
      <Navbar />
      <div className="max-w-6xl w-full mx-auto px-4 pt-6 md:pt-8 space-y-6"><JourneyHeader stage="Guide" intro="Expert guidance through every step of the SoundHeading process." /></div>
      <main className="max-w-3xl w-full mx-auto px-4 py-6 flex-1 flex flex-col">
        <h2 className="font-heading text-xl font-semibold mb-4">Your conversation</h2>

        {error && (
          <div role="alert" className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-900">
            {error}
            {!conversation && <Button variant="outline" size="sm" className="ml-3" onClick={() => window.location.reload()}>Reload</Button>}
          </div>
        )}
        <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-4 pb-4">
          {starting ? (
            <div className="flex items-center justify-center py-12 text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin mr-2" /> Starting your session…
            </div>
          ) : messages.length === 0 ? (
            <div className="flex items-center justify-center py-12 text-muted-foreground text-sm">
              Send a message to begin.
            </div>
          ) : (
            messages.map((m, idx) => <MessageBubble key={idx} message={m} />)
          )}
          {assistantBusy && !starting && (
            <div className="flex justify-start">
              <div className="rounded-2xl rounded-bl-sm bg-card border border-border px-4 py-3">
                <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
              </div>
            </div>
          )}
        </div>

        <div className="sticky bottom-0 bg-muted/30 pt-2 pb-2">
          <div className="flex items-end gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Ask about any stage of the process…"
              disabled={starting || sending || !conversation}
              className="h-12"
            />
            <Button size="icon" className="h-12 w-12" onClick={handleSend} disabled={!input.trim() || starting || sending || !conversation}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}