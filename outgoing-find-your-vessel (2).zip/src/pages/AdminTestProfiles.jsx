import React, { useState, useEffect, useCallback } from "react";
import { base44Test, invokeTestFunction } from "@/lib/base44TestClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, FlaskConical, ExternalLink, AlertCircle, RotateCw, FileText, Anchor, LineChart, BarChart3, Sparkles } from "lucide-react";
import GradeInput from "@/components/GradeInput";

const SIZE_LABELS = {
  under_18: "Under 18 ft",
  "18_24": "18–24 ft",
  "24_30": "24–30 ft",
  "30_40": "30–40 ft",
  "40_50": "40–50 ft",
  "50_plus": "50+ ft",
};

const STORAGE_LABELS = {
  trailer: "Trailer",
  marina_slip: "Marina slip",
  mooring: "Mooring",
  dry_stack: "Dry stack",
  rack_storage: "Rack storage",
  lift_kept: "Lift kept",
  private_dock: "Private dock",
  not_sure: "Not sure",
};

function ProfileSummary({ profile }) {
  const weights = profile.activity_weights || {};
  const weightEntries = Object.entries(weights).filter(([, v]) => v > 0);

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2 text-sm">
        <div><span className="text-muted-foreground">Role:</span> <span className="font-medium capitalize">{profile.buyer_role}</span></div>
        <div><span className="text-muted-foreground">Vessel:</span> <span className="font-medium capitalize">{profile.vessel_class}</span></div>
        <div><span className="text-muted-foreground">Size:</span> <span className="font-medium">{SIZE_LABELS[profile.boat_size_range] || profile.boat_size_range}</span></div>
        <div><span className="text-muted-foreground">Area:</span> <span className="font-medium">{profile.operating_area}</span></div>
        <div><span className="text-muted-foreground">Experience:</span> <span className="font-medium capitalize">{profile.experience_level}</span></div>
        <div><span className="text-muted-foreground">Prev. owned:</span> <span className="font-medium">{profile.previously_owned_boats || "—"}</span></div>
        <div><span className="text-muted-foreground">Passengers:</span> <span className="font-medium">{profile.passenger_count}</span></div>
        <div><span className="text-muted-foreground">Family use:</span> <span className="font-medium">{profile.family_use || "—"}</span></div>
        <div><span className="text-muted-foreground">Overnight:</span> <span className="font-medium">{profile.overnight_requirements || "—"}</span></div>
        <div><span className="text-muted-foreground">Storage:</span> <span className="font-medium">{STORAGE_LABELS[profile.storage] || profile.storage}</span></div>
        <div><span className="text-muted-foreground">Storage cap:</span> <span className="font-medium">{profile.storage_capacity || "—"}</span></div>
        <div><span className="text-muted-foreground">Draft:</span> <span className="font-medium">{profile.draft || "—"}</span></div>
        <div><span className="text-muted-foreground">Towing:</span> <span className="font-medium">{profile.towing || "—"}</span></div>
        <div><span className="text-muted-foreground">Budget:</span> <span className="font-medium">${(profile.purchase_budget_min || 0).toLocaleString()} – ${(profile.purchase_budget_max || 0).toLocaleString()}</span></div>
        <div><span className="text-muted-foreground">Annual:</span> <span className="font-medium">${(profile.annual_ownership_budget || 0).toLocaleString()}/yr</span></div>
        <div><span className="text-muted-foreground">Timeframe:</span> <span className="font-medium capitalize">{(profile.ownership_timeframe || "").replace(/_/g, " ")}</span></div>
        <div><span className="text-muted-foreground">Horizon:</span> <span className="font-medium capitalize">{(profile.ownership_horizon || "").replace(/_/g, " ")}</span></div>
        <div><span className="text-muted-foreground">Project boats:</span> <span className="font-medium">{profile.open_to_project_boats ? "Yes" : "No"}</span></div>
      </div>

      {(profile.must_haves || profile.preferences || profile.unacceptable_compromises) && (
        <div className="grid sm:grid-cols-3 gap-x-4 gap-y-2 text-sm pt-1">
          {profile.must_haves && <div><span className="text-muted-foreground">Must-haves:</span> <span className="font-medium">{profile.must_haves}</span></div>}
          {profile.preferences && <div><span className="text-muted-foreground">Preferences:</span> <span className="font-medium">{profile.preferences}</span></div>}
          {profile.unacceptable_compromises && <div><span className="text-muted-foreground">Unacceptable:</span> <span className="font-medium">{profile.unacceptable_compromises}</span></div>}
        </div>
      )}

      {profile.research_notes && (
        <div>
          <p className="text-xs text-muted-foreground mb-1">Research notes</p>
          <p className="text-sm whitespace-pre-wrap">{profile.research_notes}</p>
        </div>
      )}

      <div>
        <p className="text-xs text-muted-foreground mb-1">Activities</p>
        <div className="flex flex-wrap gap-1.5">
          {weightEntries.map(([act, w]) => (
            <Badge key={act} variant="secondary" className="text-xs">{act} {w}%</Badge>
          ))}
        </div>
      </div>

      <div>
        <p className="text-xs text-muted-foreground mb-1">Priorities (ranked)</p>
        <ol className="text-sm space-y-0.5">
          {(profile.priorities || []).map((p, i) => (
            <li key={i} className="flex gap-2">
              <span className="text-muted-foreground tabular-nums">{i + 1}.</span>
              <span>{p}</span>
            </li>
          ))}
        </ol>
      </div>

      {Array.isArray(profile.preferred_manufacturers) && profile.preferred_manufacturers.length > 0 && (
        <div>
          <p className="text-xs text-muted-foreground mb-1">Preferred brands</p>
          <div className="flex flex-wrap gap-1.5">
            {profile.preferred_manufacturers.map((name) => (
              <Badge key={name} variant="outline" className="text-xs border-accent/50 text-accent">{name}</Badge>
            ))}
          </div>
        </div>
      )}

      {profile.contradiction_flag?.flagged && (
        <div className="border border-amber-400/50 bg-amber-50 dark:bg-amber-950/20 rounded-lg p-3 space-y-1.5">
          <p className="text-xs font-medium text-amber-700 dark:text-amber-500 flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5" /> Potential issue flagged
          </p>
          <p className="text-xs text-amber-800 dark:text-amber-300">{profile.contradiction_flag.explanation}</p>
          {Array.isArray(profile.contradiction_flag.conflicts) && profile.contradiction_flag.conflicts.length > 0 && (
            <ul className="text-xs text-amber-700 dark:text-amber-400 space-y-0.5">
              {profile.contradiction_flag.conflicts.map((c, i) => <li key={i}>• {c}</li>)}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

function SuggestionCard({ boat }) {
  const match = boat.match || {};
  return (
    <div className="border border-border rounded-lg p-3 space-y-2 bg-muted/30">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-medium text-sm">{boat.title}</p>
          {Number(boat.price_range_min) > 0 && Number(boat.price_range_max) >= Number(boat.price_range_min) ? <p className="text-xs text-muted-foreground">Estimated model range: ${Number(boat.price_range_min).toLocaleString()}–${Number(boat.price_range_max).toLocaleString()}</p> : <p className="text-xs text-muted-foreground">Model pricing requires verification</p>}
        </div>
        <div className="text-right shrink-0">
          <span className="text-xs text-muted-foreground block">Rank {boat.rank}</span>
          {typeof boat.suitability_score === "number" && <span className="text-xs font-semibold">Fit {Math.round(boat.suitability_score)}/100</span>}
        </div>
      </div>
      {(boat.engines || boat.specs) && <p className="text-xs text-muted-foreground">{[boat.engines, boat.specs].filter(Boolean).join(" · ")}</p>}
      {boat.why_suggested && <p className="text-xs leading-relaxed">{boat.why_suggested}</p>}
      {match.summary && <p className="text-xs italic text-muted-foreground">{match.summary}</p>}
      {match.matches?.length > 0 && (
        <div>
          <p className="text-xs font-medium text-green-700 dark:text-green-600 mb-0.5">Matches</p>
          <ul className="text-xs space-y-0.5">{match.matches.map((m, i) => <li key={i} className="text-muted-foreground">• {m}</li>)}</ul>
        </div>
      )}
      {match.gaps?.length > 0 && (
        <div>
          <p className="text-xs font-medium text-amber-700 dark:text-amber-600 mb-0.5">Gaps</p>
          <ul className="text-xs space-y-0.5">{match.gaps.map((g, i) => <li key={i} className="text-muted-foreground">• {g}</li>)}</ul>
        </div>
      )}
      {boat.verification_required?.length > 0 && (
        <div>
          <p className="text-xs font-medium text-amber-700 dark:text-amber-600 mb-0.5">Verification required</p>
          <ul className="text-xs space-y-0.5">{boat.verification_required.map((v, i) => <li key={i} className="text-muted-foreground">• {v}</li>)}</ul>
        </div>
      )}
      {boat.link && (
        <a href={boat.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-accent hover:underline">
          <ExternalLink className="w-3 h-3" /> Find listings
        </a>
      )}
    </div>
  );
}

function PaidReportCard({ report }) {
  const content = report?.content || {};
  const recommendations = content.recommendations || [];
  return (
    <div className="border border-border rounded-lg p-3 space-y-2 bg-muted/30">
      <p className="text-xs font-medium flex items-center gap-1.5"><FileText className="w-3.5 h-3.5" /> Captain Report (up to 3 models)</p>
      {content.overall_assessment && <p className="text-xs leading-relaxed">{content.overall_assessment}</p>}
      {recommendations.map((rec, i) => (
        <div key={i} className="border-l-2 border-border pl-2 space-y-1">
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-medium">{rec.title}</p>
            <span className="text-xs text-muted-foreground shrink-0">{rec.match_strength}</span>
          </div>
          {rec.fit_reasons?.length > 0 && (
            <ul className="text-xs space-y-0.5">{rec.fit_reasons.map((f, j) => <li key={j} className="text-green-700 dark:text-green-600">• {f}</li>)}</ul>
          )}
          {rec.compromises?.length > 0 && (
            <ul className="text-xs space-y-0.5">{rec.compromises.map((c, j) => <li key={j} className="text-amber-700 dark:text-amber-600">• {c}</li>)}</ul>
          )}
          {rec.cost_analysis?.annual_ownership_range && (
            <p className="text-xs text-muted-foreground">Ownership: {rec.cost_analysis.annual_ownership_range}</p>
          )}
        </div>
      ))}
      {content.comparison && <p className="text-xs italic text-muted-foreground">{content.comparison}</p>}
    </div>
  );
}

export default function AdminTestProfiles() {
  const [profiles, setProfiles] = useState([]);
  const [suggestionsByProfile, setSuggestionsByProfile] = useState({});
  const [reportsByProfile, setReportsByProfile] = useState({});
  const [grades, setGrades] = useState([]);
  const [running, setRunning] = useState(false);
  const [runStep, setRunStep] = useState("");
  const [error, setError] = useState(null);
  const [initialLoading, setInitialLoading] = useState(true);

  const loadAll = useCallback(async () => {
    try {
      const [profs, suggs, reps, grds] = await Promise.all([
        base44Test.entities.BuyerProfile.list("-created_date", 50),
        base44Test.entities.SuggestedBoat.list("-created_date", 200),
        base44Test.entities.Report.list("-created_date", 50),
        base44Test.entities.TestGrade.list("-created_date", 500),
      ]);

      setProfiles(profs || []);
      setGrades(grds || []);

      const suggMap = {};
      for (const s of (suggs || [])) {
        const pid = s.test_profile_id;
        if (!pid) continue;
        if (!suggMap[pid]) suggMap[pid] = [];
        suggMap[pid].push(s);
      }
      for (const pid in suggMap) {
        suggMap[pid].sort((a, b) => (a.rank || 0) - (b.rank || 0));
      }
      setSuggestionsByProfile(suggMap);

      const repMap = {};
      for (const r of (reps || [])) {
        const pid = r.test_profile_id;
        if (!pid) continue;
        repMap[pid] = r;
      }
      setReportsByProfile(repMap);
    } catch (e) {
      console.error("Load test data error", e);
    } finally {
      setInitialLoading(false);
    }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const runFullTest = async () => {
    setRunning(true);
    setError(null);
    try {
      setRunStep("Generating profiles…");
      await invokeTestFunction("generate-test-profiles", { phase: "profiles" });
      await loadAll();
    } catch (e) {
      console.error("Generate profiles error", e);
      setError(e?.message || "Failed to generate profiles");
    } finally {
      setRunning(false);
      setRunStep("");
    }
  };

  const findGrade = (profileId) => {
    return grades.find((g) => g.phase === "overall" && g.profile_id === profileId);
  };

  if (initialLoading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="font-display text-2xl font-semibold flex items-center gap-2">
              <FlaskConical className="w-6 h-6" /> Test Profile Simulator
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Run a full test — profiles, suggestions, and paid reports — then grade the whole batch in one pass.
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <a href="/admin/match-qa" className="inline-flex items-center gap-1.5 text-sm font-medium text-accent hover:underline">
              <Sparkles className="w-4 h-4" /> MATCH QA
            </a>
            <a href="/admin/feedback-analytics" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
              <BarChart3 className="w-4 h-4" /> Feedback
            </a>
            <a href="/admin/grade-trends" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
              <LineChart className="w-4 h-4" /> Grade Trends
            </a>
          </div>
        </div>

        {/* Action button */}
        <div className="flex flex-wrap gap-2">
          <Button onClick={runFullTest} disabled={running}>
            {running ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RotateCw className="w-4 h-4 mr-2" />}
            {running ? (runStep || "Running…") : "Generate profiles"}
          </Button>
        </div>

        <Card className="border-accent/30 bg-accent/5">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">MATCH recommendation testing has moved</p>
              <p className="text-xs text-muted-foreground">The automated QA system now uses the shared suggest-engine. Run and review tests in MATCH QA.</p>
            </div>
            <a href="/admin/match-qa" className="inline-flex items-center gap-1.5 text-sm font-medium text-accent hover:underline shrink-0">
              <Sparkles className="w-4 h-4" /> Go to MATCH QA
            </a>
          </CardContent>
        </Card>

        {error && (
          <Card className="border-destructive/50">
            <CardContent className="p-4">
              <p className="text-sm text-destructive flex items-center gap-2">
                <AlertCircle className="w-4 h-4" /> {error}
              </p>
            </CardContent>
          </Card>
        )}

        {profiles.length === 0 && !running && (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              Click "Run full test" to generate profiles, suggestions, and paid reports — then grade the whole batch.
            </CardContent>
          </Card>
        )}

        {profiles.length > 0 && (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {profiles.length} profiles in the Test database. Grade each profile's full advisory chain — stars and comments save automatically and persist for the AI agent to review.
            </p>
            {profiles.map((profile, idx) => {
              const suggestions = suggestionsByProfile[profile.id] || [];
              const report = reportsByProfile[profile.id];
              return (
                <Card key={profile.id}>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <span className="text-muted-foreground tabular-nums">#{idx + 1}</span>
                      {profile.operating_area || "Unknown area"} — {SIZE_LABELS[profile.boat_size_range] || profile.boat_size_range}
                    </CardTitle>
                    <CardDescription>
                      {profile.vessel_class === "yacht" ? "Yacht" : profile.vessel_class === "charter" ? "Charter" : "Private"} · {(profile.activities || []).join(", ")}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-5">
                    {/* Profile */}
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Anchor className="w-4 h-4 text-muted-foreground" />
                        <p className="text-sm font-medium">Profile</p>
                      </div>
                      <ProfileSummary profile={profile} />
                    </div>

                    {/* QA moved to MATCH QA */}
                    <div className="pt-3 border-t border-border">
                      <a href="/admin/match-qa" className="inline-flex items-center gap-1.5 text-sm text-accent hover:underline">
                        <Sparkles className="w-4 h-4" /> Recommendation testing moved to MATCH QA
                      </a>
                    </div>

                    {/* Overall grade */}
                    <div className="pt-3 border-t border-border">
                      <p className="text-xs text-muted-foreground mb-1.5">Grade this profile's full advisory chain</p>
                      <GradeInput phase="overall" profileId={profile.id} existingGrade={findGrade(profile.id)} />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}