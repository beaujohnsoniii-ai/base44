import React,{useEffect,useState} from "react";
import {Link} from "react-router-dom";
import {base44} from "@/api/base44Client";
import Navbar from "@/components/Navbar";
import {Button} from "@/components/ui/button";
import JourneyHeader from "@/components/JourneyHeader";
import CompareSavedCandidates from "@/components/CompareSavedCandidates";
import CurrentMatchResults from "@/components/CurrentMatchResults";
import SelectedCompareFinalists from "@/components/SelectedCompareFinalists";
import {journeyStages} from "@/lib/journey";

const stages=journeyStages;
const content={
 Compare:{intro:"Match recommends models. Use Find inside Match to look for boats for sale, then save your favorites to Compare. Compare stored model research and any listing links you have added.",steps:["Select up to three saved model candidates for closer review.","Paste listing links from boats.com, boattrader.com, or yachtworld.com for each selected model.","Import available details and review extracted facts side by side."],sections:[["Saved model selection","Your selected models stay editable; they are not verified individual listings."],["Listing links","Save up to three buyer-found listing URLs for each selected model. On Compare, we attempt to retrieve links from boats.com, boattrader.com, and yachtworld.com. Some sites block automated access; missing details remain unverified."],["Side-by-side comparison","Imported listing details are displayed side by side with source links. Missing or conflicting details are labeled as not verified."]]},
 Ownership:{intro:"Understand what each finalist could cost to own.",steps:["Use the current three finalists from Compare.","Apply your location, use, storage and ownership timeframe from Match.","Compare low-to-high costs against your original annual budget."],sections:[["Annual ownership range","Fuel, maintenance, insurance, storage, annual increases and assessments."],["Upfront costs and reserves","Keep acquisition costs and cash reserves separate. Do not count reserves again as spending."],["Ownership term and resale","Expected major work and a resale range with visible assumptions."],["Budget fit","Within budget, stretching the budget or above budget—with the dollar difference."]]},
 Analyze:{intro:"Plan the purchase before making a commitment.",steps:["Bring forward Compare findings and Ownership estimates.","Assess the three finalists using available market evidence.","Choose which boat to pursue first and plan the next steps."],sections:[["Opening offer range","Asking price, available sold evidence, market context and reasons for the range."],["Delivery and improvements","Transport, closing expenses and improvement allowance, shown separately."],["Two purchase totals","Delivered before improvements; ready for your intended use after improvements."],["Proposed next steps","Deposit, survey, mechanical inspection, sea trial, target close and contingencies. Nothing is submitted or booked automatically."]]},
 Deal:{intro:"Keep the documents and decisions for your chosen boat together.",steps:["Attach contracts, surveys and inspections to the correct boat.","Confirm extracted dates, amounts and document readability.","Review concerns and feed repair findings back into your budgets."],sections:[["Boat document folder","Contracts, amendments, survey PDFs and mechanical or other inspection reports."],["Document review","Plain-language explanations, translations and concerns with source-page references."],["Dates and contingencies","Buyer-confirmed deposit, inspection and closing dates with unresolved questions."],["Findings and decisions","Preserve original reports and track what changes the offer, improvement allowance or ownership costs."]]}
};
export default function JourneyWorkspace({stage}){
 const [profile,setProfile]=useState(null),[error,setError]=useState(""),[loading,setLoading]=useState(true);
 useEffect(()=>{let active=true;(async()=>{try{const me=await base44.auth.me();const p=await base44.entities.BuyerProfile.filter({created_by_id:me.id},"-created_date",1);if(active)setProfile(p?.[0]||null);}catch{if(active)setError("Your Match profile could not be loaded. Please reload to retry.");}finally{if(active)setLoading(false);}})();return()=>{active=false;};},[]);
 const c=content[stage];
 return <div className={"min-h-screen bg-muted/30 sh-journey-shell sh-dashboard-customer"+(stage==="Compare"?" sh-compare-journey":"")}><Navbar/><main className="max-w-6xl mx-auto px-4 py-6 md:py-8 pb-28 space-y-6">
 <JourneyHeader stage={stage} intro={c.intro}/>
 {stage!=="Compare"&&<p className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm">Workspace preview: the structure below is ready to review. Listing import, finalist saving, new estimates and document review are not active here yet.</p>}
 {error&&<p role="alert">{error}</p>}
 {stage!=="Compare"&&<section className="rounded-xl border bg-white p-5"><h2 className="font-semibold">Rooted in your Match profile</h2>{loading?<p>Loading profile…</p>:profile?<p className="mt-2 text-sm">Operating area: {profile.operating_area||"Not provided"} · Annual budget: {profile.annual_ownership_budget!=null?"$"+Number(profile.annual_ownership_budget).toLocaleString():"Not provided"} · Ownership timeframe: {String(profile.ownership_timeframe||"Not provided").replaceAll("_"," ")}</p>:<p className="mt-2">Complete your Match profile to supply your needs and budget.</p>}<Button asChild variant="outline" className="min-h-11 mt-3"><Link to={profile?"/edit-profile":"/questionnaire"}>{profile?"Review Match profile":"Start Match profile"}</Link></Button></section>}
 {stage!=="Compare"&&<ol className="grid md:grid-cols-3 gap-4">{c.steps.map((x,i)=><li key={x} className="rounded-xl border bg-white p-5"><span className="text-xs uppercase text-muted-foreground">Step {i+1}</span><p className="mt-2">{x}</p></li>)}</ol>}
 {stage==="Compare" ? <><CurrentMatchResults/><CompareSavedCandidates /></> : <SelectedCompareFinalists />}
 {stage!=="Compare"&&<section className="grid md:grid-cols-2 gap-4">{c.sections.map(([title,desc])=><article key={title} className="rounded-xl border bg-white p-6"><h2 className="text-lg font-heading">{title}</h2><p className="mt-2 text-muted-foreground">{desc}</p></article>)}</section>}
 {stage==="Ownership"&&<Link className="inline-block underline" to="/ownership-estimator">Open the existing basic ownership-cost estimator</Link>}
 {stage==="Analyze"&&<Link className="inline-block underline" to="/candidate-advisor">Open the existing candidate advisor</Link>}
 <p className="text-sm text-muted-foreground">Ask Guide for help using the floating window. Estimates and recommendations require supporting information; missing evidence will not be filled in with invented facts.</p>
 </main></div>;
}