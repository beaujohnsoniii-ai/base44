import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Navbar from "@/components/Navbar";
import MessageBubble from "@/components/agents/MessageBubble";
import { Send, ArrowLeft, Loader2 } from "lucide-react";

import { profileInputFingerprint } from "../../base44/shared/profile-input-fingerprint.mjs";

const AGENT_NAME = "profile_interviewer";

export default function ProfileInterview() {
  const navigate = useNavigate();
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [starting, setStarting] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const scrollRef = useRef(null);

  // Start (or resume) a conversation with the agent on mount.
  useEffect(() => {
    let unsubscribe = null;
    (async () => {
      try {
        const me = await base44.auth.me();
        const profile = (await base44.entities.BuyerProfile.filter({ created_by_id: me.id }, "-created_date", 1))?.[0];
        const context = profile ? await profileInputFingerprint(profile) : "new-profile";
        // Resume only an interview tied to these exact answers. Old conversations stay saved.
        const existing = await base44.agents.listConversations({ q: { agent_name: AGENT_NAME }, sort: "-updated_date", limit: 1 });
        let conv = Array.isArray(existing) ? existing.find(c => c.metadata?.profile_input_fingerprint === context) : null;
        if (!conv) {
          conv = await base44.agents.createConversation({
            agent_name: AGENT_NAME,
            metadata: { name: "Buyer profile interview", profile_input_fingerprint: context },
          });
        } else {
          conv = await base44.agents.getConversation(conv.id);
        }
        setConversation(conv);
        setMessages(conv.messages || []);
        setError("");
        setStarting(false);

        // Subscribe to streaming updates.
        unsubscribe = base44.agents.subscribeToConversation(conv.id, (data) => {
          setMessages(data.messages || []);
          setSending(false);
        });
      } catch (e) {
        setError("Unable to start the buyer interview. Check your connection and sign-in, then reload to retry.");
        setStarting(false);
      }
    })();
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Auto-scroll to bottom on new messages.
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || sending || !conversation) return;
    setInput("");
    setSending(true);
    setError("");
    try {
      // addMessage triggers the agent run; the subscription updates messages.
      const updated = await base44.agents.addMessage(conversation, { role: "user", content: text });
      setConversation(updated);
    } catch (e) {
      setInput(text);
      setError("Message could not be sent. Your text has been restored; try again.");
      setSending(false);
    }
  };

  const assistantBusy = sending || messages.some(
    (m) => m.role === "assistant" && (m.tool_calls?.some((tc) => ["pending", "running", "in_progress"].includes(tc.status)))
  );

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col">
      <Navbar />
      <main className="max-w-3xl w-full mx-auto px-4 py-6 flex-1 flex flex-col">
        <div className="flex items-center gap-3 mb-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="font-heading text-xl font-semibold">Build Your Profile</h1>
            <p className="text-sm text-muted-foreground">Chat with our advisor to capture your boat-buying needs.</p>
          </div>
        </div>

        {error && (
          <div role="alert" className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-900">
            {error}
            {!conversation && <Button variant="outline" size="sm" className="ml-3" onClick={() => window.location.reload()}>Reload</Button>}
          </div>
        )}
        <div
          ref={scrollRef}
          className="flex-1 overflow-y-auto space-y-4 pb-4"
        >
          {starting ? (
            <div className="flex items-center justify-center py-12 text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin mr-2" /> Starting your interview…
            </div>
          ) : messages.length === 0 ? (
            <div className="flex items-center justify-center py-12 text-muted-foreground text-sm">
              Send a message to begin.
            </div>
          ) : (
            messages.map((m, idx) => <MessageBubble key={idx} message={m} />)
          )}
          {assistantBusy && !starting && (
            <div className="flex justify-start">
              <div className="rounded-2xl rounded-bl-sm bg-card border border-border px-4 py-3">
                <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
              </div>
            </div>
          )}
        </div>

        <div className="sticky bottom-0 bg-muted/30 pt-2 pb-2">
          <div className="flex items-end gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Type your answer…"
              disabled={starting || sending || !conversation}
              className="h-12"
            />
            <Button size="icon" className="h-12 w-12" onClick={handleSend} disabled={!input.trim() || starting || sending || !conversation}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-1.5">
            Your answers are saved to your buyer profile as you chat.
          </p>
        </div>
      </main>
    </div>
  );
}