import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CheckCircle2, ArrowRight, Pencil } from "lucide-react";
import { base44 } from "@/api/base44Client";
import Navbar from "@/components/Navbar";

export default function ThankYou() {
  const navigate = useNavigate();
  const [hasProfile, setHasProfile] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: me.id }, "-created_date", 1);
        setHasProfile(!!profiles?.[0]);
      } catch (e) {
        setHasProfile(false);
      }
    })();
  }, []);

  // A package purchase unlocks additional profile questions. Send the buyer straight to
  // profile entry so they can answer them, instead of leaving them on the dashboard unaware.
  const profileEntry = hasProfile ? "/edit-profile" : "/questionnaire";

  return (
    <div className="min-h-screen bg-muted/30">
      <Navbar />
      <main className="max-w-lg mx-auto px-4 py-20 text-center">
        <CheckCircle2 className="w-16 h-16 text-accent mx-auto" />
        <h1 className="font-heading text-3xl font-semibold mt-6">Thank you!</h1>
        <p className="text-muted-foreground mt-3">
          Your purchase is being processed and your package will unlock shortly. Your new package
          unlocks additional profile questions — answer them so your recommendations and reports
          reflect the full picture.
        </p>
        <Button className="mt-8" onClick={() => navigate(profileEntry)} disabled={hasProfile === null}>
          {hasProfile ? (
            <><Pencil className="w-4 h-4 mr-2" /> Answer your unlocked questions</>
          ) : (
            <><ArrowRight className="w-4 h-4 mr-2" /> Build your profile</>
          )}
        </Button>
        <div className="mt-3">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
            Go to dashboard
          </Button>
        </div>
      </main>
    </div>
  );
}