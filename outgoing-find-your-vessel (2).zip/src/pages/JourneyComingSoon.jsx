import React from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";

const descriptions = {
  Compare: "Compare your shortlisted boats side by side.",
  Guide: "Plan the next steps, including inspection, survey, and sea trial.",
  Deal: "Organize your offer, contingencies, and closing.",
};
export default function JourneyComingSoon({ stage }) {
  return <div className="min-h-screen bg-background">
    <Navbar />
    <main className="max-w-3xl mx-auto px-6 py-12 space-y-6">
      <Link to="/dashboard" className="underline">Back to My Account</Link>
      <img src={`/images/journey/${stage.toLowerCase()}.webp`} alt="" width="160" height="160" />
      <h1 className="text-3xl font-heading">{stage}</h1>
      <p>{descriptions[stage]}</p>
      <p className="text-muted-foreground">Coming soon.</p>
    </main>
  </div>;
}
