import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import SiteHeader from "@/components/home-v2/SiteHeader";
import Hero from "@/components/home-v2/Hero";
import Premise from "@/components/home-v2/Premise";
import HowItWorks from "@/components/home-v2/HowItWorks";
import Waters from "@/components/home-v2/Waters";
import StatementBand from "@/components/home-v2/StatementBand";
import SiteFooter from "@/components/home-v2/SiteFooter";
import useSiteV2Styles from "@/hooks/useSiteV2Styles";
import useSiteV2Motion from "@/hooks/useSiteV2Motion";

// SoundHeading homepage — Beau front-page restyle (2026-10-23) on Base44 export.
// Promise / Journal (Learn) removed. Waters tiles sit low. Storm image relocated.
export default function Home() {
  const ready = useSiteV2Styles();
  const rootRef = useRef(null);
  const [authed, setAuthed] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  useSiteV2Motion(rootRef, ready);

  useEffect(() => {
    base44.auth.me().then((user) => setAuthed(Boolean(user))).catch(() => setAuthed(false));
  }, []);

  // The design switches the header's account slot on <html data-auth>.
  useEffect(() => {
    document.documentElement.dataset.auth = authed ? "signed-in" : "signed-out";
    return () => { delete document.documentElement.dataset.auth; };
  }, [authed]);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [menuOpen]);

  if (!ready) return <div className="site-v2-boot" aria-busy="true" />;

  return (
    <div className={`site-v2${menuOpen ? " menu-open" : ""}`} ref={rootRef}>
      <a className="skip" href="#main">Skip to content</a>
      <SiteHeader
        authed={authed}
        menuOpen={menuOpen}
        onToggleMenu={setMenuOpen}
        onLogout={() => base44.auth.logout()}
      />
      <main id="main">
        <Hero authed={authed} />
        <Premise />
        <HowItWorks />
        <Waters />
        <StatementBand />
      </main>
      <SiteFooter />
    </div>
  );
}