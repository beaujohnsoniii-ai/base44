import React,{useRef,useState} from "react";
import {useAuth} from "@/lib/AuthContext";
import {base44} from "@/api/base44Client";
import IntroQuestionnaire from "@/components/IntroQuestionnaire";
import {Button} from "@/components/ui/button";
import {requestDeadline} from "@/lib/requestDeadline";
import {safeResultUrl,matchResultLink} from "@/lib/matchResultLink";
const tiers=[["free","Deckhand"],["match_plus","Bosun"],["refined_match","First Mate"],["market_match","Captain"]];
export default function AdminBuyerLaunchTest(){
 const {user,isLoadingAuth}=useAuth();
 const [plan,setPlan]=useState("free"),[profile,setProfile]=useState(null),[results,setResults]=useState(null),[saved,setSaved]=useState([]),[busy,setBusy]=useState(false),[error,setError]=useState(""),[epoch,setEpoch]=useState(0);
 const flight=useRef(false),generation=useRef(0);
 if(isLoadingAuth)return <main className="p-8">Checking access…</main>;
 if(user?.role!=="admin")return <main className="p-8">Admin access required.</main>;
 function reset(){generation.current++;setPlan("free");setProfile(null);setResults(null);setSaved([]);setError("");setEpoch(n=>n+1);}
 async function generate(answers){
  if(flight.current)return;flight.current=true;setBusy(true);setError("");setProfile(answers);const token=++generation.current;
  try{const response=await requestDeadline(()=>base44.functions.invoke("buyer-launch-test",{profile:answers,plan}),120000,"Match test timed out. No automatic retry was made; check backend logs before retrying.");if(token===generation.current)setResults(response.data);}
  catch(e){if(token===generation.current)setError(e?.response?.data?.error||"The live test failed. Your answers remain here; no payment was taken.");}
  finally{flight.current=false;setBusy(false);}
 }
 function save(boat){setSaved(current=>current.some(b=>b.key===[boat.make,boat.model,boat.year,boat.title].join("|"))?current:current.length>=5?current:[...current,{...boat,key:[boat.make,boat.model,boat.year,boat.title].join("|"),original_match_url:matchResultLink(boat),listing_urls:""}]);}
 return <main className="max-w-5xl mx-auto p-5 space-y-6">
  <header className="rounded-xl border bg-amber-50 p-5 space-y-3"><h1 className="text-2xl font-heading">First-time buyer test</h1><p>Real Match engine · no customer payment · private temporary answers and shortlist. API generation can use provider credits. Your normal account stays intact.</p><Button variant="outline" disabled={busy} onClick={reset}>Start over as a new buyer</Button><a className="block underline" href="/admin/research-monitor">Provider status and research monitor</a></header>
  <section className="space-y-3"><h2 className="text-xl">Choose a package to test at $0</h2><div className="flex flex-wrap gap-2">{tiers.map(([id,label])=><Button key={id} disabled={busy} variant={plan===id?"default":"outline"} onClick={()=>{generation.current++;setPlan(id);setResults(null);setError("");setEpoch(n=>n+1);}}>{label}</Button>)}</div><p>Package access here is temporary testing only. No checkout or permanent paid access is created.</p></section>
  <IntroQuestionnaire key={epoch} initialProfile={profile} plan={plan} onComplete={generate} submitLabel={busy?"Generating…":"Generate real test matches"} />
  {busy&&<p role="status">Running Match. Submit once; no automatic retry is made.</p>}
  {error&&<p role="alert" className="text-red-700">{error}</p>}
  {results&&<section className="space-y-4"><h2 className="text-xl">Your test matches</h2>{results.note&&<p>{results.note}</p>}{(results.suggestions||[]).map((boat,i)=>{const url=safeResultUrl(matchResultLink(boat));return <article className="rounded-xl border p-4 space-y-2" key={i}><h3 className="font-semibold">{boat.title||[boat.make,boat.model,boat.year].filter(Boolean).join(" ")}</h3><p>{boat.why_suggested}</p><p>{boat.specs}</p>{boat.match?.summary&&<p>{boat.match.summary}</p>}{boat.verification_required?.length>0&&<ul className="list-disc pl-5">{boat.verification_required.map((v,n)=><li key={n}>{v}</li>)}</ul>}<div className="flex gap-4 items-center">{url&&<a className="underline" target="_blank" rel="noopener noreferrer" href={url}>Find boats for sale</a>}<Button disabled={busy} onClick={()=>save(boat)}>Save test candidate</Button></div></article>;})}</section>}
  <section className="space-y-3"><h2 className="text-xl">Test shortlist ({saved.length}/5)</h2><p>Temporary shortlist only. This screen does not verify the production save-to-Compare path or retrieve pasted listings. Reloading clears this test.</p>{saved.map(boat=><article className="border rounded-xl p-4 space-y-2" key={boat.key}><h3>{boat.title}</h3><a className="underline" target="_blank" rel="noopener noreferrer" href={boat.original_match_url}>Original Match link</a><label className="block">Listing links for this candidate<textarea className="block w-full border rounded p-2" value={boat.listing_urls} onChange={e=>setSaved(rows=>rows.map(row=>row.key===boat.key?{...row,listing_urls:e.target.value}:row))}/></label><Button variant="outline" onClick={()=>setSaved(rows=>rows.filter(row=>row.key!==boat.key))}>Remove test candidate</Button></article>)}</section>
 </main>;
}
