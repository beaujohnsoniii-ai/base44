import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import Navbar from "@/components/Navbar";
import { isPaidPlan } from "@/lib/stages";
import FreeMatchPreview from "@/components/FreeMatchPreview";
import IntroQuestionnaire from "@/components/IntroQuestionnaire";
import { useToast } from "@/components/ui/use-toast";

export default function Questionnaire() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const resetting = searchParams.get("reset") === "1";
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [preview, setPreview] = useState(null);
  const [draft, setDraft] = useState(() => { if (resetting) return null; try { return JSON.parse(localStorage.getItem("soundheading_draft_profile") || "null"); } catch { return null; } });
  const [plan, setPlan] = useState("free");
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [fieldTiers, setFieldTiers] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const rules = await base44.functions.invoke("question-tiers", {});
        if (!cancelled) setFieldTiers(rules?.data?.field_tiers || null);
        const authed = await base44.auth.isAuthenticated();
        if (authed) {
          const me = await base44.auth.me();
          const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: me.id }, "-created_date", 1);
          if (!cancelled) {
            setPlan(me?.plan || "free");
            // A restart clears answers in the form, never the existing account record.
            setDraft(resetting ? null : profiles?.[0] || null);
          }
        }
      } catch (_) {
        if (!cancelled) setLoadError(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const saveInFlight=useRef(false);
  const handleComplete = async (profileData) => {
    if(saveInFlight.current)return;
    saveInFlight.current=true;
    setSaving(true);
    try {
      const authed = await base44.auth.isAuthenticated();
      if (authed) {
        const me = await base44.auth.me();
        const response = await base44.functions.invoke("save-matching-profile", { profile: profileData, reset_context: resetting });
        if (response?.data?.profile_save_version !== "profile-save-v1") throw new Error("Profile save acknowledgement is missing. Your answers may already be saved; keep this form open.");
        if (resetting) {
          const saved = response?.data?.profile;
          if (response?.data?.matching_context_version !== "fresh-context-v2" || response?.data?.reset_context_applied !== true || !saved?.match_context_id) throw new Error("Fresh matching context was not confirmed.");
          const persisted = await base44.entities.BuyerProfile.filter({ created_by_id: me.id }, "-created_date", 1);
          if (persisted?.[0]?.id !== saved.id || persisted[0].match_context_id !== saved.match_context_id) throw new Error("Fresh matching context could not be read back.");
        }
        localStorage.removeItem("soundheading_draft_profile");
        // Only administrators may test an unpaid questionnaire tier.
        // A buyer changing this profile field does not grant paid access.
        const effectivePlan = me?.role === "admin" ? (profileData.match_question_tier || me.plan) : me.plan;
        if (isPaidPlan(effectivePlan)) {
          try {
            await base44.functions.invoke("suggest-boats", { refresh: true });
            toast({ title: "Profile saved and matches updated" });
          } catch (error) {
            toast({ title: "Profile saved; matches were not updated", description: error?.response?.data?.error || "Try Update My Matches again.", variant: "destructive" });
          }
        } else {
          toast({ title: "Profile saved", description: "Your free results will reflect your saved answers." });
        }
        navigate("/my-matches");
      } else {
        localStorage.setItem("soundheading_draft_profile", JSON.stringify(profileData));
        toast({ title: "Your answers are saved", description: "Your answers are saved on this browser. No account required for the preview." });
        setDraft(profileData);
        setPreview(profileData);
      }
    } catch (e) {
      toast({ title: "Profile save could not be confirmed", description: e?.response?.data?.error || e?.message || "Keep this form open. Your answers may already be saved; do not reset or reload before checking.", variant: "destructive" });
    } finally {
      saveInFlight.current=false;
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-muted/30">
      <Navbar />
      <main className="max-w-2xl mx-auto px-4 py-10">
        <div className="mb-6">
          <h1 className="font-heading text-3xl font-semibold">Intro Questionnaire</h1>
          <p className="text-muted-foreground mt-1">
            {resetting ? "Start fresh. Your current profile stays active until you save this questionnaire. Likes, research notes, saved boats and reports are retained. Matching updates follow your package allowance." : "Complete your boating needs and preferences, then save them to your account."}
          </p>
        </div>
        {loading ? <p>Loading your profile and question set…</p> : loadError ? <p role="alert">Could not load your profile or question rules. Reload to retry; your saved profile has not changed.</p> : preview ? <FreeMatchPreview profile={preview} onEdit={() => setPreview(null)} onChoose={(tier) => {
          sessionStorage.setItem("soundheading_selected_tier", tier);
          navigate("/register?returnTo=" + encodeURIComponent("/dashboard?selectedTier=" + tier));
        }} /> : <IntroQuestionnaire onComplete={handleComplete} initialProfile={preview || draft} plan={plan} fieldTiers={fieldTiers} saving={saving} submitLabel="Save & Update Matches" />}
        {saving && <p className="text-sm text-muted-foreground mt-4">Saving…</p>}
      </main>
    </div>
  );
}