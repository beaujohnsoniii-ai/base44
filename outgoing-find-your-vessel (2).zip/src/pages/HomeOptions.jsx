import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Compass, Waves } from "lucide-react";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";

const HERO_IMG = "https://media.base44.com/images/public/6abbd00d2cbdcfbf9bef007e/f48819767_generated_image.png";

const OPTIONS = [
  { id: 1, name: "Cinematic", note: "Keep the ocean image; deepen the overlay and sharpen the headline contrast." },
  { id: 2, name: "Editorial", note: "A split layout with a confident navy panel and the boat image kept crisp." },
  { id: 3, name: "Tool-first", note: "Bring the six choices forward while keeping a polished nautical feel." },
  { id: 4, name: "Yacht Broker", note: "Full-bleed ocean image with a brass-framed glass card and a refined serif headline." },
  { id: 5, name: "Marina Golden", note: "Warm teak and brass palette with golden-hour imagery and elegant spacing." },
  { id: 6, name: "Bridge", note: "Deep navy with a porthole image crop and nautical instrument-panel detailing." },
  { id: 7, name: "Sportfish", note: "Cinematic full-bleed imagery blended smoothly into a deep navy text panel, with teak-and-holly and polished stainless accents." },
  { id: 8, name: "Sportfish II", note: "Diagonal blend with the boat image pushed right, a brass coordinate rule, and a bottom-aligned signature line." },
  { id: 9, name: "Sportfish III", note: "Centered headline over a darker bottom-up fade, horizontal brass divider, and a soft vignette framing the cockpit." },
];

const TOOLS = [
  ["01", "Match", "Find boats suited to your needs, experience, and budget.", true],
  ["02", "Analyze", "Review a boat in depth against your profile.", false],
  ["03", "Compare", "See candidate boats and tradeoffs side by side.", false],
  ["04", "Ownership", "Estimate the cost of owning and operating a boat.", false],
  ["05", "Guide", "Follow the buying process from search through closing.", false],
  ["06", "Advisory", "Get independent expert guidance for your purchase.", false],
];

function Actions({ light = false }) {
  const navigate = useNavigate();
  return (
    <div className="flex flex-wrap gap-3">
      <Button size="lg" variant="secondary" onClick={() => navigate("/register?returnTo=/tools")}>
        Start with Match <ArrowRight className="w-4 h-4 ml-2" />
      </Button>
      <Button
        size="lg"
        variant={light ? "outline" : "outline"}
        className={light ? "border-white/60 bg-white/5 text-white hover:bg-white/15" : "border-primary/30"}
        onClick={() => navigate("/tools")}
      >
        Explore the tools
      </Button>
    </div>
  );
}

function ToolGrid({ compact = false }) {
  return (
    <div className={`grid sm:grid-cols-2 lg:grid-cols-3 gap-3 ${compact ? "mt-6" : "mt-10"}`}>
      {TOOLS.map(([number, name, description, active]) => (
        <div key={name} className={`border p-4 ${active ? "border-brass bg-white shadow-sm" : "border-brass/25 bg-white/80"}`}>
          <div className="flex items-center justify-between gap-2">
            <span className="font-display text-lg text-brass">{number}</span>
            <span className="text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
              {active ? "Available now" : "Coming soon"}
            </span>
          </div>
          <h3 className="font-display text-lg font-semibold mt-2">{name}</h3>
          <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{description}</p>
        </div>
      ))}
    </div>
  );
}

function Cinematic() {
  return (
    <div className="relative overflow-hidden bg-primary text-white min-h-[530px] flex items-center">
      <img src={HERO_IMG} alt="" className="absolute inset-0 w-full h-full object-cover object-center" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#071c2c]/95 via-[#0b2638]/80 to-[#0b2638]/30" />
      <div className="relative max-w-6xl mx-auto w-full px-6 md:px-12 py-16">
        <p className="text-[11px] uppercase tracking-[0.32em] text-[#d0ad70] font-medium">Independent Boat-Buying Advice</p>
        <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-semibold mt-5 max-w-3xl leading-[1.05]">
          Set course to your next boat.
          <span className="block text-[#e3c994] italic mt-2">Chosen for your life on the water.</span>
        </h2>
        <p className="mt-6 max-w-xl text-base md:text-lg text-white/90 leading-relaxed">
          Independent guidance to help you find a boat that fits your needs, experience, and budget.
        </p>
        <div className="mt-8"><Actions light /></div>
        <p className="mt-8 text-[10px] uppercase tracking-[0.23em] text-white/75">One account · Six tools · Match available now</p>
      </div>
    </div>
  );
}

function Editorial() {
  return (
    <div className="grid lg:grid-cols-2 min-h-[530px] bg-[#102b3b] text-white">
      <div className="flex items-center px-6 py-14 md:px-12 lg:px-16">
        <div className="max-w-xl">
          <p className="text-[11px] uppercase tracking-[0.3em] text-[#d0ad70] font-medium">Sound Heading · Independent Advice</p>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-semibold mt-6 leading-[1.04]">
            Find the boat that fits the way you live.
          </h2>
          <p className="mt-6 text-white/80 leading-relaxed text-lg">
            Start with Match. Explore six connected tools for a clearer, more confident boat purchase.
          </p>
          <div className="mt-8"><Actions light /></div>
          <div className="mt-8 flex items-center gap-2 text-sm text-[#e3c994]">
            <Compass className="w-4 h-4" /> Built around your real boating life
          </div>
        </div>
      </div>
      <div className="relative min-h-[300px] lg:min-h-full">
        <img src={HERO_IMG} alt="Boat heading across open water" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#102b3b]/45 via-transparent to-transparent" />
        <div className="absolute bottom-6 left-6 right-6 border border-white/40 bg-[#102b3b]/80 p-4 backdrop-blur-sm">
          <p className="text-[10px] uppercase tracking-[0.22em] text-[#e3c994]">Your next decision, better informed</p>
          <p className="font-display text-xl mt-1">A heading you can trust.</p>
        </div>
      </div>
    </div>
  );
}

function ToolFirst() {
  return (
    <div className="bg-[#f5f1e7] text-[#102b3b]">
      <div className="relative overflow-hidden bg-[#102b3b] text-white">
        <div className="absolute inset-0 opacity-30">
          <img src={HERO_IMG} alt="" className="w-full h-full object-cover" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#102b3b] via-[#102b3b]/95 to-[#102b3b]/55" />
        <div className="relative max-w-6xl mx-auto px-6 md:px-12 py-14 md:py-16">
          <p className="text-[11px] uppercase tracking-[0.3em] text-[#d0ad70]">One destination · Six tools</p>
          <h2 className="font-display text-4xl md:text-5xl font-semibold mt-4 max-w-2xl leading-tight">
            Make your next boat decision with confidence.
          </h2>
          <p className="text-white/85 mt-4 max-w-xl leading-relaxed">Start with Match today. The rest of your toolkit is ready to grow with you.</p>
          <div className="mt-7"><Actions light /></div>
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-5 md:px-8 py-10">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
          <div>
            <p className="text-[10px] uppercase tracking-[0.25em] text-brass">Choose your next step</p>
            <h3 className="font-display text-2xl md:text-3xl font-semibold mt-2">Your tools, in one place</h3>
          </div>
          <p className="text-sm text-muted-foreground">Match is open now. Five more tools are on the way.</p>
        </div>
        <ToolGrid compact />
      </div>
    </div>
  );
}

function YachtBroker() {
  return (
    <div className="relative overflow-hidden bg-[#06141f] text-white min-h-[530px] flex items-center justify-center">
      <img src={HERO_IMG} alt="" className="absolute inset-0 w-full h-full object-cover object-center" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#06141f]/85 via-[#06141f]/70 to-[#06141f]/90" />
      <div className="relative max-w-6xl mx-auto w-full px-6 md:px-12 py-16">
        <div className="mx-auto max-w-2xl border border-[#d0ad70]/55 bg-[#06141f]/55 backdrop-blur-md p-8 md:p-12 text-center shadow-2xl">
          <div className="mx-auto w-16 h-px bg-[#d0ad70]" />
          <p className="text-[11px] uppercase tracking-[0.38em] text-[#d0ad70] font-medium mt-5">Sound Heading · Independent Advisory</p>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-semibold mt-6 leading-[1.05]">
            Your next boat,<span className="block italic text-[#e3c994] mt-1">chosen with judgment.</span>
          </h2>
          <p className="mt-6 max-w-xl mx-auto text-base md:text-lg text-white/85 leading-relaxed">
            Independent guidance for buyers who want a boat that fits the way they live on the water.
          </p>
          <div className="mt-8 flex justify-center"><Actions light /></div>
          <div className="mx-auto w-16 h-px bg-[#d0ad70] mt-8" />
        </div>
      </div>
    </div>
  );
}

function MarinaGolden() {
  return (
    <div className="grid lg:grid-cols-2 min-h-[530px] bg-[#f3ead6] text-[#2a1f12]">
      <div className="flex items-center px-6 py-14 md:px-12 lg:px-16">
        <div className="max-w-xl">
          <p className="text-[11px] uppercase tracking-[0.3em] text-[#9a6f2e] font-medium">Sound Heading · Independent Advice</p>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-semibold mt-6 leading-[1.04] text-[#2a1f12]">
            A heading worth keeping.
          </h2>
          <p className="mt-6 text-[#5a4631] leading-relaxed text-lg">
            Start with Match. Six connected tools help you find a boat that fits your life and your budget.
          </p>
          <div className="mt-8"><Actions /></div>
          <div className="mt-8 flex items-center gap-2 text-sm text-[#9a6f2e]">
            <Compass className="w-4 h-4" /> Built around your real boating life
          </div>
        </div>
      </div>
      <div className="relative min-h-[300px] lg:min-h-full">
        <img src={HERO_IMG} alt="Boat heading across open water" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#9a6f2e]/35 via-transparent to-[#f3ead6]/25" />
        <div className="absolute bottom-6 left-6 right-6 border border-[#9a6f2e]/50 bg-[#2a1f12]/85 p-4 backdrop-blur-sm">
          <p className="text-[10px] uppercase tracking-[0.22em] text-[#e3c994]">Your next decision, better informed</p>
          <p className="font-display text-xl mt-1 text-white">Independent. Considered. Yours.</p>
        </div>
      </div>
    </div>
  );
}

function Bridge() {
  return (
    <div className="relative overflow-hidden bg-[#0a2230] text-white min-h-[530px] flex items-center">
      <div className="absolute inset-0 opacity-25">
        <img src={HERO_IMG} alt="" className="w-full h-full object-cover" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-r from-[#0a2230] via-[#0a2230]/92 to-[#0a2230]/60" />
      <div className="relative max-w-6xl mx-auto w-full px-6 md:px-12 py-16 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <p className="text-[11px] uppercase tracking-[0.32em] text-[#d0ad70] font-medium">Independent Boat-Buying Advice</p>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-semibold mt-5 leading-[1.05]">
            Set course.<span className="block italic text-[#e3c994] mt-2">With a steady hand.</span>
          </h2>
          <p className="mt-6 max-w-md text-base md:text-lg text-white/85 leading-relaxed">
            Independent guidance to help you find a boat that fits your needs, experience, and budget.
          </p>
          <div className="mt-8"><Actions light /></div>
          <p className="mt-8 text-[10px] uppercase tracking-[0.23em] text-white/70">One account · Six tools · Match available now</p>
        </div>
        <div className="hidden md:flex justify-center">
          <div className="relative w-72 h-72 lg:w-80 lg:h-80 rounded-full border-2 border-[#d0ad70]/60 overflow-hidden shadow-2xl ring-8 ring-[#0a2230]">
            <img src={HERO_IMG} alt="Boat on open water" className="absolute inset-0 w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a2230]/55 to-transparent" />
            <div className="absolute top-3 left-1/2 -translate-x-1/2 w-1 h-5 bg-[#d0ad70]" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Sportfish() {
  return (
    <div className="relative overflow-hidden bg-[#0a2230] text-white min-h-[530px] flex items-center">
      <img src={HERO_IMG} alt="" className="absolute inset-0 w-full h-full object-cover object-center" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#0a2230] via-[#0a2230]/82 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0a2230]/30 via-transparent to-[#0a2230]/10" />
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-white/12" />
      <div className="relative max-w-6xl mx-auto w-full px-6 md:px-12 py-16">
        <div className="max-w-xl">
          <div className="flex items-center gap-3">
            <span className="w-10 h-px bg-[#c9a86a]" />
            <p className="text-[11px] uppercase tracking-[0.34em] text-[#c9a86a] font-medium">Sound Heading · Independent Advisory</p>
          </div>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-semibold mt-6 leading-[1.04]">
            The right boat,<span className="block italic text-[#e3c994] mt-1">chosen with judgment.</span>
          </h2>
          <p className="mt-6 max-w-md text-base md:text-lg text-white/90 leading-relaxed">
            Independent guidance for buyers who want a boat that fits the way they live on the water.
          </p>
          <div className="mt-8"><Actions light /></div>
          <div className="mt-8 flex items-center gap-3">
            <span className="w-6 h-px bg-[#cfd8dd]" />
            <span className="text-[10px] uppercase tracking-[0.23em] text-white/80">One account · Six tools · Match available now</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function SportfishTwo() {
  return (
    <div className="relative overflow-hidden bg-[#0a2230] text-white min-h-[530px] flex items-center">
      <img src={HERO_IMG} alt="" className="absolute inset-0 w-full h-full object-cover object-right" />
      <div className="absolute inset-0 bg-gradient-to-tr from-[#0a2230] via-[#0a2230]/78 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0a2230]/35 via-transparent to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-white/10" />
      <div className="relative max-w-6xl mx-auto w-full px-6 md:px-12 py-16">
        <div className="max-w-xl">
          <div className="flex items-center gap-3">
            <span className="w-10 h-px bg-[#c9a86a]" />
            <p className="text-[11px] uppercase tracking-[0.34em] text-[#c9a86a] font-medium">Sound Heading · Independent Advisory</p>
          </div>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-semibold mt-6 leading-[1.04]">
            A clear heading<span className="block italic text-[#e3c994] mt-1">for open water.</span>
          </h2>
          <p className="mt-6 max-w-md text-base md:text-lg text-white/90 leading-relaxed">
            Independent guidance for buyers who want a boat that fits the way they live on the water.
          </p>
          <div className="mt-8"><Actions light /></div>
        </div>
        <div className="absolute bottom-10 left-6 md:left-12 right-6 md:right-12 flex items-center justify-between gap-4">
          <span className="text-[10px] uppercase tracking-[0.23em] text-white/70">One account · Six tools · Match available now</span>
          <span className="hidden sm:block text-[10px] tracking-[0.18em] text-[#c9a86a]">27°09′N · 82°38′W</span>
        </div>
      </div>
    </div>
  );
}

function SportfishThree() {
  return (
    <div className="relative overflow-hidden bg-[#0a2230] text-white min-h-[530px] flex items-center justify-center">
      <img src={HERO_IMG} alt="" className="absolute inset-0 w-full h-full object-cover object-center" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0a2230] via-[#0a2230]/55 to-[#0a2230]/85" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_45%,#0a2230/55_100%)]" />
      <div className="relative max-w-6xl mx-auto w-full px-6 md:px-12 py-16 text-center">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-center gap-3">
            <span className="w-8 h-px bg-[#c9a86a]" />
            <p className="text-[11px] uppercase tracking-[0.34em] text-[#c9a86a] font-medium">Sound Heading · Independent Advisory</p>
            <span className="w-8 h-px bg-[#c9a86a]" />
          </div>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-semibold mt-6 leading-[1.04]">
            The right boat,<span className="block italic text-[#e3c994] mt-1">chosen with judgment.</span>
          </h2>
          <p className="mt-6 max-w-lg mx-auto text-base md:text-lg text-white/90 leading-relaxed">
            Independent guidance for buyers who want a boat that fits the way they live on the water.
          </p>
          <div className="mt-8 flex justify-center"><Actions light /></div>
          <div className="mt-8 mx-auto w-24 h-px bg-[#c9a86a]/70" />
          <p className="mt-5 text-[10px] uppercase tracking-[0.23em] text-white/75">One account · Six tools · Match available now</p>
        </div>
      </div>
    </div>
  );
}

export default function HomeOptions() {
  const [selected, setSelected] = useState(1);
  const navigate = useNavigate();
  const option = OPTIONS.find((item) => item.id === selected);

  return (
    <div className="min-h-screen bg-[#f5f1e7] text-[#102b3b]">
      <Navbar />
      <main className="max-w-6xl mx-auto px-4 py-8 md:py-12">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-5 mb-6">
          <div>
            <p className="text-[10px] uppercase tracking-[0.27em] text-brass">Homepage design previews</p>
            <h1 className="font-display text-3xl md:text-4xl font-semibold mt-2">Nine ways to set the course</h1>
            <p className="text-sm text-muted-foreground mt-2 max-w-2xl">Same brand and user flow, with a clearer, more energetic first impression.</p>
          </div>
          <Button variant="outline" onClick={() => navigate("/home-original")}>View the original homepage</Button>
        </div>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3 mb-5">
          {OPTIONS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSelected(item.id)}
              className={`text-left border p-4 transition-colors ${selected === item.id ? "border-[#102b3b] bg-white shadow-sm" : "border-brass/30 bg-white/60 hover:bg-white"}`}
              aria-pressed={selected === item.id}
            >
              <span className="text-[10px] uppercase tracking-[0.2em] text-brass">Option {item.id.toString().padStart(2, "0")}</span>
              <span className="block font-display text-xl font-semibold mt-1">{item.name}</span>
              <span className="block text-xs text-muted-foreground mt-1 leading-relaxed">{item.note}</span>
            </button>
          ))}
        </div>

        <section className="overflow-hidden border border-[#d7c7a4] shadow-sm" aria-label={`Option ${option.id}: ${option.name}`}>
          {selected === 1 && <Cinematic />}
          {selected === 2 && <Editorial />}
          {selected === 3 && <ToolFirst />}
          {selected === 4 && <YachtBroker />}
          {selected === 5 && <MarinaGolden />}
          {selected === 6 && <Bridge />}
          {selected === 7 && <Sportfish />}
          {selected === 8 && <SportfishTwo />}
          {selected === 9 && <SportfishThree />}
        </section>

        <p className="text-xs text-muted-foreground mt-4">
          These are comparison previews. The original homepage is preserved at <button className="underline text-primary" onClick={() => navigate("/home-original")}>View original</button>.
        </p>
        <footer className="border-t border-[#d7c7a4] mt-8 pt-5 flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
          <Waves className="w-4 h-4 text-brass" /> Sound Heading · Independent Boat-Buying Advisory
        </footer>
      </main>
    </div>
  );
}