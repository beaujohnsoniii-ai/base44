import React, { useEffect, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { base44 } from "@/api/base44Client";

export default function MatchEntry() {
  const { isAuthenticated, isLoadingAuth, user } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState(false);
  useEffect(() => {
    if (!isAuthenticated || !user?.id) return;
    let active = true;
    base44.entities.BuyerProfile.filter({ created_by_id: user.id }, "-created_date", 1)
      .then(profiles => { if (active) navigate(profiles?.length ? "/my-matches" : "/questionnaire", { replace: true }); })
      .catch(() => { if (active) setError(true); });
    return () => { active = false; };
  }, [isAuthenticated, user?.id, navigate]);
  if (!isLoadingAuth && !isAuthenticated) return <Navigate to="/questionnaire" replace />;
  return <main className="min-h-screen grid place-items-center p-6" aria-live="polite">
    {error ? <div><p>We could not open your saved Match profile.</p><button className="underline mt-3" onClick={() => window.location.reload()}>Try again</button></div> : <p>Opening your Match account…</p>}
  </main>;
}
