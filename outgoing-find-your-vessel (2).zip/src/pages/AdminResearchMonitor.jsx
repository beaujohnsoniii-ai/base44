import React, { useCallback, useEffect, useState, useRef } from "react";
import { requestDeadline } from "@/lib/requestDeadline";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { base44Test, refreshTestToken } from "@/lib/base44TestClient";
import { useAuth } from "@/lib/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, ArrowLeft, CheckCircle2, Loader2, RefreshCw, ShieldCheck, Server, Database, FlaskConical } from "lucide-react";

import HybridResearchAdmin from "@/components/HybridResearchAdmin";
import FirecrawlBrokerTest from "@/components/FirecrawlBrokerTest";
import { researchJobActivity, stagedEvidenceSummary, safeResearchSourceUrl } from "@/lib/researchReview";
import { previewCatalogProofReadiness } from "../../base44/shared/catalog-grounding";

const PROVIDERS = [
  ["anthropic", "Claude (Anthropic)"],
  ["groq", "Groq"],
  ["xai", "Grok (xAI)"],
  ["tavily", "Tavily"],
];

function StatusBadge({ check }) {
  if (!check) return <Badge variant="outline">Not tested</Badge>;
  return check.ok
    ? <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100"><CheckCircle2 className="w-3 h-3 mr-1" /> Connected</Badge>
    : <Badge variant="destructive"><AlertCircle className="w-3 h-3 mr-1" /> Error</Badge>;
}


export default function AdminResearchMonitor() {
  const { user, isLoadingAuth } = useAuth();
  const [health, setHealth] = useState(null);
  const [healthError, setHealthError] = useState("");
  const [checking, setChecking] = useState(false);
  const [healthUncertain, setHealthUncertain] = useState(false);
  const healthInFlight = useRef(false);
  const [stats, setStats] = useState({
    manufacturers: null,
    manufacturerCountCapped: false,
    qa: null,
    jobs: [],
    jobsCountCapped: false,
    staging: [],
    stagingCountCapped: false,
    catalog: [],
    catalogCountCapped: false,
    latestRelease: null,
    releaseUnavailable: false,
    hasPublishedCatalogRecord: null,
    updated: null,
  });
  const [statsError, setStatsError] = useState("");
  const [loadingStats, setLoadingStats] = useState(false);
  const [runningProof, setRunningProof] = useState("");
  const [proofMessage, setProofMessage] = useState("");
  const [grokPilotRunning, setGrokPilotRunning] = useState(false);
  const [grokPilotResult, setGrokPilotResult] = useState(null);
  const runGrokSpecPilot = async () => {
    if (grokPilotRunning) return;
    setGrokPilotRunning(true);
    setGrokPilotResult(null);
    try {
      const response = await base44.functions.invoke('verify-grok-sourced-spec', {});
      setGrokPilotResult(response?.data || response);
      await refreshStats();
    } catch (error) {
      setGrokPilotResult({ error: error?.message || 'Pilot request failed' });
    } finally { setGrokPilotRunning(false); }
  };
  const [gradyRunning, setGradyRunning] = useState(false);
  const [gradyResult, setGradyResult] = useState(null);
  const runGradyPilot = async () => {
    if (gradyRunning) return;
    setGradyRunning(true);
    setGradyResult(null);
    try {
      const response = await base44.functions.invoke('verify-grady-fisherman-236', {});
      const result = response?.data || response;
      setGradyResult(/^grady-v[2-9]$/.test(result?.runtime_version || '') ? result : { error: 'Outdated backend deployment: expected grady-v2 or newer', response: result });
      await refreshStats();
    } catch (error) {
      setGradyResult({ error: error?.response?.data?.error || error?.message || 'Backend unavailable or not deployed' });
    } finally { setGradyRunning(false); }
  };
  // The server rejects requests after this one-time proof approval expires.
  // Keep the admin controls in sync so an expired proof is not presented as runnable.
  const proofWindowClosed = Date.now() >= Date.parse("2026-10-15T00:00:00Z");
  const manufacturerTrialClosed = Date.now() >= Date.parse("2026-10-18T04:00:00Z");
  // Provider connection/proof exercises are not manufacturer research.
  // Keep their records in the proof card instead of counting them as workers.
  const researchJobs = stats.jobs === null ? null : stats.jobs.filter(job => !job.job_type?.startsWith("provider_proof_"));
  const latestReviewedModel = stats.catalog?.find(m => m.verification_status === "verified" || m.verification_status === "published");
  const reviewedProof = latestReviewedModel ? previewCatalogProofReadiness(latestReviewedModel) : null;

  const refreshStats = useCallback(async () => {
    setLoadingStats(true);
    setStatsError("");
    try {
      refreshTestToken();
      // Keep the research monitor useful even when the isolated QA test
      // environment is temporarily unavailable. A failed query must never
      // silently turn into a misleading zero count.
      const results = await Promise.allSettled([
        base44.entities.Manufacturer.list("-created_date", 500),
        base44Test.entities.QATestRun.list("-created_date", 1),
        base44.entities.ResearchJob.list("-created_date", 25),
        base44.entities.ResearchStaging.list("-created_date", 500),
        base44.entities.BoatModelCatalog.list("-created_date", 500),
        // A separate filtered existence check prevents the latest-500 limit
        // from incorrectly claiming there are zero published models overall.
        base44.entities.BoatModelCatalog.filter({ verification_status: "published" }, "-created_date", 1),
        // The sealed research dataset is a separate provenance snapshot, not
        // a published MATCH catalog or evidence that recommendations use it.
        base44.entities.ResearchRelease.list("-created_date", 1),
      ].map(read => requestDeadline(() => read, 8000, "Research statistics request timed out")));
      const [manufacturers, runs, jobs, staging, catalog, publishedCatalog, releases] = results.map(result =>
        result.status === "fulfilled" ? (result.value || []) : null
      );
      const failed = ["Manufacturers", "MATCH QA", "Research jobs", "Research staging", "Boat model catalog", "Catalog publication check", "Research release snapshot"]
        .filter((_, index) => results[index].status === "rejected");
      if (failed.length) setStatsError(`Unable to refresh: ${failed.join(", ")}. Other sections remain available.`);
      const lastRun = runs?.[0] || null;
      setStats({
        manufacturers: manufacturers === null ? null : manufacturers.length,
        manufacturerCountCapped: (manufacturers?.length || 0) >= 500,
        qa: runs === null ? { unavailable: true } : lastRun ? {
          id: lastRun.id,
          status: lastRun.status,
          profileCount: lastRun.profile_count ?? 0,
          flagged: lastRun.flagged_count ?? 0,
          updated: lastRun.updated_date || lastRun.created_date,
        } : null,
        jobs,
        jobsCountCapped: (jobs?.length || 0) >= 25,
        staging,
        stagingCountCapped: (staging?.length || 0) >= 500,
        catalog,
        catalogCountCapped: (catalog?.length || 0) >= 500,
        latestRelease: releases?.[0] || null,
        releaseUnavailable: releases === null,
        hasPublishedCatalogRecord: publishedCatalog === null ? null : publishedCatalog.length > 0,
        updated: new Date().toISOString(),
      });
    } catch (error) {
      setStatsError(error?.message || "Unable to load research and QA statistics");
    } finally {
      setLoadingStats(false);
    }
  }, []);

  useEffect(() => {
    if (user?.role !== "admin") return;
    refreshStats();
    const interval = window.setInterval(refreshStats, 60000);
    return () => window.clearInterval(interval);
  }, [user?.role, refreshStats]);

  const testConnections = async () => {
    if (healthInFlight.current || healthUncertain) return;
    healthInFlight.current = true;
    setChecking(true);
    setHealthError("");
    try {
      const result = await requestDeadline(() => base44.functions.invoke("research-provider-health", {}), 30000, "The provider test did not return within 30 seconds. It may still have consumed a Tavily credit. No automatic retry was made; do not keep clicking.");
      const data = result?.data || result;
      if (!data?.providers) throw new Error("Health-check function returned no provider results.");
      setHealth(data);
    } catch (error) {
      setHealth(null);
      if (error.code === "REQUEST_TIMEOUT") setHealthUncertain(true);
      setHealthError(error?.response?.data?.error || error?.message || "Connection test failed.");
    } finally {
      healthInFlight.current = false;
      setChecking(false);
    }
  };

  const runProof = async (task) => {
    if (runningProof) return;
    setRunningProof(task);
    setProofMessage("");
    try {
      const result = await base44.functions.invoke(task === "manufacturer" ? "run-manufacturer-trial" : "run-provider-proof", { task });
      const data = result.data;
      setProofMessage(data?.needs_review ? `${data.staged} manufacturer records staged for source review; not published to MATCH.` : data?.verified_generation ? "Provider output received and saved for review." : "This trial already has a recorded result. No duplicate generation started.");
    } catch (error) {
      setProofMessage(error?.response?.data?.error || "The job did not return a confirmed result. Check saved activity before retrying.");
    } finally {
      setRunningProof("");
      await refreshStats();
    }
  };

  if (isLoadingAuth) return <main className="max-w-5xl mx-auto p-8"><Loader2 className="animate-spin" /></main>;
  if (user?.role !== "admin") return <main className="max-w-5xl mx-auto p-8"><h1 className="text-xl font-semibold">Admin access required</h1><Link to="/dashboard" className="underline">Return to dashboard</Link></main>;

  return (
    <main className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <Link to="/dashboard" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-2"><ArrowLeft className="w-4 h-4" /> Dashboard</Link>
          <h1 className="text-3xl font-semibold tracking-tight">Research Monitor</h1>
          <p className="text-muted-foreground mt-1">Admin-only integration diagnostics and research / MATCH QA status.</p>
          <div className="mt-4 rounded-lg border p-4"><h2 className="font-semibold">Three-model Parker research trial</h2><p className="text-sm text-muted-foreground my-2">One bounded run: three manufacturer searches, Claude extraction and a separate source review. Results stay staged. No automatic retries or catalog publication.</p>{manufacturerTrialClosed ? <p className="text-sm text-amber-700">The one-time research trial has ended. Its saved manufacturer evidence remains in the source-verification queue below; this page will not start another paid research request.</p> : <Button disabled={!!runningProof} onClick={() => runProof("manufacturer")}>{runningProof === "manufacturer" ? "Running research trial…" : "Run three-model research trial"}</Button>}{proofMessage && <p role="status" className="mt-2 text-sm">{proofMessage}</p>}</div>
          <Link to="/admin/private-match-trial" className="inline-block mt-3 text-blue-700 underline">Open private 26 ft evidence trial</Link>
          <Link to="/admin/journey-trial" className="block mt-3 text-blue-700 underline">Start fresh buyer journey simulation</Link>
        </div>
        <Button variant="outline" onClick={refreshStats} disabled={loadingStats}><RefreshCw className={`w-4 h-4 mr-2 ${loadingStats ? "animate-spin" : ""}`} /> Refresh counts</Button>
      </div>

      <Card><CardHeader><CardTitle>Grok + Tavily source-backed verification — 2025 Parker 2520 XLD</CardTitle><CardDescription>Admin-only bounded Tavily manufacturer-source search and extraction followed by Grok review. Saves an unverified proposal, never updates catalog records. API usage may incur charges. Repeated runs reuse the saved job.</CardDescription></CardHeader><CardContent className="space-y-3"><Button onClick={runGrokSpecPilot} disabled={grokPilotRunning}>{grokPilotRunning ? 'Running Grok verification…' : 'Run Grok + Tavily Source Verification'}</Button>{grokPilotResult && <pre role="status" className="whitespace-pre-wrap break-words text-xs border rounded p-3 max-h-80 overflow-auto">{JSON.stringify(grokPilotResult,null,2)}</pre>}</CardContent></Card>
      <Card><CardHeader><CardTitle>Grady-White Fisherman 236 — independent manufacturer pilot</CardTitle><CardDescription>One bounded manufacturer-page retrieval and Grok review. Read-only; no catalog or MATCH writes. Shows runtime version to detect stale deployments. A successful API call is not proof of verified model-year specifications.</CardDescription></CardHeader><CardContent className="space-y-3"><Button onClick={runGradyPilot} disabled={gradyRunning}>{gradyRunning ? 'Running manufacturer verification…' : 'Run Grady-White Source Verification'}</Button>{gradyResult && <pre role="status" className="whitespace-pre-wrap break-words text-xs border rounded p-3 max-h-80 overflow-auto">{JSON.stringify(gradyResult,null,2)}</pre>}</CardContent></Card>
      <FirecrawlBrokerTest />
      <HybridResearchAdmin />
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ShieldCheck className="w-5 h-5" /> Provider connectivity</CardTitle>
          <CardDescription>Manual connectivity tests only: Claude, Groq and xAI use model-list requests; Tavily performs one small search that can consume provider API credits. Repeated clicks may incur repeated Tavily usage. Viewing or refreshing this page does not start a provider test, research job, or orchestration.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={testConnections} disabled={checking || healthUncertain}><Server className="w-4 h-4 mr-2" /> {checking ? "Testing providers..." : "Test connections"}</Button>
          {health?.checked_at && <p className="text-xs text-muted-foreground">Last tested: {new Date(health.checked_at).toLocaleString()}</p>}
          {healthError && <p role="alert" className="text-sm text-red-700">{healthError}</p>}
          {health?.providers && <p className={`text-sm rounded-md border px-3 py-2 ${(health.research_ready ?? (health.providers.anthropic?.ok && health.providers.tavily?.ok)) ? "bg-emerald-50 text-emerald-800" : "bg-amber-50 text-amber-900"}`}>
            {(health.research_ready ?? (health.providers.anthropic?.ok && health.providers.tavily?.ok))
              ? "Core research providers connected: Claude + Tavily. Groq and Grok (xAI) are optional and can be tested separately. Authentication checks do not prove the research worker pipeline is running."
              : "Core research connectivity is incomplete. Both Claude and Tavily must connect before a research pilot can run."}
          </p>}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {PROVIDERS.map(([id, label]) => {
              const check = health?.providers?.[id];
              return <div key={id} className="rounded-lg border p-4 space-y-2">
                <div className="font-semibold">{label}</div>
                <StatusBadge check={check} />
                <p className="text-xs text-muted-foreground break-words">{check?.detail || "Awaiting first connection test"}</p>
                {check?.status && <p className="text-xs text-muted-foreground">HTTP {check.status}</p>}
              </div>;
            })}
          </div>
          <p className="text-xs text-muted-foreground">No API keys are displayed. Connectivity tests do not prove model-generation access or an operating research pipeline. A Tavily connection test makes a search request; use the button only when needed.</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Bounded provider pilot</CardTitle>
          <CardDescription>Two one-time text assignments using existing API accounts. Each caps output at 1,600 tokens and retains its result. No automatic runs, catalog promotion, payment changes, or image replacement.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-3">
            <Button onClick={() => runProof("claude")} disabled={!!runningProof || proofWindowClosed}>{runningProof === "claude" ? "Claude is reviewing..." : "Run Claude entitlement review"}</Button>
            <Button variant="outline" onClick={() => runProof("grok")} disabled={!!runningProof || proofWindowClosed}>{runningProof === "grok" ? "Grok is preparing..." : "Run Grok image-direction brief"}</Button>
          </div>
          {proofWindowClosed && <p className="text-sm text-amber-700">The one-time proof approval period has ended. Saved results remain visible; no new provider proof can be run from this panel.</p>}
          <p className="text-xs text-muted-foreground">Approved pilot cap: $1 total. Fixed prompts and token limits are designed for less than $0.10 combined at the checked standard model rates. Grok means xAI, separate from Groq. Stored outputs are proposals requiring review, not verified facts or implemented fixes.</p>
          {proofMessage && <p role="status" className="text-sm">{proofMessage}</p>}
          {(stats.jobs || []).filter(job => job.job_type?.startsWith("provider_proof_")).map(job => {
            let result = null;
            try { result = JSON.parse(job.last_message || ""); } catch { /* Activity can be plain text while running. */ }
            return <details key={job.id} className="rounded border p-3">
              <summary className="cursor-pointer font-medium">{job.job_type === "provider_proof_claude" ? "Claude entitlement review" : "Grok image-direction brief"} · {job.status}</summary>
              <p className="text-xs text-muted-foreground my-2">{result?.model || "Model pending"} · {job.input_tokens || 0} input / {job.output_tokens || 0} output tokens{result?.output ? (Number.isFinite(job.estimated_cost_usd) && job.estimated_cost_usd > 0 ? (" · estimated $" + job.estimated_cost_usd.toFixed(4) + " USD") : " · API cost not independently verified") : ""}</p>
              <pre className="whitespace-pre-wrap break-words text-sm font-sans">{result?.output || job.error_message || job.last_message}</pre>
            </details>;
          })}
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Database className="w-5 h-5" /> Manufacturer records</CardTitle>
            <CardDescription>Live app database count, refreshed every 60 seconds while this page is open.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-semibold">{stats.manufacturers === null ? "—" : `${stats.manufacturers}${stats.manufacturerCountCapped ? "+" : ""}`}</p>
            <p className="text-xs text-muted-foreground mt-2">This is the Base44 Manufacturer entity, not the separate research workbook. It does not indicate how many models are verified.</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><FlaskConical className="w-5 h-5" /> Latest MATCH QA</CardTitle>
            <CardDescription>Read-only status from the isolated test database.</CardDescription>
          </CardHeader>
          <CardContent>
            {stats.qa?.unavailable ? <p className="text-sm text-amber-700">QA test environment unavailable; no status inferred.</p> : stats.qa ? <>
              <p className="text-lg font-semibold capitalize">{stats.qa.status || "Unknown"}</p>
              <p className="text-sm text-muted-foreground">{stats.qa.profileCount} profiles · {stats.qa.flagged} flagged tier results</p>
              <p className="text-xs text-muted-foreground mt-2">{stats.qa.updated ? new Date(stats.qa.updated).toLocaleString() : ""}</p>
            </> : <p className="text-sm text-muted-foreground">No QA runs available.</p>}
            <Link className="text-sm underline inline-block mt-3" to="/admin/match-qa">Open MATCH QA</Link>
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Database className="w-5 h-5" /> MATCH model catalog</CardTitle>
          <CardDescription>Separate model-generation records intended for verified MATCH research; not inventory listings or the external master workbook.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {stats.catalog === null ? <p className="text-sm text-amber-700">Catalog status unavailable. No total inferred.</p> : <>
            <p className="text-3xl font-semibold">{stats.catalog.length}{stats.catalogCountCapped ? "+" : ""} <span className="text-sm font-normal text-muted-foreground">model-generation records</span></p>
            <p className="text-sm text-muted-foreground">{stats.catalog.filter(m => m.verification_status === "published").length} published · {stats.catalog.filter(m => m.verification_status === "verified").length} verified pending publication · {stats.catalog.filter(m => m.verification_status === "needs_review" || m.verification_status === "staged").length} pending review</p>
            <p className="text-xs text-muted-foreground">Only independently supported model facts should advance through verification. Counts show the newest 500 records{stats.catalogCountCapped ? "; status totals may be incomplete" : ""}. A staged item is not a validated recommendation.</p>
            {reviewedProof && <div className="rounded-md border bg-muted/20 px-3 py-2 space-y-1">
              <p className="text-sm font-medium">Field-level proof readiness — {latestReviewedModel.manufacturer_name} {latestReviewedModel.model_name} ({reviewedProof.year || "year unspecified"})</p>
              <p className="text-sm">{reviewedProof.usableFields.length} of {reviewedProof.presentFields.length} physical screening facts meet MATCH's source-and-year evidence format{latestReviewedModel.verification_status !== "published" ? "; model is not published" : ""}.</p>
              {reviewedProof.blockedFields.length > 0 && <p className="text-xs text-amber-800">Evidence metadata still needs review for: {reviewedProof.blockedFields.join(", ").replaceAll("_", " ")}.</p>}
              {reviewedProof.presentFields.length === 0 && <p className="text-xs text-amber-800">No populated physical screening fields are available for this model year.</p>}
              <p className="text-xs text-muted-foreground">This is a read-only audit of one recent reviewed model, not an automatic source verification, publication, or full-catalog count.</p>
            </div>}
            <p role="status" className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><strong>Launch gate — MATCH integration:</strong> AI still selects the recommended models; this is not yet catalog-constrained selection. The server now cross-checks an exact model/year match against published BoatModelCatalog records and may use individually source-verified dimensions for hard-limit screening. Unmatched, unpublished and unsupported facts remain provisional. Publishing a catalog record alone does not establish full model-data integration. Do not present paid MATCH as catalog-verified until production selection uses adequately populated, validated model evidence and end-to-end QA proves it.</p>
            {stats.hasPublishedCatalogRecord === false && <p role="status" className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><strong>Launch gate — model evidence:</strong> No published, independently verified model-generation records are present in this app database. The separate research workbook and successful API connections do not establish that production MATCH is grounded in verified model data. Do not describe MATCH recommendations as catalog-verified or publish paid MATCH on that basis until the model-data integration and end-to-end QA have been demonstrated.</p>}
            {stats.hasPublishedCatalogRecord === null && <p role="status" className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">Catalog publication status could not be independently checked. The latest 500 records do not establish that published model data exists or does not exist; verify catalog publication before paid MATCH launch.</p>}
          </>}
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ShieldCheck className="w-5 h-5" /> Research dataset snapshot</CardTitle>
          <CardDescription>Most recent staged research release. This is separate from independently published BoatModelCatalog records and does not supply verified MATCH recommendations.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {stats.releaseUnavailable ? <p className="text-sm text-amber-700">Research release status unavailable; no dataset status inferred.</p> : !stats.latestRelease ? <p className="text-sm text-muted-foreground">No research release snapshot has been recorded in the app database.</p> : <>
            <p className="font-medium break-all">{stats.latestRelease.release_id || "Unnamed release"}</p>
            <p className="text-sm">{stats.latestRelease.sealed ? "Sealed snapshot" : "Unsealed snapshot"} · {stats.latestRelease.approved ? "Approved for further release processing" : "Not approved"}</p>
            <div className="grid gap-2 sm:grid-cols-3 text-sm">
              <p><strong>{Number.isSafeInteger(stats.latestRelease.manifest?.record_count) ? stats.latestRelease.manifest.record_count.toLocaleString() : "—"}</strong> model-generation reference records</p>
              <p><strong>{Number.isSafeInteger(stats.latestRelease.manifest?.observation_count) ? stats.latestRelease.manifest.observation_count.toLocaleString() : "—"}</strong> source-scoped observations</p>
              <p><strong>{Number.isSafeInteger(stats.latestRelease.manifest?.pending_review_count) ? stats.latestRelease.manifest.pending_review_count.toLocaleString() : "—"}</strong> recorded pending-review items</p>
            </div>
            <p role="status" className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">These records are source-scoped research references, not independently verified physical-fit facts. A sealed or approved snapshot is not a published MATCH model catalog. Release activation is still blocked until conditional pointer updates and end-to-end verification are demonstrated; this panel cannot approve or activate it.</p>
          </>}
        </CardContent>
      </Card>
      {statsError && <p role="alert" className="text-sm text-red-700">{statsError}</p>}
      {stats.updated && <p className="text-xs text-muted-foreground">Last database refresh: {new Date(stats.updated).toLocaleTimeString()}</p>}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Research worker activity</CardTitle>
          <CardDescription>Read-only persisted research jobs and staging records. Viewing this page does not start research.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-4">
            <div><p className="text-xs text-muted-foreground">Model research jobs (among latest 25)</p><p className="text-2xl font-semibold">{researchJobs === null ? "—" : researchJobs.length}</p></div>
            <div><p className="text-xs text-muted-foreground">Staged (latest 500)</p><p className="text-2xl font-semibold">{stats.staging === null ? "—" : stats.staging.filter(r => r.status === "staged").length}</p></div>
            <div><p className="text-xs text-muted-foreground">Verified (latest 500)</p><p className="text-2xl font-semibold">{stats.staging === null ? "—" : stats.staging.filter(r => r.status === "verified").length}</p></div>
            <div><p className="text-xs text-muted-foreground">Conflicts (latest 500)</p><p className="text-2xl font-semibold">{stats.staging === null ? "—" : stats.staging.filter(r => r.status === "conflict").length}</p></div>
          </div>
          {researchJobs === null ? <p className="text-sm text-amber-700">Research job history could not be loaded.</p> : researchJobs.length === 0 ? <p className="text-sm text-muted-foreground">No manufacturer research worker is recorded among the most recent 25 jobs. Provider connection tests and design/entitlement proof jobs do not count as model research; a connected background research queue is not verified.</p> : <div className="space-y-2">{researchJobs.slice(0, 10).map(job => <div key={job.id} className="rounded-lg border p-3 flex items-start justify-between gap-4"><div className="min-w-0"><p className="font-medium">{job.manufacturer || job.batch_label || job.job_type}</p><p className="text-xs text-muted-foreground break-words">{job.provider || "coordinator"} · {researchJobActivity(job)}</p>{job.error_message && <p className="text-xs text-red-700 mt-1">{job.error_message}</p>}</div><Badge variant="outline" className="capitalize shrink-0">{String(job.status || "unknown").replaceAll("_", " ")}</Badge></div>)}</div>}
          {stats.staging !== null && stats.staging.some(r => r.status === "staged" || r.status === "conflict") && (
            <section aria-label="Model evidence requiring review" className="space-y-2">
              <h3 className="font-semibold text-sm">Source verification queue (latest records)</h3>
              <p className="text-xs text-muted-foreground">Research excerpts are leads, not confirmed model specifications. Review source documents and model-year applicability before any catalog promotion.</p>
              {stats.staging.filter(r => r.status === "staged" || r.status === "conflict").slice(0, 6).map(record => {
                const sourceUrl = safeResearchSourceUrl(record.source_url);
                const evidence = stagedEvidenceSummary(record);
                return <div key={record.id} className="rounded-lg border p-3 space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm">{record.manufacturer} {record.model || "Unnamed model"}</span>
                    <Badge variant="outline" className="capitalize">{record.status}</Badge>
                    <span className="text-xs text-muted-foreground">{evidence.documentedClaims} source-linked field claims (not published) · {record.model_years || "model years unverified"}</span>
                  </div>
                  {evidence.sourceContext && <p className="text-xs text-muted-foreground">{evidence.sourceContext}</p>}
                  {sourceUrl && <a href={sourceUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-700 underline break-all">Review original source document (may redirect)</a>}
                  {evidence.checks.length > 0 && <details className="rounded-md border bg-muted/20 p-2">
                    <summary className="cursor-pointer text-xs font-medium">{evidence.checks.length} recorded source checks — expand</summary>
                    {evidence.checks.map((check, index) => <p key={index} className="text-xs mt-2 break-words">Source check: {check}</p>)}
                  </details>}
                  {evidence.issues.map((issue, index) => <p key={index} className="text-xs text-amber-800 break-words">Unresolved: {issue}</p>)}
                  {evidence.action && <p className="text-xs text-amber-900 font-medium break-words">Before catalog publication: {evidence.action}</p>}
                </div>;
              })}
            </section>
          )}
          <p className="text-xs text-muted-foreground">Counts reflect persisted records only. Provider proof tasks are excluded from model-research job counts. Research jobs are counted only among the 25 most recent records of all job types, so older jobs may not appear. Staging counts cover the newest 500 records{stats.stagingCountCapped ? " (500+ records exist, so category counts are incomplete)" : ""}. No fabricated completion percentage or cost is shown.</p>
        </CardContent>
      </Card>
    </main>
  );
}
