import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import { Lock, Save, ArrowLeft, FlaskConical, Home } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { FIELD_TIERS, QUESTION_FIELD_GROUPS } from "@/lib/question-fields";

const TIERS = [
  { value: "match_plus", label: "Bosun", short: "$9" },
  { value: "refined_match", label: "First Mate", short: "$29" },
  { value: "market_match", label: "Captain", short: "$99" },
];

// Admin-only page: the owner assigns each questionnaire field to a tier.
// Free fields are shown to everyone. MATCH+ fields ($9) widen the set to the
// 10-14 models the buyer looks around with (nothing marked).
// Refined Match fields ($29) re-rank that same pool and decide the leading 5-7.
// Market Match fields ($99) re-rank it to the top 3 finalists and the ownership plan.
export default function AdminQuestionConfig() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [configId, setConfigId] = useState(null);
  const [matchPlus, setMatchPlus] = useState(Object.keys(FIELD_TIERS).filter(key => FIELD_TIERS[key] === "match_plus"));
  const [refinedMatch, setRefinedMatch] = useState([]);
  const [marketMatch, setMarketMatch] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        if (me?.role !== "admin") {
          toast({ title: "Admins only", variant: "destructive" });
          navigate("/dashboard");
          return;
        }
        const list = await base44.entities.QuestionConfig.list("-created_date", 1);
        const cfg = list?.[0];
        if (cfg) {
          setConfigId(cfg.id);
          setMatchPlus(Array.isArray(cfg.match_plus_fields) ? cfg.match_plus_fields : []);
          setRefinedMatch(Array.isArray(cfg.refined_match_fields) ? cfg.refined_match_fields : []);
          setMarketMatch(Array.isArray(cfg.market_match_fields) ? cfg.market_match_fields : []);
        }
      } catch (e) {
        toast({ title: "Could not load question config", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const tierOf = (key) => {
    if (marketMatch.includes(key)) return "market_match";
    if (refinedMatch.includes(key)) return "refined_match";
    if (matchPlus.includes(key)) return "match_plus";
    return "free";
  };

  const setTier = (key, tier) => {
    setMatchPlus((prev) => prev.filter((k) => k !== key));
    setRefinedMatch((prev) => prev.filter((k) => k !== key));
    setMarketMatch((prev) => prev.filter((k) => k !== key));
    if (tier === "match_plus") setMatchPlus((prev) => [...prev, key]);
    if (tier === "refined_match") setRefinedMatch((prev) => [...prev, key]);
    if (tier === "market_match") setMarketMatch((prev) => [...prev, key]);
  };

  const save = async () => {
    setSaving(true);
    try {
      if (configId) {
        await base44.entities.QuestionConfig.update(configId, {
          match_plus_fields: matchPlus,
          refined_match_fields: refinedMatch,
          market_match_fields: marketMatch,
        });
      } else {
        const created = await base44.entities.QuestionConfig.create({
          match_plus_fields: matchPlus,
          refined_match_fields: refinedMatch,
          market_match_fields: marketMatch,
        });
        setConfigId(created.id);
      }
      toast({
        title: "Saved",
        description: `${matchPlus.length} Bosun field(s), ${refinedMatch.length} First Mate field(s), ${marketMatch.length} Captain field(s).`,
      });
    } catch (e) {
      toast({ title: "Could not save", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <Navbar />
      <main className="max-w-3xl mx-auto px-4 py-10 space-y-6">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="font-heading text-2xl font-semibold flex items-center gap-2">
              <Lock className="w-5 h-5 text-accent" /> Tiered Questions
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Assign each questionnaire field to a tier. Free fields are shown to everyone.
              Bosun fields ($9) widen the set to the 10-14 models to look around with. First Mate fields ($29) re-rank that same pool and decide the leading 5-7. Captain
              fields ($99) re-rank it to the top 3 finalists and the ownership plan.
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Questionnaire fields</CardTitle>
            <CardDescription>
              {matchPlus.length} at Bosun · {refinedMatch.length} at First Mate · {marketMatch.length} at Captain ·{" "}
              {QUESTION_FIELD_GROUPS.flatMap((g) => g.fields).length - matchPlus.length - refinedMatch.length - marketMatch.length} free
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {QUESTION_FIELD_GROUPS.map((grp) => (
              <div key={grp.group}>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-2">
                  {grp.group}
                </p>
                <div className="space-y-1">
                  {grp.fields.map((f) => {
                    const tier = tierOf(f.key);
                    return (
                      <div
                        key={f.key}
                        className="flex items-center justify-between gap-3 rounded-lg border border-border bg-card px-3 py-2.5"
                      >
                        <span className="text-sm font-medium">{f.label}</span>
                        <div className="flex rounded-lg border border-border overflow-hidden">
                          <button
                            type="button"
                            onClick={() => setTier(f.key, "free")}
                            className={`text-xs px-3 py-1.5 transition ${
                              tier === "free"
                                ? "bg-muted text-foreground"
                                : "bg-card text-muted-foreground hover:bg-muted/50"
                            }`}
                          >
                            Free
                          </button>
                          {TIERS.map((t) => {
                            const active = tier === t.value;
                            return (
                              <button
                                key={t.value}
                                type="button"
                                onClick={() => setTier(f.key, t.value)}
                                className={`text-xs px-3 py-1.5 transition ${
                                  active
                                    ? t.value === "market_match"
                                      ? "bg-primary text-primary-foreground"
                                      : t.value === "refined_match"
                                      ? "bg-accent text-accent-foreground"
                                      : "bg-accent/70 text-accent-foreground"
                                    : "bg-card text-muted-foreground hover:bg-muted/50"
                                }`}
                              >
                                {t.short}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="flex flex-wrap gap-2">
          <Button onClick={save} disabled={saving}>
            <Save className="w-4 h-4 mr-2" /> {saving ? "Saving…" : "Save configuration"}
          </Button>
          <Button variant="outline" onClick={() => navigate("/admin/test-profiles")}>
            <FlaskConical className="w-4 h-4 mr-2" /> Test profile simulator
          </Button>
          <Button variant="secondary" onClick={() => navigate("/")}>
            <Home className="w-4 h-4 mr-2" /> Exit to home
          </Button>
        </div>
      </main>
    </div>
  );
}