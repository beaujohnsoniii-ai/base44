import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import Navbar from '@/components/Navbar';
import Home from '@/pages/Home';
import MatchEntry from '@/pages/MatchEntry';
import Explore from '@/pages/Explore';
import HomeOptions from '@/pages/HomeOptions';
import Tools from '@/pages/Tools';
import Questionnaire from '@/pages/Questionnaire';
import Dashboard from '@/pages/Dashboard';
import ThankYou from '@/pages/ThankYou';
import Report from '@/pages/Report';
import ProfileInterview from '@/pages/ProfileInterview';
import StageGuide from '@/pages/StageGuide';
import BoatAnalysis from '@/pages/BoatAnalysis';
import OwnershipCalculator from '@/pages/OwnershipCalculator';
import EditProfile from '@/pages/EditProfile';
import AdminRelabel from '@/pages/AdminRelabel';
import AdminTestProfiles from '@/pages/AdminTestProfiles';
import AdminGradeTrends from '@/pages/AdminGradeTrends';
import AdminFeedbackAnalytics from '@/pages/AdminFeedbackAnalytics';
import AdminQuestionConfig from '@/pages/AdminQuestionConfig';
import AdminMatchQA from '@/pages/AdminMatchQA';
import AdminFunnelDistribution from '@/pages/AdminFunnelDistribution';
import AdminResearchMonitor from '@/pages/AdminResearchMonitor';
import AdminPrivateMatchTrial from '@/pages/AdminPrivateMatchTrial';
import AdminJourneyTrial from '@/pages/AdminJourneyTrial';
import AdminBuyerLaunchTest from '@/pages/AdminBuyerLaunchTest';
import AdminListingIntakeStage from '@/pages/AdminListingIntakeStage';
import FindMyBoatReport from '@/pages/FindMyBoatReport';
import ProtectedRoute from '@/components/ProtectedRoute';
import AdminRoute from '@/components/AdminRoute';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import OAuthConsent from '@/pages/OAuthConsent';
import FloatingGuide from "@/components/FloatingGuide";
import JourneyWorkspace from "@/pages/JourneyWorkspace";

// Only routes without their own Navbar use this presentation wrapper.
// Protected routes retain their existing outer authentication boundary.
function SharedHeaderPage({ children }) {
  return <div className="shared-header-page"><Navbar /><div className="shared-header-content">{children}</div></div>;
}

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin, checkAppState } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    } else {
      return <main className="max-w-lg mx-auto p-8 space-y-4" role="alert"><h1 className="text-xl font-semibold">App connection unavailable</h1><p>{authError.message || 'The app could not finish loading.'}</p><button className="rounded border px-4 py-3" onClick={checkAppState}>Retry loading</button><p className="text-sm">Retrying loading does not run a provider test.</p></main>;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<SharedHeaderPage><Login /></SharedHeaderPage>} />
      <Route path="/register" element={<SharedHeaderPage><Register /></SharedHeaderPage>} />
      <Route path="/forgot-password" element={<SharedHeaderPage><ForgotPassword /></SharedHeaderPage>} />
      <Route path="/reset-password" element={<SharedHeaderPage><ResetPassword /></SharedHeaderPage>} />
      <Route path="/oauth/consent" element={<SharedHeaderPage><OAuthConsent /></SharedHeaderPage>} />
      <Route path="/" element={<Home />} />
      <Route path="/home-original" element={<Explore />} />
      <Route path="/home-options" element={<HomeOptions />} />
      <Route path="/tools" element={<Tools />} />

      <Route path="/ThankYou" element={<ThankYou />} />
      <Route element={<ProtectedRoute />}>
        <Route path="/helm" element={<Dashboard />} />
        <Route path="/match" element={<SharedHeaderPage><MatchEntry /></SharedHeaderPage>} />
        <Route path="/my-matches" element={<Dashboard matchOnly />} />
        <Route path="/questionnaire" element={<Questionnaire />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/compare" element={<JourneyWorkspace stage="Compare" />} />
        <Route path="/guide" element={<StageGuide />} />
        <Route path="/deal" element={<JourneyWorkspace stage="Deal" />} />
        <Route path="/report/:type" element={<Report />} />
        <Route path="/report/find-my-boat" element={<FindMyBoatReport />} />
        <Route path="/profile-interview" element={<ProfileInterview />} />
        <Route path="/stage-guide" element={<StageGuide />} />
        <Route path="/boat-analysis" element={<JourneyWorkspace stage="Analyze" />} />
        <Route path="/ownership-calculator" element={<JourneyWorkspace stage="Ownership" />} />
        <Route path="/candidate-advisor" element={<BoatAnalysis />} />
        <Route path="/ownership-estimator" element={<OwnershipCalculator />} />
        <Route path="/edit-profile" element={<EditProfile />} />
        <Route element={<AdminRoute />}>
        <Route path="/admin/relabel" element={<SharedHeaderPage><AdminRelabel /></SharedHeaderPage>} />
        <Route path="/admin/test-profiles" element={<SharedHeaderPage><AdminTestProfiles /></SharedHeaderPage>} />
        <Route path="/admin/grade-trends" element={<SharedHeaderPage><AdminGradeTrends /></SharedHeaderPage>} />
        <Route path="/admin/feedback-analytics" element={<SharedHeaderPage><AdminFeedbackAnalytics /></SharedHeaderPage>} />
        <Route path="/admin/question-config" element={<AdminQuestionConfig />} />
        <Route path="/admin/match-qa" element={<SharedHeaderPage><AdminMatchQA /></SharedHeaderPage>} />
        <Route path="/admin/funnel-distribution" element={<SharedHeaderPage><AdminFunnelDistribution /></SharedHeaderPage>} />
        <Route path="/admin/research-monitor" element={<SharedHeaderPage><AdminResearchMonitor /></SharedHeaderPage>} />
        <Route path="/admin/private-match-trial" element={<SharedHeaderPage><AdminPrivateMatchTrial /></SharedHeaderPage>} />
        <Route path="/admin/buyer-launch-test" element={<SharedHeaderPage><AdminBuyerLaunchTest /></SharedHeaderPage>} />
        <Route path="/admin/listing-intake-stage" element={<SharedHeaderPage><AdminListingIntakeStage /></SharedHeaderPage>} />
        <Route path="/admin/journey-trial" element={<SharedHeaderPage><AdminJourneyTrial /></SharedHeaderPage>} />
        </Route>
      </Route>
      <Route path="*" element={<SharedHeaderPage><PageNotFound /></SharedHeaderPage>} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
          <FloatingGuide />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App