import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, Pencil, RotateCw, Loader2 } from "lucide-react";

export default function ContradictionBanner({ profile, onResolved }) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [rerunning, setRerunning] = useState(false);

  const flag = profile?.contradiction_flag;
  if (!flag?.flagged) return null;

  const credit = Number(profile.advisor_credit || 0);
  const expires = profile.advisor_credit_expires;
  const expiresLabel = expires
    ? new Date(expires).toLocaleDateString("en-US", { month: "short", day: "numeric" })
    : null;

  const handleRerun = async () => {
    setRerunning(true);
    try {
      const res = await base44.functions.invoke("suggest-boats", { refresh: true });
      const suggestions = res?.data?.suggestions || [];
      if (onResolved) onResolved(suggestions);
      toast({
        title: "Advisor re-run complete",
        description: suggestions.length
          ? `${suggestions.length} fresh suggestions ready.`
          : "Your profile has been re-evaluated.",
      });
    } catch (e) {
      toast({ title: "Could not re-run advisor", variant: "destructive" });
    } finally {
      setRerunning(false);
    }
  };

  return (
    <Card className="border-amber-400/60 bg-amber-50 dark:bg-amber-950/30">
      <CardContent className="p-5 space-y-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-500 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-medium text-amber-900 dark:text-amber-200">Potential issues to review</p>
            <p className="text-sm text-amber-800 dark:text-amber-300">{flag.explanation}</p>
          </div>
        </div>

        {Array.isArray(flag.conflicts) && flag.conflicts.length > 0 && (
          <div className="ml-8 space-y-1">
            <p className="text-xs font-medium text-amber-700 dark:text-amber-400 uppercase tracking-wide">Conflicting constraints</p>
            <ul className="text-sm text-amber-800 dark:text-amber-300 space-y-0.5">
              {flag.conflicts.map((c, i) => (
                <li key={i} className="flex gap-2">
                  <span className="text-amber-500">•</span>
                  <span>{c}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {Array.isArray(flag.closest_alternatives) && flag.closest_alternatives.length > 0 && (
          <div className="ml-8 space-y-1">
            <p className="text-xs font-medium text-amber-700 dark:text-amber-400 uppercase tracking-wide">Closest realistic paths</p>
            <ul className="text-sm text-amber-800 dark:text-amber-300 space-y-0.5">
              {flag.closest_alternatives.map((a, i) => (
                <li key={i} className="flex gap-2">
                  <span className="text-amber-500">→</span>
                  <span>{a}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {credit > 0 && (
          <div className="ml-8 text-sm text-amber-800 dark:text-amber-300">
            <span className="font-medium">${credit} credit</span> issued for the inconvenience
            {expiresLabel ? ` — expires ${expiresLabel}.` : "."} Use it toward your first paid report after you adjust your profile.
          </div>
        )}

        <div className="ml-8 text-sm text-amber-800 dark:text-amber-300">
          Free re-runs remaining: {Math.max(0, 3 - (Number(profile.contradiction_rerun_count) || 0))} of 3 after a potential issue is flagged.
        </div>

        <div className="flex flex-wrap gap-2 ml-8">
          <Button variant="outline" onClick={() => navigate("/edit-profile")}>
            <Pencil className="w-4 h-4 mr-2" /> Edit your profile
          </Button>
          <Button onClick={handleRerun} disabled={rerunning}>
            {rerunning ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RotateCw className="w-4 h-4 mr-2" />}
            {rerunning ? "Re-running…" : "Re-run advisor"}
          </Button>
        </div>

        <p className="ml-8 text-sm font-medium text-amber-900 dark:text-amber-200 border-t border-amber-300/50 pt-3">
          Please take a few minutes to review and edit your profile accordingly — the results will improve significantly once the flagged fields are corrected.
        </p>
      </CardContent>
    </Card>
  );
}