import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { StickyNote, ExternalLink, Trash2, Plus, Loader2 } from "lucide-react";

export default function ResearchNotesPanel({ profile, notes, onNotesChange, onProfileNotesSaved }) {
  const { toast } = useToast();
  const [url, setUrl] = useState("");
  const [label, setLabel] = useState("");
  const [savingLink, setSavingLink] = useState(false);
  const [notesText, setNotesText] = useState(profile?.research_notes || "");
  const [savingNotes, setSavingNotes] = useState(false);
  const [removingId, setRemovingId] = useState(null);

  const addLink = async () => {
    const trimmed = url.trim();
    if (!trimmed) {
      toast({ title: "Add a link first", description: "Paste a URL to save it.", variant: "destructive" });
      return;
    }
    let normalized = trimmed;
    if (!/^https?:\/\//i.test(normalized)) normalized = "https://" + normalized;
    setSavingLink(true);
    try {
      const created = await base44.entities.ResearchNote.create({ url: normalized, label: label.trim() });
      onNotesChange([...(notes || []), created]);
      setUrl("");
      setLabel("");
      toast({ title: "Link saved", description: "Added to your research notes." });
    } catch (e) {
      toast({ title: "Could not save link", variant: "destructive" });
    } finally {
      setSavingLink(false);
    }
  };

  const removeLink = async (id) => {
    setRemovingId(id);
    try {
      await base44.entities.ResearchNote.delete(id);
      onNotesChange((notes || []).filter((n) => n.id !== id));
    } catch (e) {
      toast({ title: "Could not remove link", variant: "destructive" });
    } finally {
      setRemovingId(null);
    }
  };

  const saveNotes = async () => {
    if (!profile?.id) {
      toast({ title: "Build your profile first", description: "Take the questionnaire to start saving notes.", variant: "destructive" });
      return;
    }
    setSavingNotes(true);
    try {
      const updated = await base44.entities.BuyerProfile.update(profile.id, { research_notes: notesText });
      onProfileNotesSaved?.(updated);
      toast({ title: "Notes saved" });
    } catch (e) {
      toast({ title: "Could not save notes", variant: "destructive" });
    } finally {
      setSavingNotes(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><StickyNote className="w-5 h-5" /> Research notes</CardTitle>
        <CardDescription>
          Keep your search research in one place — forum threads, walkthrough videos, surveyor names, slip-fee pages, insurance quotes. Your saved links and notes feed into your paid shortlist reports.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Add link form */}
        <div className="space-y-3">
          <div className="grid sm:grid-cols-[1fr_1fr_auto] gap-2 items-start">
            <Input
              type="url"
              placeholder="https://…"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !savingLink) addLink(); }}
            />
            <Input
              placeholder="Label (e.g. Grady hull issue thread)"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !savingLink) addLink(); }}
            />
            <Button onClick={addLink} disabled={savingLink}>
              {savingLink ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              <span className="sm:sr-only">Add</span>
            </Button>
          </div>
        </div>

        {/* Saved links */}
        <div className="divide-y rounded-lg border border-border">
          {notes.length === 0 ? (
            <p className="text-sm text-muted-foreground p-4">No research links saved yet.</p>
          ) : (
            notes.map((n) => (
              <div key={n.id} className="flex items-center gap-3 p-3">
                <a
                  href={n.url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 min-w-0 flex-1 text-sm hover:text-accent"
                  title={n.url}
                >
                  <ExternalLink className="w-4 h-4 shrink-0 text-muted-foreground" />
                  <span className="truncate">
                    {n.label || n.url}
                    {n.label && <span className="block text-xs text-muted-foreground truncate">{n.url}</span>}
                  </span>
                </a>
                <Button
                  variant="ghost"
                  size="icon"
                  className="shrink-0 text-muted-foreground hover:text-destructive"
                  disabled={removingId === n.id}
                  onClick={() => removeLink(n.id)}
                >
                  {removingId === n.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                </Button>
              </div>
            ))
          )}
        </div>

        {/* Free-text notes */}
        <div className="space-y-2">
          <Textarea
            placeholder="Free-form notes — surveyor names, questions for sellers, insurance quotes, slip fees, anything you want the advisor to consider…"
            value={notesText}
            onChange={(e) => setNotesText(e.target.value)}
            rows={5}
          />
          <div className="flex justify-end">
            <Button variant="outline" onClick={saveNotes} disabled={savingNotes || !profile}>
              {savingNotes ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              Save notes
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}