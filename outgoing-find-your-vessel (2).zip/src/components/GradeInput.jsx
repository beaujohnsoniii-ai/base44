import React, { useState, useEffect, useRef } from "react";
import { base44Test } from "@/lib/base44TestClient";
import { useToast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea";
import StarRating from "@/components/StarRating";
import { Loader2 } from "lucide-react";

export default function GradeInput({ phase, profileId, suggestionId, reportId, existingGrade }) {
  const { toast } = useToast();
  const [grade, setGrade] = useState(existingGrade?.grade || 0);
  const [comment, setComment] = useState(existingGrade?.comment || "");
  const [saving, setSaving] = useState(false);
  const [gradeRecord, setGradeRecord] = useState(existingGrade || null);
  const recordIdRef = useRef(existingGrade?.id);

  useEffect(() => {
    setGrade(existingGrade?.grade || 0);
    setComment(existingGrade?.comment || "");
    setGradeRecord(existingGrade || null);
    recordIdRef.current = existingGrade?.id;
  }, [existingGrade?.id]);

  const save = async (newGrade, newComment) => {
    if (newGrade === 0 && !newComment.trim()) return;
    setSaving(true);
    try {
      const data = {
        phase,
        profile_id: profileId,
        suggestion_id: suggestionId || null,
        report_id: reportId || null,
        grade: newGrade,
        comment: newComment,
      };
      let record;
      if (recordIdRef.current) {
        record = await base44Test.entities.TestGrade.update(recordIdRef.current, data);
      } else {
        record = await base44Test.entities.TestGrade.create(data);
        recordIdRef.current = record.id;
      }
      setGradeRecord(record);
      toast({ title: "Grade saved", duration: 1200 });
    } catch (e) {
      console.error("Save grade error", e);
      toast({ title: "Could not save grade", variant: "destructive", duration: 1500 });
    } finally {
      setSaving(false);
    }
  };

  const handleStarChange = (newGrade) => {
    setGrade(newGrade);
    save(newGrade, comment);
  };

  const handleCommentBlur = () => {
    if (comment !== (gradeRecord?.comment || "")) {
      save(grade, comment);
    }
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-2">
        <StarRating value={grade} onChange={handleStarChange} size={18} />
        {saving && <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />}
        {grade > 0 && !saving && (
          <span className="text-xs text-muted-foreground tabular-nums">{grade}/5</span>
        )}
      </div>
      <Textarea
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        onBlur={handleCommentBlur}
        placeholder="Comment for the AI advisor…"
        className="text-xs min-h-[50px] resize-y"
      />
    </div>
  );
}