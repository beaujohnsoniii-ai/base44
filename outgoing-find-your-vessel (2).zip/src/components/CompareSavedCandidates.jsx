import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { listingUrls, normalizeListingUrl, selectionFor } from "@/lib/compareCandidates";
import { compareResultLink } from "@/lib/matchResultLink";
import { requestDeadline } from "@/lib/requestDeadline";
import { compareWithSavedInputs } from "@/lib/compareAction";
import { loadCompareCandidates } from "@/lib/matchCompareHandoff";
import { Button } from "@/components/ui/button";
import CompareImportResults from "@/components/CompareImportResults";
import ModelComparisonView from "@/components/ModelComparisonView";
import { compareModelsWithSavedSelection } from "@/lib/compareModelsAction";
import { useListingIntake } from "@/lib/useListingIntake";
import ListingIntakePanel from "@/components/ListingIntakePanel";

function ListingFields({ boat, onSaved, onDirty, comparing, startWrite, endWrite, onUncertain, captureValues, onCaptureValues }) {
  const [values, setValues] = useState(boat.listing_urls?.length ? boat.listing_urls : [""]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const change = (next, nextCaptures = captureValues) => { setValues(next); onCaptureValues(nextCaptures); onDirty(boat.id, true, next); setMessage(""); setError(""); };
  const captureAt = (index, text) => { const next=[...captureValues]; next[index]=text; onCaptureValues(next); };
  const save = async () => {
    setError(""); setMessage("");
    let urls;
    try { urls = listingUrls(values); } catch (e) { setError(e.message); return; }
    if (!startWrite()) return;
    setBusy(true);
    try {
      await requestDeadline(async signal => {
      const saved = await base44.entities.SavedBoat.update(boat.id, { listing_urls: urls }); signal.throwIfAborted();
      // Verify durable data before claiming success.
      const confirmed = await base44.entities.SavedBoat.get(boat.id); signal.throwIfAborted();
      if (JSON.stringify(confirmed.listing_urls || []) !== JSON.stringify(urls)) throw new Error("verification");
      setValues(urls.length ? urls : [""]); onCaptureValues([]); onSaved({ ...boat, ...saved, ...confirmed }); onDirty(boat.id, false);
      setMessage(urls.length ? "Listing links saved to your account." : "Listing links cleared from your account.");
      }, 15000, "Link save was not confirmed. Your entries remain here. Copy any unsaved entries before reloading to check your account.");
    } catch (e) { if(e.code==="REQUEST_TIMEOUT"){onUncertain();setError(e.message);}else setError("Could not confirm the save. Your entries are still here; retry saving."); }
    finally { setBusy(false); endWrite(); }
  };
  return <div className="space-y-3 border-t pt-3">
    <p className="font-medium">Current listing links (up to 3)</p>
    <p className="text-sm text-muted-foreground">Paste a listing URL or the text copied from a listing's Share button. We keep the link when you save or compare.</p>
    {values.map((value, i) => <div key={i} className="space-y-1">
      <label className="text-sm" htmlFor={boat.id + "-listing-" + i}>Listing {i + 1} URL</label>
      <div className="flex gap-2">
        <input id={boat.id + "-listing-" + i} type="text" inputMode="url" autoCapitalize="none" autoCorrect="off" spellCheck={false} placeholder="Paste boat listing link or Share text" value={value} disabled={busy || comparing} onPaste={e => { try { const url = normalizeListingUrl(e.clipboardData.getData("text")); if (url) { e.preventDefault(); change(values.map((v, n) => n === i ? url : v), captureValues.map((v, n) => n === i ? "" : v)); } } catch { /* Keep the pasted text so the buyer sees a specific validation message on Save. */ } }} onChange={e => change(values.map((v, n) => n === i ? e.target.value : v), captureValues.map((v, n) => n === i ? "" : v))} className="min-w-0 w-full rounded border p-3 text-base" />
        <Button type="button" disabled={busy || comparing} aria-label={"Remove listing " + (i + 1)} onClick={() => change(values.length === 1 ? [""] : values.filter((_, n) => n !== i), values.length === 1 ? [] : captureValues.filter((_, n) => n !== i))} className="min-h-11 px-3" variant="outline">Remove</Button>
      </div>
      <label className="text-xs text-muted-foreground" htmlFor={boat.id + "-capture-" + i}>If automatic import fails, paste the visible title, details, and specifications from this exact page (optional)</label>
      <textarea id={boat.id + "-capture-" + i} value={captureValues[i] || ""} maxLength={16000} rows={4} disabled={busy || comparing || !value.trim()} onChange={e => captureAt(i,e.target.value)} className="min-w-0 w-full rounded border p-3 text-sm" placeholder="Buyer-copied page text; sent only for this Compare action and not saved." />
    </div>)}
    <div className="sh-compare-actions">
      <Button variant="outline" disabled={busy || comparing || values.length >= 3} onClick={() => change([...values, ""], [...captureValues, ""])} className="min-h-11">Add listing</Button>
      <Button variant="outline" disabled={busy || comparing} onClick={() => change([""], [])} className="min-h-11">Clear links</Button>
      <Button disabled={busy || comparing} onClick={save} className="min-h-11">{busy ? "Saving…" : "Save links"}</Button>
    </div>
    <p className="text-xs text-muted-foreground">Links save when you choose Compare. Copied page text is transient, is not independently verified, and is never saved to your account.</p>
    {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
    {message && <p role="status" className="text-sm">{message}</p>}
  </div>;
}

export default function CompareSavedCandidates({ listingIntakeDataEnv = "prod" } = {}) {
  const intake = useListingIntake(listingIntakeDataEnv);
  const [boats, setBoats] = useState([]);
  const [workspace, setWorkspace] = useState(null);
  const [selected, setSelected] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectionMessage, setSelectionMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [retry, setRetry] = useState(0);
  const [drafts, setDrafts] = useState({});
  const [captures, setCaptures] = useState({});
  const [comparing, setComparing] = useState(false);
  const [comparison, setComparison] = useState(null);
  const [compareError, setCompareError] = useState("");
  const [modelComparison, setModelComparison] = useState(null);
  const [modelError, setModelError] = useState("");
  const compareModels = async () => {
    if(compareInFlight.current || writeInFlight.current)return;
    compareInFlight.current=true;setComparing(true);setModelError("");setModelComparison(null);
    try {
      const result=await compareModelsWithSavedSelection(base44,{boats,selected,workspace});
      setWorkspace(result.workspace);setModelComparison(result.comparison);
    } catch(e){if(e.code==="REQUEST_TIMEOUT"&&e.save_uncertain)onUncertain();setModelError(e?.response?.data?.error||e.message||"Model comparison unavailable.");}
    finally{compareInFlight.current=false;setComparing(false);}
  };
  const markDirty = (id, value, values) => { setDrafts(current => { const next={...current}; if(value)next[id]=values;else delete next[id];return next; }); setComparison(null); };
  const compareInFlight=useRef(false);
  const writeInFlight=useRef(false),uncertainWrite=useRef(false);
  const [writeUncertain,setWriteUncertain]=useState(false);
  const startWrite=()=>{if(compareInFlight.current||writeInFlight.current)return false;writeInFlight.current=true;setBusy(true);return true;};
  const endWrite=()=>{writeInFlight.current=uncertainWrite.current;setBusy(false);};
  const onUncertain=()=>{uncertainWrite.current=true;writeInFlight.current=true;setWriteUncertain(true);};
  const compare = async () => {
    if(compareInFlight.current)return;
    if(writeInFlight.current)return;
    compareInFlight.current=true;
    setComparing(true); setCompareError(""); setComparison(null);
    try {
      const result = await compareWithSavedInputs(base44, {boats, selected, drafts, captures, workspace}, saved => {
        setBoats(current => current.map(b => b.id === saved.id ? {...b,...saved} : b));
        markDirty(saved.id, false);
      });
      setWorkspace(result.workspace); setComparison(result.comparison);
    } catch (e) { if(e.code==="REQUEST_TIMEOUT"&&e.save_uncertain)onUncertain(); setCompareError(e?.response?.data?.error || e.message || "Comparison unavailable. Your entries remain here; any confirmed saves are retained."); }
    finally { compareInFlight.current=false; setComparing(false); }
  };
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const {saved,spaces}=await requestDeadline(async signal=>{
        const me = await base44.auth.me();signal.throwIfAborted();
        const saved = await loadCompareCandidates(base44, me.id, signal);signal.throwIfAborted();
        const spaces = await base44.entities.CompareWorkspace.filter({ created_by_id: me.id }, "-created_date", 1);signal.throwIfAborted();
        return {saved,spaces};
        },15000,"Loading saved candidates timed out.");
        if (active) { setModelComparison(null); setBoats(saved); setWorkspace(spaces[0] || null); setSelected(selectionFor(saved, spaces[0])); setError(""); }
      } catch { if (active) setError("Your saved candidates could not be loaded. Please retry."); }
      finally { if (active) setLoading(false); }
    })();
    return () => { active = false; };
  }, [retry]);
  useEffect(() => { const refresh = () => setRetry(x => x + 1); window.addEventListener("soundheading-candidates-changed", refresh); return () => window.removeEventListener("soundheading-candidates-changed", refresh); }, []);
  const persistSelection = async next => {
    if (next.length > 3) { setSelectionMessage("Choose up to three. Deselect a model before adding another; all candidates stay saved."); return; }
    if(!startWrite())return;
    setSelectionMessage(""); setComparison(null); setModelComparison(null); setModelError("");
    try {
      await requestDeadline(async signal=>{
      const saved = workspace
        ? await base44.entities.CompareWorkspace.update(workspace.id, { selected_ids: next })
        : await base44.entities.CompareWorkspace.create({ selected_ids: next });signal.throwIfAborted();
      const confirmed = await base44.entities.CompareWorkspace.get(saved.id);signal.throwIfAborted();
      if (JSON.stringify(confirmed.selected_ids) !== JSON.stringify(next)) throw new Error("verification");
      setWorkspace(confirmed); setSelected(next); setSelectionMessage("Your Compare selection is saved.");
      },15000,"Selection save was not confirmed. Your current selection remains here. Reload to check your account before retrying.");
    } catch(e) { if(e.code==="REQUEST_TIMEOUT"){onUncertain();setSelectionMessage(e.message);}else setSelectionMessage("Could not confirm the selection save. Please retry."); }
    finally { endWrite(); }
  };
  return <section className="space-y-4" aria-label="Saved Match candidates">
    <div><h2 className="text-xl font-heading">Your saved candidates ({boats.length})</h2>
      <p className="text-sm text-muted-foreground">Automatically carried over from Match. Choose your top three without deleting other saved candidates.</p>
      <p className="mt-2">{selected.length} of 3 selected{!workspace && boats.length > 0 ? " · First saved models selected to get you started. Change a selection to save your preference." : ""}</p>
      {!loading && !error && boats.length > 0 && <Button variant="outline" disabled={busy || comparing || writeUncertain} onClick={() => persistSelection(selected)} className="min-h-11 mt-3">Save current selection</Button>}
      {selectionMessage && <p role="status">{selectionMessage}</p>}
    </div>
    {loading ? <p role="status">Loading your saved candidates…</p> : error ?
      <div role="alert"><p>{error}</p><button className="underline min-h-11" onClick={() => { setLoading(true); setRetry(x => x + 1); }}>Retry</button></div> :
      boats.length === 0 ? <div className="rounded-xl border bg-white p-5"><p>No saved candidates yet. Save a model from your Match results and it will appear here.</p><Link className="inline-block underline mt-3" to="/match">Go to My Matches</Link></div> :
      <div className="sh-compare-model-grid grid md:grid-cols-3 gap-4">{boats.map(boat => {
        const rank = selected.indexOf(boat.id);
        let originalUrl = "";
        try { originalUrl = listingUrls([boat.url || ""])[0] || ""; } catch {}
        return <article key={boat.id} className={"min-w-0 rounded-xl border bg-white p-5 space-y-3 " + (rank >= 0 ? "border-primary" : "")}>
          <h3 className="font-semibold">{boat.title || [boat.make, boat.model, boat.year].filter(Boolean).join(" ") || "Saved boat"}</h3>
          <Button variant={rank >= 0 ? "default" : "outline"} disabled={busy || comparing || writeUncertain} aria-pressed={rank >= 0} onClick={() => persistSelection(selected.includes(boat.id) ? selected.filter(id => id !== boat.id) : [...selected, boat.id])} className="min-h-11">{rank >= 0 ? "Selected " + (rank + 1) + " · Deselect" : "Select for Compare"}</Button>
          <a className="block underline py-2" href={compareResultLink(boat)} target="_blank" rel="noopener noreferrer">{boat.original_match_url ? "Open original Match result" : originalUrl ? "Open original saved link" : "Search Google for this model"}</a>
          <p className="text-xs text-muted-foreground">Original research link or model search; not a verified listing.</p>
          {intake.enabled && <Button variant="outline" size="sm" onClick={() => intake.openReview(boat)}>Review listings</Button>}
          {originalUrl && <a className="block underline" href={originalUrl} target="_blank" rel="noopener noreferrer">Open original saved listing</a>}
          {boat.match?.summary && <p className="text-sm">{boat.match.summary}</p>}
          {boat.match?.matches?.length > 0 && <p className="text-sm">Match strengths: {boat.match.matches.join("; ")}</p>}
          {boat.match?.gaps?.length > 0 && <p className="text-sm">To verify: {boat.match.gaps.join("; ")}</p>}
          {boat.specs && <p className="text-sm whitespace-pre-wrap">{boat.specs}</p>}
          {boat.notes && <p className="text-sm whitespace-pre-wrap">{boat.notes}</p>}
          <details hidden={rank < 0}><summary className="cursor-pointer underline py-2">Optional: add actual listing links</summary><ListingFields boat={boat} comparing={comparing || busy || writeUncertain} startWrite={startWrite} endWrite={endWrite} onUncertain={onUncertain} onDirty={markDirty} captureValues={captures[boat.id] || []} onCaptureValues={values => setCaptures(current => ({...current,[boat.id]:values}))} onSaved={saved => setBoats(current => current.map(b => b.id === saved.id ? saved : b))} /></details>
        </article>;
      })}</div>}
    {!loading && !error && boats.length > 0 && <section className="rounded-xl border bg-white p-5 space-y-3" aria-label="Compare database models">
      <h2 className="text-xl font-heading">Compare your selected models</h2>
      <p>Compare saved models using SoundHeading’s database. No listing links are needed. Missing or conflicting specifications remain visible.</p>
      <Button className="min-h-11" disabled={busy || comparing || writeUncertain || !selected.length} onClick={compareModels}>{comparing ? "Checking…" : "Compare models"}</Button>
      <p className="text-xs text-muted-foreground">Uses stored research without paid AI or listing retrieval. Use Find inside Match to look for boats for sale, then save your favorites here.</p>
      {modelError && <p role="alert" className="text-red-700">{modelError}</p>}
      {modelComparison && <ModelComparisonView comparison={modelComparison} />}
    </section>}
    {!loading && !error && boats.length > 0 && <details className="rounded-xl border bg-white p-5 space-y-3" aria-label="Compare saved listings">
      <summary className="cursor-pointer font-medium">Optional: check actual listing details</summary>
      <h2 className="text-xl font-heading">Compare your saved listings</h2>
      <p className="text-sm">Paste each actual listing URL once, then choose Compare. Your links and selection are saved automatically. Retrieval from boats.com, boattrader.com and yachtworld.com is attempted; blocked pages may provide no details. Other links are saved with a warning. Seller claims are evidence only, not verified specifications.</p>
      <Button className="min-h-11" disabled={busy || comparing || writeUncertain || !selected.length} onClick={compare}>{comparing ? "Saving and checking…" : "Compare"}</Button>
      <p className="text-xs text-muted-foreground">This evidence check does not consume an AI evaluation allowance.</p>
      {writeUncertain && <p role="alert">A save could not be confirmed. Your entries remain visible. Copy any unsaved entries before reloading to check your account; further saves are paused.</p>}
      {compareError && <p role="alert" className="text-red-700">{compareError}</p>}
      {comparison && <CompareImportResults comparison={comparison} />}
    </details>}
    <Link className="inline-block underline text-sm" to="/dashboard">Manage saved candidates in My Account</Link>
    {intake.enabled && intake.reviewBoat && <ListingIntakePanel boat={intake.reviewBoat} requestMode={listingIntakeDataEnv} sourceType="saved" onClose={intake.closeReview} onCountChange={intake.updateCounts} />}
  </section>;
}