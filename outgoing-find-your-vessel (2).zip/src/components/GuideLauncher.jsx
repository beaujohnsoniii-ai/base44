import React, { useEffect, useId, useRef, useState } from "react";
import {
  GUIDE_LAUNCHER_SIZE,
  clampGuidePosition,
  defaultGuidePosition,
  fitGuideLauncher,
  keyboardGuidePosition,
  moveGuideDrag,
  readGuideViewport,
  startGuideDrag,
} from "./guide-launcher-position.mjs";
import "./guide-launcher.css";

export default function GuideLauncher({ launcherRef, open, onToggle, onClose }) {
  const helpId = useId();
  const [geometry, setGeometry] = useState({ position: null, size: GUIDE_LAUNCHER_SIZE });
  const [dragging, setDragging] = useState(false);
  const [announcement, setAnnouncement] = useState("");
  const current = useRef(geometry);
  const moved = useRef(false);
  const drag = useRef(null);
  const suppressClick = useRef(false);

  function place(position, size) {
    current.current = { position, size };
    setGeometry(current.current);
  }

  useEffect(() => {
    function keepVisible() {
      const viewport = readGuideViewport(window);
      const size = fitGuideLauncher(viewport);
      const position = moved.current && current.current.position
        ? clampGuidePosition(current.current.position, viewport, size)
        : defaultGuidePosition(viewport, size);
      // A viewport change can interrupt a gesture (for example rotation). End
      // that gesture without allowing its eventual click to open the panel.
      if (drag.current) {
        suppressClick.current = true;
        drag.current = null;
        setDragging(false);
      }
      place(position, size);
    }
    keepVisible();
    window.addEventListener("resize", keepVisible);
    const viewport = window.visualViewport;
    viewport?.addEventListener("resize", keepVisible);
    viewport?.addEventListener("scroll", keepVisible);
    return () => {
      window.removeEventListener("resize", keepVisible);
      viewport?.removeEventListener("resize", keepVisible);
      viewport?.removeEventListener("scroll", keepVisible);
    };
  }, []);

  function startDrag(event) {
    if (event.button !== 0 || event.isPrimary === false) return;
    const viewport = readGuideViewport(window);
    const size = fitGuideLauncher(viewport);
    const position = current.current.position || defaultGuidePosition(viewport, size);
    suppressClick.current = false;
    drag.current = startGuideDrag(event, position);
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function updateDrag(event) {
    if (!drag.current || event.pointerId !== drag.current.pointerId) return null;
    const next = moveGuideDrag(drag.current, event, readGuideViewport(window), current.current.size);
    drag.current = next;
    if (next.dragging) {
      event.preventDefault();
      moved.current = true;
      setDragging(true);
      place(next.position, current.current.size);
    }
    return next;
  }

  function endDrag(event) {
    const finished = updateDrag(event);
    if (!finished) return;
    suppressClick.current = finished.dragging;
    drag.current = null;
    setDragging(false);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
  }

  function cancelDrag(event) {
    if (!drag.current || event.pointerId !== drag.current.pointerId) return;
    suppressClick.current = true;
    drag.current = null;
    setDragging(false);
  }

  function activate(event) {
    // Native pointer clicks follow pointerup even after a drag. Keyboard and
    // assistive-technology activation (detail === 0) should always still work.
    if (suppressClick.current && event.detail !== 0) {
      suppressClick.current = false;
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    suppressClick.current = false;
    onToggle();
  }

  function repositionWithKeyboard(event) {
    if (event.key === "Escape") {
      if (open) onClose();
      return;
    }
    const reset = event.key === "Home" && !event.ctrlKey && !event.metaKey;
    const arrow = event.altKey && !event.ctrlKey && !event.metaKey && /^Arrow(Left|Right|Up|Down)$/.test(event.key);
    if (!reset && !arrow) return;
    event.preventDefault();
    const viewport = readGuideViewport(window);
    const size = fitGuideLauncher(viewport);
    const position = current.current.position || defaultGuidePosition(viewport, size);
    moved.current = !reset;
    place(keyboardGuidePosition(position, event.key, viewport, size), size);
    setAnnouncement(reset ? "Guide button reset to the lower-right corner." : "Guide button position adjusted.");
  }

  return <>
    <button
      ref={launcherRef}
      type="button"
      className="sh-guide-launcher"
      data-dragging={dragging || undefined}
      style={{
        ...(geometry.position ? { left: geometry.position.x, top: geometry.position.y, right: "auto", bottom: "auto" } : {}),
        width: geometry.size,
        height: geometry.size,
      }}
      onPointerDown={startDrag}
      onPointerMove={updateDrag}
      onPointerUp={endDrag}
      onPointerCancel={cancelDrag}
      onLostPointerCapture={cancelDrag}
      onClick={activate}
      onKeyDown={repositionWithKeyboard}
      onDragStart={event => event.preventDefault()}
      aria-label={open ? "Close Guide" : "Ask Guide"}
      aria-expanded={open}
      aria-controls="floating-guide"
      aria-describedby={helpId}
      aria-keyshortcuts="Alt+ArrowUp Alt+ArrowDown Alt+ArrowLeft Alt+ArrowRight Home"
      title="Drag to move. Alt + arrow keys move the button; Home resets its position."
    >
      <svg className="sh-guide-launcher__rose" viewBox="0 0 112 112" aria-hidden="true" focusable="false">
        <circle cx="56" cy="56" r="49" fill="#071d32" stroke="#bda477" strokeWidth=".8" />
        <circle cx="56" cy="56" r="44" fill="none" stroke="#f4efe3" strokeOpacity=".4" strokeWidth=".7" />
        <path d="M56 8V17M104 56H95M56 104V95M8 56H17M22 22L28 28M90 22L84 28M90 90L84 84M22 90L28 84" fill="none" stroke="#c7b28b" strokeWidth="1.1" />
        <path d="M56 15 63 42 56 36 49 42ZM97 56 70 63 76 56 70 49ZM56 97 49 70 56 76 63 70ZM15 56 42 49 36 56 42 63Z" fill="#f4efe3" />
        <path d="M56 15 56 36 63 42ZM97 56 76 56 70 63ZM56 97 56 76 49 70ZM15 56 36 56 42 49Z" fill="#bda477" />
        <path d="M29 29 47 39 42 42 39 47ZM83 29 73 47 70 42 65 39ZM83 83 65 73 70 70 73 65ZM29 83 39 65 42 70 47 73Z" fill="#f4efe3" fillOpacity=".55" />
        <circle cx="56" cy="56" r="25" fill="#071d32" stroke="#bda477" strokeWidth=".7" />
      </svg>
      <span className="sh-guide-launcher__label"><span>{open ? "Close" : "Ask"}</span><span>Guide</span></span>
    </button>
    <span className="sh-guide-launcher__help" id={helpId}>Drag to move the Guide button. With the button focused, use Alt plus an arrow key to move it, or Home to reset to the lower-right corner. Enter or Space opens or closes Guide; Escape closes it.</span>
    <span className="sh-guide-launcher__help" role="status" aria-live="polite">{announcement}</span>
  </>;
}
