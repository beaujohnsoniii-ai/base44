// Launcher-only geometry. Coordinates are relative to the layout viewport;
// visualViewport offsets keep the button reachable during mobile zoom/keyboard use.
export const GUIDE_LAUNCHER_SIZE = 96;
export const GUIDE_DRAG_THRESHOLD = 6;
export const GUIDE_EDGE_INSET = 8;

export function readGuideViewport(host) {
  const viewport = host.visualViewport;
  return {
    left: viewport?.offsetLeft ?? 0,
    top: viewport?.offsetTop ?? 0,
    width: viewport?.width ?? host.innerWidth,
    height: viewport?.height ?? host.innerHeight,
  };
}

export function fitGuideLauncher(viewport) {
  return Math.max(0, Math.min(
    GUIDE_LAUNCHER_SIZE,
    viewport.width - GUIDE_EDGE_INSET * 2,
    viewport.height - GUIDE_EDGE_INSET * 2,
  ));
}

export function clampGuidePosition(position, viewport, size = GUIDE_LAUNCHER_SIZE) {
  const insetX = Math.min(GUIDE_EDGE_INSET, Math.max(0, (viewport.width - size) / 2));
  const insetY = Math.min(GUIDE_EDGE_INSET, Math.max(0, (viewport.height - size) / 2));
  const minX = viewport.left + insetX;
  const minY = viewport.top + insetY;
  const maxX = Math.max(minX, viewport.left + viewport.width - size - insetX);
  const maxY = Math.max(minY, viewport.top + viewport.height - size - insetY);
  return {
    x: Math.max(minX, Math.min(maxX, position.x)),
    y: Math.max(minY, Math.min(maxY, position.y)),
  };
}

export function defaultGuidePosition(viewport, size = GUIDE_LAUNCHER_SIZE) {
  return clampGuidePosition({
    x: viewport.left + viewport.width - size - 20,
    y: viewport.top + viewport.height - size - 20,
  }, viewport, size);
}

export function startGuideDrag(pointer, position) {
  return {
    pointerId: pointer.pointerId,
    startX: pointer.clientX,
    startY: pointer.clientY,
    origin: { ...position },
    position: { ...position },
    dragging: false,
  };
}

export function moveGuideDrag(drag, pointer, viewport, size = GUIDE_LAUNCHER_SIZE) {
  if (pointer.pointerId !== drag.pointerId) return drag;
  const dx = pointer.clientX - drag.startX;
  const dy = pointer.clientY - drag.startY;
  const dragging = drag.dragging || Math.hypot(dx, dy) >= GUIDE_DRAG_THRESHOLD;
  return {
    ...drag,
    dragging,
    position: dragging
      ? clampGuidePosition({ x: drag.origin.x + dx, y: drag.origin.y + dy }, viewport, size)
      : drag.position,
  };
}

export function keyboardGuidePosition(position, key, viewport, size = GUIDE_LAUNCHER_SIZE) {
  if (key === "Home") return defaultGuidePosition(viewport, size);
  const steps = { ArrowLeft: [-16, 0], ArrowRight: [16, 0], ArrowUp: [0, -16], ArrowDown: [0, 16] };
  const step = steps[key];
  return step ? clampGuidePosition({ x: position.x + step[0], y: position.y + step[1] }, viewport, size) : position;
}
