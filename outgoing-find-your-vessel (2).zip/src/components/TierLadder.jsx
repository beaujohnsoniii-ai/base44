import React from "react";
import { Check, Lock, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TIERS, UPGRADES_OPEN, EARLY_ACCESS_HREF } from "@/lib/tiers";
import { tierRank } from "@/lib/stages";
import "@/components/tier-teaser.css";

// "Your plan": the four tiers in one row, the buyer's own marked, lower tiers
// shown as included, higher tiers locked with a disabled "coming soon" button.
// Replaces the old "Choose a question set" buttons, which looked like packages
// but only opened the profile editor.
export default function TierLadder({ plan = "free" }) {
  const rank = tierRank(plan);
  return (
    <section id="packages" className="rounded-xl border bg-background p-6" aria-label="Your plan">
      <h2 className="font-heading text-xl font-semibold">Your plan</h2>
      <p className="text-sm text-muted-foreground mt-1">Each tier keeps everything below it. Your matches are never for sale.</p>
      <ol className="sh-ladder mt-5">
        {TIERS.map((t) => {
          const r = tierRank(t.id);
          const state = r === rank ? "current" : r < rank ? "included" : "locked";
          return (
            <li key={t.id} className={`sh-ladder__step sh-ladder__step--${state}`}>
              <p className="sh-ladder__state">
                {state === "current" ? "Your plan" : state === "included" ? <><Check className="w-3.5 h-3.5" /> Included</> : <><Lock className="w-3.5 h-3.5" /> Locked</>}
              </p>
              <h3 className="sh-ladder__name">{t.name} <span>{t.priceLabel}</span></h3>
              <p className="sh-ladder__promise">{t.promise}</p>
              {state === "locked" && (
                <Button size="sm" variant="outline" className="mt-3" disabled={!UPGRADES_OPEN} title="Upgrades open after launch. No payment is taken.">Coming soon</Button>
              )}
            </li>
          );
        })}
      </ol>
      {rank < 3 && (
        <p className="mt-4 text-sm"><a className="sh-teaser__link" href={EARLY_ACCESS_HREF}>Request early access <ArrowRight className="w-4 h-4" aria-hidden="true" /></a></p>
      )}
    </section>
  );
}
