import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Compass, ExternalLink, RefreshCw, Check, AlertCircle, Search, Plus, ThumbsUp, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";
import ModelEvidencePanel from "@/components/ModelEvidencePanel";
import ListingLink from "@/components/ListingLink";
import MatchResultsShowcase from "@/components/match/MatchResultsShowcase";
import CandidatesCollapsible from "@/components/CandidatesCollapsible";
import { boatLink } from "@/lib/utils";
import { isPaidPlan } from "@/lib/stages";
import { formatModelPriceGuidance } from "@/lib/modelPriceGuidance";
import { useToast } from "@/components/ui/use-toast";
import { useListingIntake } from "@/lib/useListingIntake";
import ListingIntakePanel from "@/components/ListingIntakePanel";
import { topMatchResults } from "../../base44/shared/listing-intake-allowance.mjs";

// The advisor pool: boats SoundHeading researched to match the buyer's profile.
// Free Discovery: the 4 broad starting directions, with an upgrade prompt to MATCH+.
// Paid tiers: the WHOLE result pool is always shown, with an update counter and the
//   package's access window. The tier decides only how many models carry its
//   recommendation mark (MATCH+ none, Refined the leading 5-7, Market the top 3) —
//   a paid tier never hides the models it did not mark. Refreshing consumes one of
//   the buyer's updates.
export default function SuggestedBoatsPanel({
  suggestions,
  previousSuggestions = [],
  loading,
  plan = "free",
  adminTesting = false,
  updatesUsed = 0,
  updatesLimit = 0,
  planExpires = null,
  firstPaidGenerationAvailable = false,
  onPurchase,
  purchasing = null,
  onRefresh,
  refreshing = false,
  onAddCandidate,
  onChooseCompare,
  note,
  boats,
  onAddBoat,
  onRemoveBoat,
  onUpdateBoat,
  maxBoats,
  minBoats,
  onAnalyze,
  prefillBoat = null,
  onToggleLike = null,
  disableExternalLinks = false,
  listingIntakeDataEnv = "prod",
}) {
  const { toast } = useToast();
  const intake = useListingIntake(listingIntakeDataEnv);
  const likeFlight = useRef(false);
  const choosingRef=useRef(false);
  const [choosing,setChoosing]=useState(null);
  const choose=async boat=>{if(choosingRef.current)return;choosingRef.current=true;setChoosing(boat.id);try{await onChooseCompare(boat);}finally{choosingRef.current=false;setChoosing(null);}};
  const allSuggestions = [...(suggestions || []), ...(previousSuggestions || [])];
  const [likedIds, setLikedIds] = useState(
    () => new Set(allSuggestions.filter((s) => s.liked).map((s) => s.id))
  );
  const suggKey = allSuggestions.map((s) => s.id).join(",");
  useEffect(() => {
    setLikedIds(new Set([...(suggestions || []), ...(previousSuggestions || [])].filter((s) => s.liked).map((s) => s.id)));
  }, [suggKey]);

  const toggleLike = async (b) => {
    if (likeFlight.current) return;
    likeFlight.current = true;
    const isLiked = likedIds.has(b.id);
    const next = new Set(likedIds);
    if (isLiked) next.delete(b.id); else next.add(b.id);
    setLikedIds(next);
    try {
      // An explicit injected handler lets the private journey keep Likes in memory.
      if (onToggleLike) { await onToggleLike(b, !isLiked); return; }
      // toggle-like updates both SuggestedBoat.liked (UI) and BuyerProfile.liked_models
      // (durable history that survives regeneration).
      if (!isLiked && onAddCandidate) {
        const saved = await onAddCandidate(b);
        if (saved === false) { setLikedIds(likedIds); return; }
      }
      await base44.functions.invoke("toggle-like", {
        suggestionId: b.id,
        liked: !isLiked,
        make: b.make,
        model: b.model,
        title: b.title,
      });
    } catch (e) {
      setLikedIds(likedIds);
      toast({ title: "Could not update Like", description: e?.response?.data?.error || "Your previous preference was restored. Try again.", variant: "destructive" });
    } finally {
      likeFlight.current = false;
    }
  };

  const renderBoat = (b) => (
    <div key={b.id || b.rank} className="py-3 border-t first:border-t-0">
      <div className="flex items-start gap-2">
        {disableExternalLinks ? <span className="font-medium">{b.title}</span> : <ListingLink href={boatLink(b)} className="font-medium hover:underline flex items-center gap-1">
          {b.title} <ExternalLink className="w-3.5 h-3.5" />
        </ListingLink>}
      </div>
      <p className="text-sm text-muted-foreground">
        {[b.make, b.model, b.year].filter(Boolean).join(" ")}
        {` · ${formatModelPriceGuidance(b)}`}
        {b.source && b.source !== "N/A" ? ` · ${b.source}` : ""}
      </p>
      {b.id && !disableExternalLinks && <ModelEvidencePanel suggestion={b} />}
      {b.engines && <p className="text-sm text-muted-foreground">{b.engines}</p>}
      {b.specs && <p className="text-sm text-muted-foreground">{b.specs}</p>}
      <div className="mt-2 flex flex-wrap items-center gap-2">
        {typeof b.suitability_score === "number" && (
          <span className="inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold">
            SoundHeading Fit {Math.round(b.suitability_score)} / 100
          </span>
        )}
        {b.verification_required?.length > 0 && (
          <span className="text-xs text-muted-foreground">{b.verification_required.length} item{b.verification_required.length === 1 ? "" : "s"} to verify</span>
        )}
      </div>
      {b.why_suggested && (
        <p className="text-sm mt-1"><span className="font-medium">Why this fits: </span>{b.why_suggested}</p>
      )}
      {b.verification_required?.length > 0 && (
        <details className="mt-2 text-sm">
          <summary className="cursor-pointer list-none text-sm text-muted-foreground underline underline-offset-4 hover:text-foreground focus-visible:outline focus-visible:outline-2 [&::-webkit-details-marker]:hidden">Verification details ({b.verification_required.length})</summary>
          <ul className="mt-1 space-y-1">
            {b.verification_required.map((item, i) => <li key={i} className="flex items-start gap-2"><AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />{item}</li>)}
          </ul>
        </details>
      )}
      {b.match?.summary && (
        <div className="mt-2 rounded-lg bg-accent/5 border border-accent/20 p-3 text-sm space-y-2">
          <p className="text-foreground/90">{b.match.summary}</p>
          {b.match.matches?.length > 0 && (
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Matches</p>
              <ul className="mt-1 space-y-1">
                {b.match.matches.map((m, i) => (
                  <li key={i} className="flex items-start gap-2 text-foreground/80">
                    <Check className="w-3.5 h-3.5 text-accent mt-0.5 shrink-0" /> {m}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {b.match.gaps?.length > 0 && (
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mt-2">Gaps</p>
              <ul className="mt-1 space-y-1">
                {b.match.gaps.map((g, i) => (
                  <li key={i} className="flex items-start gap-2 text-foreground/80">
                    <AlertCircle className="w-3.5 h-3.5 text-destructive mt-0.5 shrink-0" /> {g}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
      <div className="mt-3 rounded-lg border bg-muted/30 p-3">
        <p className="mb-2 text-xs text-muted-foreground">Use Find to look for boats for sale, then save your favorite models to Compare.</p>
        <div className="flex flex-wrap gap-2">
          {!disableExternalLinks && <Button asChild variant="outline" size="sm"><a href={boatLink(b)} target="_blank" rel="noopener noreferrer"><Search className="w-3.5 h-3.5 mr-1.5" /> Find boats for sale</a></Button>}
          {onChooseCompare && <Button size="sm" disabled={choosing!==null} onClick={()=>choose(b)}>{choosing===b.id?"Saving…":"Save model & open Compare"}</Button>}
          <details><summary className="cursor-pointer text-sm underline py-2">Save for later / preference</summary><div className="flex flex-wrap gap-2 pt-2">
          {onAddCandidate && (
            <Button variant="outline" size="sm" onClick={() => onAddCandidate(b)}>
              <Plus className="w-3.5 h-3.5 mr-1.5" /> Save for later
            </Button>
          )}
          {b.id && (
            <Button
              variant={likedIds.has(b.id) ? "default" : "outline"}
              size="sm"
              onClick={() => toggleLike(b)}
              title={likedIds.has(b.id) ? "You liked this suggestion" : "Mark this suggestion as helpful — it steers future refreshes"}
            >
              <ThumbsUp className="w-3.5 h-3.5 mr-1.5" /> {likedIds.has(b.id) ? "Liked" : "Like"}
            </Button>
          )}
        </div></details></div>
      </div>
    </div>
  );

  const isPaid = isPaidPlan(plan);
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Compass className="w-5 h-5" /> Models Worth Considering</CardTitle>
          <CardDescription>Finding models that match your profile…</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-24 rounded-lg bg-muted animate-pulse" />
          ))}
        </CardContent>
      </Card>
    );
  }

  // Free accounts: show the 4 broad starting directions based on the profile, with an upgrade prompt.
  if (!isPaid) {
    return (
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2"><Compass className="w-5 h-5" /> Deckhand</CardTitle>
              <CardDescription>
                {suggestions && suggestions.length > 0
                  ? `${suggestions.length} illustrative example results — not verified model recommendations.`
                  : "Complete your profile to see illustrative example results."}
              </CardDescription>
            </div>
            {onRefresh && (
              <Button variant="ghost" size="icon" onClick={onRefresh} disabled={refreshing} title="Refresh directions">
                <RefreshCw className={`w-4 h-4 ${refreshing ? "animate-spin" : ""}`} />
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          {suggestions && suggestions.length > 0 ? (
            <>
              {suggestions.map((b) => renderBoat(b))}
              {note && (
                <div className="mt-3 flex items-start gap-2 rounded-lg border border-accent/20 bg-accent/5 p-3 text-sm text-foreground/80">
                  <AlertCircle className="w-4 h-4 text-accent mt-0.5 shrink-0" />
                  <span>{note}</span>
                </div>
              )}
              <div className="rounded-lg border border-dashed border-accent/40 bg-accent/5 p-4">
                <p className="font-medium text-sm">Want improved matches?</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Bosun widens the set to 10-14 models to look around with, using deeper questions plus your Likes, with the ability to refresh your matches as you refine your profile.
                </p>
                {onPurchase && (
                  <Button className="mt-3" size="sm" onClick={() => onPurchase("match_plus")} disabled={purchasing === "match_plus"}>
                    <Sparkles className="w-4 h-4 mr-2" />
                    {purchasing === "match_plus" ? "Redirecting…" : "Bosun — $9"}
                  </Button>
                )}
              </div>
            </>
          ) : (
            <p className="text-sm text-muted-foreground py-2">
              No examples yet. Edit your profile to explore illustrative starting points.
            </p>
          )}
          <div id="saved-candidates"><CandidatesCollapsible
            boats={boats}
            onAdd={onAddBoat}
            onRemove={onRemoveBoat}
            onUpdate={onUpdateBoat}
            maxBoats={maxBoats}
            minBoats={minBoats}
            onAnalyze={onAnalyze}
            prefill={prefillBoat}
          /></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <><Card>
      <CardContent className="pt-6" aria-busy={refreshing}>
        {(suggestions?.length > 0) ? (
          <MatchResultsShowcase
            plan={plan}
            suggestions={suggestions}
            likedIds={likedIds}
            busyId={choosing}
            disableExternalLinks={disableExternalLinks}
            onToggleLike={toggleLike}
            onReviewListings={intake.enabled && !disableExternalLinks ? intake.openReview : undefined}
            listingCounts={intake.counts}
            listingEligibleIds={listingIntakeDataEnv === "owner-prod" ? topMatchResults(suggestions).map(result => result.id) : null}
          />
        ) : (
          <p className="text-sm text-muted-foreground py-2">
            No matches yet. Try editing your profile, or add boats you're considering below.
          </p>
        )}
      </CardContent>
      <CardContent aria-busy={refreshing}>
        {refreshing && <p role="status" className="mb-4 rounded-lg bg-muted p-3 text-sm">Updating your matches. Your current results remain available while we work.</p>}
        {note && (
          <div className="mt-3 flex items-start gap-2 rounded-lg border border-accent/20 bg-accent/5 p-3 text-sm text-foreground/80">
            <AlertCircle className="w-4 h-4 text-accent mt-0.5 shrink-0" />
            <span>{note}</span>
          </div>
        )}
        <p className="text-xs text-muted-foreground mt-3">
          Model guidance, not verified live listings. Like a model to keep it in your history. Current answers lead your matches; past Likes influence a new search only when you choose to use them.
        </p>

        <div id="saved-candidates" className="mt-6"><CandidatesCollapsible
          boats={boats}
          onAdd={onAddBoat}
          onRemove={onRemoveBoat}
          onUpdate={onUpdateBoat}
          maxBoats={maxBoats}
          minBoats={minBoats}
          onAnalyze={onAnalyze}
          prefill={prefillBoat}
        /></div>
      </CardContent>
    </Card>
    {intake.enabled && intake.reviewBoat && <ListingIntakePanel boat={intake.reviewBoat} requestMode={listingIntakeDataEnv} onClose={intake.closeReview} onCountChange={intake.updateCounts} />}
    </>
  );
}