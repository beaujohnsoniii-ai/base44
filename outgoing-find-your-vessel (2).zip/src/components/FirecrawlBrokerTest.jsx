import React,{useEffect,useRef,useState} from "react";
import {base44} from "@/api/base44Client";
import {Button} from "@/components/ui/button";
import {requestDeadline} from "@/lib/requestDeadline";
export default function FirecrawlBrokerTest(){
 const [state,setState]=useState(null),[error,setError]=useState(""),[busy,setBusy]=useState(false),[uncertain,setUncertain]=useState(false);const inFlight=useRef(false);
 async function call(action){
  if(inFlight.current)return;inFlight.current=true;setBusy(true);setError("");
  try{const r=await requestDeadline(()=>base44.functions.invoke("firecrawl-broker-test",{action}),40000,"Response timed out. Check saved test status; do not rerun.");const d=r.data||r;if(d.error)throw Error(d.error);setState(d);}
  catch(e){setError(e?.response?.data?.error||e.message||"Status unavailable");if(action==="run_basic_test")setUncertain(true);}
  finally{inFlight.current=false;setBusy(false);}
 }
 useEffect(()=>{call("status");},[]);
 const canRun=state?.key_configured&&state?.test_status==="ready"&&!uncertain;
 return <section className="rounded-lg border p-4 space-y-3" aria-label="Approved Firecrawl broker test">
  <h2 className="text-xl font-semibold">Approved Firecrawl broker test</h2>
  <p className="text-sm">One basic scrape of the approved 2012 BlackJack 224 CC, stock 3928. Expected one credit. No retries, enhanced fallback or Compare import is enabled.</p>
  <p className="text-xs break-all">https://www.theboatyardinc.com/inventory/2012-blackjack-224-cc-3928/</p>
  {state&&<p>Key configured: {state.key_configured?"Yes":"Not detected"} · Test: {state.test_status}</p>}
  {state?.key_configured===false&&<p>Add FIRECRAWL_API_KEY directly in Base44 Dashboard → Secrets. Do not paste the key into chat.</p>}
  <div className="flex flex-wrap gap-2"><Button disabled={busy||!canRun} onClick={()=>call("run_basic_test")}>{busy?"Checking…":"Run approved one-call test"}</Button><Button variant="outline" disabled={busy} onClick={()=>call("status")}>Check saved test status</Button></div>
  {error&&<p role="alert" className="text-red-700">{error}</p>}
  {state?.failure&&<p role="status">{state.failure}</p>}
  {state?.result&&<details open><summary>Saved test result — seller claims, not verified Compare facts</summary><pre className="text-xs whitespace-pre-wrap break-words max-h-96 overflow-auto">{JSON.stringify(state.result,null,2)}</pre></details>}
 </section>;
}
