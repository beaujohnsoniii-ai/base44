import React, { useEffect, useRef, useState } from 'react';
import { Button, buttonVariants } from '@/components/ui/button';
import ListingLink from '@/components/ListingLink';
import { copyListingSearchLink } from '@/lib/listingSearchFallback';
import { Dialog, DialogContent as SharedDialogContent, DialogHeader as SharedDialogHeader, DialogTitle as SharedDialogTitle, DialogDescription as SharedDialogDescription } from '@/components/ui/dialog';
import { Search, Upload, Check, RotateCcw } from 'lucide-react';
import { listingSearchUrl } from '@/lib/utils';
import { listingIntakeRequest } from '@/lib/listingIntakeAction';
import { INTAKE_FIELDS, INTAKE_LIMITS, knownListingReference } from '../../base44/shared/listing-intake.mjs';
import './listing-intake.css';

/** Existing shared primitives have incomplete inferred JS prop types. Runtime components stay unchanged. */
const DialogContent = /** @type {React.ComponentType<any>} */ (SharedDialogContent);
const DialogHeader = /** @type {React.ComponentType<any>} */ (SharedDialogHeader);
const DialogTitle = /** @type {React.ComponentType<any>} */ (SharedDialogTitle);
const DialogDescription = /** @type {React.ComponentType<any>} */ (SharedDialogDescription);
const stamp = value => value ? new Date(value).toLocaleString() : 'Not provided';
const show = value => value == null || value === '' ? 'Not provided' : String(value);
export default function ListingIntakePanel({ boat, sourceType = 'suggestion', requestMode = 'dev', historyListingId = null, onClose, onCountChange = (_listings) => {} }) {
  const request = body => listingIntakeRequest(body, requestMode);
  const [state, setState] = useState(null), [model, setModel] = useState(null), [error, setError] = useState(''), [busy, setBusy] = useState(false), [loading, setLoading] = useState(true);
  const [searchCopyStatus, setSearchCopyStatus] = useState('');
  const loadSequence = useRef(0);
  const imageLimit = state?.allowance?.images_per_listing || INTAKE_LIMITS.images_per_listing;
  const resultAllowance = state?.allowance?.by_result?.find(result => result.source_id === boat.id);
  const searchModel = model || boat;
  const searchUrl = listingSearchUrl(searchModel.title, searchModel.make, searchModel.model);
  const copySearch = async () => {
    setSearchCopyStatus('copying');
    const copied = await copyListingSearchLink(searchUrl);
    if (mounted.current) setSearchCopyStatus(copied ? 'copied' : 'unavailable');
  };
  const inFlight = useRef(false), mounted = useRef(true), stateRef = useRef(null), pendingRequest = useRef(null);
  const accept = (result, sequence) => { if (!mounted.current || sequence !== loadSequence.current) return null; if (pendingRequest.current && result.operations?.some(operation => operation.id === pendingRequest.current.operation_id && operation.status === 'complete')) pendingRequest.current = null; stateRef.current = result; if (mounted.current) setState(result); onCountChange(result.context_stale || result.history_only ? [] : result.listings || []); return result; };
  const load = async () => {
    const sequence = ++loadSequence.current;
    setLoading(true); setError(''); setSearchCopyStatus(''); setState(null); setModel(null);
    try {
      let result;
      if (historyListingId) {
        result = await request({ action: 'read' });
        const saved = [...result.listings, ...(result.context_history || []).flatMap(context => context.listings)].find(listing => listing.id === historyListingId && listing.model.source_type === sourceType && listing.model.source_id === boat.id);
        if (!saved) throw Error('Saved listing history is unavailable.');
        result = { ...result, listings: [saved], model: saved.model, history_only: true };
      } else {
        try { result = await request({ action: 'model', model_type: sourceType, model_id: boat.id }); }
        catch (error) {
          if (error.status !== 409) throw error;
          const saved = await request({ action: 'read' });
          const prior = [...saved.listings, ...(saved.context_history || []).flatMap(context => context.listings)].find(listing => listing.model.source_type === sourceType && listing.model.source_id === boat.id);
          if (!prior) throw error;
          result = { ...saved, listings: [prior], model: prior.model, history_only: true };
        }
      }
      if (mounted.current && sequence === loadSequence.current) { setModel(result.model); accept(result, sequence); }
    } catch (e) { if (mounted.current && sequence === loadSequence.current) setError(e.message); }
    finally { if (mounted.current && sequence === loadSequence.current) setLoading(false); }
  };
  useEffect(() => { mounted.current = true; pendingRequest.current = null; load(); return () => { mounted.current = false; loadSequence.current++; }; }, [boat.id, sourceType, historyListingId, requestMode]);
  const run = async (action, fields = {}) => {
    if (inFlight.current) return null;
    const sequence = loadSequence.current;
    inFlight.current = true; setBusy(true); setError('');
    try { pendingRequest.current = { action, ...fields, revision: stateRef.current.revision, operation_id: crypto.randomUUID() }; return accept(await request(pendingRequest.current), sequence); }
    catch (e) { if (mounted.current && sequence === loadSequence.current) { if (e.status && e.status < 500) pendingRequest.current = null; setError(e.message); } return null; }
    finally { inFlight.current = false; if (mounted.current) setBusy(false); }
  };
  const uploads = async (listing, files) => {
    if (inFlight.current || !files.length) return;
    if (files.length > (stateRef.current?.allowance?.screenshots_remaining ?? INTAKE_LIMITS.images_per_listing)) { setError('The selected files exceed this private workspace’s remaining screenshot allowance.'); return; }
    if (files.length + listing.uploads.length > imageLimit) { setError(imageLimit === 1 ? 'Choose one screenshot for this listing submission.' : 'Use up to six screenshots for one listing.'); return; }
    if (files.some(file => !['image/jpeg', 'image/png'].includes(file.type) || file.size > INTAKE_LIMITS.image_bytes)) { setError('Choose JPEG or PNG screenshots up to 6 MB each.'); return; }
    const sequence = loadSequence.current;
    inFlight.current = true; setBusy(true); setError('');
    try {
      for (const file of files) {
        if (!mounted.current || sequence !== loadSequence.current) return;
        const uploadId = crypto.randomUUID();
        pendingRequest.current = { action: 'upload', listing_id: listing.id, upload_id: uploadId, file, revision: stateRef.current.revision, operation_id: crypto.randomUUID() };
        if (!accept(await request(pendingRequest.current), sequence)) return;
        pendingRequest.current = { action: 'read_screenshot', listing_id: listing.id, upload_id: uploadId, revision: stateRef.current.revision, operation_id: crypto.randomUUID() };
        const result = accept(await request(pendingRequest.current), sequence);
        if (!result) return;
        const upload = result.listings.find(l => l.id === listing.id)?.uploads.find(u => u.id === uploadId);
        if (upload?.status !== 'complete') throw Error('Screenshot reading is not confirmed. Reload to check before continuing.');
      }
    } catch (e) { if (mounted.current && sequence === loadSequence.current) { if (e.status && e.status < 500) pendingRequest.current = null; setError(e.message); } }
    finally { inFlight.current = false; if (mounted.current) setBusy(false); }
  };
  const reconcilePending = async () => {
    if (!pendingRequest.current || inFlight.current) return;
    const sequence = loadSequence.current;
    inFlight.current = true; setBusy(true);
    try { const result = accept(await request(pendingRequest.current), sequence); if (!result) return; setError(result.operation_status && result.operation_status !== 'complete' ? 'This same operation is still unconfirmed. No second upload or extraction was started.' : ''); }
    catch (e) { if (mounted.current && sequence === loadSequence.current) setError(e.message); }
    finally { inFlight.current = false; if (mounted.current) setBusy(false); }
  };
  const activeListings = state?.context_stale && !state?.history_only ? [] : state?.listings?.filter(l => l.status !== 'abandoned' && (state?.history_only || !state?.allowance?.eligible_result_ids || state.allowance.eligible_result_ids.includes(l.model.source_id))) || [];
  const earlierResultListings = state?.allowance?.eligible_result_ids ? (state.listings || []).filter(listing => !state.allowance.eligible_result_ids.includes(listing.model.source_id)) : [];
  const listings = activeListings.filter(l => historyListingId ? l.id === historyListingId : state?.allowance?.scope === 'current_top_three_results' ? l.model.source_type === sourceType && l.model.source_id === boat.id : l.model.model_key === model?.model_key);
  const uncertain = state?.operations?.some(o => ['reserved', 'uncertain'].includes(o.status));
  const readOnly = state?.context_stale === true || state?.history_only === true || Boolean(pendingRequest.current);
  return <Dialog open onOpenChange={open => { if (!open && !busy) onClose(); }}>
    <DialogContent className="sh-listing-intake max-w-4xl max-h-[90vh] overflow-y-auto" onEscapeKeyDown={event => { if (busy) event.preventDefault(); }} onInteractOutside={event => { if (busy) event.preventDefault(); }}>
      <DialogHeader className="sh-listing-intake__header"><DialogTitle className="sh-listing-intake__title">Review listings · {boat.title || [boat.make, boat.model].filter(Boolean).join(' ')}</DialogTitle><DialogDescription className="sh-listing-intake__description">{requestMode === 'owner-prod' ? 'Private account-only listing review. Your questionnaire and Match results stay unchanged.' : 'Private owner preview · Test data only. Your Match results and saved Compare selection stay unchanged.'}</DialogDescription></DialogHeader>
      <div className="space-y-4">
        <div className="sh-listing-intake__toolbar flex flex-wrap items-center gap-2">
          <ListingLink href={searchUrl} className={buttonVariants({ variant: "outline", size: "sm" })}><Search className="w-4 h-4 mr-2" />Find listings · Google</ListingLink>
          {state && <span className="sh-listing-intake__count">{listings.filter(listing => listing.uploads.length || listing.reference_url).length} of 3 listings with details</span>}
        </div>
        <details className="text-xs text-muted-foreground">
          <summary className="cursor-pointer underline">Google didn’t open?</summary>
          <p className="mt-2">Copy this search link and paste it in your browser. Your listing review stays open.</p>
          <label className="sr-only" htmlFor={"listing-search-" + boat.id}>Google search link for this model</label>
          <textarea id={"listing-search-" + boat.id} readOnly rows={3} value={searchUrl} onFocus={event => event.target.select()} className="mt-2 block w-full rounded-md border bg-background p-2 text-xs" />
          <Button type="button" variant="outline" size="sm" className="mt-2" disabled={searchCopyStatus === "copying"} onClick={copySearch}>Copy search link</Button>
          {searchCopyStatus && <p role="status" className="mt-2">{searchCopyStatus === "copied" ? "Search link copied. Paste it in your browser." : searchCopyStatus === "copying" ? "Copying search link…" : "Automatic copy isn’t available here. Select the link above and use your device’s Copy action."}</p>}
          <p className="mt-2">Search only. This is not saved as a listing reference or evidence.</p>
        </details>
        <p className="text-sm text-muted-foreground">{imageLimit === 1 ? 'Add one screenshot from each actual listing. You can submit up to three listings for each of your top three current Match results.' : 'Add screenshots from each actual listing. Keep screenshots from the same boat together.'} Details are seller claims, not an independent inspection. Nothing is fetched from a listing website.</p>
        {sourceType === 'saved' && <p className="text-xs text-muted-foreground">Opened from your saved model. This does not turn an older saved model into a new Match recommendation.</p>}
        {loading && <p role="status">Loading this model’s saved listing review…</p>}
        {error && <div role="alert" className="rounded-lg border border-destructive/30 p-3 text-sm"><p>{error}</p><Button variant="outline" size="sm" disabled={busy} onClick={load} className="mt-2">Reload saved review</Button></div>}
        {pendingRequest.current && <Button variant="outline" size="sm" disabled={busy} onClick={reconcilePending}>Check the same pending request</Button>}
        {state?.history_only && !state?.context_stale && <p role="status" className="rounded-lg border bg-muted/30 p-3 text-sm">Read-only retained history. It is not reassigned to a current model or used to change Match results.</p>}
        {state?.context_stale && <div role="status" className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm">
          <p>Saved with earlier Match answers. Earlier listing evidence stays read-only and is not used as a current assessment.</p>
          {state.context_transition_available && !state.history_only ? <>
            <p className="mt-2">Add a listing tied to this current Match result and your latest answers. Earlier drafts and screenshots stay with their original results in history. Your remaining screenshot allowance is unchanged.</p>
            <Button className="mt-3" disabled={busy || uncertain || Boolean(pendingRequest.current)} onClick={() => run('start_current_context', { model_type: sourceType, model_id: boat.id, listing_id: crypto.randomUUID() })}>Add a listing for this Match</Button>
          </> : <p className="mt-2">Open a current model in My Helm to add listings for your latest answers.</p>}
        </div>}
        {state && !state.integrations_enabled && <p className="sh-listing-intake__notice rounded-lg border bg-muted/30 p-3 text-sm">Screenshot processing is held for owner-only verification. No upload or extraction will run in this build.</p>}
        {state?.allowance?.unavailable && <p role="alert" className="text-sm">{state.allowance.error} Earlier evidence remains available below; no new upload was started.</p>}
        {state?.integrations_enabled && state.allowance && !state.allowance.unavailable && <p className="text-xs text-muted-foreground">{state.allowance.scope === 'current_top_three_results'
          ? <>One screenshot per listing · {resultAllowance?.screenshots_remaining ?? 0} of 3 screenshot submissions remaining for this result · {state.allowance.screenshots_remaining} of 9 remaining across your top three current results. Earlier results stay in history; resetting a submitted listing does not refill its slot.</>
          : <>Private owner trial · {state.allowance.screenshots_remaining} of 6 screenshot uploads remaining across this workspace. Reset keeps history and does not refill this allowance.</>} Reading screenshots uses AI integration credits.</p>}
        {uncertain && <p role="status" className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm">A previous operation is not confirmed. Reload to check it. Do not repeat the upload or reading automatically.</p>}
        {listings.map((listing, index) => <ListingReviewCard key={listing.id + ':' + listing.revision} listing={listing} index={index} busy={busy || uncertain || readOnly || listing.submission?.read_only} processingEnabled={state.integrations_enabled} uploadsRemaining={resultAllowance?.screenshots_remaining ?? state.allowance?.screenshots_remaining} imageLimit={imageLimit} request={request} onAction={run} onFiles={files => uploads(listing, files)} />)}
        {model && state && !state.history_only && !state.context_stale && <Button variant="outline" disabled={busy || uncertain || readOnly || resultAllowance?.listing_slots_remaining === 0 || listings.length >= 3 || (new Set(activeListings.map(l => l.model.model_key)).size >= 3 && !listings.length)} onClick={() => run('add_listing', { listing_id: crypto.randomUUID(), model_type: sourceType, model_id: boat.id, reference_url: sourceType === 'saved' ? knownListingReference(boat, listings.length) : '' })}>Add {listings.length ? 'another listing' : 'a listing'}</Button>}
        {state && new Set(activeListings.map(l => l.model.model_key)).size >= 3 && !listings.length && <p className="text-sm">Three models already have listings. Continue with one of those models; nothing was replaced.</p>}
        {state?.listings?.some(listing => listing.status === "abandoned") && <details><summary className="cursor-pointer text-xs underline">Abandoned empty drafts</summary>{state.listings.filter(listing => listing.status === "abandoned").map(listing => <div key={listing.id} className="flex flex-wrap items-center gap-2 mt-2 text-xs"><span>{listing.model.title} · {stamp(listing.abandoned_at)}</span><Button size="sm" variant="outline" disabled={busy || uncertain || readOnly} onClick={() => run("restore_empty", { listing_id: listing.id })}>Restore empty draft</Button></div>)}</details>}
        {!state?.history_only && (state?.context_history?.length > 0 || earlierResultListings.length > 0 || state?.context_stale && state?.listings?.length > 0) && <details>
          <summary className="cursor-pointer text-sm underline">Earlier Match listing history</summary>
          <p className="my-3 text-xs text-muted-foreground">Read-only saved evidence. These drafts, screenshots and confirmed versions are not reassigned to current Match results.</p>
          {[...(state.context_history || []), ...(earlierResultListings.length && !state.context_stale ? [{ id: 'earlier-result-evidence', listings: earlierResultListings }] : []), ...(state.context_stale && !state.history_only ? [{ id: 'previous-active-context', listings: state.listings }] : [])].map(context => <div key={context.id} className="mt-3 space-y-3">
            {context.listings.map((listing, index) => <details key={listing.id}><summary className="cursor-pointer text-sm underline">{listing.model.title} · Listing {index + 1} · {listing.status}</summary><ListingReviewCard listing={listing} index={index} busy={true} processingEnabled={false} uploadsRemaining={0} request={request} onAction={() => null} onFiles={() => null} /></details>)}
          </div>)}
        </details>}
        <p className="text-xs text-muted-foreground">Confirm each listing’s details separately. Screenshots and confirmed versions are saved privately; Done only closes this window. There is no overall submission or listing assessment yet.</p>
        <div className="sh-listing-intake__footer flex justify-end"><Button variant="outline" disabled={busy} onClick={onClose}>Done</Button></div>
      </div>
    </DialogContent>
  </Dialog>;
}
function ListingReviewCard({ listing, index, busy, processingEnabled, uploadsRemaining, imageLimit = Number(INTAKE_LIMITS.images_per_listing), request, onAction, onFiles }) {
  const [reference, setReference] = useState(listing.reference_url || ''), [identityNote, setIdentityNote] = useState(''), [preview, setPreview] = useState(null), [previewError, setPreviewError] = useState('');
  const confirmed = listing.status === 'confirmed', evidence = listing.evidence;
  const identityPending = evidence.identity_conflicts.length > 0 && !evidence.identity_review_current;
  const identityBlocked = evidence.conflicts.some(field => ['make', 'model', 'year'].includes(field)) || listing.uploads.some(upload => upload.status !== 'complete');
  const confirmationReason = evidence.conflicts.length ? 'Resolve the conflicting source details before confirming.'
    : identityPending ? 'Choose Keep as alternative model, or add your own identity review, before confirming.'
    : reference !== listing.reference_url ? 'Save the edited reference link before confirming.'
    : !listing.uploads.some(upload => upload.status === 'complete') ? 'Add and read a screenshot before confirming.'
    : listing.uploads.some(upload => upload.status !== 'complete') ? 'A screenshot is not fully read. Check its status before confirming.'
    : '';
  const advertisedIdentity = ['make', 'model', 'year'].map(field => show(evidence.fields[field].value)).join(' · ');
  const previewSource = async upload => { setPreviewError(''); try { const result = await request({ action: 'preview_source', listing_id: listing.id, upload_id: upload.id }); setPreview({ url: result.preview_url, name: upload.name }); setTimeout(() => setPreview(null), 55000); } catch (e) { setPreviewError(e.message); } };
  return <section className="sh-listing-intake__card rounded-xl border bg-background p-4 sm:p-5 space-y-3" aria-label={`Listing ${index + 1}`}>
    <div className="sh-listing-intake__card-heading flex flex-wrap items-center justify-between gap-2"><h3 className="font-heading text-lg">Listing {index + 1}</h3><span className="sh-listing-intake__status text-xs">{confirmed ? `Confirmed version ${listing.confirmed_version}` : `Draft revision ${listing.revision}`}</span></div>
    {!confirmed && listing.uploads.some(upload => upload.status === 'complete') && <p role="status" className="text-sm">{confirmationReason || 'Ready for you to review and confirm this listing’s details.'}</p>}
    {evidence.year_difference && <p className="rounded-md border border-amber-200 bg-amber-50 p-3 text-sm">Advertised year: {show(evidence.fields.year.value)}. Your model card shows {listing.model.year}. A different year is allowed; confirmation saves the screenshot’s year. Model-year specifications are not transferred.</p>}
    <label className="block text-sm" htmlFor={listing.id + '-url'}>Listing link — saved for reference</label>
    <input id={listing.id + '-url'} type="url" value={reference} disabled={busy || confirmed} onChange={event => setReference(event.target.value)} placeholder="Optional exact listing URL" className="w-full min-h-11 rounded-md border bg-background p-3 text-sm" autoComplete="off" />
    {!confirmed && reference !== listing.reference_url && <Button size="sm" variant="outline" disabled={busy} onClick={() => onAction('save_reference', { listing_id: listing.id, reference_url: reference })}>Save reference link</Button>}
    <p className="text-xs text-muted-foreground">A reference only. A Google search link is never used as listing evidence.</p>
    {listing.submission?.reason && <p role="status" className="text-sm">{listing.submission.reason}</p>}
    {!confirmed && <label className={`sh-listing-intake__upload inline-flex min-h-11 items-center rounded-md border px-3 py-2 text-sm ${busy || !processingEnabled ? 'opacity-50' : 'cursor-pointer hover:bg-muted'}`}><Upload className="w-4 h-4 mr-2" />{imageLimit === 1 ? 'Add screenshot' : 'Add screenshots'}<input className="sr-only" type="file" accept="image/jpeg,image/png" multiple={imageLimit > 1} disabled={busy || !processingEnabled || uploadsRemaining === 0 || listing.submission?.upload_available === false || listing.uploads.length >= imageLimit} onChange={event => { const files = Array.from(event.target.files || []); event.target.value = ''; onFiles(files); }} /></label>}
    <p className="text-xs text-muted-foreground">{listing.uploads.length} of {imageLimit} {imageLimit === 1 ? 'screenshot for this submission' : 'screenshots'} · JPEG or PNG, up to 6 MB each.</p>
    {listing.uploads.length > 0 && <ul className="space-y-2 text-xs">{listing.uploads.map(upload => <li key={upload.id} className="rounded-md bg-muted/30 p-2"><span>{upload.name} · Uploaded {stamp(upload.uploaded_at)} · {upload.status === 'complete' ? 'Read, not independently verified' : upload.status}</span>{upload.status === 'uploaded' && !confirmed && <Button size="sm" variant="outline" disabled={busy || !processingEnabled} onClick={() => onAction('read_screenshot', { listing_id: listing.id, upload_id: upload.id })} className="ml-2">Read screenshot</Button>}{['uploaded', 'complete'].includes(upload.status) && <button type="button" className="ml-2 underline" onClick={() => previewSource(upload)}>View source</button>}</li>)}</ul>}
    {previewError && <p role="alert" className="text-sm">{previewError}</p>}
    {preview && <div className="rounded-lg border p-2"><img src={preview.url} alt={preview.name} className="max-h-96 w-full object-contain" /><Button size="sm" variant="ghost" onClick={() => setPreview(null)}>Close source</Button></div>}
    {listing.uploads.some(upload => upload.status === 'complete') && <>
      <p className="font-medium text-sm">Review extracted details</p>
      <div className="grid sm:grid-cols-2 gap-3">{Object.entries(INTAKE_FIELDS).map(([field, [label]]) => { const entry = evidence.fields[field]; return <div key={field} className="rounded-md border p-3 min-w-0"><p className="text-xs text-muted-foreground">{label}</p><p className="text-sm break-words">{entry.conflict && !entry.resolved ? 'Conflicting source details' : show(entry.value)}</p>
        {entry.conflict && !confirmed && <label className="block mt-2 text-xs">Choose the source to keep<select className="block w-full rounded border bg-background p-2 mt-1 text-sm" value={entry.resolution?.choice || ''} disabled={busy} onChange={event => onAction('resolve_field', { listing_id: listing.id, field, choice: event.target.value })}><option value="" disabled>Resolve this conflict</option>{entry.candidates.map(candidate => <option key={candidate.id} value={candidate.id}>{show(candidate.value)} · {candidate.source_name}</option>)}<option value="unknown">Keep as Not provided</option></select></label>}
        {entry.candidates.length > 0 && <details className="mt-2 text-xs"><summary className="cursor-pointer underline">Source evidence</summary>{entry.candidates.map(candidate => <div key={candidate.id} className="mt-2"><p>{candidate.source_name} · Uploaded {stamp(candidate.uploaded_at)}</p><p className="break-words">“{candidate.quote}”</p></div>)}</details>}
      </div>; })}</div>
      {evidence.features.length > 0 && <details><summary className="cursor-pointer text-sm underline">Seller-described equipment and layout</summary><ul className="mt-2 space-y-2 text-sm">{evidence.features.map(feature => <li key={feature.id}>{feature.text}<span className="block text-xs text-muted-foreground">{feature.source_name} · Not independently verified</span></li>)}</ul></details>}
      {evidence.claims.length > 0 && <details><summary className="cursor-pointer text-sm underline">Seller claims, not verified findings</summary><ul className="mt-2 space-y-2 text-sm">{evidence.claims.map(claim => <li key={claim.id}>{claim.text}<span className="block text-xs text-muted-foreground">{claim.source_name}</span></li>)}</ul></details>}
      {evidence.identity_conflicts.length > 0 && <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm">
        <p className="font-medium">This screenshot shows a different model.</p>
        <p className="mt-2">Selected model: {listing.model.title}</p><p>Screenshot: {advertisedIdentity}</p>
        <p className="mt-2">Keep it only if you want this different boat as an alternative. This does not change your Match results or transfer the selected model’s specifications.</p>
        {evidence.identity_review_current || confirmed ? <p className="mt-2">Your saved choice: {listing.identity_resolution?.note}</p> : <>
          {listing.identity_resolution && <p className="mt-2">The identity evidence changed. Please review this choice again.</p>}
          <Button size="sm" variant="outline" className="mt-2" disabled={busy || identityBlocked} onClick={() => onAction('review_identity', { listing_id: listing.id, choice: 'keep_alternative' })}>Keep as alternative model</Button>
          {identityBlocked && <p className="mt-2">Finish reading and resolve conflicting identity details first.</p>}
          <details className="mt-3"><summary className="cursor-pointer underline">Or add your own identity review</summary>
            <label className="block mt-2" htmlFor={listing.id + '-identity'}>Explain the difference (8–500 characters)</label>
            <textarea id={listing.id + '-identity'} className="w-full rounded border p-2 mt-2" value={identityNote} maxLength={500} onChange={event => setIdentityNote(event.target.value)} disabled={busy} />
            <Button size="sm" variant="outline" disabled={busy || identityBlocked || identityNote.trim().length < 8} onClick={() => onAction('review_identity', { listing_id: listing.id, note: identityNote })}>Save identity review</Button>
          </details>
        </>}
      </div>}
    </>}
    <Button size="sm" variant="outline" disabled={busy || imageLimit === 1 && listing.submission?.screenshot_used} onClick={() => { const needsConfirmation = listing.uploads.length > 0 || confirmed; if (!needsConfirmation || window.confirm('Replace this listing’s current details? Its previous screenshots and confirmed versions will stay in history. Other listings and Match results will not change.')) onAction('reset_listing', { listing_id: listing.id, reset_confirmed: needsConfirmation }); }}>Reset listing</Button>
    {(listing.archived_revisions || []).length > 0 && <details><summary className="cursor-pointer text-xs underline">Previous listing evidence ({listing.archived_revisions.length})</summary>{listing.archived_revisions.map(revision => <div key={revision.revision} className="text-xs mt-2"><p>Revision {revision.revision} · Replaced {stamp(revision.reset_at)}</p>{revision.uploads.map(upload => <button key={upload.id} type="button" className="block underline py-1" onClick={() => previewSource(upload)}>View retained source: {upload.name}</button>)}</div>)}</details>}
    {!confirmed && listing.uploads.length === 0 && listing.versions.length === 0 && <Button size="sm" variant="ghost" disabled={busy} onClick={() => onAction('abandon_empty', { listing_id: listing.id })}>Abandon empty draft</Button>}
    <div className="flex flex-wrap gap-2">{confirmed ? <Button size="sm" variant="outline" disabled={busy} onClick={() => onAction('reopen', { listing_id: listing.id })}><RotateCcw className="w-4 h-4 mr-2" />Reopen for a new revision</Button> : <Button size="sm" disabled={busy || Boolean(confirmationReason)} onClick={() => onAction('confirm', { listing_id: listing.id })}><Check className="w-4 h-4 mr-2" />Confirm listing details</Button>}</div>
    {!confirmed && confirmationReason && <p className="text-sm" role="status">{confirmationReason}</p>}
    {confirmed && <p className="text-xs text-muted-foreground">Saved: confirmed version {listing.confirmed_version}, with these screenshot details, source evidence and profile snapshot. This is not a submitted assessment or independent verification of the seller’s claims.</p>}
    {listing.versions.length > 0 && <details><summary className="cursor-pointer text-xs underline">Confirmed version history ({listing.versions.length})</summary><ul className="text-xs mt-2 space-y-1">{listing.versions.map(version => <li key={version.version}><details><summary className="cursor-pointer underline">Version {version.version} · {stamp(version.confirmed_at)} · {Object.values(version.fields).filter(field => field.value != null).length} provided details</summary><p className="mt-2">{version.qualification}</p><dl className="grid sm:grid-cols-2 gap-2 mt-2">{Object.entries(version.fields).map(([field, entry]) => <div key={field}><dt className="text-muted-foreground">{INTAKE_FIELDS[field]?.[0] || field}</dt><dd>{show(entry.value)}{entry.selected && <span className="block text-muted-foreground">{entry.selected.source_name} · “{entry.selected.quote}”</span>}</dd></div>)}</dl></details></li>)}</ul></details>}
  </section>;
}
