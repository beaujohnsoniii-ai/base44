import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Link2, Plus, X, Ship } from "lucide-react";

const empty = () => ({ description: "", url: "", note: "" });

export default function SavedBoatForm({ onAdd, disabled, max = 5, availableSlots = max, prefill }) {
  const [rows, setRows] = useState([empty(), empty(), empty()]);
  const [analyzing, setAnalyzing] = useState(false);

  // When the buyer taps "Add to my candidates" on a suggested boat, the parent
  // passes a prefill object — fill the first empty row with the model name.
  useEffect(() => {
    if (!prefill) return;
    const desc = [prefill.make, prefill.model, prefill.year].filter(Boolean).join(" ") || prefill.title || "";
    setRows((prev) => {
      const firstEmpty = prev.findIndex((r) => !r.description.trim() && !r.url.trim());
      if (firstEmpty === -1) {
        if (prev.length < max) return [...prev, { description: desc, url: "", note: "" }];
        return prev;
      }
      return prev.map((r, i) => (i === firstEmpty ? { ...r, description: desc } : r));
    });
  }, [prefill]);

  const update = (i, field, val) => {
    setRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, [field]: val } : r)));
  };

  const addRow = () => {
    if (rows.length >= max) return;
    setRows((prev) => [...prev, empty()]);
  };

  const removeRow = (i) => {
    if (rows.length <= 1) return;
    setRows((prev) => prev.filter((_, idx) => idx !== i));
  };

  // Paste-and-go: a URL alone is enough — the backend researches the boat from the
  // listing link. A description alone also works when the buyer has no link.
  const validRows = rows.filter((r) => r.description.trim() || r.url.trim());

  const submit = async (e) => {
    e.preventDefault();
    if (validRows.length === 0 || validRows.length > availableSlots || analyzing || disabled) return;
    setAnalyzing(true);
    try {
      const failed = [];
      for (const row of validRows) {
        let saved = false;
        try {
          saved = await onAdd({ description: row.description.trim(), url: row.url.trim(), note: row.note.trim() });
        } catch (_) {}
        if (saved !== true) failed.push(row);
      }
      setRows(failed.length ? failed : [empty()]);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="space-y-3">
        {rows.map((row, i) => (
          <div key={i} className="rounded-lg border border-border p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-muted-foreground">Boat {i + 1}</span>
              {rows.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeRow(i)}
                  className="text-muted-foreground hover:text-destructive disabled:opacity-40"
                  disabled={disabled || analyzing}
                  aria-label={`Remove boat ${i + 1}`}
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            <div>
              <Label htmlFor={`desc-${i}`} className="sr-only">
                Boat name or description
              </Label>
              <Input
                id={`desc-${i}`}
                placeholder="e.g. 2021 Cutwater 30 Pilot House"
                value={row.description}
                maxLength={280}
                onChange={(e) => update(i, "description", e.target.value)}
                disabled={disabled || analyzing}
              />
            </div>
            <div className="grid sm:grid-cols-2 gap-2">
              <div className="relative">
                <Link2 className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="url"
                  placeholder="Listing link (optional)"
                  value={row.url}
                  maxLength={2048}
                  onChange={(e) => update(i, "url", e.target.value)}
                  disabled={disabled || analyzing}
                  className="pl-9"
                />
              </div>
              <Input
                placeholder="What you like about it (optional)"
                value={row.note}
                maxLength={2000}
                onChange={(e) => update(i, "note", e.target.value)}
                disabled={disabled || analyzing}
              />
            </div>
          </div>
        ))}
      </div>
      {rows.length < max && (
        <Button type="button" variant="outline" size="sm" onClick={addRow} disabled={disabled || analyzing}>
          <Plus className="w-4 h-4 mr-2" /> Add another boat
        </Button>
      )}
      <div className="flex items-center gap-3">
        <Button type="submit" disabled={disabled || analyzing || validRows.length === 0 || validRows.length > availableSlots}>
          {analyzing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Researching your boats…
            </>
          ) : (
            <>
              <Ship className="w-4 h-4 mr-2" /> Save {validRows.length > 0 ? `${validRows.length} ` : ""}candidate{validRows.length === 1 ? "" : "s"}
            </>
          )}
        </Button>
        {disabled && (
          <p className="text-xs text-muted-foreground">You can save up to {max} candidate boats.</p>
        )}
        {!disabled && validRows.length > availableSlots && (
          <p className="text-xs text-destructive" role="status">
            Only {availableSlots} candidate slot{availableSlots === 1 ? "" : "s"} remain. Remove extra entries before saving.
          </p>
        )}
      </div>
    </form>
  );
}