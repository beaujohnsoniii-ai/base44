import React from "react";
import { Dialog, DialogTrigger, DialogContent, DialogTitle, DialogDescription, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { pastLikedBoats } from "@/lib/pastLikedBoats";
export default function LikedSearchHistory({ suggestions = [], ownerId }) {
  const boats = pastLikedBoats(suggestions, ownerId);
  return <Dialog>
    <DialogTrigger asChild><button type="button" className="mt-4 text-sm underline underline-offset-4 text-current">Liked boats from your past searches</button></DialogTrigger>
    <DialogContent className="max-h-[85vh] overflow-y-auto">
      <DialogTitle>Liked boats from your past searches</DialogTitle>
      <DialogDescription>Your saved Likes, not current recommendations. Your latest questionnaire determines your current results.</DialogDescription>
      {boats.length ? <ul className="space-y-3">{boats.map(boat => <li key={boat.id} className="rounded-lg border p-3">
        <p className="font-semibold">{boat.title || [boat.make, boat.model].filter(Boolean).join(" ")}</p>
        <p className="text-xs text-muted-foreground">Liked in a previous search</p>
      </li>)}</ul> : <p className="text-sm">You have no liked boats from past searches yet.</p>}
      <DialogClose asChild><Button variant="outline">Back to current results</Button></DialogClose>
    </DialogContent>
  </Dialog>;
}
