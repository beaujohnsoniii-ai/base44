import React from "react";
import { Check, AlertCircle, Info } from "lucide-react";
import { splitScoreComponents, MATCH_SCORE_TOTAL } from "@/lib/matchScoreComponents";

// The ranking justification shown on every result: where the model sits in the
// pool, what that position is based on, the fit reasons behind it, what it gives
// up, and the scoring points that actually produced the placement. Everything is
// read from the stored record — no figure is recalculated or inferred here.

// What the model's mark does and does not mean at this tier.
const MARK_NOTE = {
  best: "This is the strongest fit in your current results.",
  alternative: "Marked in your results as one of the models SoundHeading recommends for your profile.",
  pool: "Nothing is marked at this level. Every model here is ranked on fit alone, so use the order, not a label, to decide what to research first.",
  compact: "Not marked as a recommendation. It stays in your results ranked on fit, with what it gives up shown below.",
};

const BASIS = "Ranking order applies your hard limits first (maximum budget, and any size, storage, towing or draft limit you set), then fit to your activity mix, operating area, passenger load, experience and stated priorities.";

export default function MatchRankingSummary({ boat, variant = "compact", rank = null, poolSize = null }) {
  if (!boat) return null;
  const fitReasons = boat.match?.matches || [];
  const tradeoffs = boat.match?.gaps || [];
  const score = typeof boat.suitability_score === "number" ? Math.round(boat.suitability_score) : null;
  const { earned, zeroed, scored } = splitScoreComponents(boat.score_breakdown);
  const coverage = boat.evidence_summary?.critical;
  const toVerify = Array.isArray(boat.verification_required) ? boat.verification_required.length : 0;
  const rankLabel = rank ? `Why this ranks #${rank}${poolSize > 1 ? ` of ${poolSize}` : ""}` : "Why this ranks here";
  // The card's opening line already shows why_suggested when no summary exists.
  const showRankingNote = Boolean(boat.why_suggested) && boat.why_suggested !== boat.match?.summary;

  return (
    <section className="sh-match-rank" aria-label="Ranking summary">
      <h4 className="sh-match-rank__title">{rankLabel}</h4>
      <p className="sh-match-rank__basis">
        {score !== null ? `SoundHeading Fit ${score} / ${MATCH_SCORE_TOTAL}. ` : "No fit score was stored for this model. "}
        {MARK_NOTE[variant] || MARK_NOTE.compact}
      </p>
      <p className="sh-match-rank__basis sh-match-rank__basis--muted">{BASIS}</p>

      {showRankingNote && (
        <div className="sh-match-block">
          <p className="sh-match-block__label">Ranking note</p>
          <p className="sh-match-rank__note">{boat.why_suggested}</p>
        </div>
      )}

      {fitReasons.length > 0 && (
        <div className="sh-match-block">
          <p className="sh-match-block__label">Why it fits</p>
          <ul>{fitReasons.map((reason, i) => <li key={i}><Check aria-hidden="true" />{reason}</li>)}</ul>
        </div>
      )}

      {tradeoffs.length > 0 && (
        <div className="sh-match-block">
          <p className="sh-match-block__label">Trade-offs to weigh</p>
          <ul>{tradeoffs.map((gap, i) => <li key={i}><AlertCircle aria-hidden="true" />{gap}</li>)}</ul>
        </div>
      )}

      {scored && (
        <div className="sh-match-rank__points">
          <p className="sh-match-block__label">Data points used (of {MATCH_SCORE_TOTAL})</p>
          <ul className="sh-match-rank__chips">
            {earned.map((component) => (
              <li key={component.key}>
                <span className="sh-match-rank__chip-label">{component.label}</span>
                <span className="sh-match-rank__chip-value">{component.value} / {component.max}</span>
              </li>
            ))}
          </ul>
          {zeroed.length > 0 && <p className="sh-match-rank__zero">No points scored for: {zeroed.join(", ")}.</p>}
        </div>
      )}

      {coverage && (
        <p className="sh-match-rank__coverage">
          <Info aria-hidden="true" />
          <span>
            Specification data behind this placement: {coverage.confirmed} of {coverage.total} match-critical fields confirmed
            {coverage.disputed > 0 ? `, ${coverage.disputed} disputed` : ""}
            {coverage.unconfirmed > 0 ? `, ${coverage.unconfirmed} not yet confirmed` : ""}
            {toVerify > 0 ? ` · ${toVerify} item${toVerify === 1 ? "" : "s"} to verify` : ""}.
          </span>
        </p>
      )}
      {!coverage && toVerify > 0 && (
        <p className="sh-match-rank__coverage">
          <Info aria-hidden="true" />
          <span>{toVerify} item{toVerify === 1 ? "" : "s"} must be verified before this placement can be relied on.</span>
        </p>
      )}
    </section>
  );
}