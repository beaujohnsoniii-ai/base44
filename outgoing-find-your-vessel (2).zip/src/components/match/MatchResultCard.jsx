import React from "react";
import { Button, buttonVariants } from "@/components/ui/button";
import ListingLink from "@/components/ListingLink";
import { boatLink } from "@/lib/utils";
import { formatModelPriceGuidance } from "@/lib/modelPriceGuidance";
import { AlertCircle, Search, ThumbsUp, ChevronDown } from "lucide-react";
import BuilderMark from "@/components/match/BuilderMark";
import MatchEvidenceDetails from "@/components/match/MatchEvidenceDetails";
import MatchRankingSummary from "@/components/match/MatchRankingSummary";

// "pool" is the tier's wide set with no recommendation mark (MATCH+), so it must
// not read like a model that lost a ranking it was never part of.
const VARIANT_LABEL = { best: "Strongest match", alternative: "Alternative", compact: "Also considered", pool: "Worth considering" };

// Up to three short spec chips from fields the record already has (no invented specs).
function specChips(boat) {
  const fromSpecs = String(boat.specs || "").split(/[·|•;]/).map((s) => s.trim())
    .filter((s) => s && !/sample spec line/i.test(s));
  const chips = [...fromSpecs];
  if (boat.engines) chips.push(boat.engines);
  if (boat.passenger_capacity) chips.push(`${boat.passenger_capacity} people`);
  return [...new Set(chips)].slice(0, 3);
}

// Horizontal result card (Beau, Oct 22): logo slot and rank at the left, the model in
// serif with its builder, a one-line fit summary and spec chips in the middle, the fit
// score as a slim gold bar at the right. The full ranking justification, limitations
// and evidence open below on request, so a results list stays compact. No model or
// manufacturer photos are shown; the logo slot takes an approved logo later.
export default function MatchResultCard({
  boat, variant = "compact", eyebrow = null, rank = null, poolSize = null, liked = false, busy = false, disableExternalLinks = false,
  featured = false, index = 0, onToggleLike, onReviewListings, listingCount = null,
}) {
  if (!boat) return null;
  const topLine = boat.match?.summary || boat.why_suggested || "";
  const limitations = Array.isArray(boat.verification_required) ? boat.verification_required : [];
  const meta = [boat.make, boat.model, boat.year].filter(Boolean).join(" ");
  const priced = boat.price_range_min || boat.price_range_max;
  const score = typeof boat.suitability_score === "number" ? Math.max(0, Math.min(100, Math.round(boat.suitability_score))) : null;
  const chips = specChips(boat);
  const badge = eyebrow || VARIANT_LABEL[variant] || "Model";
  const isLead = variant === "best";
  const opensGoogleSearch = /^https:\/\/(?:www\.)?google\.com\/search\?/i.test(boatLink(boat));

  return (
    <article
      className={`sh-match-card sh-match-card--${variant} sh-mcard${featured || isLead ? " sh-mcard--featured" : ""}`}
      style={/** @type {React.CSSProperties} */ ({ "--i": Math.min(index, 12), "--fit": score === null ? 0 : score / 100 })}
    >
      <div className="sh-mcard__row">
        <div className="sh-mcard__rail">
          <span className="sh-mcard__rank" aria-label={rank ? `Rank ${rank}` : undefined}>{rank ? <><small>#</small>{rank}</> : "–"}</span>
          <BuilderMark name={boat.make} logoUrl={boat.builder_logo_url || null} size={isLead ? "lg" : "md"} />
        </div>

        <div className="sh-mcard__main">
          <p className="sh-match-eyebrow sh-mcard__badge"><span>{badge}</span>{rank && poolSize > 1 ? <em>of {poolSize}</em> : null}</p>
          <h3 className="sh-match-title sh-mcard__title">{boat.title || meta}</h3>
          <p className="sh-match-meta sh-mcard__builder">{[boat.make, boat.year].filter(Boolean).join(" · ")}{priced ? ` · ${formatModelPriceGuidance(boat)}` : ""}</p>
          {topLine && <p className="sh-match-summary sh-mcard__summary">{topLine}</p>}
          {chips.length > 0 && <ul className="sh-mcard__chips" aria-label="Key specs">{chips.map((c) => <li key={c}>{c}</li>)}</ul>}
        </div>

        <div className="sh-mcard__score" aria-label={score === null ? "Fit not scored" : `Fit ${score} out of 100`}>
          <p className="sh-mcard__scorelabel">Fit</p>
          <p className="sh-mcard__scorenum sh-match-fit">{score === null ? "—" : score}<small>/100</small></p>
          <span className="sh-mcard__bar" aria-hidden="true"><span /></span>
        </div>
      </div>

      <div className="sh-mcard__foot">
        <div className="sh-match-actions">
          {!disableExternalLinks && (
            <ListingLink href={boatLink(boat)} className={buttonVariants({ variant: "outline", size: "sm" })}>
              <Search aria-hidden="true" /> Find Listings{opensGoogleSearch ? " · Google" : ""}
            </ListingLink>
          )}
          {onReviewListings && boat.id && <Button variant="outline" size="sm" disabled={busy} onClick={() => onReviewListings(boat)}>Review listings</Button>}
          {onReviewListings && Number.isInteger(listingCount) && listingCount > 0 && <span className="self-center text-xs">{listingCount} of 3 added</span>}
          {onToggleLike && boat.id && (
            <Button variant={liked ? "default" : "outline"} size="sm" aria-pressed={liked} onClick={() => onToggleLike(boat)}
              title={liked ? "You liked this suggestion" : "Mark this suggestion as helpful — it steers future refreshes"}>
              <ThumbsUp aria-hidden="true" /> {liked ? "Liked" : "Like"}
            </Button>
          )}
        </div>
        <details className="sh-mcard__more">
          <summary>Why it ranks here{limitations.length > 0 ? ` · ${limitations.length} to confirm` : ""} <ChevronDown aria-hidden="true" /></summary>
          <div className="sh-mcard__detail">
            <MatchRankingSummary boat={boat} variant={variant} rank={rank} poolSize={poolSize} />

            {limitations.length > 0 && (
              <div className="sh-match-block sh-match-block--limits">
                <p className="sh-match-block__label">Limitations to confirm ({limitations.length})</p>
                <ul>{limitations.slice(0, 5).map((item, i) => <li key={i}><AlertCircle aria-hidden="true" />{item}</li>)}</ul>
              </div>
            )}

            <MatchEvidenceDetails boat={{ ...boat, __test: disableExternalLinks }} />
          </div>
        </details>
      </div>
    </article>
  );
}
