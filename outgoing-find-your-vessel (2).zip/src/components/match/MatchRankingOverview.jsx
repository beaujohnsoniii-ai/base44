import React from "react";
import { Check, AlertCircle } from "lucide-react";
import { splitScoreComponents, MATCH_SCORE_TOTAL } from "@/lib/matchScoreComponents";

// Pool-wide ranking summary, shown once above the result cards. It walks the pool
// in the order the cards are shown and states, for each model, where it sits, the
// fit reasons behind that position and the scoring points that produced it.
// Everything is read from the stored record: no score, reason or data point is
// recalculated, re-ranked or invented here.
const BASIS = "Every model is screened against your hard limits first (maximum budget, plus any size, storage, towing or draft limit you set), then scored on your activity mix, operating area, passenger load, experience and stated priorities. The order below is that fit score; where your package marks models, the mark is applied to the top of the order.";

// What a recommendation mark means at the tier that applies one.
const MARK_CHIP = {
  match_plus: null,
  refined_match: "Recommended",
  market_match: "Finalist",
};

const REASONS_SHOWN = 3;
const POINTS_SHOWN = 3;

function modelName(boat) {
  return boat.title || [boat.make, boat.model, boat.year].filter(Boolean).join(" ");
}

export default function MatchRankingOverview({ suggestions = [], plan = "match_plus" }) {
  const pool = (suggestions || []).filter(Boolean);
  if (pool.length === 0) return null;
  const markedCount = pool.filter((boat) => boat.highlighted === true).length;
  const markChip = MARK_CHIP[plan] || null;
  const coverage = `${pool.length} model${pool.length === 1 ? "" : "s"} in this pool`;

  return (
    <section className="sh-match-overview" aria-label="How these models were ranked">
      <h3 className="sh-match-subhead">How these models were ranked</h3>
      <p className="sh-match-overview__basis">{BASIS}</p>
      <p className="sh-match-overview__basis sh-match-overview__basis--muted">
        {coverage}
        {markChip && markedCount > 0 ? `, top ${markedCount} marked` : ", none marked as a recommendation"}
        {". Positions come from your profile fit, never from a listing price or brand preference."}
      </p>

      <ol className="sh-match-overview__list">
        {pool.map((boat, i) => {
          const rank = Number(boat.rank) || i + 1;
          const fit = typeof boat.suitability_score === "number" ? Math.round(boat.suitability_score) : null;
          const reasons = Array.isArray(boat.match?.matches) ? boat.match.matches : [];
          const gaps = Array.isArray(boat.match?.gaps) ? boat.match.gaps : [];
          const { earned, scored } = splitScoreComponents(boat.score_breakdown);
          const topLine = boat.match?.summary || boat.why_suggested || "";
          const mark = boat.highlighted === true ? markChip : null;
          const hiddenReasons = reasons.length - REASONS_SHOWN;

          return (
            <li key={boat.id || `rank-${rank}`} className="sh-match-overview__row">
              <div className="sh-match-overview__position">
                <span className="sh-match-overview__rank">#{rank}</span>
                <h4 className="sh-match-overview__title">{modelName(boat)}</h4>
                <p className="sh-match-overview__fit">
                  {fit !== null ? `SoundHeading Fit ${fit} / ${MATCH_SCORE_TOTAL}` : "No fit score stored"}
                  {mark && <span className="sh-match-overview__mark">{mark}</span>}
                </p>
              </div>

              <div className="sh-match-overview__detail">
                {topLine && <p className="sh-match-overview__why">{topLine}</p>}

                {reasons.length > 0 && (
                  <div className="sh-match-block">
                    <p className="sh-match-block__label">Fit reasons</p>
                    <ul>{reasons.slice(0, REASONS_SHOWN).map((reason, k) => <li key={k}><Check aria-hidden="true" />{reason}</li>)}</ul>
                    {hiddenReasons > 0 && (
                      <p className="sh-match-overview__more">
                        {hiddenReasons} more fit reason{hiddenReasons === 1 ? "" : "s"} in the full card below.
                      </p>
                    )}
                  </div>
                )}

                {scored ? (
                  <div className="sh-match-overview__points">
                    <p className="sh-match-block__label">Data points behind this position</p>
                    <ul className="sh-match-rank__chips">
                      {earned.slice(0, POINTS_SHOWN).map((component) => (
                        <li key={component.key}>
                          <span className="sh-match-rank__chip-label">{component.label}</span>
                          <span className="sh-match-rank__chip-value">{component.value} / {component.max}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : (
                  <p className="sh-match-overview__more">No scoring breakdown was stored for this model, so its position rests on the fit reasons above.</p>
                )}

                {gaps.length > 0 && (
                  <p className="sh-match-overview__gaps">
                    <AlertCircle aria-hidden="true" />
                    <span>{gaps.length} trade-off{gaps.length === 1 ? "" : "s"} to weigh — {gaps[0]}</span>
                  </p>
                )}
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
}