import React from "react";
import ModelEvidencePanel from "@/components/ModelEvidencePanel";
import { formatModelPriceGuidance } from "@/lib/modelPriceGuidance";

const STATUS_LABEL = {
  source_confirmed: "Confirmed",
  conflict: "Sources disagree",
  missing: "Not recorded",
  not_checked: "Not confirmed",
};

function Coverage({ summary }) {
  if (!summary?.critical) return null;
  const rows = [
    { key: "critical", label: "MATCH-critical specifications", tally: summary.critical },
    { key: "optional", label: "Optional specifications", tally: summary.optional },
  ];
  return (
    <div className="sh-match-coverage">
      {rows.map(row => (
        <p key={row.key}>
          <span className="sh-match-coverage__label">{row.label}: </span>
          {row.tally.confirmed} confirmed · {row.tally.unconfirmed} unconfirmed · {row.tally.disputed} disputed
          <span className="sh-match-coverage__total"> ({row.tally.total} recorded fields)</span>
        </p>
      ))}
      {summary.basis && <p className="sh-match-coverage__basis">{summary.basis}</p>}
    </div>
  );
}

function FieldList({ fields }) {
  if (!Array.isArray(fields) || fields.length === 0) return null;
  return (
    <ul className="sh-match-evidence__fields">
      {fields.map(row => (
        <li key={row.field}>
          <span className="sh-match-evidence__field">{row.field}</span>
          <span className={`sh-match-evidence__status is-${row.status}`}>{STATUS_LABEL[row.status] || row.status}</span>
          {row.value !== null && row.value !== undefined && <span>{row.value}{row.unit ? " " + row.unit : ""}</span>}
          {row.source_url && <a href={row.source_url} target="_blank" rel="noopener noreferrer">Source</a>}
          <span className="sh-match-evidence__class">{row.matchClass === "critical" ? "match-critical" : "optional"}</span>
        </li>
      ))}
    </ul>
  );
}

// Everything factual behind the card, stated as recorded rather than implied.
export default function MatchEvidenceDetails({ boat }) {
  const summary = boat?.evidence_summary;
  const score = boat?.score_breakdown || {};
  const scoreRows = Object.entries(score).filter(([, value]) => typeof value === "number");
  return (
    <details className="sh-match-evidence">
      <summary>Technical evidence and sources</summary>
      {boat?.specs && <p className="sh-match-evidence__specs">{boat.specs}</p>}
      {boat?.engines && <p><span className="sh-match-evidence__field">Engines: </span>{boat.engines}</p>}
      {boat?.price_range_context && (
        <p><span className="sh-match-evidence__field">Price basis: </span>{boat.price_range_context} · {formatModelPriceGuidance(boat)}</p>
      )}
      <Coverage summary={summary} />
      <FieldList fields={summary?.fields} />
      {scoreRows.length > 0 && (
        <div className="sh-match-evidence__score">
          <p className="sh-match-evidence__field">Fit score components</p>
          {scoreRows.map(([key, value]) => (
            <span key={key}>{key.replaceAll("_", " ")}: {value}</span>
          ))}
        </div>
      )}
      {boat?.id && !boat?.__test ? <ModelEvidencePanel suggestion={{ id: boat.id }} /> : null}
    </details>
  );
}