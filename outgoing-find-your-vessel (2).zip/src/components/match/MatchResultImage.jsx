import React from "react";
import { Image } from "@/components/ui/image";
import { Compass } from "lucide-react";

// Model photography is only ever shown when the published catalog record
// carries both an image URL and an explicit licence recorded by a reviewer.
// Anything else falls back to a tasteful placeholder rather than a borrowed or
// invented photo of a different boat.
export function hasLicensedModelImage(boat) {
  return typeof boat?.image_url === "string" && boat.image_url.trim().length > 0 &&
    typeof boat?.image_license === "string" && boat.image_license.trim().length > 0;
}

export default function MatchResultImage({ boat, variant = "card" }) {
  const label = [boat?.make, boat?.model].filter(Boolean).join(" ") || boat?.title || "Model";
  if (hasLicensedModelImage(boat)) {
    return (
      <figure className={`sh-match-photo sh-match-photo--${variant}`}>
        <Image
          src={boat.image_url}
          alt={label + " model photo"}
          className="h-full w-full"
          fittingType="fill"
        />
        <figcaption>{boat.image_license}</figcaption>
      </figure>
    );
  }
  return (
    <div className={`sh-match-photo sh-match-photo--placeholder sh-match-photo--${variant}`} role="img" aria-label={label + " — no licensed model photo available"}>
      <Compass aria-hidden="true" />
      <span>{label}</span>
      <small>No licensed model photo on file</small>
    </div>
  );
}