import React from "react";

// Logo slot for a result card. Until a builder's logo is approved, the slot shows a
// navy-and-gold monogram of the builder's initials, sized and placed exactly where
// the logo will sit. Approved artwork drops in through one prop (logoUrl): pass the
// approved file's URL and the monogram is replaced. Never pass a scraped or
// unapproved logo, and never a manufacturer photo.
export function builderInitials(name) {
  const words = String(name || "").replace(/[^A-Za-z0-9 ]+/g, " ").trim().split(/\s+/).filter(Boolean);
  if (!words.length) return "SH";
  return (words.length === 1 ? words[0].slice(0, 2) : words[0][0] + words[1][0]).toUpperCase();
}

export default function BuilderMark({ name, logoUrl = null, size = "md" }) {
  const label = name ? `${name} logo` : "Builder logo";
  if (logoUrl) {
    return <span className={`sh-mark sh-mark--${size} sh-mark--logo`}><img src={logoUrl} alt={label} loading="lazy" /></span>;
  }
  return (
    <span className={`sh-mark sh-mark--${size}`} role="img" aria-label={`${name || "Builder"} (logo slot, monogram placeholder)`}>
      <span className="sh-mark__ring" aria-hidden="true" />
      <span className="sh-mark__initials" aria-hidden="true">{builderInitials(name)}</span>
    </span>
  );
}
