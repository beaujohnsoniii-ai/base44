import React from "react";
import MatchResultCard from "@/components/match/MatchResultCard";
import { intakeModelKey } from "../../../base44/shared/listing-intake.mjs";
import "@/components/match-results.css";

// Paid MATCH presentation. The engine ranks the whole pool and marks only the
// models that carry the tier's recommendation: the leading 5-7 at Refined Match
// and the top 3 at Market Match. MATCH+ marks nothing — it is deliberately the
// wide set to look around with — so at that tier every model is shown as one set
// and none is labelled as our recommendation. A mark is only ever displayed, never
// invented here: what the buyer sees is what was stored.
const PASS_COPY = {
  match_plus: {
    spread: "Models to look around with",
    note: "A wide set to research. None of these is marked as our recommendation yet — answer the deeper questions to sharpen the order.",
  },
  refined_match: { marked: "Recommended for you", spread: "Also considered", eyebrow: "Recommended" },
  market_match: { marked: "Your finalists", spread: "Other models considered", eyebrow: "Finalist" },
};

export default function MatchResultsShowcase({
  plan = "match_plus", suggestions = [], likedIds, busyId = null,
  disableExternalLinks = false, onToggleLike, onReviewListings, listingCounts = null, listingEligibleIds = null,
}) {
  const marked = suggestions.filter((b) => b.highlighted === true);
  const spread = suggestions.filter((b) => b.highlighted !== true);
  const total = suggestions.length;
  const copy = PASS_COPY[plan] || PASS_COPY.match_plus;
  const markedLabel = copy.marked || "Marked models";

  // Captain: every finalist gets the featured treatment, not only the leader.
  const featuredMarks = plan === "market_match";
  let order = 0;
  const card = (boat, variant, fallbackRank, poolSize, archived = false) => (
    <MatchResultCard
      key={boat.id || `${variant}-${boat.rank || fallbackRank}`}
      boat={boat}
      variant={variant}
      eyebrow={variant === "alternative" ? copy.eyebrow : null}
      rank={Number(boat.rank) || fallbackRank}
      poolSize={poolSize}
      featured={!archived && featuredMarks && boat.highlighted === true}
      index={order++}
      liked={Boolean(likedIds?.has?.(boat.id))}
      busy={busyId === boat.id}
      disableExternalLinks={disableExternalLinks}
      onReviewListings={!archived && !disableExternalLinks && (!listingEligibleIds || listingEligibleIds.includes(boat.id)) ? onReviewListings : undefined}
      listingCount={listingCounts ? listingCounts[boat.id] ?? listingCounts[intakeModelKey(boat)] ?? 0 : null}
      onToggleLike={archived && !likedIds?.has?.(boat.id) ? undefined : onToggleLike}
    />
  );

  // The strongest marked model leads; the rest of the marked models follow, then
  // the whole remaining pool stays visible in rank order.
  const leader = marked[0] || null;
  const remainingMarked = marked.slice(1);

  return (
    <div className="sh-match-results">
      {leader && (
        <section className="sh-match-best" aria-label="Strongest match">
          {card(leader, "best", 1, total)}
        </section>
      )}
      {remainingMarked.length > 0 && (
        <section aria-label={markedLabel}>
          <h3 className="sh-match-subhead">{markedLabel}</h3>
          <div className="sh-match-grid sh-match-list">{remainingMarked.map((boat, i) => card(boat, "alternative", i + 2, total))}</div>
        </section>
      )}
      {spread.length > 0 && (
        <section aria-label={copy.spread}>
          <h3 className="sh-match-subhead">{copy.spread}</h3>
          {!leader && copy.note && <p className="text-sm text-muted-foreground mb-3">{copy.note}</p>}
          <div className="sh-match-grid sh-match-list">
            {spread.map((boat, i) => card(boat, leader ? "compact" : "pool", i + 1, total))}
          </div>
        </section>
      )}

    </div>
  );
}