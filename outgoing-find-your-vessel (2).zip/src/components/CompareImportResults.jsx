import React from "react";

const FACT_LABELS = {
  make: "Make",
  model: "Model",
  year: "Year",
  asking_price: "Asking Price",
  asking_price_currency: "Currency",
  engine_hours: "Engine Hours",
  overall_length_ft: "Overall Length",
  beam_ft: "Beam",
  draft_ft: "Draft",
  storage_height_ft: "Storage Height",
  loaded_storage_weight_lb: "Storage Weight",
  passenger_capacity: "Passenger Capacity",
};

function formatValue(field, value, currency) {
  if (value === null || value === undefined) return "Not verified";
  if (field === "asking_price") return (currency ? currency + " " : "") + Number(value).toLocaleString();
  if (field === "engine_hours") return Number(value).toLocaleString() + " h";
  if (["overall_length_ft", "beam_ft", "draft_ft", "storage_height_ft"].includes(field)) return value + " ft";
  if (field === "loaded_storage_weight_lb") return Number(value).toLocaleString() + " lb";
  if (field === "passenger_capacity") return value + " persons";
  return String(value);
}

function StatusBadge({ status }) {
  const styles = {
    evaluated: "bg-amber-50 text-amber-800 border-amber-200",
    partial_evidence: "bg-amber-50 text-amber-800 border-amber-200",
    insufficient_evidence: "bg-amber-50 text-amber-800 border-amber-200",
    unsupported_source: "bg-slate-50 text-slate-700 border-slate-200",
    fetch_failed: "bg-red-50 text-red-800 border-red-200",
    access_blocked: "bg-red-50 text-red-800 border-red-200",
    extraction_failed: "bg-red-50 text-red-800 border-red-200",
    ambiguous_listing: "bg-amber-50 text-amber-800 border-amber-200",
    capture_insufficient_evidence: "bg-amber-50 text-amber-800 border-amber-200",
  };
  const cls = styles[status] || "bg-slate-50 text-slate-700 border-slate-200";
  const label = status === "evaluated" || status === "partial_evidence" ? "Partial evidence — not verified" : String(status).replaceAll("_", " ");
  return <span className={"inline-block text-xs font-medium px-2 py-1 rounded border " + cls}>{label}</span>;
}

function ListingColumn({ result }) {
  const facts = result.nullable_facts || {};
  const hasFacts = Object.values(facts).some(v => v !== null);
  const fieldEvidence = Object.entries(result.facts || {}).filter(([, fact]) => fact?.quote);
  const savedYear = String(result.model_title || "").match(/\b(?:19|20)\d{2}\b/g)?.at(-1);
  const listingYear = facts.year;
  // Listing URL labels are hints only, never accepted as verified data.
  let urlYear = null;
  try { urlYear = new URL(result.url).pathname.match(/^\/boat\/((?:19|20)\d{2})-/i)?.[1] || null; } catch { /* Unreadable URL: no inferred year. */ }
  const conflictingYear = savedYear && (listingYear != null ? Number(savedYear) !== Number(listingYear) : urlYear && savedYear !== urlYear);
  const priceCurrency = facts.asking_price_currency || result.facts?.asking_price?.unit || "";

  return (
    <article className="min-w-0 rounded-xl border bg-white p-5 space-y-4">
      <div className="space-y-1">
        <h3 className="font-semibold text-sm">Saved Match model: {result.model_title || "Unknown"}</h3>
        <p className="text-xs text-muted-foreground">Individual listing year: {listingYear ?? "Not verified"}{result.resolution?.transport === "indexed_search" && listingYear != null ? " (indexed source claim)" : listingYear != null ? " (listing page claim)" : ""}</p>
        {conflictingYear && <p className="text-xs text-amber-800" role="note">Year mismatch: the saved Match model is {savedYear}, but {listingYear != null ? "this listing claims " + listingYear : "the listing URL suggests " + urlYear + " (not verified)"}. Confirm the boat before comparing specifications.</p>}
        <a href={result.url} target="_blank" rel="noopener noreferrer" className="block text-xs underline break-all text-muted-foreground">{result.url}</a>
        <StatusBadge status={result.status} />
        {result.reason && <p className="text-xs text-muted-foreground">{result.reason}</p>}
      </div>

      {hasFacts && <div className="space-y-1.5">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Extracted Details</p>
        {Object.entries(FACT_LABELS).map(([field, label]) => {
          const value = facts[field];
          const isMissing = value === null || value === undefined;
          return (
            <div key={field} className="flex justify-between gap-2 text-sm border-b border-slate-100 pb-1">
              <span className="text-muted-foreground">{label}</span>
              <span className={isMissing ? "text-muted-foreground italic" : "font-medium"}>{formatValue(field, value, priceCurrency)}</span>
            </div>
          );
        })}
      </div>}

      {hasFacts && <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Source: {result.resolution?.transport === "user_capture" ? "Buyer-copied page text" : result.resolution?.transport === "indexed_search" ? "Exact-URL indexed excerpt" : "Direct listing page"}
        </p>
        {result.resolution?.transport === "indexed_search" && (
          <p className="text-xs text-amber-800">The live page was blocked. These seller claims came from a cached search excerpt for this exact URL, not a live page read.</p>
        )}
        {result.resolution?.transport === "user_capture" && (
          <p className="text-xs text-amber-800">This text was copied by the buyer from the saved URL for this Compare action. SoundHeading did not retrieve or independently verify the page.</p>
        )}
        {fieldEvidence.length > 0 && <details>
          <summary className="cursor-pointer text-xs font-medium">View field evidence</summary>
          <div className="mt-2 space-y-2">
            {fieldEvidence.map(([field, fact]) => (
              <div key={field} className="text-xs">
                <span className="font-medium">{FACT_LABELS[field] || field}: </span>
                <span className="text-muted-foreground">{fact.quote}</span>
              </div>
            ))}
          </div>
        </details>}
        {result.source_evidence?.excerpt && <details>
          <summary className="cursor-pointer text-xs font-medium">View bounded source excerpt</summary>
          {result.source_evidence.title && <p className="mt-2 text-xs font-medium">{result.source_evidence.title}</p>}
          <p className="mt-1 text-xs text-muted-foreground whitespace-pre-wrap">{result.source_evidence.excerpt}</p>
        </details>}
      </div>}

      {result.checks?.length > 0 && <div className="space-y-1">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Profile Fit</p>
        {result.checks.map((check, i) => (
          <p key={i} className="text-xs">
            <span className="font-medium">{check.criterion}:</span>{" "}
            <span className={check.status === "seller_claim_within_limit" ? "text-green-700" : check.status === "potential_conflict" ? "text-amber-700" : "text-muted-foreground"}>
              {String(check.status).replaceAll("_", " ")}
            </span>
          </p>
        ))}
      </div>}

      {result.concerns?.length > 0 && <div className="space-y-1">
        <p className="text-xs font-semibold uppercase tracking-wide text-amber-700">Concerns</p>
        {result.concerns.map((text, i) => <p key={i} className="text-xs text-amber-800">{text}</p>)}
      </div>}

      {result.unknowns?.length > 0 && <div className="space-y-1">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Not Verified</p>
        {result.unknowns.map((text, i) => <p key={i} className="text-xs text-muted-foreground">{text}</p>)}
      </div>}

      {result.resolution?.retrieved_at && (
        <p className="text-xs text-muted-foreground">Retrieved {new Date(result.resolution.retrieved_at).toLocaleString()}</p>
      )}
    </article>
  );
}

export default function CompareImportResults({ comparison }) {
  if (!comparison?.results?.length) return null;

  return (
    <div className="space-y-4" aria-live="polite">
      <div className="flex items-baseline justify-between">
        <h2 className="text-xl font-heading">Side-by-side comparison</h2>
        <p className="text-sm text-muted-foreground">{comparison.results.length} listing{comparison.results.length === 1 ? "" : "s"}</p>
      </div>
      <p className="text-sm">{comparison.recommendation?.explanation}</p>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {comparison.results.map(result => (
          <ListingColumn key={result.url} result={result} />
        ))}
      </div>
      <p className="text-xs text-muted-foreground">{comparison.notice}</p>
    </div>
  );
}