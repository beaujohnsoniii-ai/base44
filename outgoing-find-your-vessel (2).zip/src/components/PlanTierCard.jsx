import React from "react";
import { CheckCircle2, ArrowRight, ShieldCheck, Sparkles, Star, RefreshCw, Clock, AlertCircle, Ship } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { ACTIVATION_FEE, creditedPrice, normalizePlan, TIER_RANK } from "@/lib/stages";

// Tier card for the three packages. Handles:
//   - not purchased: show the purchase price (with activation credit if eligible)
//   - upgrade: a lower-tier customer sees the upgrade price (prior payment credited)
//   - active: show the update counter, access window, and a link to the report (if any)
//   - included: a higher-tier customer sees the tier is already part of their package
export default function PlanTierCard({
  tier,
  plan,
  updatesUsed = 0,
  updatesLimit = 0,
  planExpires = null,
  hasActivation = false,
  onPurchase,
  purchasing = null,
  checkoutAvailable = false,
  onViewReport = null,
  flagged = false,
  simulation = false,
}) {
  const np = normalizePlan(plan);
  const isCurrent = np === tier.id;
  const featured = tier.main;
  const userRank = TIER_RANK[np] || 0;
  const tierRank = TIER_RANK[tier.id] || 0;
  const hasHigher = userRank > tierRank;

  // Determine the upgrade price and product id based on the buyer's current plan.
  let upgradePrice = null;
  let purchaseId = tier.id;
  if (tier.id === "refined_match" && np === "match_plus") {
    upgradePrice = tier.upgradeFromMatchPlus;
    purchaseId = "upgrade_match_plus_to_refined";
  } else if (tier.id === "market_match" && np === "match_plus") {
    upgradePrice = tier.upgradeFromMatchPlus;
    purchaseId = "upgrade_match_plus_to_market";
  } else if (tier.id === "market_match" && np === "refined_match") {
    upgradePrice = tier.upgradeFromRefined;
    purchaseId = "upgrade_refined_to_market";
  }

  const isUpgrade = upgradePrice !== null;
  const creditApplies = hasActivation && tier.credit_eligible && !isUpgrade;
  const displayPrice = isUpgrade ? upgradePrice : creditedPrice(tier.price, creditApplies);
  const expiryLabel = planExpires
    ? new Date(planExpires).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
    : null;

  return (
    <Card
      className={`flex flex-col relative overflow-hidden ${
        featured ? "border-accent ring-2 ring-accent/40 shadow-lg" : "border-border shadow-sm"
      } ${isCurrent ? "border-accent" : ""} ${flagged && !isCurrent && !hasHigher ? "border-amber-400/60" : ""}`}
    >
      {featured && !isCurrent && !hasHigher && (
        <div className="absolute top-0 inset-x-0 bg-accent text-accent-foreground text-xs font-medium px-4 py-1.5 flex items-center justify-center gap-1.5">
          <Star className="w-3.5 h-3.5 fill-current" /> Most comprehensive
        </div>
      )}

      <CardHeader className={featured && !isCurrent && !hasHigher ? "pt-9" : ""}>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-heading flex items-center gap-2">{tier.name}</CardTitle>
          {isCurrent && <CheckCircle2 className="w-5 h-5 text-accent" />}
        </div>
        <CardDescription className="text-sm">{tier.tagline}</CardDescription>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col">
        <p className="text-sm text-muted-foreground">{tier.description}</p>

        {!isCurrent && !hasHigher && (
          <div className="mt-5 flex items-baseline gap-2 flex-wrap">
            <span className="text-4xl font-heading font-semibold">${displayPrice}</span>
            {creditApplies && (
              <>
                <span className="text-sm text-muted-foreground line-through">${tier.price}</span>
                <span className="text-xs font-medium text-accent">${ACTIVATION_FEE} activation credit applied</span>
              </>
            )}
            {isUpgrade && (
              <span className="text-xs text-muted-foreground">${tier.price} total — prior payment credited</span>
            )}
          </div>
        )}

        {isCurrent && (
          <div className="mt-5 space-y-2 text-sm">
            <p className="flex items-center gap-2 text-accent font-medium">
              <CheckCircle2 className="w-4 h-4" /> Active
            </p>
            <div className="flex items-center gap-4 text-muted-foreground flex-wrap">
              <span className="flex items-center gap-1.5">
                <RefreshCw className="w-3.5 h-3.5" />
                Updates: {updatesUsed} of {updatesLimit} used
              </span>
              {expiryLabel && (
                <span className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  Through {expiryLabel}
                </span>
              )}
            </div>
            {tier.listingEvals > 0 && (
              <p className="flex items-center gap-1.5 text-muted-foreground">
                <Ship className="w-3.5 h-3.5" />
                {tier.listingEvals} listing evaluations included
              </p>
            )}
          </div>
        )}

        <ul className="mt-5 space-y-2 flex-1">
          {tier.deliverables.map((d) => (
            <li key={d} className="flex items-start gap-2.5 text-sm">
              <CheckCircle2 className={`w-4 h-4 mt-0.5 shrink-0 ${featured ? "text-accent" : "text-primary"}`} />
              <span>{d}</span>
            </li>
          ))}
        </ul>

        <p className="mt-5 text-xs text-muted-foreground flex items-start gap-1.5 border-t border-border pt-4">
          <ShieldCheck className="w-3.5 h-3.5 mt-0.5 shrink-0 text-accent" />
          {tier.remedy}
        </p>
      </CardContent>

      <CardFooter className="pt-0">
        {isCurrent ? (
          onViewReport ? (
            <Button className="w-full" onClick={onViewReport}>
              View your report <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button className="w-full" variant="secondary" disabled>
              Unlocked
            </Button>
          )
        ) : hasHigher ? (
          <Button className="w-full" variant="secondary" disabled>
            Included in your package
          </Button>
        ) : flagged ? (
          <div className="w-full space-y-2">
            <Button className="w-full" variant="secondary" disabled>
              Resolve profile issues first
            </Button>
            <p className="text-xs text-amber-700 dark:text-amber-400 flex items-start gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              Your profile has potential issues to review. Adjust the flagged fields and re-run the advisor to unlock purchases.
            </p>
          </div>
        ) : (
          <Button
            className="w-full"
            variant={featured ? "default" : "outline"}
            onClick={() => onPurchase(purchaseId)}
            disabled={!checkoutAvailable || purchasing === purchaseId}
          >
            {!checkoutAvailable ? (
              "Checkout unavailable"
            ) : purchasing === purchaseId ? (
              "Redirecting…"
            ) : (
              <>
                {featured && <Sparkles className="w-4 h-4 mr-1" />}
                {simulation ? `Simulate ${isUpgrade ? "upgrade" : "purchase"} · $${displayPrice} display only` : isUpgrade ? `Upgrade for $${displayPrice}` : `Purchase for $${displayPrice}`}
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}