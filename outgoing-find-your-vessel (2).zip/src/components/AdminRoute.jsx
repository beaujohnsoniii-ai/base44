import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
export default function AdminRoute() {
  const { user, isAuthenticated, isLoadingAuth, authChecked, authError } = useAuth();
  if (isLoadingAuth || !authChecked) return <div role="status">Checking administrator access…</div>;
  if (authError || !isAuthenticated || user?.role !== "admin") return <Navigate to="/dashboard" replace />;
  return <Outlet />;
}
