import React from "react";

// Bespoke Sound Heading linework: shared yacht hull, six distinct navigation marks.
const Hull = () => <><path d="M17 51h46l-7 10H28z"/><path d="M26 51l5-12h19l8 12M34 39v-8h12v8M30 46h20"/><path d="M19 66c5-3 9-3 14 0s9 3 14 0 9-3 14 0" opacity=".65"/></>;
export default function ServiceMark({ service, size = 72, ...props }) {
 return <svg width={size} height={size} viewBox="0 0 80 80" fill="none" stroke="currentColor" strokeWidth="1.55" strokeLinecap="round" strokeLinejoin="round" focusable="false" {...props}>
  {service === "MATCH" && <><path d="M10 28a31 31 0 0 1 60 0M40 7v8M16 17l6 6M64 17l-6 6" opacity=".55"/><path d="m40 17-7 12 7-3 7 3z" fill="currentColor" stroke="none"/><Hull/></>}
  {service === "ANALYZE" && <><Hull/><circle cx="57" cy="24" r="13"/><path d="m66 34 7 8M49 25l5 4 9-11M13 25h14M13 31h10" /></>}
  {service === "COMPARE" && <><path d="M40 12v55M10 39h23l-5 9H16zM47 39h23l-5 9H53zM16 39l4-10h7l4 10M53 39l4-10h7l4 10M15 24h14m-14 0 4-4m-4 4 4 4M51 24h14m0 0-4-4m4 4-4 4"/><path d="M9 55c4-3 8-3 12 0s8 3 12 0M47 55c4-3 8-3 12 0s8 3 12 0" opacity=".65"/></>}
  {service === "OWNERSHIP" && <><Hull/><path d="M14 45V17h13M14 17l-5 6m5-6 5 6M66 45V17H53M66 17l-5 6m5-6 5 6"/><circle cx="40" cy="18" r="8"/><path d="M40 13v10M36 18h8"/></>}
  {service === "LEARN" && <><path d="M40 63c-10-7-20-8-30-6V19c11-2 22 1 30 7 8-6 19-9 30-7v38c-10-2-20-1-30 6zm0 0V26"/><path d="m18 40 16 2-4 7h-8zM22 40l3-9 5 10M49 30h12M49 37h12M49 44h8M18 53l15 3" /></>}
  {service === "PRIVATE ADVISORY" && <><path d="M40 7c9 7 19 9 29 10v26c0 15-17 25-29 30C28 68 11 58 11 43V17c10-1 20-3 29-10z" opacity=".65"/><path d="m40 17-4 8 4-2 4 2z" fill="currentColor" stroke="none"/><g transform="translate(4 7) scale(.9)"><Hull/></g></>}
 </svg>;
}
