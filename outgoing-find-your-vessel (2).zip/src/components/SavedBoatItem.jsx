import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import ListingLink from "@/components/ListingLink";
import { Trash2, Pencil, Check, X, ExternalLink, AlertCircle } from "lucide-react";

// One saved candidate row with an inline edit mode so the buyer can correct
// specs the auto-extraction got wrong (e.g. a listing's model year).
export default function SavedBoatItem({ boat, onRemove, onUpdate }) {
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    make: boat.make || "",
    model: boat.model || "",
    year: boat.year ?? "",
    asking_price: boat.asking_price ?? "",
    engines: boat.engines || "",
    specs: boat.specs || "",
  });

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = async () => {
    setSaving(true);
    try {
      const cleaned = {
        make: form.make.trim(),
        model: form.model.trim(),
        year: form.year === "" ? null : Number(form.year),
        asking_price: form.asking_price === "" ? null : Number(form.asking_price),
        engines: form.engines.trim(),
        specs: form.specs.trim(),
      };
      await onUpdate(boat.id, cleaned);
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  const cancel = () => {
    setForm({
      make: boat.make || "",
      model: boat.model || "",
      year: boat.year ?? "",
      asking_price: boat.asking_price ?? "",
      engines: boat.engines || "",
      specs: boat.specs || "",
    });
    setEditing(false);
  };

  return (
    <div className="py-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          {boat.url ? (
            <ListingLink href={boat.url} className="font-medium hover:underline flex items-center gap-1">
              {boat.title} <ExternalLink className="w-3.5 h-3.5" />
            </ListingLink>
          ) : (
            <p className="font-medium">{boat.title}</p>
          )}

          {editing ? (
            <div className="mt-2 space-y-3 rounded-lg border border-border p-3 bg-muted/30">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Make</Label>
                  <Input value={form.make} onChange={(e) => set("make", e.target.value)} />
                </div>
                <div>
                  <Label className="text-xs">Model</Label>
                  <Input value={form.model} onChange={(e) => set("model", e.target.value)} />
                </div>
                <div>
                  <Label className="text-xs">Year</Label>
                  <Input type="number" value={form.year} onChange={(e) => set("year", e.target.value)} />
                </div>
                <div>
                  <Label className="text-xs">Asking price ($)</Label>
                  <Input type="number" value={form.asking_price} onChange={(e) => set("asking_price", e.target.value)} />
                </div>
              </div>
              <div>
                <Label className="text-xs">Engines</Label>
                <Input value={form.engines} onChange={(e) => set("engines", e.target.value)} />
              </div>
              <div>
                <Label className="text-xs">Specs</Label>
                <Input value={form.specs} onChange={(e) => set("specs", e.target.value)} />
              </div>
              <div className="flex gap-2">
                <Button size="sm" onClick={save} disabled={saving}>
                  <Check className="w-4 h-4 mr-1" /> {saving ? "Saving…" : "Save"}
                </Button>
                <Button size="sm" variant="ghost" onClick={cancel} disabled={saving}>
                  <X className="w-4 h-4 mr-1" /> Cancel
                </Button>
              </div>
            </div>
          ) : (
            <>
              <p className="text-sm text-muted-foreground">
                {[boat.make, boat.model, boat.year].filter(Boolean).join(" ")}
                {boat.asking_price ? ` · $${Number(boat.asking_price).toLocaleString()}` : ""}
                {boat.source ? ` · ${boat.source}` : ""}
              </p>
              {boat.attraction_comment && <p className="text-sm text-muted-foreground italic mt-1">"{boat.attraction_comment}"</p>}
              {boat.engines && <p className="text-sm text-muted-foreground">{boat.engines}</p>}
              {boat.specs && <p className="text-sm text-muted-foreground">{boat.specs}</p>}
              {boat.match?.summary && (
                <div className="mt-2 rounded-lg bg-accent/5 border border-accent/20 p-3 text-sm space-y-2">
                  <p className="font-medium text-accent">How it fits your needs</p>
                  <p className="text-foreground/90">{boat.match.summary}</p>
                  {boat.match.matches?.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mt-2">Matches</p>
                      <ul className="mt-1 space-y-1">
                        {boat.match.matches.map((m, i) => (
                          <li key={i} className="flex items-start gap-2 text-foreground/80">
                            <Check className="w-3.5 h-3.5 text-accent mt-0.5 shrink-0" /> {m}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {boat.match.gaps?.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mt-2">Gaps</p>
                      <ul className="mt-1 space-y-1">
                        {boat.match.gaps.map((g, i) => (
                          <li key={i} className="flex items-start gap-2 text-foreground/80">
                            <AlertCircle className="w-3.5 h-3.5 text-destructive mt-0.5 shrink-0" /> {g}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
        <div className="flex gap-1">
          {!editing && (
            <Button size="icon" variant="ghost" onClick={() => setEditing(true)} title="Edit specs">
              <Pencil className="w-4 h-4" />
            </Button>
          )}
          <Button size="icon" variant="ghost" onClick={() => onRemove(boat.id)} title="Remove">
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}