import React from "react";

/**
 * SoundHeading mark — a clean, minimal compass heading icon.
 * The compass ring frames a bold bearing arrow pointing to the
 * course heading: the direction a vessel is steered. Professional,
 * single-weight, reads clearly at small sizes.
 */
export default function SoundHeadingMark({ className = "" }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      {/* compass ring */}
      <circle
        cx="12"
        cy="12"
        r="9"
        stroke="currentColor"
        strokeWidth="1.3"
        opacity="0.35"
      />
      {/* cardinal tick — north (the heading reference) */}
      <path
        d="M12 2.4 L12 4"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
      />
      {/* course heading arrow — the bearing being steered */}
      <path
        d="M12 5.2 L15.6 13.2 L12 11.1 L8.4 13.2 Z"
        fill="currentColor"
      />
    </svg>
  );
}