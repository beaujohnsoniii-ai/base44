import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import PriorityList from "@/components/PriorityList";
import ManufacturerPicker from "@/components/ManufacturerPicker";
import PriceRangeSlider from "@/components/PriceRangeSlider";
import { ChevronLeft, ChevronRight, Check, ArrowUp, ArrowDown, GripVertical, X } from "lucide-react";
import ActivityWeightPie from "@/components/ActivityWeightPie";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { FIELD_TIERS } from "@/lib/question-fields";
import { normalizePlan } from "@/lib/stages";
import { apportionActivityWeights, toggleActivityWeightSelection } from "@/lib/activityWeights";

const ROLES = [
  { value: "buyer", label: "I'm the buyer" },
  { value: "assistant", label: "I'm helping the buyer" },
  { value: "broker", label: "I'm a broker / representative" },
];
const ACTIVITIES = [
  "Day cruising", "Overnight cruising", "Fishing", "Watersports / tubing",
  "Diving", "Entertaining", "Commuting", "Liveaboard",
];
const EXPERIENCE = [
  { value: "none", label: "No experience" },
  { value: "beginner", label: "Beginner" },
  { value: "intermediate", label: "Intermediate" },
  { value: "experienced", label: "Experienced" },
  { value: "expert", label: "Expert" },
];
const STORAGE = [
  { value: "trailer", label: "Trailer at home" },
  { value: "marina_slip", label: "Marina slip" },
  { value: "mooring", label: "Mooring" },
  { value: "dry_stack", label: "Dry stack / rack storage" },
  { value: "lift_kept", label: "Lift kept" },
  { value: "private_dock", label: "Private dock at my home" },
  { value: "not_sure", label: "Not sure yet" },
];
const TIMELINES = [
  { value: "asap", label: "As soon as possible" },
  { value: "1_to_3_months", label: "1–3 months" },
  { value: "3_to_6_months", label: "3–6 months" },
  { value: "6_plus_months", label: "6+ months" },
  { value: "just_exploring", label: "Just exploring" },
];
const HORIZONS = [
  { value: "1_to_3_years", label: "1–3 years" },
  { value: "3_to_7_years", label: "3–7 years" },
  { value: "7_to_12_years", label: "7–12 years" },
  { value: "last_boat", label: "This may be my last boat" },
];
const VESSEL_CLASSES = [
  { value: "private", label: "Private boat — personal & family use" },
  { value: "charter", label: "Charter boat — I plan to charter it out" },
];
const SIZE_RANGES = [
  { value: "under_18", label: "Under 18 ft" },
  { value: "18_24", label: "18–24 ft" },
  { value: "24_30", label: "24–30 ft" },
  { value: "30_40", label: "30–40 ft" },
  { value: "40_50", label: "40–50 ft" },
  { value: "50_plus", label: "50+ ft" },
];
const PRIORITIES = [
  "Safety & seaworthiness",
  "Build quality & construction",
  "Ride quality & seakeeping",
  "Reliability & low maintenance",
  "Age/hours & condition",
  "Longevity & durability",
  "Purchase price / value",
  "Comfort & accommodations",
  "Performance & handling",
  "Fuel efficiency",
  "Resale value",
  "Layout & space for passengers",
  "Trailerability / storage ease",
];

const MUST_HAVE_CHIPS = [
  "Enclosed head", "Trailerable", "Single outboard", "Shallow-water access",
  "Swim platform", "Cabin / sleeping", "Protected helm", "Bimini or top",
  "Fishing cockpit", "Easy boarding",
];
const PREFERENCE_CHIPS = [
  "Wakeboard tower", "White hull", "Premium sound", "Twin engines",
  "Hardtop", "Live well", "Heater / AC", "Radar",
  "Freshwater shower", "Bow seating",
];
const UNACCEPTABLE_CHIPS = [
  "No inboards", "No outdrives", "No project boats", "No wood hull",
  "No salvage title", "No rebuilds", "No single-engine offshore", "No gas engines",
];

function togglePhrase(text, phrase) {
  const items = (text || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const idx = items.findIndex((s) => s.toLowerCase() === phrase.toLowerCase());
  if (idx >= 0) items.splice(idx, 1);
  else items.push(phrase);
  return items.join(", ");
}

function ChipRow({ chips, value, onToggle }) {
  return (
    <div className="flex flex-wrap gap-2">
      {chips.map((c) => {
        const active = (value || "")
          .split(",")
          .map((s) => s.trim().toLowerCase())
          .includes(c.toLowerCase());
        return (
          <button
            key={c}
            type="button"
            onClick={() => onToggle(c)}
            className={`text-xs rounded-full border px-3 py-1 transition ${
              active ? "border-accent bg-accent/10 text-accent" : "border-border text-muted-foreground hover:border-accent/50"
            }`}
          >
            {c}
          </button>
        );
      })}
    </div>
  );
}

function OptionCard({ option, selected, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`text-left rounded-lg border p-3 transition ${
        selected ? "border-accent bg-accent/10" : "border-border hover:border-accent/50"
      }`}
    >
      <span className="flex items-center justify-between">
        <span className="text-sm font-medium">{option.label}</span>
        {selected && <Check className="w-4 h-4 text-accent" />}
      </span>
    </button>
  );
}

export default function IntroQuestionnaire({ onComplete, initialProfile, plan = "free", fieldTiers = null, saving = false, submitLabel = "Save & Update My Matches" }) {
  const [step, setStep] = useState(0);
  const questionSets = [
    { id: "free", label: "Deckhand · Free", detail: "Basic buyer profile" },
    { id: "match_plus", label: "Bosun · $9", detail: "Activity priorities, passengers and past boats" },
    { id: "refined_match", label: "First Mate · $29", detail: "Physical limits, family needs and deal-breakers" },
    { id: "market_match", label: "Captain · $99", detail: "Ownership horizon, annual budget and ranked priorities" },
  ];
  const [questionTier, setQuestionTier] = useState(() => {
    const requested = new URLSearchParams(window.location.search).get("tier");
    return questionSets.some(t => t.id === requested) ? requested : normalizePlan(plan);
  });
  const [data, setData] = useState(() => {
    const base = {
      buyer_role: "buyer",
      vessel_class: "",
      boat_size_range: "",
      operating_area: "",
      activities: [],
      experience_level: "",
      previously_owned_boats: "",
      passenger_count: 2,
      occasional_passenger_count: "",
      family_use: "",
      overnight_requirements: "",
      storage: "",
      storage_capacity: "",
      hard_max_overall_length_ft: "",
      hard_max_beam_ft: "",
      hard_max_height_ft: "",
      hard_max_storage_weight_lb: "",
      hard_max_draft_ft: "",
      tow_capacity_lb: "",
      draft: "",
      towing: "",
      purchase_budget_min: 0,
      purchase_budget_max: 100000,
      annual_ownership_budget: "",
      open_to_project_boats: false,
      ownership_timeframe: "",
      ownership_horizon: "",
      must_haves: "",
      preferences: "",
      unacceptable_compromises: "",
      priorities: PRIORITIES,
      activity_weights: {},
      preferred_manufacturers: [],
    };
    if (initialProfile) {
      return {
        ...base,
        buyer_role: initialProfile.buyer_role || base.buyer_role,
        vessel_class: initialProfile.vessel_class || "",
        boat_size_range: initialProfile.boat_size_range || "",
        operating_area: initialProfile.operating_area || "",
        activities: Array.isArray(initialProfile.activities) ? initialProfile.activities : [],
        experience_level: initialProfile.experience_level || "",
        previously_owned_boats: initialProfile.previously_owned_boats || "",
        passenger_count: initialProfile.passenger_count ?? 2,
        occasional_passenger_count: initialProfile.occasional_passenger_count ?? "",
        family_use: initialProfile.family_use || "",
        overnight_requirements: initialProfile.overnight_requirements || "",
        storage: initialProfile.storage || "",
        storage_capacity: initialProfile.storage_capacity || "",
        hard_max_overall_length_ft: initialProfile.hard_max_overall_length_ft || "",
        hard_max_beam_ft: initialProfile.hard_max_beam_ft || "",
        hard_max_height_ft: initialProfile.hard_max_height_ft || "",
        hard_max_storage_weight_lb: initialProfile.hard_max_storage_weight_lb || "",
        hard_max_draft_ft: initialProfile.hard_max_draft_ft || "",
        tow_capacity_lb: initialProfile.tow_capacity_lb || "",
        draft: initialProfile.draft || "",
        towing: initialProfile.towing || "",
        purchase_budget_min: initialProfile.purchase_budget_min ?? 0,
        purchase_budget_max: initialProfile.purchase_budget_max ?? 100000,
        annual_ownership_budget: initialProfile.annual_ownership_budget ?? "",
        open_to_project_boats: initialProfile.open_to_project_boats ?? false,
        ownership_timeframe: initialProfile.ownership_timeframe || "",
        ownership_horizon: initialProfile.ownership_horizon || "",
        must_haves: initialProfile.must_haves || "",
        preferences: initialProfile.preferences || "",
        unacceptable_compromises: initialProfile.unacceptable_compromises || "",
        priorities: Array.isArray(initialProfile.priorities) && initialProfile.priorities.length ? initialProfile.priorities : PRIORITIES,
        activity_weights: (initialProfile.activity_weights && typeof initialProfile.activity_weights === "object") ? initialProfile.activity_weights : {},
        preferred_manufacturers: Array.isArray(initialProfile.preferred_manufacturers) ? initialProfile.preferred_manufacturers : [],
      };
    }
    return base;
  });

  const set = (key, value) => setData((d) => ({ ...d, [key]: value }));
  const toggle = (key, value) =>
    setData((d) => ({
      ...d,
      [key]: d[key].includes(value) ? d[key].filter((v) => v !== value) : [...d[key], value],
    }));

  // A field is locked when the buyer's current tier hasn't unlocked it.
  // normalizePlan maps legacy values (initial_boat_match → match_plus, etc.).
  const np = questionTier;
  const isLocked = (key) => {
    if (np === "market_match") return false;
    const tier = (fieldTiers || FIELD_TIERS)[key];
    if (!tier || tier === "free") return false;
    if (np === "match_plus") return tier === "refined_match" || tier === "market_match";
    if (np === "refined_match") return tier === "market_match";
    // free: lock all paid-tier fields
    return true;
  };
  // Hide fields the buyer's current tier hasn't unlocked — they'll be prompted to
  // answer them after upgrading, when they're sent back here to complete the new tier.
  const gate = (key, node) => (isLocked(key) ? null : node);

  const toggleActivity = (value) => {
    setData(d => {
      const { activities, weights } = toggleActivityWeightSelection(
        d.activities, d.activity_weights, value,
      );
      return { ...d, activities, activity_weights: weights };
    });
  };

  const ALL_STEPS = [
    { title: "Who's filling this out?", key: "buyer_role", type: "single", options: ROLES, fields: ["buyer_role"] },
    { title: "What kind of boat are you after?", key: "vessel_class", type: "vessel_size", fields: ["vessel_class", "boat_size_range"] },
    { title: "Where will you boat, and what will you do?", key: "area_activities", type: "compound", fields: ["operating_area", "activities", "activity_weights"] },
    { title: "What's your boating experience?", key: "experience", type: "compound2", fields: ["experience_level", "previously_owned_boats"] },
    { title: "Who's on board?", key: "passengers", type: "compound3", fields: ["passenger_count", "family_use", "overnight_requirements"] },
    { title: "Where will you keep the boat?", key: "storage", type: "compound4", fields: ["storage", "storage_capacity", "draft", "towing"] },
    { title: "What's your budget?", key: "budget", type: "compound5", fields: ["purchase_budget_max", "purchase_budget_min", "annual_ownership_budget", "open_to_project_boats"] },
    { title: "What's your buying timeline?", key: "ownership_timeframe", type: "single", options: TIMELINES, fields: ["ownership_timeframe"] },
    { title: "Looking ahead", key: "ownership_horizon", type: "single", options: HORIZONS, fields: ["ownership_horizon"] },
    { title: "What matters to you?", key: "needs", type: "needs", fields: ["must_haves", "preferences", "unacceptable_compromises"] },
    { title: "What's most important", key: "priorities", type: "priorities", fields: ["priorities"] },
    { title: "Any brands you keep high on your list?", key: "preferred_manufacturers", type: "brands", fields: ["preferred_manufacturers"] },
  ];
  // Only show steps with at least one field the buyer's tier has unlocked.
  const steps = ALL_STEPS.filter((s) => s.fields.some((f) => !isLocked(f)));

  const current = steps[step];
  const isLast = step === steps.length - 1;

  const canNext = () => {
    const ok = (key, cond) => (isLocked(key) ? true : cond);
    switch (current.key) {
      case "buyer_role": return ok("buyer_role", !!data.buyer_role);
      case "vessel_class": return ok("vessel_class", !!data.vessel_class) && ok("boat_size_range", !!data.boat_size_range);
      case "area_activities": return ok("operating_area", !!data.operating_area) && ok("activities", data.activities.length > 0);
      case "experience": return ok("experience_level", !!data.experience_level);
      case "passengers": return ok("passenger_count", Number(data.passenger_count) > 0);
      case "storage": return ok("storage", !!data.storage);
      case "budget": return ok("purchase_budget_max", Number(data.purchase_budget_max) > 0 && Number(data.purchase_budget_max) >= Number(data.purchase_budget_min));
      case "ownership_timeframe": return ok("ownership_timeframe", !!data.ownership_timeframe);
      case "ownership_horizon": return ok("ownership_horizon", !!data.ownership_horizon);
      default: return true;
    }
  };

  const finish = () => {
    onComplete({
      match_question_tier: questionTier,
      buyer_role: data.buyer_role,
      vessel_class: data.vessel_class || "private",
      boat_size_range: data.boat_size_range,
      operating_area: data.operating_area,
      activities: data.activities,
      experience_level: data.experience_level,
      previously_owned_boats: data.previously_owned_boats,
      passenger_count: Number(data.passenger_count) || 0,
      occasional_passenger_count: data.occasional_passenger_count ? Number(data.occasional_passenger_count) : null,
      family_use: data.family_use,
      overnight_requirements: data.overnight_requirements,
      storage: data.storage,
      storage_capacity: data.storage_capacity,
      hard_max_overall_length_ft: data.hard_max_overall_length_ft ? Number(data.hard_max_overall_length_ft) : null,
      hard_max_beam_ft: data.hard_max_beam_ft ? Number(data.hard_max_beam_ft) : null,
      hard_max_height_ft: data.hard_max_height_ft ? Number(data.hard_max_height_ft) : null,
      hard_max_storage_weight_lb: data.hard_max_storage_weight_lb ? Number(data.hard_max_storage_weight_lb) : null,
      hard_max_draft_ft: data.hard_max_draft_ft ? Number(data.hard_max_draft_ft) : null,
      tow_capacity_lb: data.tow_capacity_lb ? Number(data.tow_capacity_lb) : null,
      draft: data.draft,
      towing: data.towing,
      purchase_budget_min: Number(data.purchase_budget_min) || null,
      purchase_budget_max: Number(data.purchase_budget_max) || null,
      annual_ownership_budget: data.annual_ownership_budget ? Number(data.annual_ownership_budget) : null,
      open_to_project_boats: data.open_to_project_boats ?? false,
      ownership_timeframe: data.ownership_timeframe,
      ownership_horizon: data.ownership_horizon,
      must_haves: data.must_haves,
      preferences: data.preferences,
      unacceptable_compromises: data.unacceptable_compromises,
      priorities: data.priorities,
      activity_weights: apportionActivityWeights(data.activities, data.activity_weights),
      preferred_manufacturers: data.preferred_manufacturers,
      status: "active",
    });
  };

  return (
    <Card>
      <CardContent className="p-6">
        <fieldset disabled={saving} className="mb-6">
          <legend className="font-semibold mb-2">Buyer profile question sets</legend>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {questionSets.map(tier => (
              <Button key={tier.id} type="button" variant={questionTier === tier.id ? "default" : "outline"}
                aria-pressed={questionTier === tier.id}
                onClick={() => { setQuestionTier(tier.id); setStep(0); }}>{tier.label}</Button>
            ))}
          </div>
          <p className="text-sm mt-2">{questionSets.find(t => t.id === questionTier)?.detail}. Includes earlier question sets; switching keeps your answers.</p>
          <p className="text-xs text-muted-foreground mt-1">All four question sets can be previewed. Saving answers does not unlock a paid package; model generation requires an active package or admin test access. More detail may reinforce the same boats rather than change them.</p>
        </fieldset>
        <div className="flex items-center gap-2 mb-6">
          <div className="h-1.5 flex-1 rounded-full bg-muted overflow-hidden">
            <div className="h-full bg-accent transition-all" style={{ width: `${((step + 1) / steps.length) * 100}%` }} />
          </div>
          <span className="text-xs text-muted-foreground whitespace-nowrap">{step + 1} / {steps.length}</span>
        </div>

        <h2 className="font-heading text-xl font-semibold mb-4">{current.title}</h2>

        {current.type === "single" && (
          <div className="grid sm:grid-cols-2 gap-2">
            {current.options.map((o) => (
              <OptionCard key={o.value} option={o} selected={data[current.key] === o.value} onClick={() => set(current.key, o.value)} />
            ))}
          </div>
        )}

        {current.type === "vessel_size" && (
          <div className="space-y-4">
            {gate("vessel_class",
              <div>
                <Label>Vessel class</Label>
                <div className="grid sm:grid-cols-1 gap-2 mt-1">
                  {VESSEL_CLASSES.map((o) => (
                    <OptionCard key={o.value} option={o} selected={data.vessel_class === o.value} onClick={() => set("vessel_class", o.value)} />
                  ))}
                </div>
              </div>
            )}
            {gate("boat_size_range",
              <div>
                <Label>What size range are you pursuing?</Label>
                <div className="grid sm:grid-cols-2 gap-2 mt-1">
                  {SIZE_RANGES.map((o) => (
                    <OptionCard key={o.value} option={o} selected={data.boat_size_range === o.value} onClick={() => set("boat_size_range", o.value)} />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {current.type === "compound" && (
          <div className="space-y-4">
            {gate("operating_area",
              <div>
                <Label htmlFor="area">Operating area (waterway, lake, coast, region)</Label>
                <Input id="area" placeholder="e.g. Chesapeake Bay, Lake Tahoe, Florida ICW" value={data.operating_area} onChange={(e) => set("operating_area", e.target.value)} />
              </div>
            )}
            {gate("activities",
              <div>
                <Label>Intended activities</Label>
                <div className="grid sm:grid-cols-2 gap-2 mt-1">
                  {ACTIVITIES.map((a) => (
                    <OptionCard key={a} option={{ value: a, label: a }} selected={data.activities.includes(a)} onClick={() => toggleActivity(a)} />
                  ))}
                </div>
              </div>
            )}
            {/* Capture activity priorities during Discovery too; paid Match keeps its existing tier-aware use of these saved answers. */}
            {data.activities.length >= 1 && (
              <ActivityWeightPie
                activities={data.activities}
                weights={data.activity_weights}
                onChange={(w) => set("activity_weights", w)}
              />
            )}
          </div>
        )}

        {current.type === "compound2" && (
          <div className="space-y-4">
            {gate("experience_level",
              <div>
                <Label>Experience level</Label>
                <div className="grid sm:grid-cols-2 gap-2 mt-1">
                  {EXPERIENCE.map((o) => (
                    <OptionCard key={o.value} option={o} selected={data.experience_level === o.value} onClick={() => set("experience_level", o.value)} />
                  ))}
                </div>
              </div>
            )}
            {gate("previously_owned_boats",
              <div>
                <Label htmlFor="prev">Boats previously or currently owned</Label>
                <Input id="prev" placeholder="e.g. 2015 Boston Whaler 21 Montauk" value={data.previously_owned_boats} onChange={(e) => set("previously_owned_boats", e.target.value)} />
              </div>
            )}
          </div>
        )}

        {current.type === "compound3" && (
          <div className="space-y-4">
            {gate("passenger_count",
              <div className="max-w-xs">
                <Label htmlFor="pax">People aboard</Label>
                <p className="text-xs text-muted-foreground mb-2">How many people are normally aboard?</p>
                <Input id="pax" type="number" min={1} value={data.passenger_count} onChange={(e) => set("passenger_count", e.target.value)} />
                <p className="text-xs text-muted-foreground mt-3 mb-2">Occasionally carry more? Enter the largest group you realistically expect. Leave blank if your normal group is also your maximum.</p>
                <Input type="number" min={1} placeholder="Occasional maximum (optional)" value={data.occasional_passenger_count} onChange={(e) => set("occasional_passenger_count", e.target.value)} />
              </div>
            )}
            {gate("family_use",
              <div>
                <Label htmlFor="fam">How will the boat need to work for you?</Label>
                <Input id="fam" placeholder="e.g. kids and guests, fishing, entertaining, easy boarding" value={data.family_use} onChange={(e) => set("family_use", e.target.value)} />
              </div>
            )}
            {gate("overnight_requirements",
              <div>
                <Label htmlFor="overnight">Overnight accommodations</Label>
                <Input id="overnight" placeholder="e.g. need to sleep 4; separate guest berth; off-grid A/C needed" value={data.overnight_requirements} onChange={(e) => set("overnight_requirements", e.target.value)} />
              </div>
            )}
          </div>
        )}

        {current.type === "compound4" && (
          <div className="space-y-4">
            {gate("storage",
              <div>
                <Label>Storage / keeping the boat</Label>
                <div className="grid sm:grid-cols-2 gap-2 mt-1">
                  {STORAGE.map((o) => (
                    <OptionCard key={o.value} option={o} selected={data.storage === o.value} onClick={() => set("storage", o.value)} />
                  ))}
                </div>
              </div>
            )}
            {["marina_slip", "dry_stack", "rack_storage", "lift_kept", "private_dock"].includes(data.storage) && !isLocked("storage_capacity") && (
              <div>
                <Label>Does your storage location or setup impose any absolute limits?</Label>
                <p className="text-xs text-muted-foreground mb-2">Only enter limits the boat cannot exceed — such as a marina rule, slip, lift, rack, garage, bridge, or access restriction. Leave anything that is only a preference blank.</p>
                <div className="grid sm:grid-cols-2 gap-2">
                  <Input type="number" min={0} step="0.1" placeholder="Max overall length (ft)" value={data.hard_max_overall_length_ft} onChange={(e) => set("hard_max_overall_length_ft", e.target.value)} />
                  <Input type="number" min={0} step="0.1" placeholder="Max beam (ft)" value={data.hard_max_beam_ft} onChange={(e) => set("hard_max_beam_ft", e.target.value)} />
                  <Input type="number" min={0} step="0.1" placeholder="Max height (ft), if applicable" value={data.hard_max_height_ft} onChange={(e) => set("hard_max_height_ft", e.target.value)} />
                  <Input type="number" min={0} step="100" placeholder="Max supported weight (lb)" value={data.hard_max_storage_weight_lb} onChange={(e) => set("hard_max_storage_weight_lb", e.target.value)} />
                </div>
                <Input className="mt-2" id="storage_capacity" placeholder="Other facility or storage restrictions (optional)" value={data.storage_capacity} onChange={(e) => set("storage_capacity", e.target.value)} />
              </div>
            )}
            {gate("draft",
              <div>
                <Label htmlFor="draft">Draft restrictions, if any</Label>
                <Input id="draft" placeholder="Optional notes about your maximum acceptable vessel draft" value={data.draft} onChange={(e) => set("draft", e.target.value)} />
                <Label className="block mt-2" htmlFor="hard_max_draft_ft">Maximum acceptable vessel draft (ft)</Label>
                <Input id="hard_max_draft_ft" aria-describedby="draft-help" className="mt-2" type="number" min={0} step="0.1" placeholder="e.g. 2.5" value={data.hard_max_draft_ft} onChange={(e) => set("hard_max_draft_ft", e.target.value)} />
                <p id="draft-help" className="text-xs text-muted-foreground mt-2">Optional: enter the deepest vessel draft you can accept, in feet, not the water depth. Leave blank if you have no known restriction.</p>
              </div>
            )}
            {data.storage === "trailer" && !isLocked("towing") && (
              <div>
                <Label htmlFor="towing">Transport / towing</Label>
                <p className="text-xs text-muted-foreground mb-2">Will you use a personal vehicle to transport or launch the boat? Enter the vehicle or tow rating if it limits you, and note if buying/upgrading a tow vehicle would affect your boat budget.</p>
                <label className="flex items-center gap-2 mt-1 mb-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={data.towing === "none"}
                    onChange={(e) => set("towing", e.target.checked ? "none" : "")}
                    className="w-4 h-4 rounded border-border accent-accent"
                  />
                  <span className="text-sm text-muted-foreground">No issues concerning transport or towing</span>
                </label>
                <Input
                  id="towing"
                  placeholder="e.g. vehicle upgrade would affect my boat budget"
                  value={data.towing === "none" ? "" : data.towing}
                  disabled={data.towing === "none"}
                  onChange={(e) => set("towing", e.target.value)}
                />
                {data.towing !== "none" && (
                  <Input className="mt-2" type="number" min={0} step="100" placeholder="Vehicle tow rating (lb), if it is a hard limit" value={data.tow_capacity_lb} onChange={(e) => set("tow_capacity_lb", e.target.value)} />
                )}
              </div>
            )}
          </div>
        )}

        {current.type === "compound5" && (
          <div className="space-y-6">
            {gate("purchase_budget_max",
              isLocked("purchase_budget_min") ? (
                <div>
                  <Label>Maximum purchase budget</Label>
                  <p className="text-xs text-muted-foreground mb-4">What's the most you'd spend on the right boat?</p>
                  <div className="max-w-xs">
                    <Input
                      type="number"
                      min={0}
                      step={5000}
                      placeholder="e.g. 50000"
                      value={data.purchase_budget_max}
                      onChange={(e) => set("purchase_budget_max", e.target.value)}
                    />
                  </div>
                </div>
              ) : (
                <div>
                  <Label>Purchase budget range</Label>
                  <p className="text-xs text-muted-foreground mb-4">Drag the handles to set your minimum and maximum purchase price.</p>
                  <PriceRangeSlider
                    min={0}
                    max={20000000}
                    step={5000}
                    value={[Number(data.purchase_budget_min) || 0, Number(data.purchase_budget_max) || 100000]}
                    onChange={(lo, hi) => {
                      setData((d) => ({ ...d, purchase_budget_min: lo, purchase_budget_max: hi }));
                    }}
                  />
                </div>
              )
            )}
            {gate("annual_ownership_budget",
              <div className="max-w-xs">
                <Label htmlFor="annual">Annual budget ($/year)</Label>
                <Input id="annual" type="number" min={0} placeholder="e.g. 8000" value={data.annual_ownership_budget} onChange={(e) => set("annual_ownership_budget", e.target.value)} />
              </div>
            )}
            {gate("open_to_project_boats",
              <div>
                <Label>Open to project boats?</Label>
                <p className="text-xs text-muted-foreground mb-2">Project boats are fixer-uppers that cost less but need work — repairs, refit, or restoration. Most buyers want turnkey boats, so this defaults to no.</p>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => set("open_to_project_boats", false)}
                    className={`text-sm rounded-lg border px-4 py-2 transition ${data.open_to_project_boats === false ? "border-accent bg-accent/10 text-accent" : "border-border text-muted-foreground hover:border-accent/50"}`}
                  >
                    No — turnkey only
                  </button>
                  <button
                    type="button"
                    onClick={() => set("open_to_project_boats", true)}
                    className={`text-sm rounded-lg border px-4 py-2 transition ${data.open_to_project_boats === true ? "border-accent bg-accent/10 text-accent" : "border-border text-muted-foreground hover:border-accent/50"}`}
                  >
                    Yes — open to project boats
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {current.type === "needs" && (
          <div className="space-y-5">
            <p className="text-sm text-muted-foreground rounded-md border bg-muted/30 p-3">MATCH evaluates boat models and layouts—not a particular boat for sale. Equipment, engine hours, maintenance history, and condition are checked during listing review. You can still enter listing-specific requirements below, but they do not establish what is factory-standard on a model.</p>
            {gate("must_haves",
              <PriorityList
                label="Must-haves"
                hint="Choose model capabilities you require, then rank them. Optional equipment can be checked on individual boats later."
                chips={MUST_HAVE_CHIPS}
                value={data.must_haves}
                onChange={(v) => set("must_haves", v)}
                placeholder="Type a must-have and press Enter"
              />
            )}
            {gate("preferences",
              <PriorityList
                label="Preferences (nice-to-haves)"
                hint="Tap quick picks or type your own, then rank them — most important first."
                chips={PREFERENCE_CHIPS}
                value={data.preferences}
                onChange={(v) => set("preferences", v)}
                placeholder="Type a preference and press Enter"
              />
            )}
            {gate("unacceptable_compromises",
              <div>
                <Label htmlFor="no">Deal-breakers</Label>
                <p className="text-xs text-muted-foreground mb-2">Tap any that apply — or type your own below.</p>
                <ChipRow chips={UNACCEPTABLE_CHIPS} value={data.unacceptable_compromises} onToggle={(c) => set("unacceptable_compromises", togglePhrase(data.unacceptable_compromises, c))} />
                <Textarea id="no" className="mt-2" placeholder="e.g. no inboards, no project boats, no wood hull" value={data.unacceptable_compromises} onChange={(e) => set("unacceptable_compromises", e.target.value)} />
              </div>
            )}
          </div>
        )}

        {current.type === "priorities" && (
          <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Drag to reorder — or use the arrows. The top of the list is your highest priority. Remove anything you don't care about.
              </p>
              <DragDropContext onDragEnd={(result) => {
                if (!result.destination || result.destination.index === result.source.index) return;
                setData((d) => {
                  const arr = [...d.priorities];
                  const [moved] = arr.splice(result.source.index, 1);
                  arr.splice(result.destination.index, 0, moved);
                  return { ...d, priorities: arr };
                });
              }}>
                <Droppable droppableId="priorities">
                  {(provided) => (
                    <ol className="space-y-2" ref={provided.innerRef} {...provided.droppableProps}>
                      {data.priorities.map((p, i) => (
                        <Draggable key={p} draggableId={p} index={i}>
                          {(dragProvided, snapshot) => (
                            <li
                              ref={dragProvided.innerRef}
                              {...dragProvided.draggableProps}
                              className={`flex items-center gap-3 rounded-lg border border-border bg-card p-3 transition ${
                                snapshot.isDragging ? "shadow-md border-accent/40" : ""
                              }`}
                            >
                              <span {...dragProvided.dragHandleProps} className="cursor-grab active:cursor-grabbing text-muted-foreground/40 hover:text-muted-foreground touch-none">
                                <GripVertical className="w-4 h-4" />
                              </span>
                              <span className="grid place-items-center w-7 h-7 rounded-full bg-accent/10 text-accent text-sm font-semibold shrink-0">
                                {i + 1}
                              </span>
                              <span className="flex-1 text-sm font-medium">{p}</span>
                              <div className="flex flex-col gap-1">
                                <button
                                  type="button"
                                  disabled={i === 0}
                                  onClick={() =>
                                    setData((d) => {
                                      const arr = [...d.priorities];
                                      [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]];
                                      return { ...d, priorities: arr };
                                    })
                                  }
                                  className="text-muted-foreground hover:text-accent disabled:opacity-30"
                                  aria-label={`Move ${p} up`}
                                >
                                  <ArrowUp className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  disabled={i === data.priorities.length - 1}
                                  onClick={() =>
                                    setData((d) => {
                                      const arr = [...d.priorities];
                                      [arr[i + 1], arr[i]] = [arr[i], arr[i + 1]];
                                      return { ...d, priorities: arr };
                                    })
                                  }
                                  className="text-muted-foreground hover:text-accent disabled:opacity-30"
                                  aria-label={`Move ${p} down`}
                                >
                                  <ArrowDown className="w-4 h-4" />
                                </button>
                              </div>
                              <button
                                type="button"
                                onClick={() =>
                                  setData((d) => ({ ...d, priorities: d.priorities.filter((_, idx) => idx !== i) }))
                                }
                                className="text-muted-foreground hover:text-destructive p-1"
                                aria-label={`Remove ${p}`}
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </li>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </ol>
                  )}
                </Droppable>
              </DragDropContext>
            </div>
        )}

        {current.type === "brands" && (
          <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Add any brands you already favor. We'll weight them higher when they genuinely fit
                your needs — we won't force a poor match just because you like the name.
              </p>
              <ManufacturerPicker
                value={data.preferred_manufacturers}
                onChange={(v) => set("preferred_manufacturers", v)}
              />
              <p className="text-xs text-muted-foreground">Optional — skip if you're open to any brand.</p>
            </div>
        )}

        <div className="flex items-center gap-3 mt-8">
          <Button variant="ghost" disabled={step === 0} onClick={() => setStep((s) => s - 1)}>
            <ChevronLeft className="w-4 h-4 mr-1" /> Back
          </Button>
          {initialProfile && (
            <input
              type="range"
              min={0}
              max={steps.length - 1}
              value={step}
              onChange={(e) => setStep(Number(e.target.value))}
              className="flex-1 accent-accent"
              aria-label="Jump to section"
              title="Drag to jump to any section"
            />
          )}
          {isLast ? (
            <Button onClick={finish} disabled={saving || !canNext()}>
              {saving ? "Saving and preparing results…" : submitLabel} <Check className="w-4 h-4 ml-1" />
            </Button>
          ) : (
            <Button onClick={() => setStep((s) => s + 1)} disabled={!canNext()}>
              Next <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          )}
        </div>

        <p className="text-xs text-muted-foreground mt-4">
          Current version supports recreational and coastal powerboats up to 65 ft. Future versions will expand coverage to vessels 65 ft and over.
        </p>
      </CardContent>
    </Card>
  );
}