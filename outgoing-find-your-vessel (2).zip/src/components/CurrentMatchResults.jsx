import React,{useEffect,useState,useRef} from "react";
import {Link} from "react-router-dom";
import {base44} from "@/api/base44Client";
import {Button} from "@/components/ui/button";
import {ownerRecords,chooseMatchCandidate} from "@/lib/matchCompareHandoff";
import {profileInputFingerprint} from "../../base44/shared/profile-input-fingerprint.mjs";
import {currentMatchResults} from "@/lib/currentMatchResults";
import {safeResultUrl} from "@/lib/matchResultLink";

export default function CurrentMatchResults(){
 const [state,setState]=useState({results:[],status:"loading",userId:""}),[error,setError]=useState(""),[busy,setBusy]=useState(null),[notice,setNotice]=useState("");
 useEffect(()=>{let active=true;(async()=>{try{
  const me=await base44.auth.me();
  const [profiles,rows]=await Promise.all([base44.entities.BuyerProfile.filter({created_by_id:me.id},"-created_date",1),ownerRecords(base44.entities.SuggestedBoat,me.id)]);
  const fingerprint=profiles[0]?await profileInputFingerprint(profiles[0]):null;
  if(active)setState({...currentMatchResults(rows,profiles[0]||null,me.id,fingerprint),userId:me.id});
 }catch{if(active)setError("Saved Match results could not be loaded.");}})();return()=>{active=false;};},[]);
 const choosingRef=useRef(false);
 const save=async boat=>{if(choosingRef.current)return;choosingRef.current=true;setBusy(boat.id);setNotice("");try{const result=await chooseMatchCandidate(base44,boat,state.userId);window.dispatchEvent(new Event("soundheading-candidates-changed"));setNotice(result.selected?"Saved to Compare. Use Find inside Match to look for boats for sale.":"Saved for later. Three models are already selected; change your shortlist below.");}catch{setNotice("Could not confirm the choice. Your saved candidates remain available; retry.");}finally{choosingRef.current=false;setBusy(null);}};

 return <section aria-label="Top saved Match results" className="space-y-3">
  <div><h2 className="text-xl font-heading">Your top Match results</h2><p className="text-sm text-muted-foreground">Choose your favorite models, then compare the research already in SoundHeading.</p></div>
  {error?<p role="alert">{error} <Link className="underline" to="/match">Open Match</Link></p>:state.status==="loading"?<p role="status">Loading saved Match results…</p>:!state.results.length?<div className="rounded-xl border bg-white p-5"><p>No saved results are available for your current profile.</p><Button asChild variant="outline" className="min-h-11 mt-3"><Link to="/match">Get Match results</Link></Button></div>:<>
   {state.status==="legacy_pool"&&<p className="text-xs text-muted-foreground">These are your active saved results. Older results do not record an exact profile link.</p>}
   {state.status==="saved_before_profile_update"&&<p className="text-xs text-muted-foreground">Saved before your latest profile change; these results may need updating.</p>}
   <ul className="divide-y rounded-xl border bg-white">{state.results.map(boat=>{const href=safeResultUrl(boat.link);return <li key={boat.id} className="grid grid-cols-[auto_minmax(0,1fr)] sm:grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 px-3 py-3">
    <span className="shrink-0 text-sm font-semibold text-muted-foreground" aria-label={"Match rank "+boat.rank}>• {boat.rank}</span>
    <div className="min-w-0 flex-1">{href?<a className="font-medium underline break-words" href={href} target="_blank" rel="noopener noreferrer">{boat.title||[boat.make,boat.model,boat.year].filter(Boolean).join(" ")}</a>:<><span className="font-medium">{boat.title||[boat.make,boat.model,boat.year].filter(Boolean).join(" ")}</span><span className="block text-xs text-muted-foreground">Original link unavailable</span></>}</div>
    <div className="col-start-2 sm:col-start-auto flex shrink-0 gap-2">{href?<Button asChild variant="outline" size="sm" className="min-h-11"><a href={href} target="_blank" rel="noopener noreferrer">{/^https?:\/\/(www\.)?google\.[^/]+\/search(?:[?/#]|$)/i.test(href)?"Optional model search":"Open Match research"}</a></Button>:<Button variant="outline" size="sm" className="min-h-11" disabled>Search unavailable</Button>}<Button variant="outline" size="sm" className="min-h-11 px-2" disabled={busy!==null} onClick={()=>save(boat)} aria-label={"Save to Compare: "+boat.title}>{busy===boat.id?"Saving…":"Save to Compare"}</Button></div>
   </li>})}</ul>
  </>}
  {notice&&<p role="status" className="text-sm">{notice}</p>}
 </section>;
}
