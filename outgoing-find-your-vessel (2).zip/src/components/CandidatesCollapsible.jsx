import React, { useId, useState } from "react";
import { Button } from "@/components/ui/button";
import { Ship, ChevronDown, ChevronUp, Sparkles } from "lucide-react";
import SavedBoatForm from "@/components/SavedBoatForm";
import SavedBoatItem from "@/components/SavedBoatItem";

// Collapsible "add a boat you're considering" section rendered under the
// recommendations so saving candidates is an option, not a required step.
export default function CandidatesCollapsible({ boats = [], onAdd, onRemove, onUpdate, maxBoats = 5, minBoats = 3, onAnalyze, prefill }) {
  const [open, setOpen] = useState(false);
  const panelId = useId();
  return (
    <div className="mt-6 pt-5 border-t border-border">
      <button
        type="button"
        aria-expanded={open}
        aria-controls={panelId}
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
      >
        <Ship className="w-4 h-4" />
        {boats.length > 0 ? `Your saved candidates (${boats.length}/${maxBoats})` : "Add a boat you’re considering"}
        {open ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
      </button>
      {open && (
        <div id={panelId} className="mt-4 space-y-4">
          <p className="text-xs text-muted-foreground">
            List boats you have in mind — by name, model, or however you'd describe them. Add a listing link if you have one, and a note on what you like.
          </p>
          <SavedBoatForm onAdd={onAdd} disabled={boats.length >= maxBoats} availableSlots={Math.max(0, maxBoats - boats.length)} max={maxBoats} prefill={prefill} />
          {boats.length > 0 && (
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-3">
                <Button variant="outline" size="sm" onClick={onAnalyze} disabled={boats.length < minBoats}>
                  <Sparkles className="w-3.5 h-3.5 mr-1.5" /> Analyze my candidates
                </Button>
                {boats.length < minBoats && (
                  <p className="text-xs text-muted-foreground">Save at least {minBoats} to analyze ({boats.length}/{minBoats}).</p>
                )}
              </div>
              <div className="divide-y">
                {boats.map((b) => (
                  <SavedBoatItem key={b.id} boat={b} onRemove={onRemove} onUpdate={onUpdate} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}