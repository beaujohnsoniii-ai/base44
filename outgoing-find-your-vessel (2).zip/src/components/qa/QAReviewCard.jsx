import React, { useState, useEffect } from "react";
import { base44Test } from "@/lib/base44TestClient";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronDown, ChevronUp, ThumbsUp, ArrowUpDown, XCircle, Search, Brain, HelpCircle, ExternalLink } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const TIER_LABELS = {
  free: "Deckhand",
  match_plus: "Bosun ($9)",
  refined_match: "First Mate ($29)",
  market_match: "Captain ($99)",
};

const CONCERN_COLORS = {
  green: "bg-green-100 text-green-800 border-green-300",
  yellow: "bg-amber-100 text-amber-800 border-amber-300",
  red: "bg-red-100 text-red-800 border-red-300",
  uncertain: "bg-blue-100 text-blue-800 border-blue-300",
  not_evaluated: "bg-muted text-muted-foreground border-border",
};

const VERDICTS = [
  { value: "good", label: "GOOD", icon: ThumbsUp, color: "bg-green-600 hover:bg-green-700" },
  { value: "ranking_wrong", label: "RANKING WRONG", icon: ArrowUpDown, color: "bg-amber-600 hover:bg-amber-700" },
  { value: "bad_recommendation", label: "BAD RECOMMENDATION", icon: XCircle, color: "bg-red-600 hover:bg-red-700" },
  { value: "missing_better_boat", label: "MISSING BETTER BOAT", icon: Search, color: "bg-blue-600 hover:bg-blue-700" },
  { value: "bad_reasoning", label: "BAD REASONING", icon: Brain, color: "bg-orange-600 hover:bg-orange-700" },
  { value: "other", label: "OTHER", icon: HelpCircle, color: "bg-gray-600 hover:bg-gray-700" },
];

export function CompactProfile({ snapshot }) {
  const s = snapshot || {};
  const weights = s.activity_weights || {};
  const topActivities = Object.entries(weights).sort((a, b) => b[1] - a[1]).slice(0, 3);
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-3 gap-y-1 text-xs">
      <div><span className="text-muted-foreground">Size:</span> {s.boat_size_range?.replace(/_/g, " ") || "—"}</div>
      <div><span className="text-muted-foreground">Area:</span> {s.operating_area || "—"}</div>
      <div><span className="text-muted-foreground">Experience:</span> <span className="capitalize">{s.experience_level || "—"}</span></div>
      <div><span className="text-muted-foreground">Budget:</span> ${(s.purchase_budget_min || 0).toLocaleString()}–${(s.purchase_budget_max || 0).toLocaleString()}</div>
      <div><span className="text-muted-foreground">Storage:</span> <span className="capitalize">{s.storage?.replace(/_/g, " ") || "—"}</span></div>
      <div><span className="text-muted-foreground">Overnight:</span> {s.overnight_requirements?.replace(/None.*/, "None") || "—"}</div>
      <div className="col-span-2 sm:col-span-3"><span className="text-muted-foreground">Activities:</span> {topActivities.map(([a, w]) => `${a} ${w}%`).join(", ")}</div>
      <div className="col-span-2 sm:col-span-3"><span className="text-muted-foreground">Priorities:</span> {(s.priorities || []).slice(0, 3).join(", ")}</div>
      {s.preferred_manufacturers?.length > 0 && <div className="col-span-2 sm:col-span-3"><span className="text-muted-foreground">Preferred:</span> {s.preferred_manufacturers.join(", ")}</div>}
    </div>
  );
}

export function SuggestionList({ suggestions, maxShow = 5 }) {
  const [showAll, setShowAll] = useState(false);
  const shown = showAll ? suggestions : suggestions.slice(0, maxShow);
  return (
    <div className="space-y-2">
      {shown.map((s, i) => (
        <div key={i} className="border border-border rounded p-2 bg-muted/30 text-xs space-y-1">
          <div className="flex items-start justify-between gap-2">
            <div>
              <span className="text-muted-foreground tabular-nums">#{s.rank || i + 1}</span>{" "}
              <span className="font-medium">{s.title}</span>
              {Number(s.price_range_min) > 0 && Number(s.price_range_max) >= Number(s.price_range_min)
                ? <span className="text-muted-foreground ml-2">est. ${Number(s.price_range_min).toLocaleString()}–${Number(s.price_range_max).toLocaleString()} (model range)</span>
                : <span className="text-muted-foreground ml-2">model price needs verification</span>}
            </div>
            {s.link && (
              <a href={s.link} target="_blank" rel="noopener noreferrer" className="text-accent hover:underline shrink-0">
                <ExternalLink className="w-3 h-3 inline" />
              </a>
            )}
          </div>
          {s.why_suggested && <p className="leading-relaxed">{s.why_suggested}</p>}
          <div className="flex gap-3 flex-wrap">
            {s.match?.matches?.length > 0 && (
              <div>
                <span className="text-green-700 font-medium">Matches:</span>{" "}
                {s.match.matches.slice(0, 3).join("; ")}
              </div>
            )}
            {s.match?.gaps?.length > 0 && (
              <div>
                <span className="text-amber-700 font-medium">Gaps:</span>{" "}
                {s.match.gaps.slice(0, 3).join("; ")}
              </div>
            )}
          </div>
        </div>
      ))}
      {suggestions.length > maxShow && (
        <button onClick={() => setShowAll(!showAll)} className="text-xs text-accent hover:underline">
          {showAll ? "Show less" : `Show all ${suggestions.length}`}
        </button>
      )}
    </div>
  );
}

export default function QAReviewCard({ tierResult, existingGrade, onSaved }) {
  const { toast } = useToast();
  const [expanded, setExpanded] = useState(false);
  const [prevTier, setPrevTier] = useState(null);
  const [loadingPrev, setLoadingPrev] = useState(false);
  const [verdict, setVerdict] = useState(existingGrade?.verdict || "");
  const [comment, setComment] = useState(existingGrade?.comment || "");
  const [suggestionTitle, setSuggestionTitle] = useState(existingGrade?.suggestion_title || "");
  const [saving, setSaving] = useState(false);
  const gradeIdRef = React.useRef(existingGrade?.id);

  useEffect(() => {
    setVerdict(existingGrade?.verdict || "");
    setComment(existingGrade?.comment || "");
    setSuggestionTitle(existingGrade?.suggestion_title || "");
    gradeIdRef.current = existingGrade?.id;
  }, [existingGrade?.id]);

  const loadPrevTier = async () => {
    if (!tierResult.previous_tier_result_id || prevTier) return;
    setLoadingPrev(true);
    try {
      const prev = await base44Test.entities.QATierResult.get(tierResult.previous_tier_result_id);
      setPrevTier(prev);
    } catch (e) {
      console.error("Load prev tier failed", e);
    } finally {
      setLoadingPrev(false);
    }
  };

  const saveVerdict = async (newVerdict, newComment, newSuggestionTitle) => {
    if (!newVerdict && !newComment?.trim()) return;
    setSaving(true);
    try {
      const data = {
        phase: "qa",
        profile_id: tierResult.test_profile_id,
        tier_result_id: tierResult.id,
        tier: tierResult.tier,
        run_id: tierResult.run_id,
        verdict: newVerdict || null,
        ai_concern_level: tierResult.concern_level,
        ai_scorecard: tierResult.ai_scorecard || null,
        suggestion_title: newSuggestionTitle || null,
        comment: newComment || "",
        grade: 0,
      };
      let record;
      if (gradeIdRef.current) {
        record = await base44Test.entities.TestGrade.update(gradeIdRef.current, data);
      } else {
        record = await base44Test.entities.TestGrade.create(data);
        gradeIdRef.current = record.id;
      }
      setVerdict(newVerdict);
      toast({ title: "Verdict saved", duration: 1200 });
      if (onSaved) onSaved();
    } catch (e) {
      console.error("Save verdict failed", e);
      toast({ title: "Save failed", variant: "destructive", duration: 1500 });
    } finally {
      setSaving(false);
    }
  };

  const handleVerdictClick = (v) => {
    setVerdict(v);
    saveVerdict(v, comment, suggestionTitle);
  };

  const handleCommentBlur = () => {
    if (comment !== (existingGrade?.comment || "")) {
      saveVerdict(verdict, comment, suggestionTitle);
    }
  };

  const concern = tierResult.concern_level || "green";
  const flagReasons = tierResult.flag_reasons || [];
  const suggestions = tierResult.suggestions || [];
  const aiScorecard = tierResult.ai_scorecard || {};
  const progChecks = tierResult.progression_checks || {};
  const isRegression = tierResult.is_regression;

  return (
    <Card className={isRegression ? "border-red-400/50" : ""}>
      <CardContent className="p-4 space-y-3">
        {/* Header */}
        <div className="flex items-start justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge className={CONCERN_COLORS[concern]} variant="outline">
              {concern.toUpperCase()}
            </Badge>
            <span className="font-medium text-sm">{TIER_LABELS[tierResult.tier] || tierResult.tier}</span>
            {tierResult.is_golden && <Badge variant="secondary" className="text-xs">Golden: {tierResult.golden_profile_name}</Badge>}
            {isRegression && <Badge variant="outline" className="text-xs border-red-400 text-red-700">REGRESSION</Badge>}
          </div>
          <Button variant="ghost" size="sm" onClick={() => { setExpanded(!expanded); if (!expanded) loadPrevTier(); }}>
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            {expanded ? "Collapse" : "Expand"}
          </Button>
        </div>

        {/* Flag reasons */}
        {flagReasons.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {flagReasons.map((r, i) => (
              <Badge key={i} variant="outline" className="text-xs text-amber-700 border-amber-300">{r}</Badge>
            ))}
          </div>
        )}

        {/* Compact profile */}
        <CompactProfile snapshot={tierResult.profile_snapshot} />

        {/* Suggestions (always visible) */}
        <div>
          <p className="text-xs font-medium mb-1.5">Results ({suggestions.length})</p>
          <SuggestionList suggestions={suggestions} />
        </div>

        {/* Expanded details */}
        {expanded && (
          <div className="space-y-3 pt-2 border-t border-border">
            {/* AI Scorecard */}
            {aiScorecard?.overall_summary && (
              <div>
                <p className="text-xs font-medium mb-1">AI QA Scorecard</p>
                <p className="text-xs leading-relaxed">{aiScorecard.overall_summary}</p>
                {aiScorecard.per_tier_summary && (
                  <p className="text-xs text-muted-foreground mt-1 italic">{aiScorecard.per_tier_summary}</p>
                )}
                {aiScorecard.dimensions?.filter(d => d.rating === "concern" || d.rating === "bad").map((d, i) => (
                  <div key={i} className="text-xs mt-1">
                    <span className="font-medium">{d.name}:</span> <span className="text-amber-700">{d.rating}</span> — {d.notes}
                  </div>
                ))}
                {aiScorecard.uncertain_areas?.length > 0 && (
                  <div className="text-xs mt-1">
                    <span className="font-medium text-blue-700">Uncertain:</span> {aiScorecard.uncertain_areas.join("; ")}
                  </div>
                )}
              </div>
            )}

            {/* Programmatic checks */}
            <div>
              <p className="text-xs font-medium mb-1">Programmatic Checks</p>
              <div className="text-xs space-y-0.5">
                <div>Count: {tierResult.programmatic_checks?.count_actual} (expected {tierResult.programmatic_checks?.count_min}-{tierResult.programmatic_checks?.count_max})</div>
                {tierResult.programmatic_checks?.hard_constraint_violations?.length > 0 && (
                  <div className="text-red-700">Hard-constraint violations: {tierResult.programmatic_checks.hard_constraint_violations.length}</div>
                )}
                {tierResult.programmatic_checks?.duplicate_models?.length > 0 && (
                  <div className="text-amber-700">Duplicates: {tierResult.programmatic_checks.duplicate_models.join(", ")}</div>
                )}
                {tierResult.programmatic_checks?.like_override_detected && (
                  <div className="text-red-700">Like override detected!</div>
                )}
              </div>
            </div>

            {/* Progression */}
            {progChecks.overlap_count !== undefined && tierResult.previous_tier_result_id && (
              <div>
                <p className="text-xs font-medium mb-1">Progression (vs previous tier)</p>
                <div className="text-xs space-y-0.5">
                  <div>Overlap: {progChecks.overlap_count} | New: {progChecks.new_models?.length || 0} | Dropped: {progChecks.dropped_models?.length || 0} | Churn: {Math.round((progChecks.churn_rate || 0) * 100)}%</div>
                  {loadingPrev && <p className="text-muted-foreground">Loading previous tier...</p>}
                  {prevTier && (
                    <div className="mt-2 pt-2 border-t border-border">
                      <p className="font-medium mb-1">Previous tier: {TIER_LABELS[prevTier.tier]}</p>
                      <SuggestionList suggestions={prevTier.suggestions || []} maxShow={3} />
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Likes before this tier */}
            {tierResult.liked_models?.length > 0 && (
              <div>
                <p className="text-xs font-medium mb-1">Likes before this tier ({tierResult.liked_models.length})</p>
                <div className="text-xs text-muted-foreground">
                  {tierResult.liked_models.map((lm, i) => (
                    <span key={i}>{lm.title} ({lm.liked_at_tier}){i < tierResult.liked_models.length - 1 ? ", " : ""}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Expert actions */}
        <div className="pt-2 border-t border-border space-y-2">
          <p className="text-xs font-medium">Expert Verdict {verdict && `(${VERDICTS.find(v => v.value === verdict)?.label})`}</p>
          <div className="flex flex-wrap gap-1.5">
            {VERDICTS.map((v) => {
              const Icon = v.icon;
              return (
                <Button
                  key={v.value}
                  size="sm"
                  variant={verdict === v.value ? "default" : "outline"}
                  className={`text-xs h-7 ${verdict === v.value ? v.color + " text-white" : ""}`}
                  onClick={() => handleVerdictClick(v.value)}
                  disabled={saving}
                >
                  <Icon className="w-3 h-3 mr-1" />
                  {v.label}
                </Button>
              );
            })}
          </div>
          <div className="flex gap-2 items-start">
            <Select value={suggestionTitle} onValueChange={(v) => { setSuggestionTitle(v === "none" ? "" : v); }}>
              <SelectTrigger className="w-[200px] h-8 text-xs">
                <SelectValue placeholder="Specific boat (optional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No specific boat</SelectItem>
                {suggestions.map((s, i) => (
                  <SelectItem key={i} value={s.title}>{s.title}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              onBlur={handleCommentBlur}
              placeholder="Expert comment (optional)..."
              className="text-xs min-h-[40px] flex-1 resize-y"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}