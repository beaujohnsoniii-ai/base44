import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from "lucide-react";
import { CompactProfile, SuggestionList } from "./QAReviewCard";

const TIER_ORDER = ["free", "match_plus", "refined_match", "market_match"];
const TIER_LABELS = {
  free: "FREE",
  match_plus: "Bosun $9",
  refined_match: "REFINED $29",
  market_match: "MARKET MATCH $99",
};
const CONCERN_COLORS = {
  green: "bg-green-100 text-green-800 border-green-300",
  yellow: "bg-amber-100 text-amber-800 border-amber-300",
  red: "bg-red-100 text-red-800 border-red-300",
  uncertain: "bg-blue-100 text-blue-800 border-blue-300",
  not_evaluated: "bg-muted text-muted-foreground border-border",
};

function TierBlock({ tr }) {
  const [expanded, setExpanded] = useState(false);
  const concern = tr.concern_level || "green";
  const suggestions = tr.suggestions || [];
  const pc = tr.programmatic_checks || {};
  const ai = tr.ai_scorecard || {};

  return (
    <Card>
      <CardContent className="p-3 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Badge className={CONCERN_COLORS[concern]} variant="outline">{concern.toUpperCase()}</Badge>
            <span className="text-sm font-medium">{TIER_LABELS[tr.tier] || tr.tier}</span>
            <span className="text-xs text-muted-foreground">{suggestions.length} boats</span>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)}>
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </Button>
        </div>

        {(tr.flag_reasons || []).length > 0 && (
          <div className="flex flex-wrap gap-1">
            {tr.flag_reasons.map((r, i) => (
              <Badge key={i} variant="outline" className="text-xs text-amber-700 border-amber-300">{r}</Badge>
            ))}
          </div>
        )}

        <SuggestionList suggestions={suggestions} maxShow={3} />

        {expanded && (
          <div className="pt-2 border-t border-border space-y-2 text-xs">
            <div>
              <p className="font-medium mb-0.5">Programmatic Checks</p>
              <div>Count: {pc.count_actual ?? suggestions.length} (expected {pc.count_min ?? "—"}-{pc.count_max ?? "—"})</div>
              {pc.hard_constraint_violations?.length > 0 && <div className="text-red-700">Hard-constraint violations: {pc.hard_constraint_violations.length}</div>}
              {pc.budget_violations?.length > 0 && <div className="text-amber-700">Budget: {pc.budget_violations.length}</div>}
              {pc.size_violations?.length > 0 && <div className="text-amber-700">Size: {pc.size_violations.length}</div>}
              {pc.duplicate_models?.length > 0 && <div className="text-amber-700">Duplicates: {pc.duplicate_models.join(", ")}</div>}
              {pc.like_override_detected && <div className="text-red-700">Like override detected</div>}
            </div>
            {ai.overall_summary && (
              <div>
                <p className="font-medium mb-0.5">AI QA Scorecard</p>
                <p className="leading-relaxed">{ai.overall_summary}</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function QARunResults({ run, tierResults }) {
  if (!run) {
    return <CardContent className="p-8 text-center text-muted-foreground">Run a QA batch to inspect results here.</CardContent>;
  }
  const byProfile = new Map();
  for (const tr of tierResults) {
    const key = tr.test_profile_id;
    if (!byProfile.has(key)) byProfile.set(key, []);
    byProfile.get(key).push(tr);
  }
  const profiles = [...byProfile.entries()].map(([id, tiers]) => {
    const map = new Map(tiers.map((t) => [t.tier, t]));
    const first = tiers[0];
    return { id, first, tiers: TIER_ORDER.map((t) => map.get(t)).filter(Boolean) };
  });

  if (profiles.length === 0) {
    return <CardContent className="p-8 text-center text-muted-foreground">No tier results stored for this run.</CardContent>;
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">{profiles.length} profile{profiles.length !== 1 ? "s" : ""} tested in this run.</p>
      {profiles.map(({ id, first, tiers }) => (
        <Card key={id}>
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                {first.is_golden ? (
                  <Badge variant="secondary">Golden: {first.golden_profile_name || first.golden_profile_id || "—"}</Badge>
                ) : (
                  <Badge variant="outline">Synthetic</Badge>
                )}
                <span className="text-xs text-muted-foreground">Profile {id.slice(-6)}</span>
              </div>
            </div>
            <CompactProfile snapshot={first.profile_snapshot} />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {tiers.map((tr) => <TierBlock key={tr.id} tr={tr} />)}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}