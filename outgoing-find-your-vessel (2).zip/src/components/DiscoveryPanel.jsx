import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import ListingLink from "@/components/ListingLink";
import { Input } from "@/components/ui/input";
import { Search, ExternalLink, Sparkles, CheckCircle2, AlertCircle } from "lucide-react";

export default function DiscoveryPanel({ existing, onComplete }) {
  const { toast } = useToast();
  const [urls, setUrls] = useState(["", "", ""]);
  const [analyzing, setAnalyzing] = useState(false);
  const [discovery, setDiscovery] = useState(existing || null);

  const canSubmit = urls.every((u) => u.trim().length > 0) && !analyzing;

  const handleSubmit = async () => {
    setAnalyzing(true);
    try {
      const res = await base44.functions.invoke("analyze-references", { urls: urls.map((u) => u.trim()) });
      const d = res?.data?.discovery;
      if (d) {
        setDiscovery(d);
        onComplete?.(d);
      } else {
        toast({ title: "Could not analyze listings", variant: "destructive" });
      }
    } catch (e) {
      const msg = e?.response?.data?.error || "Could not analyze listings";
      toast({ title: msg, variant: "destructive" });
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <Card className="border-accent/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="w-5 h-5 text-accent" /> Discovery: Find Similar Listings
        </CardTitle>
        <CardDescription>
          Paste links to the 3 boats you think best suit your needs. We'll read each listing, identify what they
          have in common, compare that to your needs and wants, and find similar boats ready for your shortlist.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <div key={i}>
              <label className="text-sm font-medium mb-1 block">Boat {i + 1} listing URL</label>
              <Input
                type="url"
                placeholder="https://www.boattrader.com/..."
                value={urls[i]}
                onChange={(e) => {
                  const next = [...urls];
                  next[i] = e.target.value;
                  setUrls(next);
                }}
                disabled={analyzing}
              />
            </div>
          ))}
        </div>
        <Button onClick={handleSubmit} disabled={!canSubmit}>
          {analyzing ? (
            <>
              <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2" />
              Analyzing your reference boats…
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" /> Find similar listings
            </>
          )}
        </Button>

        {analyzing && (
          <p className="text-sm text-muted-foreground">
            Reading each listing, extracting specs, identifying common traits, comparing to your needs, and
            searching for similar boats. This may take a minute.
          </p>
        )}

        {discovery && !analyzing && (
          <div className="space-y-4 pt-4 border-t">
            {discovery.status === "complete" && (
              <>
                <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
                  <p className="font-medium flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-accent" />
                    SoundHeading has found {discovery.listings_found} listing
                    {discovery.listings_found === 1 ? "" : "s"} ready to be reviewed and prepared for the next
                    paid stage you select.
                  </p>
                </div>

                {discovery.common_traits?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-semibold mb-2">Common Traits Across Your 3 Boats</h4>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc pl-5">
                      {discovery.common_traits.map((t, i) => (
                        <li key={i}>{t}</li>
                      ))}
                    </ul>
                    {discovery.pattern_summary && (
                      <p className="text-sm text-muted-foreground mt-2">{discovery.pattern_summary}</p>
                    )}
                  </div>
                )}

                {discovery.profile_comparison && (
                  <div>
                    <h4 className="text-sm font-semibold mb-2">How This Compares to Your Needs & Wants</h4>
                    <p className="text-sm text-muted-foreground">{discovery.profile_comparison}</p>
                    {discovery.profile_aligned?.length > 0 && (
                      <p className="text-sm text-green-600 mt-1">
                        <span className="font-medium">Aligned:</span> {discovery.profile_aligned.join(", ")}
                      </p>
                    )}
                    {discovery.profile_gaps?.length > 0 && (
                      <p className="text-sm text-amber-600 mt-1">
                        <span className="font-medium">Gaps:</span> {discovery.profile_gaps.join(", ")}
                      </p>
                    )}
                  </div>
                )}

                {discovery.found_listings?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-semibold mb-2">
                      Found listings ({discovery.found_listings.length})
                    </h4>
                    <div className="space-y-2">
                      {discovery.found_listings.map((l, i) => (
                        <div key={i} className="border rounded-lg p-3">
                          <ListingLink
                            href={l.link}
                            className="font-medium hover:underline flex items-center gap-1"
                          >
                            {l.title} <ExternalLink className="w-3.5 h-3.5" />
                          </ListingLink>
                          <p className="text-sm text-muted-foreground">
                            {l.source ? `${l.source} · ` : ""}
                            {l.asking_price ? `Asking ${l.asking_price}` : ""}
                          </p>
                          {l.why_similar && (
                            <p className="text-sm text-muted-foreground mt-1">{l.why_similar}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {discovery.reference_boats?.some((b) => !b.fetched) && (
                  <div className="flex items-start gap-2 text-sm text-amber-600">
                    <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                    <p>
                      Some listing pages could not be accessed automatically. The analysis is based on the
                      available data — you may want to add manual specs for those boats.
                    </p>
                  </div>
                )}

                {discovery.search_notes && (
                  <p className="text-xs text-muted-foreground italic">{discovery.search_notes}</p>
                )}
              </>
            )}
            {discovery.status === "failed" && (
              <p className="text-sm text-destructive">Analysis failed. Please try again or check your links.</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}