import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { MessageSquareWarning, Loader2, CheckCircle2 } from "lucide-react";

const REASONS = [
  { value: "doesnt_fit_profile", label: "Doesn't fit my profile" },
  { value: "missed_my_answers", label: "Missed how I answered the questions" },
  { value: "inaccurate_specs", label: "Inaccurate specifications" },
  { value: "missing_info", label: "Missing information I provided" },
  { value: "other", label: "Other" },
];

export default function ReportFeedbackForm({ reportId, stageName }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const list = await base44.entities.ReportFeedback.filter({ report_id: reportId }, "-created_date", 1);
        if (list?.[0]) setDone(true);
      } catch (e) {
        /* ignore */
      }
    })();
  }, [reportId]);

  const submit = async () => {
    if (!reason) {
      toast({ title: "Select a reason", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      const res = await base44.functions.invoke("submit-report-feedback", { report_id: reportId, reason, details });
      if (res?.data?.feedback) {
        setDone(true);
        setOpen(false);
        toast({
          title: "Feedback submitted",
          description: "Your report is flagged for personal review by a SoundHeading advisor.",
        });
      } else {
        toast({ title: res?.data?.error || "Could not submit feedback", variant: "destructive" });
      }
    } catch (e) {
      const msg = e?.response?.data?.error || "Could not submit feedback";
      if (msg.includes("already submitted")) setDone(true);
      toast({ title: msg, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <Card className="border-accent/30 bg-accent/5">
        <CardContent className="p-4 flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-accent mt-0.5 shrink-0" />
          <div>
            <p className="font-medium">Feedback received</p>
            <p className="text-sm text-muted-foreground">
              Your {stageName} report is flagged for personal review by a SoundHeading advisor. No credit or
              refund is issued automatically — if one is warranted, an advisor will follow up with you directly
              after reviewing your case.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setOpen((o) => !o)}>
        <MessageSquareWarning className="w-4 h-4 mr-2" /> This doesn't fit my profile
      </Button>
      {open && (
        <Card className="mt-3">
          <CardHeader>
            <CardTitle className="text-base">Report Feedback</CardTitle>
            <CardDescription>
              If this report doesn't match your profile or how you answered, tell us. We'll flag it for personal
              review by a SoundHeading advisor. No credit or refund is issued automatically — an advisor will
              follow up with you directly if one is warranted.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>What's wrong?</Label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring"
              >
                <option value="">Select a reason…</option>
                {REASONS.map((r) => (
                  <option key={r.value} value={r.value}>
                    {r.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="fb-details">Details (optional)</Label>
              <Textarea
                id="fb-details"
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Tell us what didn't fit so the advisor can review and improve your result."
                rows={4}
              />
            </div>
            <Button onClick={submit} disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting…
                </>
              ) : (
                "Submit feedback"
              )}
            </Button>
          </CardContent>
        </Card>
      )}
    </>
  );
}