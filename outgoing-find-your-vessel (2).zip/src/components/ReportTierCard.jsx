import React from "react";
import { CheckCircle2, ArrowRight, ShieldCheck, Sparkles, Star, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { ACTIVATION_FEE } from "@/lib/stages";

// Distinct card for the two core report tiers (Find My Boat, Model Shortlist).
// `featured` marks the hero tier (Model Shortlist) with an accent ribbon + ring.
export default function ReportTierCard({ stage, purchased, onPurchase, purchasing, hasActivation = false, flagged = false }) {
  const featured = stage.main;
  const creditApplies = hasActivation && stage.credit_eligible;
  const displayPrice = creditApplies ? stage.price - ACTIVATION_FEE : stage.price;

  return (
    <Card
      className={`flex flex-col relative overflow-hidden ${
        featured ? "border-accent ring-2 ring-accent/40 shadow-lg" : "border-border shadow-sm"
      } ${purchased ? "border-accent" : ""} ${flagged && !purchased ? "border-amber-400/60" : ""}`}
    >
      {featured && (
        <div className="absolute top-0 inset-x-0 bg-accent text-accent-foreground text-xs font-medium px-4 py-1.5 flex items-center justify-center gap-1.5">
          <Star className="w-3.5 h-3.5 fill-current" /> Most popular
        </div>
      )}

      <CardHeader className={featured ? "pt-9" : ""}>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-heading flex items-center gap-2">
            {stage.name}
          </CardTitle>
          {stage.tier_label && !featured && (
            <span className="text-xs font-medium rounded-full bg-primary/10 text-primary px-2.5 py-1">
              {stage.tier_label}
            </span>
          )}
          {purchased ? <CheckCircle2 className="w-5 h-5 text-accent" /> : null}
        </div>
        <CardDescription className="text-sm">{stage.tagline}</CardDescription>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col">
        <p className="text-sm text-muted-foreground">{stage.description}</p>

        <div className="mt-5 flex items-baseline gap-2 flex-wrap">
          <span className="text-4xl font-heading font-semibold">${displayPrice}</span>
          {creditApplies && (
            <span className="text-sm text-muted-foreground line-through">${stage.price}</span>
          )}
          {creditApplies && (
            <span className="text-xs font-medium text-accent">${ACTIVATION_FEE} activation credit applied</span>
          )}
        </div>

        <ul className="mt-5 space-y-2 flex-1">
          {stage.deliverables.map((d) => (
            <li key={d} className="flex items-start gap-2.5 text-sm">
              <CheckCircle2 className={`w-4 h-4 mt-0.5 shrink-0 ${featured ? "text-accent" : "text-primary"}`} />
              <span>{d}</span>
            </li>
          ))}
        </ul>

        <p className="mt-5 text-xs text-muted-foreground flex items-start gap-1.5 border-t border-border pt-4">
          <ShieldCheck className="w-3.5 h-3.5 mt-0.5 shrink-0 text-accent" />
          {stage.remedy}
        </p>
      </CardContent>

      <CardFooter className="pt-0">
        {purchased ? (
          <Button className="w-full" variant="secondary" disabled>
            Unlocked
          </Button>
        ) : flagged ? (
          <div className="w-full space-y-2">
            <Button className="w-full" variant="secondary" disabled>
              Resolve profile issues first
            </Button>
            <p className="text-xs text-amber-700 dark:text-amber-400 flex items-start gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              Your profile has potential issues to review. Adjust the flagged fields and re-run the advisor to unlock purchases — the results will improve significantly once corrected.
            </p>
          </div>
        ) : (
          <Button
            className="w-full"
            variant={featured ? "default" : "outline"}
            onClick={() => onPurchase(stage.id)}
            disabled={purchasing === stage.id}
          >
            {purchasing === stage.id ? (
              "Redirecting…"
            ) : (
              <>
                {featured && <Sparkles className="w-4 h-4 mr-1" />}
                Purchase for ${displayPrice}
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}