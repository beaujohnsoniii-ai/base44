import React from "react";
import {modelSearch} from "@/lib/compareCandidates";
const empty="Not confirmed";
export default function ModelComparisonView({comparison}){
 const models=comparison?.results||[];
 if(!models.length)return null;
 const names=models[0].fields.map(f=>f.field);
 return <section className="rounded-xl border bg-white p-5 space-y-4" aria-label="Model comparison from database">
  <div><h2 className="text-xl font-heading">Your models, side by side</h2><p className="text-sm text-muted-foreground">{comparison.notice}</p></div>
  <div className="overflow-x-auto"><table className="w-full text-sm border-collapse"><caption className="sr-only">Selected model years and confirmed specifications</caption>
   <thead><tr><th scope="col" className="p-3 border text-left min-w-40">Model detail</th>{models.map(b=><th key={b.id} scope="col" className="p-3 border text-left min-w-56">{b.title}</th>)}</tr></thead>
   <tbody>
    <tr><th scope="row" className="p-3 border text-left">Selected model year</th>{models.map(b=><td key={b.id} className="p-3 border">{b.year||"Year not established"}</td>)}</tr>
    <tr><th scope="row" className="p-3 border text-left">Match fit notes</th>{models.map(b=><td key={b.id} className="p-3 border align-top">{b.match?.summary||"No saved fit notes."}<p className="text-xs text-muted-foreground mt-1">Saved guidance; not verified specifications.</p>{b.match?.matches?.length>0&&<p className="mt-2">Strengths: {b.match.matches.join("; ")}</p>}{b.match?.gaps?.length>0&&<p className="mt-2">To check: {b.match.gaps.join("; ")}</p>}</td>)}</tr>
    {names.map(name=><tr key={name}><th scope="row" className="p-3 border text-left">{name}</th>{models.map(b=>{const f=b.fields.find(f=>f.field===name);return <td key={b.id} className="p-3 border align-top">{f?.status==="source_confirmed"?<><strong>{f.value} {f.unit}</strong><p className="text-xs">Source confirmed · {f.year_start}–{f.year_end}</p><a className="underline" href={f.source_url} target="_blank" rel="noopener noreferrer">Source</a></>:<><span>{f?.status==="conflict"?"Conflicting evidence":empty}</span><p className="text-xs text-muted-foreground">{f?.message}</p></>}</td>;})}</tr>)}
    <tr><th scope="row" className="p-3 border text-left">Stored model research</th>{models.map(b=><td key={b.id} className="p-3 border align-top">{!b.research.length?<p>No exact database model record found.</p>:<details><summary className="cursor-pointer underline">Review {b.research.length} research record(s)</summary><p className="text-xs my-2">The values below are research notes. Applicable years, units and configuration require confirmation; records are kept separate.</p>{b.research.map(r=><article key={r.id} className="border-t py-3 space-y-2"><p className="font-medium">{r.generation}</p><p className="text-xs">Workbook v{r.workbook_version} · {r.status}</p><dl>{Object.entries(r.values).map(([k,v])=><div key={k} className="mb-2"><dt className="font-medium">{k}</dt><dd className="whitespace-pre-wrap">{v}</dd></div>)}</dl>{r.source_url&&<a className="underline" href={r.source_url} target="_blank" rel="noopener noreferrer">Research source</a>}</article>)}</details>}{b.truncated&&<p role="alert">Research results are incomplete; specification confirmation is withheld.</p>}</td>)}</tr>
    <tr><th scope="row" className="p-3 border text-left">Next: Find</th>{models.map(b=><td key={b.id} className="p-3 border"><a className="inline-block rounded border px-4 py-3 underline" href={modelSearch(b)} target="_blank" rel="noopener noreferrer">Find boats for sale</a><p className="mt-2 text-xs text-muted-foreground">Opens an external search. Availability and listing import are not guaranteed.</p></td>)}</tr>
   </tbody>
  </table></div>
 </section>;
}
