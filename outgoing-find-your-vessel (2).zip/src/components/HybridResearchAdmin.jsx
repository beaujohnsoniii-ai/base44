import React,{useState} from "react";
import {base44} from "@/api/base44Client";
import {Button} from "@/components/ui/button";
export default function HybridResearchAdmin(){
 const [manufacturer,setManufacturer]=useState("Parker"),[rows,setRows]=useState([]),[issues,setIssues]=useState([]),[selected,setSelected]=useState(null),[fields,setFields]=useState({}),[result,setResult]=useState(null),[error,setError]=useState(""),[busy,setBusy]=useState(false);
 const [form,setForm]=useState({field:"LOA",status:"not_checked",notes:"",value:"",year_start:"",year_end:"",source_url:"",quote:"",source_reviewed:false,issue_id:""});
 function change(k,v){setForm(x=>({...x,[k]:v}));}
 async function call(action){setBusy(true);setError("");try{const r=await base44.functions.invoke("hybrid-evidence",{action,manufacturer,dataset_id:selected?.id,...(action==="resolve"?{...form,unit:fields[form.field]?.unit,basis:fields[form.field]?.basis}: {})});const d=r.data||r;if(d.error)throw new Error(d.error);if(action==="search"){setRows(d.rows);setFields(d.fields);setSelected(null);}else if(action==="issues")setIssues(d.issues);else setResult(d);}catch(e){setError(e.response?.data?.error||e.message||"Request failed");}finally{setBusy(false);}}
 return <section className="border rounded-lg p-4 space-y-3"><h2 className="text-xl font-semibold">Workbook hybrid review</h2>
 <p className="text-sm">Workbook facts remain unchanged. Online checks gather evidence; uncertain facts remain provisional until reviewed. Checks may consume provider credits and reuse results for 24 hours.</p>
 <label className="block">Manufacturer (exact workbook spelling)<input className="border rounded p-2 ml-2" value={manufacturer} onChange={e=>setManufacturer(e.target.value)}/></label>
 <div className="flex gap-2"><Button disabled={busy} onClick={()=>call("search")}>Load workbook records</Button><Button variant="outline" disabled={busy} onClick={()=>call("issues")}>Refresh admin issues</Button></div>
 <p className="text-xs">Displays up to 100 workbook rows or open issues per request.</p>
 {rows.length>0&&<select aria-label="Workbook model" className="border p-2 w-full" value={selected?.id||""} onChange={e=>{setSelected(rows.find(r=>r.id===e.target.value));setResult(null);}}><option value="">Choose model and generation</option>{rows.map(r=><option value={r.id} key={r.id}>{r.manufacturer} {r.model} · {r.generation} · row {r.workbook_row}</option>)}</select>}
 {selected&&<><p>Workbook revision {selected.workbook_version}, row {selected.workbook_row}</p><details><summary>Original workbook facts and notes</summary><pre className="text-xs whitespace-pre-wrap break-words">{JSON.stringify(selected.raw_fields,null,2)}</pre></details>
 <Button disabled={busy} onClick={()=>call("check")}>{busy?"Working…":"Check selected model online"}</Button>
 <details className="border rounded p-3"><summary>Review a specification</summary>
 <select aria-label="Specification" className="border p-2 my-2" value={form.field} onChange={e=>change("field",e.target.value)}>{Object.keys(fields).map(f=><option key={f}>{f}</option>)}</select>
 <select aria-label="Review status" className="border p-2 m-2" value={form.status} onChange={e=>change("status",e.target.value)}>{["not_checked","missing","conflict","source_confirmed"].map(s=><option key={s}>{s}</option>)}</select>
 {["notes","value","year_start","year_end","source_url","quote","issue_id"].map(k=><label key={k} className="block my-2">{k.replaceAll("_"," ")}<input className="border rounded p-2 w-full" value={form[k]} onChange={e=>change(k,e.target.value)}/></label>)}
 <p>Required measurement: {fields[form.field]?.unit}, {fields[form.field]?.basis}. Verify model identity, applicable years and measurement definition against the source.</p>
 <label className="block my-2"><input type="checkbox" checked={form.source_reviewed} onChange={e=>change("source_reviewed",e.target.checked)}/> I reviewed the source and applicable model years.</label>
 <Button disabled={busy||!form.notes.trim()} onClick={()=>call("resolve")}>Save reviewed evidence</Button></details></>}
 {error&&<p role="alert" className="text-red-700">{error}</p>}
 {result&&<details open><summary>Check / review result</summary><pre className="text-xs whitespace-pre-wrap break-words max-h-96 overflow-auto">{JSON.stringify(result,null,2)}</pre></details>}
 {issues.map(i=><details key={i.id} className="border p-2"><summary>{i.manufacturer} {i.model} · {i.field} · {i.kind}</summary><p>{i.description}</p><p className="text-xs">Issue ID: {i.id}</p><pre className="text-xs whitespace-pre-wrap break-words max-h-80 overflow-auto">{JSON.stringify(i.evidence,null,2)}</pre></details>)}
 </section>;
}