import React from "react";
import { CheckCircle2, Loader2, Anchor, Ship, Sparkles, Compass, Flag } from "lucide-react";
import { isPaidPlan } from "@/lib/stages";

const MILESTONES = [
  { id: "profile", label: "Build profile", icon: Anchor },
  { id: "candidates", label: "Save 3 candidates", icon: Ship },
  { id: "teaser", label: "Your match", icon: Compass },
  { id: "purchase", label: "Buy a package", icon: Sparkles },
  { id: "finalize", label: "Report finalized", icon: Flag },
];

export default function ReportFinalizationTracker({
  hasProfile = false,
  candidateCount = 0,
  minCandidates = 3,
  hasFeedback = false,
  hasTeaser = false,
  plan = "free",
  reports = [],
}) {
  const isPaid = isPaidPlan(plan);
  const paidReportTypes = ["top_pick", "top_three", "private_advisory", "introductions", "survey_review"];
  const hasFinalizedReport = reports.some(
    (r) => paidReportTypes.includes(r.type) && r.status !== "failed"
  );

  const state = {
    profile: hasProfile,
    candidates: candidateCount >= minCandidates,
    teaser: hasTeaser || hasFeedback,
    purchase: isPaid,
    finalize: hasFinalizedReport,
  };

  const doneCount = MILESTONES.filter((m) => state[m.id]).length;
  const percent = Math.round((doneCount / MILESTONES.length) * 100);
  const nextMilestone = MILESTONES.find((m) => !state[m.id]);
  const allDone = doneCount === MILESTONES.length;

  return (
    <div className="rounded-xl border bg-card p-5 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-4">
        <div>
          <h3 className="font-heading text-lg font-semibold">Your advisory status</h3>
          <p className="text-sm text-muted-foreground">
            {allDone
              ? "Your advisory report is finalized — view or download it below."
              : nextMilestone
              ? `Next: ${nextMilestone.label}`
              : "Complete the steps below to finalize your report."}
          </p>
        </div>
        <span className="text-2xl font-semibold tabular-nums text-primary">{percent}%</span>
      </div>

      <div className="relative h-2.5 rounded-full bg-muted overflow-hidden">
        <div
          className="absolute inset-y-0 left-0 rounded-full bg-accent transition-all duration-500"
          style={{ width: `${percent}%` }}
        />
      </div>

      <ol className="mt-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {MILESTONES.map((m, i) => {
          const isDone = state[m.id];
          const isNext = !isDone && m.id === nextMilestone?.id;
          const Icon = isDone ? CheckCircle2 : isNext ? Loader2 : m.icon;
          return (
            <li
              key={m.id}
              className={`rounded-lg border p-3 ${
                isDone
                  ? "border-accent bg-accent/5"
                  : isNext
                  ? "border-primary/40 bg-primary/5"
                  : "border-border bg-muted/30"
              }`}
            >
              <div className="flex items-center gap-2">
                <Icon
                  className={`w-4 h-4 ${
                    isDone
                      ? "text-accent"
                      : isNext
                      ? "text-primary animate-spin"
                      : "text-muted-foreground"
                  }`}
                />
                <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
                  Step {i + 1}
                </span>
              </div>
              <p className={`text-sm font-medium mt-1 ${isDone ? "text-foreground" : "text-muted-foreground"}`}>
                {m.label}
              </p>
            </li>
          );
        })}
      </ol>
    </div>
  );
}