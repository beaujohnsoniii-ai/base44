import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import { ChevronRight, Loader2, Check, X, AlertCircle } from "lucide-react";

const STATUS_META = {
  pending: { icon: Loader2, spin: true, label: "Pending", tone: "text-muted-foreground" },
  running: { icon: Loader2, spin: true, label: "Running", tone: "text-muted-foreground" },
  in_progress: { icon: Loader2, spin: true, label: "Working", tone: "text-muted-foreground" },
  completed: { icon: Check, spin: false, label: "Done", tone: "text-emerald-600" },
  success: { icon: Check, spin: false, label: "Done", tone: "text-emerald-600" },
  failed: { icon: X, spin: false, label: "Failed", tone: "text-destructive" },
  error: { icon: AlertCircle, spin: false, label: "Error", tone: "text-destructive" },
};

function ToolCallDisplay({ toolCall }) {
  const [expanded, setExpanded] = useState(false);
  const status = toolCall.status || "pending";
  const meta = STATUS_META[status] || STATUS_META.pending;
  const Icon = meta.icon;

  let parsedResults = toolCall.results;
  if (typeof parsedResults === "string") {
    try {
      parsedResults = JSON.parse(parsedResults);
    } catch (_) {
      /* keep raw */
    }
  }
  const failed = status === "failed" || status === "error" ||
    (parsedResults && typeof parsedResults === "object" && parsedResults.success === false) ||
    (typeof parsedResults === "string" && /error|failed/i.test(parsedResults));

  let args = toolCall.arguments_string;
  try {
    args = JSON.stringify(JSON.parse(args), null, 2);
  } catch (_) {
    /* keep raw */
  }

  const proj = toolCall.display_projection || {};
  const hideDetails = proj.hide_details && proj.details_redacted;
  const stateLabel = hideDetails
    ? (failed ? (proj.error_label || "Failed") : (meta.spin ? (proj.active_label || "Working…") : (proj.label || "Done")))
    : null;

  return (
    <div className="mt-2 text-xs rounded-lg border border-border bg-muted/40 px-3 py-2">
      <button
        type="button"
        onClick={() => !hideDetails && setExpanded((e) => !e)}
        className="flex items-center gap-2 w-full text-left"
      >
        <Icon className={`w-3.5 h-3.5 ${meta.spin ? "animate-spin" : ""} ${failed ? "text-destructive" : meta.tone}`} />
        <span className="font-medium capitalize">{toolCall.name?.replace(/_/g, " ")}</span>
        <span className={failed ? "text-destructive" : meta.tone}>· {stateLabel || meta.label}</span>
        {!hideDetails && <ChevronRight className={`w-3 h-3 ml-auto transition-transform ${expanded ? "rotate-90" : ""}`} />}
      </button>
      {expanded && !hideDetails && (
        <div className="mt-2 space-y-2">
          {args && args !== "{}" && (
            <div>
              <p className="text-muted-foreground mb-0.5">Parameters:</p>
              <pre className="whitespace-pre-wrap break-words font-mono text-[11px] bg-background rounded p-2">{args}</pre>
            </div>
          )}
          {parsedResults != null && (
            <div>
              <p className="text-muted-foreground mb-0.5">Result:</p>
              <pre className="whitespace-pre-wrap break-words font-mono text-[11px] bg-background rounded p-2 max-h-40 overflow-auto">
                {typeof parsedResults === "string" ? parsedResults : JSON.stringify(parsedResults, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function MessageBubble({ message }) {
  const isUser = message.role === "user";
  return (
    <div className={isUser ? "flex justify-end" : "flex justify-start"}>
      <div className={`max-w-[85%] ${isUser ? "" : "w-full"}`}>
        {message.content && (
          isUser ? (
            <div className="rounded-2xl rounded-br-sm bg-primary text-primary-foreground px-4 py-2.5 text-sm">
              <p className="whitespace-pre-wrap">{message.content}</p>
            </div>
          ) : (
            <div className="rounded-2xl rounded-bl-sm bg-card border border-border px-4 py-3">
              <ReactMarkdown className="text-sm prose prose-sm max-w-none prose-p:my-1 prose-ul:my-1 prose-li:my-0">
                {message.content}
              </ReactMarkdown>
            </div>
          )
        )}
        {message.tool_calls?.map((tc, idx) => (
          <ToolCallDisplay key={idx} toolCall={tc} />
        ))}
      </div>
    </div>
  );
}