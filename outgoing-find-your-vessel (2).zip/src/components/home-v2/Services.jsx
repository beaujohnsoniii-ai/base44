import React, { useEffect, useRef, useState } from "react";
import Icon from "@/components/home-v2/Icon";

const GROUPS = [
  { n: "I", title: "Find", note: "Get to the right kind of boat.", items: [
    { n: "01", name: "Match", href: "#quiz", img: "svc_match.jpg", desc: "Your buyer profile, translated into the boat types, sizes and layouts that fit how you live." },
    { n: "02", name: "Explore", href: "#services", img: "svc_explore.jpg", desc: "Browse categories and real examples by how they’re used\u00A0— not just by brand or price." },
    { n: "03", name: "Learn", href: "#journal", img: "svc_learn.jpg", desc: "Plain-English guides to hulls, power, electronics and the buying process." },
  ] },
  { n: "II", title: "Evaluate", note: "Know what it really costs and how it compares.", items: [
    { n: "04", name: "Analyze", href: "#services", img: "svc_analyze.jpg", desc: "Fuel, insurance, storage, maintenance and resale, modeled before you commit." },
    { n: "05", name: "Compare", href: "#services", img: "svc_compare.jpg", desc: "Side by side and apples to apples: layout, range, draft, ride and upkeep." },
  ] },
  { n: "III", title: "Buy & own", note: "From shortlist to first season.", items: [
    { n: "06", name: "Advisory", href: "#pricing", img: "svc_advisory.jpg", desc: "One-on-one guidance from shortlist through survey, sea trial and closing." },
    { n: "07", name: "Ownership", href: "#services", img: "svc_ownership.jpg", desc: "Lift, slip, rack or trailer; service rhythms; your first-season checklist." },
  ] },
];

const ALL_ITEMS = GROUPS.flatMap((group) => group.items);
const imgSrc = (file) => `/site-v2/assets/img/${file}`;

// Seven services in three stages, with the example photo trailing the cursor in the gutter.
export default function Services() {
  const listRef = useRef(null);
  const floatRef = useRef(null);
  const [hovered, setHovered] = useState(null);
  const [image, setImage] = useState(ALL_ITEMS[0].img);

  useEffect(() => {
    const list = listRef.current;
    const float = floatRef.current;
    if (!list || !float) return;
    if (!matchMedia("(hover:hover) and (min-width:761px)").matches) return;
    const section = list.closest("section");
    const desc = list.querySelector(".svc__desc");
    ALL_ITEMS.forEach((item) => { new Image().src = imgSrc(item.img); });
    let tx = 0, ty = 0, cx = 0, cy = 0, raf = 0;
    const loop = () => {
      cx += (tx - cx) * 0.14;
      cy += (ty - cy) * 0.14;
      float.style.transform = `translate(${cx - 110}px,${cy - 140}px) rotate(${((tx - cx) * 0.02).toFixed(2)}deg)`;
      raf = Math.abs(tx - cx) + Math.abs(ty - cy) > 0.3 ? requestAnimationFrame(loop) : 0;
    };
    const onMove = (event) => {
      const box = section.getBoundingClientRect();
      const copy = desc.getBoundingClientRect();
      tx = copy.left - box.left - 140 + (event.clientX - box.left - box.width / 2) * 0.03;
      ty = event.clientY - box.top;
      if (!raf) raf = requestAnimationFrame(loop);
    };
    section.addEventListener("mousemove", onMove);
    return () => {
      section.removeEventListener("mousemove", onMove);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  const hover = (item) => { setHovered(item.n); setImage(item.img); };

  return (
    <section className="svc navy-deep" id="services">
      <div className="wrap">
        <div className="sec-head sec-head--split">
          <div>
            <p className="kicker" data-reveal>Our services</p>
            <h2 data-reveal>Seven ways to <em>get it right.</em></h2>
          </div>
          <p className="sec-head__aside" data-reveal>Use what you need. Start with the free tools, go deeper with a Captain, or bring in an advisor for the whole passage.</p>
        </div>

        <div className={`svc__groups${hovered ? " has-hover" : ""}`} id="svcList" ref={listRef} onMouseLeave={() => setHovered(null)}>
          {GROUPS.map((group) => (
            <div className="svc__group" key={group.title}>
              <h3 className="svc__ghead" data-reveal><span className="svc__gn">{group.n}</span>{group.title}<small>{group.note}</small></h3>
              <ul className="svc__list">
                {group.items.map((item) => (
                  <li
                    key={item.n}
                    className={hovered === item.n ? "hov" : undefined}
                    data-img={imgSrc(item.img)}
                    data-reveal
                    onMouseEnter={() => hover(item)}
                  >
                    <a href={item.href}>
                      <span className="svc__n">{item.n}</span>
                      <span className="svc__name">{item.name}</span>
                      <span className="svc__desc">{item.desc}</span>
                      <Icon name="arrow" className="svc__arr" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      <div className={`svc__float${hovered ? " on" : ""}`} id="svcFloat" ref={floatRef} aria-hidden="true">
        <img alt="" src={imgSrc(image)} />
      </div>
    </section>
  );
}