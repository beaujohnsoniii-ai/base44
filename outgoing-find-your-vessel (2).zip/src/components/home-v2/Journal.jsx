import React from "react";
import Icon from "@/components/home-v2/Icon";

const POSTS = [
  { img: "journal_lift.jpg", alt: "Center console on a boat lift at a marsh dock", topic: "Ownership",
    title: "Lift, slip or dry stack? Storage math for Southeast owners.",
    body: "Where a boat lives shapes what it costs, how often you use it, and which boats make sense." },
  { img: "journal_sandbar.jpg", alt: "Aerial of boats lined along a sandbar in a marsh inlet", topic: "Buying guide",
    title: "Draft, tides and the sandbar test.",
    body: "Why eight inches of draft can decide where you spend your summer." },
  { img: "journal_storm.jpg", alt: "Building thunderhead over open water seen from a pilothouse boat", topic: "Seamanship",
    title: "What an afternoon squall teaches you about hull and helm.",
    body: "Southeast summer weather, and the boat features that matter when it builds fast." },
];

// The logbook: three sample resources.
export default function Journal() {
  return (
    <section className="journal sand" id="journal">
      <div className="wrap">
        <div className="sec-head sec-head--split">
          <div>
            <p className="kicker" data-reveal>Learn · The logbook</p>
            <h2 data-reveal>Know more <em>before you buy.</em></h2>
          </div>
          <a className="link-arrow" href="#journal" data-reveal>All resources <Icon name="arrow" /></a>
        </div>
        <div className="posts">
          {POSTS.map((post, i) => (
            <article className="post" key={post.title} data-reveal style={{ "--d": i }}>
              <a href="#journal">
                <figure><img src={`/site-v2/assets/img/${post.img}`} alt={post.alt} loading="lazy" /></figure>
                <p className="post__meta"><span>{post.topic}</span><em>Sample article</em></p>
                <h3>{post.title}</h3>
                <p>{post.body}</p>
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}