import React from "react";
import Icon from "@/components/home-v2/Icon";

const STEPS = [
  { n: "01", title: "Answer the key questions", body: "Where you boat, who’s aboard, how you use the day, what you’re willing to maintain. A few minutes, no sales call." },
  { n: "02", title: "Save your buyer profile", body: "Your answers become a profile you can refine as plans change\u00A0— budget, storage, tow vehicle, home waters." },
  { n: "03", title: "Get matched, then compare", body: "See the boat types and sizes that fit, then explore, analyze and compare real options side by side." },
];

// Three bearings to the right boat.
export default function HowItWorks() {
  return (
    <section className="how navy" id="how">
      <div className="how__media" aria-hidden="true">
        <img
          src="/site-v2/assets/img/journal_storm.jpg"
          alt=""
          loading="lazy"
          data-parallax=".12"
        />
      </div>
      <div className="wrap">
        <div className="sec-head">
          <p className="kicker" data-reveal>How it works</p>
          <h2 data-reveal>Three bearings to <em>the right boat.</em></h2>
          <p className="sec-head__aside" data-reveal>A few honest questions do more than a hundred listings. Here’s the course we plot together.</p>
        </div>
        <ol className="timeline" data-reveal>
          {STEPS.map((step, i) => (
            <li className="step" key={step.n} style={{ "--d": i }}>
              <span className="step__mark"><Icon name="dial" /></span>
              <span className="step__n">{step.n}</span>
              <h3>{step.title}</h3>
              <p>{step.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}