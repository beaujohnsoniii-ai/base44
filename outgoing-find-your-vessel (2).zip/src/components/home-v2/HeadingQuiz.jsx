import React, { useState } from "react";
import Icon from "@/components/home-v2/Icon";
import { scoreHeading } from "@/lib/headingQuiz";

const QUESTIONS = [
  { key: "water", n: "01", legend: "Where will you spend most of your time?", options: [
    { v: "icw", label: "ICW & tidal creeks" }, { v: "sandbar", label: "Sounds & sandbars" },
    { v: "near", label: "Nearshore & inlets" }, { v: "off", label: "Offshore\u00A0— Gulf Stream" } ] },
  { key: "crew", n: "02", legend: "Who’s usually aboard?", options: [
    { v: "duo", label: "Just one or two" }, { v: "family", label: "Family, kids in tow" },
    { v: "friends", label: "A crowd of friends" }, { v: "anglers", label: "Serious anglers" } ] },
  { key: "day", n: "03", legend: "Your ideal day looks like…", options: [
    { v: "dawn", label: "Lines wet at dawn" }, { v: "anchor", label: "Anchor, swim, repeat" },
    { v: "dinner", label: "Cruise to dinner" }, { v: "overnight", label: "Overnight or multi-day" } ] },
];

// Interactive preview: three questions from the full profile, answered here for a sample match.
export default function HeadingQuiz() {
  const [answers, setAnswers] = useState({});
  const answered = QUESTIONS.filter((question) => answers[question.key]).length;
  const match = scoreHeading(answers);

  return (
    <section className="quiz sand" id="quiz">
      <div className="wrap quiz__grid">
        <aside className="quiz__intro">
          <p className="kicker" data-reveal>Interactive preview</p>
          <h2 data-reveal>Find your <em>heading.</em></h2>
          <p data-reveal>Three questions from the full SoundHeading profile. Choose one answer in each and watch a sample match take shape.</p>
          <p className="demo-note" data-reveal><span className="tag">Demo</span> Illustrative results only{"\u00A0"}— not a recommendation. Your real match draws on your complete buyer profile.</p>
          <figure className="quiz__photo" data-reveal>
            <img src="/site-v2/assets/img/quiz_marina.jpg" alt="Sportfish convertible tied up at a Southeast marina" loading="lazy" width="1100" height="1375" data-parallax=".06" />
          </figure>
        </aside>

        <div className="quiz__card" data-reveal>
          <div className="quiz__top">
            <span className="quiz__label">Your heading</span>
            <span className="quiz__prog"><b>{answered}</b> of 3 answered</span>
          </div>

          <form className="qs" onSubmit={(event) => event.preventDefault()}>
            {QUESTIONS.map((question) => (
              <fieldset className="q" key={question.key}>
                <legend><span>{question.n}</span>{question.legend}</legend>
                <div className="chips">
                  {question.options.map((option) => (
                    <button
                      type="button"
                      className={`chip${answers[question.key] === option.v ? " on" : ""}`}
                      key={option.v}
                      aria-pressed={answers[question.key] === option.v}
                      onClick={() => setAnswers((prev) => ({ ...prev, [question.key]: option.v }))}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </fieldset>
            ))}
          </form>

          <div className="match" aria-live="polite">
            {!match && (
              <div className="match__empty">
                <Icon name="rose" className="match__rose" />
                <p>Answer all three to set a sample heading.</p>
              </div>
            )}
            {match && (
              <div className="match__card">
                <div className="match__head">
                  <div>
                    <span className="match__eyebrow">Sample match <em>· demo</em></span>
                    <h3 className="match__type">{match.type.name}</h3>
                  </div>
                  <div className="match__compass">
                    <Icon name="dial" />
                    <svg className="match__needle" viewBox="0 0 100 100" style={{ transform: `rotate(${match.type.deg}deg)` }}>
                      <path d="M50 10 L55 50 L50 57 L45 50Z" fill="currentColor" />
                      <path d="M50 90 L55 50 L45 50Z" fill="currentColor" opacity=".3" />
                    </svg>
                    <b>{String(match.type.deg).padStart(3, "0")}°</b>
                  </div>
                </div>
                <dl className="match__specs">
                  <div><dt>Length</dt><dd>{match.type.len}</dd></div>
                  <div><dt>Power</dt><dd>{match.type.pow}</dd></div>
                  <div><dt>Watch for</dt><dd>{match.type.watch}</dd></div>
                </dl>
                <div className="match__why">
                  <h4>Why it fits</h4>
                  <ul>{match.why.map((reason, i) => <li key={i}>{reason}</li>)}</ul>
                </div>
                <p className="match__trade"><b>Tradeoff to weigh:</b> <span>{match.type.trade}</span></p>
                <div className="match__foot">
                  <span>Also worth a look: <b>{match.alt.name}</b></span>
                  <a className="btn btn--gold btn--sm" href="#account">Request early access <Icon name="arrow" /></a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}