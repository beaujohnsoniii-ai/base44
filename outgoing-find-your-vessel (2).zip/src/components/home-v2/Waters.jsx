import React, { useState } from "react";

export const HOME_WATER_CARDS = [
  {
    title: "Sandbars",
    img: "sandbar_featured.jpg",
    alt: "Aerial view of boats gathered along a sandbar channel",
    body: "Shallow draft, easy bow boarding, a swim ladder that works and real shade. The boat should make a Saturday easier, not harder.",
  },
  {
    title: "Inshore",
    img: "water_inshore.jpg",
    alt: "Wake behind a single outboard on a tidal creek",
    body: "Creeks, flats and oyster bars at low tide. Draft, hull slap and how she drifts or poles start to matter.",
  },
  {
    title: "Offshore",
    img: "water_offshore.jpg",
    alt: "Sportfish with tower running offshore, seen from another boat",
    body: "Inlet bars, the long run home, and open water. Seakeeping, range, redundancy and fuel capacity lead the list.",
  },
];

// Premium interactive home-water rail — hover expands and lifts the active tile.
export default function Waters() {
  const [active, setActive] = useState(0);

  return (
    <section className="waters sand" id="waters" aria-label="Home waters">
      <div className="wrap">
        <div className="sec-head sec-head--center">
          <p className="kicker" data-reveal>Where you run</p>
          <h2 data-reveal>Coastal and inland <em>waters.</em></h2>
          <p className="sec-head__aside" data-reveal>From sandbars and creeks to the inlet and beyond — the right boat follows the days you actually have.</p>
        </div>
        <div
          className="waters__rail has-active"
          data-reveal
          onMouseLeave={() => setActive(0)}
        >
          {HOME_WATER_CARDS.map((card, i) => (
            <article
              key={card.img}
              className={`wtile${active === i ? " is-active" : ""}`}
              style={{ "--d": i }}
              tabIndex={0}
              aria-expanded={active === i}
              onMouseEnter={() => setActive(i)}
              onFocus={() => setActive(i)}
              onClick={() => setActive(i)}
            >
              <div className="wtile__media" aria-hidden="true">
                <img src={`/site-v2/assets/img/${card.img}`} alt="" loading="lazy" />
              </div>
              <div className="wtile__body">
                <span className="wtile__n">{String(i + 1).padStart(2, "0")}</span>
                <h3>{card.title}</h3>
                <p>{card.body}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
