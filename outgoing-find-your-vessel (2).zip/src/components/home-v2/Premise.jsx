import React from "react";
import Icon from "@/components/home-v2/Icon";

// Premise: lift photo left, work-backward copy right.
export default function Premise() {
  return (
    <section className="premise sand" id="premise">
      <Icon name="rose" className="premise__rose" id="rose" />
      <div className="wrap premise__grid">
        <p className="kicker" data-reveal>The premise</p>
        <h2 className="premise__title" data-reveal>Start with your life, <em>not a listing.</em></h2>

        <div className="premise__lead" data-reveal>
          <figure className="premise__lift">
            <img
              src="/site-v2/assets/img/water_icw.jpg"
              alt="Waterfront home with a boat on a lift along sheltered coastal water"
              loading="lazy"
              data-parallax=".06"
            />
          </figure>
          <div className="premise__copy">
            <p className="lead">Most boat searches start with a listing and work backward. SoundHeading starts with you{"\u00A0"}— where you run, who comes along, how you spend a Saturday{"\u00A0"}— and works forward to the boats that fit.</p>
            <p>No inventory to move. No brand to push. Just a clear heading, and the reasoning behind it.</p>
          </div>
        </div>
      </div>
    </section>
  );
}