import React from "react";

// Icon sheet from the design file: the symbols live in one sprite served with the rest
// of the site v2 assets, referenced by id so <use> keeps the design's currentColor fills.
const SPRITE = "/site-v2/assets/img/sprite.svg";

export default function Icon({ name, className, id }) {
  return (
    <svg className={className} id={id} aria-hidden="true">
      <use href={`${SPRITE}#i-${name}`} />
    </svg>
  );
}