import React, { useState } from "react";
import Icon from "@/components/home-v2/Icon";

const COLUMNS = [
  { title: "Services", links: [["Match", "/match"], ["Explore", "#waters"], ["Analyze", "/boat-analysis"], ["Compare", "/compare"], ["Ownership", "/ownership-calculator"], ["Advisory", "#pricing"]] },
  { title: "Company", links: [["How It Works", "#how"], ["Home waters", "#waters"], ["Contact", "#account"], ["For dealers & partners", "/partners"]] },
  { title: "Account", links: [["My Account", "#account"], ["Request early access", "#account"], ["Captain", "#pricing"]] },
];

// Footer: brand, service columns, and the field-notes sign-up.
export default function SiteFooter() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState(false);

  const subscribe = (event) => {
    event.preventDefault();
    if (!email.trim()) return;
    setMessage(true);
  };

  return (
    <footer className="ftr" id="account">
      <div className="wrap">
        <div className="ftr__top">
          <div className="ftr__brand">
            <a className="brand brand--lg" href="#top" aria-label="SoundHeading home">
              <Icon name="rose" className="brand__star brand__rose" />
              <span className="brand__word">Sound<span className="brand__gap"></span>Heading</span>
            </a>
            <p>Independent vessel acquisition advisory. We chart the course. You pick the boat.</p>
            <div className="apps"><span className="app">App Store <em>placeholder</em></span><span className="app">Google Play <em>placeholder</em></span></div>
          </div>

          <nav className="ftr__cols" aria-label="Footer">
            {COLUMNS.map((column) => (
              <div key={column.title}>
                <h4>{column.title}</h4>
                {column.links.map(([label, href]) => <a key={label} href={href}>{label}</a>)}
              </div>
            ))}
          </nav>

          <form className="news" onSubmit={subscribe}>
            <h4>Field notes</h4>
            <p>Occasional, useful, never salesy.</p>
            <label className="news__row">
              <span className="sr">Email address</span>
              <input type="email" placeholder="Email address" required value={email} onChange={(event) => setEmail(event.target.value)} />
              <button type="submit" aria-label="Subscribe"><Icon name="arrow" /></button>
            </label>
            {message && <p className="news__msg">Demo only{"\u00A0"}— nothing was sent.</p>}
          </form>
        </div>

        <div className="ftr__bot">
          <p>© 2026 SoundHeading. All rights reserved.</p>
          <p className="ftr__links"><a href="#top">Privacy</a><a href="#top">Terms</a><span>Concept build · not for publication</span></p>
        </div>
      </div>
      <Icon name="rose" className="ftr__rose" />
    </footer>
  );
}