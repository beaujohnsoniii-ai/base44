import React from "react";
import { Link } from "react-router-dom";
import Icon from "@/components/home-v2/Icon";

// Hero: one swappable photo (desktop + portrait), the two-line headline, and the live
// compass dial in the bar along the bottom edge. Signed-in visitors get "Open My Helm"
// as the primary action instead of the early-access request (proposal, Oct 22).
export default function Hero({ authed = false }) {
  return (
    <section className="hero hero--full" id="top">
      <div className="hero__media" id="hero-image" style={{ "--fx": "60%", "--fy": "46%", "--fy-m": "100%" }}>
        <picture>
          <source media="(max-width:760px)" srcSet="/site-v2/assets/img/hero_full_m.jpg" width="1080" height="2451" />
          <img
            src="/site-v2/assets/img/hero_full.jpg"
            alt="A white offshore center console with outriggers and T-top drifting on calm blue water, crew fishing from the cockpit"
            width="2560"
            height="1440"
          />
        </picture>
      </div>
      <div className="hero__shade" aria-hidden="true"></div>

      <div className="hero__body wrap">
        <p className="eyebrow hero__eyebrow"><span>Boats</span><i></i><span>Expertise</span><i></i><span>Real-World Insight</span></p>
        <h1 className="hero__title">
          <span className="ln"><span>We chart the course.</span></span>
          <span className="ln"><span><em>You pick the boat.</em></span></span>
        </h1>
        <p className="hero__sub">Let us guide you to the boat that suits your lifestyle!</p>
        <div className="hero__cta">
          {authed
            ? <Link className="btn btn--gold" to="/helm">Open My Helm <Icon name="arrow" /></Link>
            : <a className="btn btn--gold" href="#account">Request early access <Icon name="arrow" /></a>}
          <a className="btn btn--ghost" href="#how">How it works</a>
        </div>
      </div>

      <div className="hero__foot wrap" aria-hidden="true">
        <div className="hdg">
          <span className="hdg__dial">
            <Icon name="dial" />
            <svg className="hdg__needle" id="needle" viewBox="0 0 100 100">
              <path d="M50 12 L54 50 L50 56 L46 50Z" fill="currentColor" />
              <path d="M50 88 L54 50 L46 50Z" fill="currentColor" opacity=".35" />
            </svg>
          </span>
          <span className="hdg__txt">Heading <b id="hdgval">000°</b></span>
        </div>
        <div className="hero__scroll"><span>Scroll</span><i></i></div>
        <p className="hero__loc">US coasts and inland waters</p>
      </div>
    </section>
  );
}