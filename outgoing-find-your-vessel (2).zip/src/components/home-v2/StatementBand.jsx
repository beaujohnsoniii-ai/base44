import React from "react";
import Pricing from "@/components/home-v2/Pricing";

// Full-bleed membership band — the packages laid over the dynamic wake photo.
export default function StatementBand() {
  return (
    <section className="band band--packages" id="pricing" aria-label="Membership packages">
      <div className="band__media">
        <img src="/site-v2/assets/img/band_dawn_wake.jpg" alt="" loading="lazy" data-parallax=".18" />
      </div>
      <div className="band__in band__in--packages wrap">
        <Pricing />
      </div>
    </section>
  );
}