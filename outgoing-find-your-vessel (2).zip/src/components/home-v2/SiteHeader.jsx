import React from "react";
import { Link } from "react-router-dom";
import Icon from "@/components/home-v2/Icon";

// Design's white header bar: v16 badge at the left, the three centred links, and the
// account slot at the far right — Log Out once signed in, Sign In otherwise. Under 1024px
// the links collapse into the full-screen menu.
export default function SiteHeader({ authed, menuOpen, onToggleMenu, onLogout }) {
  const accountHref = authed ? "/helm" : "/login?returnTo=%2Fhelm";
  const close = () => onToggleMenu(false);

  return (
    <>
      <header className="hdr hdr--white" id="hdr">
        <div className="hdr__in">
          <a className="brand brand--logo" id="logo" href="#top" aria-label="SoundHeading home">
            <picture>
              <source type="image/svg+xml" srcSet="/site-v2/assets/img/logo_v16.svg" />
              <source type="image/webp" srcSet="/site-v2/assets/img/logo_v16.webp" />
              <img
                className="brand__logo"
                src="/site-v2/assets/img/logo_v16.png"
                alt="SoundHeading — Independent Vessel Acquisition Advisory"
                width="326"
                height="160"
                decoding="async"
                fetchPriority="high"
              />
            </picture>
          </a>

          <nav className="nav" aria-label="Primary">
            <a href="#premise">About</a>
            <a href="#how">Approach</a>
            <a href="#waters">Resources</a>
          </nav>

          <div className="hdr__auth">
            <Link className="hdr__out hdr__acctlink" to={accountHref}>My Account</Link>
            <span className="hdr__div" aria-hidden="true"></span>
            {authed
              ? <button type="button" className="hdr__out auth-in" onClick={onLogout}>Log Out</button>
              : <Link className="hdr__out auth-out" to="/login?returnTo=%2Fhelm">Sign In</Link>}
          </div>

          <button className="burger" id="burger" aria-label="Open menu" aria-expanded={menuOpen} aria-controls="menu" onClick={() => onToggleMenu(!menuOpen)}>
            <span></span><span></span>
          </button>
        </div>
      </header>

      <div className="menu" id="menu" aria-hidden={!menuOpen}>
        <nav className="menu__nav" aria-label="Mobile">
          <a href="#premise" onClick={close}><small>01</small>About</a>
          <a href="#how" onClick={close}><small>02</small>Approach</a>
          <a href="#waters" onClick={close}><small>03</small>Resources</a>
          <Link to={accountHref} onClick={close}><small>04</small>My Account</Link>
          {authed
            ? <button type="button" className="auth-in" onClick={() => { close(); onLogout(); }}><small>05</small>Log Out</button>
            : <Link className="auth-out" to="/login?returnTo=%2Fhelm" onClick={close}><small>05</small>Sign In</Link>}
        </nav>
        <Icon name="rose" className="menu__rose" />
      </div>
    </>
  );
}