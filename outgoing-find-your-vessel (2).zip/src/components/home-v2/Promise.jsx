import React from "react";

const VOWS = [
  { n: "i.", title: "Nothing to sell you", body: "We don’t own, list or broker inventory. There’s no boat we need to move." },
  { n: "ii.", title: "Reasons, shown", body: "Every recommendation comes with the why\u00A0— and what you give up." },
  { n: "iii.", title: "Your profile is yours", body: "We don’t sell your information to dealers, brokers or builders." },
  { n: "iv.", title: "Plain about money", body: "If anything we recommend could ever pay us, you’ll be told up front." },
];

// The independence promise: who SoundHeading answers to.
export default function Promise() {
  return (
    <section className="promise navy" id="promise">
      <div className="wrap promise__grid">
        <figure className="promise__photo" data-reveal>
          <img src="/site-v2/assets/img/water_icw.jpg" alt="Waterfront homes with boat lifts along the Intracoastal Waterway" loading="lazy" data-parallax=".07" />
          <figcaption>Waterfront homes and boat lifts</figcaption>
        </figure>
        <div className="promise__copy">
          <p className="kicker" data-reveal>The independence promise</p>
          <h2 data-reveal>We answer to the buyer. <em>Only the buyer.</em></h2>
          <ol className="vows">
            {VOWS.map((vow) => (
              <li data-reveal key={vow.n}>
                <span>{vow.n}</span>
                <div><h3>{vow.title}</h3><p>{vow.body}</p></div>
              </li>
            ))}
          </ol>
          <p className="draft-note" data-reveal><span className="tag tag--dark">Draft</span> Commitment wording for SoundHeading to confirm before launch.</p>
        </div>
      </div>
    </section>
  );
}