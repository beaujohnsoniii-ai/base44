import React from "react";
import Icon from "@/components/home-v2/Icon";
import { TIERS as DISPLAY_TIERS } from "@/lib/tiers";
import { PLAN_TIERS } from "@/lib/stages";

// Display only. Early-access links do not start checkout or change entitlement.
const BENEFITS = {
  free: ["Four illustrative example results", "Boat types that show how SoundHeading works", "Edit your buyer profile as your needs change"],
  match_plus: ["A 10–14-model research pool", "No models marked as recommendations at this level", "Deeper questions and your prior Likes inform the research"],
  refined_match: ["The full 10–14-model pool, re-ranked", "Leading 5–7 models marked as recommendations", "Deeper constraints and deal-breakers applied"],
  market_match: ["The full model pool remains visible", "Top 3 models marked as finalists", "Reasons for each finalist recommendation"],
};
export const MEMBERSHIP_TIERS = DISPLAY_TIERS.map(tier => {
  const paid = PLAN_TIERS.find(packageInfo => packageInfo.id === tier.id);
  return {
    id: tier.id, title: tier.name, price: tier.price === 0 ? "Free" : tier.priceLabel,
    featured: tier.id === "market_match",
    items: [...BENEFITS[tier.id], ...(paid ? [`${paid.updates} matching updates within ${paid.accessDays} days`] : [])],
  };
});

// Membership packages block — rendered inside the homepage band, over its photo.
export default function Pricing() {
  return (
    <div className="packages">
      <div className="sec-head sec-head--center">
        <p className="kicker" data-reveal>Membership</p>
        <h2 className="pricing__title" data-reveal>Membership packages. <em>Clear steps, honest research.</em></h2>
        <p className="sec-head__aside" data-reveal>Start with four free examples. Go deeper when you’re ready.</p>
      </div>
      <div className="tiers tiers--four">
        {MEMBERSHIP_TIERS.map((tier, i) => (
          <article className="tier tier--feat tier--gold" key={tier.id} data-reveal style={{ "--d": i }}>
            <h3>{tier.title}</h3>
            <p className="tier__price"><span>{tier.price}</span>{tier.id !== "free" && <small>one-time package</small>}</p>
            <ul>{tier.items.map(item => <li key={item}>{item}</li>)}</ul>
            <a className="btn btn--gold" href="#account">Request early access <Icon name="arrow" /></a>
          </article>
        ))}
      </div>
      <p className="pricing__promise" data-reveal><Icon name="star" /><span>Examples are illustrative, not verified model recommendations. Paid research may return fewer models when too few qualify. Checkout is not open; no payment is taken here.</span></p>
    </div>
  );
}