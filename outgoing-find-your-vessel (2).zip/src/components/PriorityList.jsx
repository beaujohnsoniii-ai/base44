import React, { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ChevronUp, ChevronDown, X, Plus, GripVertical } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

// An ordered list builder: tap quick-pick chips or type custom items, then
// rank them by drag-and-drop or up/down arrows. Value is stored as an ordered
// comma-separated string (order = priority, most important first).
export default function PriorityList({ label, hint, chips = [], value, onChange, placeholder }) {
  const items = (value || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const [draft, setDraft] = useState("");

  const add = (phrase) => {
    if (!phrase || items.some((i) => i.toLowerCase() === phrase.toLowerCase())) return;
    onChange([...items, phrase].join(", "));
  };
  const remove = (idx) => {
    const next = items.filter((_, i) => i !== idx);
    onChange(next.join(", "));
  };
  const move = (idx, dir) => {
    const j = idx + dir;
    if (j < 0 || j >= items.length) return;
    const next = [...items];
    [next[idx], next[j]] = [next[j], next[idx]];
    onChange(next.join(", "));
  };
  const onDragEnd = (result) => {
    if (!result.destination || result.destination.index === result.source.index) return;
    const next = [...items];
    const [moved] = next.splice(result.source.index, 1);
    next.splice(result.destination.index, 0, moved);
    onChange(next.join(", "));
  };

  return (
    <div>
      <Label>{label}</Label>
      {hint && <p className="text-xs text-muted-foreground mb-2">{hint}</p>}
      <div className="flex flex-wrap gap-2 mb-3">
        {chips.map((c) => {
          const active = items.some((i) => i.toLowerCase() === c.toLowerCase());
          return (
            <button
              key={c}
              type="button"
              onClick={() => (active ? remove(items.findIndex((i) => i.toLowerCase() === c.toLowerCase())) : add(c))}
              className={`text-xs rounded-full border px-3 py-1 transition ${
                active ? "border-accent bg-accent/10 text-accent" : "border-border text-muted-foreground hover:border-accent/50"
              }`}
            >
              {c}
            </button>
          );
        })}
      </div>
      <div className="flex gap-2 mb-3">
        <Input
          value={draft}
          placeholder={placeholder}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              add(draft.trim());
              setDraft("");
            }
          }}
        />
        <button
          type="button"
          onClick={() => {
            add(draft.trim());
            setDraft("");
          }}
          className="shrink-0 inline-flex items-center gap-1 rounded-md border border-border px-3 text-sm hover:border-accent/50"
        >
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>
      {items.length > 0 && (
        <DragDropContext onDragEnd={onDragEnd}>
          <Droppable droppableId="priority-list">
            {(provided) => (
              <ol className="space-y-1.5" ref={provided.innerRef} {...provided.droppableProps}>
                {items.map((it, idx) => (
                  <Draggable key={`${it}-${idx}`} draggableId={`${it}-${idx}`} index={idx}>
                    {(dragProvided, snapshot) => (
                      <li
                        ref={dragProvided.innerRef}
                        {...dragProvided.draggableProps}
                        className={`flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 transition ${
                          snapshot.isDragging ? "shadow-md border-accent/40" : ""
                        }`}
                      >
                        <span
                          {...dragProvided.dragHandleProps}
                          className="cursor-grab active:cursor-grabbing text-muted-foreground/40 hover:text-muted-foreground touch-none"
                          aria-label="Drag to reorder"
                        >
                          <GripVertical className="w-4 h-4" />
                        </span>
                        <span className="grid place-items-center w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-semibold">
                          {idx + 1}
                        </span>
                        <span className="flex-1 text-sm">{it}</span>
                        <button type="button" onClick={() => move(idx, -1)} disabled={idx === 0} className="p-1 rounded hover:bg-muted disabled:opacity-30">
                          <ChevronUp className="w-4 h-4" />
                        </button>
                        <button type="button" onClick={() => move(idx, 1)} disabled={idx === items.length - 1} className="p-1 rounded hover:bg-muted disabled:opacity-30">
                          <ChevronDown className="w-4 h-4" />
                        </button>
                        <button type="button" onClick={() => remove(idx)} className="p-1 rounded hover:bg-muted text-destructive">
                          <X className="w-4 h-4" />
                        </button>
                      </li>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </ol>
            )}
          </Droppable>
        </DragDropContext>
      )}
    </div>
  );
}