import React from "react";
import { CheckCircle2, Circle, Sparkles } from "lucide-react";

// The buyer's progress through the packages: Free Discovery → MATCH+ → Refined Match →
// Market Match. Each milestone lights up when the buyer reaches it.
export default function StageTracker({ plan = "free", hasProfile = false, hasCandidates = false, hasFeedback = false, hasTeaser = false }) {
  const stages = [
    { id: "profile", name: "Buyer profile", sub: "Free", done: hasProfile },
    { id: "candidates", name: "Saved candidates", sub: "Free", done: hasCandidates },
    { id: "teaser", name: "Your matches", sub: "Paid", done: hasTeaser || hasFeedback },
    { id: "match_plus", name: "Bosun", sub: "$9", done: plan === "match_plus" || plan === "initial_boat_match" || plan === "refined_match" || plan === "market_match" || plan === "buyer_pass", main: false },
    { id: "refined_match", name: "First Mate", sub: "$29", done: plan === "refined_match" || plan === "market_match" || plan === "buyer_pass", main: false },
    { id: "market_match", name: "Captain", sub: "$99", done: plan === "market_match" || plan === "buyer_pass", main: true },
  ];

  return (
    <ol className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      {stages.map((s, i) => (
        <li
          key={s.id}
          className={`rounded-lg border p-3 ${s.done ? "border-accent bg-accent/5" : "border-border bg-card"}`}
        >
          <div className="flex items-center gap-2">
            {s.done ? (
              <CheckCircle2 className="w-5 h-5 text-accent" />
            ) : s.main ? (
              <Sparkles className="w-5 h-5 text-accent" />
            ) : (
              <Circle className="w-5 h-5 text-muted-foreground" />
            )}
            <span className="text-xs text-muted-foreground">{s.sub}</span>
          </div>
          <p className="text-sm font-medium mt-1">{s.name}</p>
        </li>
      ))}
    </ol>
  );
}