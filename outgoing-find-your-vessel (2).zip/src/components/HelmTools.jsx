import React from "react";
import { Link } from "react-router-dom";
import { ShipWheel, ScrollText, Gauge } from "lucide-react";
import { isPaidPlan } from "@/lib/stages";

const TOOLS = [
  { id: "report", label: "Match report", body: "Review your model recommendations.", Icon: ScrollText },
  { id: "compare", label: "Compare", body: "See models side by side.", Icon: ShipWheel },
  { id: "ownership", label: "True cost of ownership", body: "Plan beyond the purchase price.", Icon: Gauge },
];

// Use the existing report and its existing paid-tier gate.
// Compare and ownership remain inactive; no new service or entitlement is added.
export default function HelmTools({ plan = "free" }) {
  const reportAvailable = isPaidPlan(plan);
  return <>
    <h2 className="font-heading text-xl">Tools</h2>
    <ul>
      {TOOLS.map(({ id, label, body, Icon }) => {
        const available = id === "report" && reportAvailable;
        const status = id === "report" ? (available ? "View report" : "From Bosun") : "Coming soon";
        const content = <>
          <span className="sh-helm-tool__instrument" aria-hidden="true"><Icon /></span>
          <span className="sh-helm-tool__copy">
            <strong>{label}</strong>
            <span className="sh-helm-tool__description" id={`helm-tool-${id}-description`}>{id === "report" && !reportAvailable ? "Specific-model reports start at Bosun." : body}</span>
            <span className="sh-helm-tool__status">{status}</span>
          </span>
        </>;
        return <li key={id}>
          {available
            ? <Link className="sh-helm-tool sh-helm-tool--available" to="/report/find-my-boat" aria-label="Open Match report" aria-describedby={`helm-tool-${id}-description`}>{content}</Link>
            : <button type="button" className="sh-helm-tool" disabled aria-disabled="true" aria-label={`${label}. ${status}.`} aria-describedby={`helm-tool-${id}-description`} title={id === "report" ? "Match reports are included from Bosun." : `${label} is coming soon and is not available yet.`}>{content}</button>}
        </li>;
      })}
    </ul>
  </>;
}
