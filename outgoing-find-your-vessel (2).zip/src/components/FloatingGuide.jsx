import React, { useEffect, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import * as Dialog from "@radix-ui/react-dialog";
import { Compass, ArrowUp, X, Sparkles } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { base44 } from "@/api/base44Client";
import GuideLauncher from "@/components/GuideLauncher";
import "@/components/guide-panel.css";

const LIMIT = 600;
const PROMPTS = [
 { label: "Why this match?", text: "Help me understand my strongest match. Which saved evidence supports it, and what is still unknown?" },
 { label: "See trade-offs", text: "Help me think through the trade-offs between my model recommendations. Flag any evidence you cannot access." },
 { label: "What if my budget changes?", text: "Help me explore a budget change without changing my profile or matches. What would we need to verify?" },
];

// Reviewed presentation on the app's EXISTING stage_guide connection. No demo
// fixtures, provider setup, entitlement changes or automatic requests are added.
export default function FloatingGuide() {
 const location=useLocation();
 const {pathname}=location;
 const {user,isAuthenticated}=useAuth();
 const [open,setOpen]=useState(false),[conversation,setConversation]=useState(null),[messages,setMessages]=useState([]),[input,setInput]=useState(""),[busy,setBusy]=useState(false),[error,setError]=useState("");
 const end=useRef(null),launcher=useRef(null),field=useRef(null),heading=useRef(null),lock=useRef(false),identity=useRef(0);
 useEffect(()=>{identity.current+=1;setConversation(null);setMessages([]);setInput("");setOpen(false);setError("");lock.current=false;setBusy(false);},[user?.id,isAuthenticated]);
 useEffect(()=>{setOpen(false);},[location.key]);
 useEffect(()=>{
  if(!isAuthenticated||!conversation?.id)return;
  const subscribedIdentity=identity.current;
  return base44.agents.subscribeToConversation(conversation.id,data=>{if(subscribedIdentity===identity.current)setMessages(data.messages||[]);});
 },[conversation?.id,isAuthenticated]);
 useEffect(()=>{if(open)end.current?.scrollIntoView({block:"nearest"});},[messages,open]);
 const close=()=>setOpen(false);
 async function send(e){
  e.preventDefault(); const text=input.trim();if(!text||lock.current||!isAuthenticated)return;
  if(text.length>LIMIT){setError(`Keep your question to ${LIMIT} characters.`);return;}
  const requestIdentity=identity.current;
  lock.current=true;setBusy(true);setError("");
  let sent=false;
  try {
   let conv=conversation;
   if(!conv){
    const existing=await base44.agents.listConversations({q:{agent_name:"stage_guide"},sort:"-updated_date",limit:1});
    if(requestIdentity!==identity.current)return;
    conv=existing?.[0]?await base44.agents.getConversation(existing[0].id):await base44.agents.createConversation({agent_name:"stage_guide",metadata:{name:"Sound Heading Guide"}});
    if(requestIdentity!==identity.current)return;
    setConversation(conv);setMessages(conv.messages||[]);
   }
   await base44.agents.addMessage(conv,{role:"user",content:text,custom_context:[{type:"page_context",message:"Current Sound Heading page. Context is not proof of listing facts or paid entitlement.",data:{path:pathname}}]});
   if(requestIdentity!==identity.current)return;
   sent=true;setInput("");
   const updated=await base44.agents.getConversation(conv.id);
   if(requestIdentity===identity.current)setMessages(updated.messages||[]);
  }catch(e){if(requestIdentity===identity.current)setError(sent?"Your question was sent, but the reply could not be refreshed. Please wait before sending it again.":"Guide could not send your message. Your text is still here; please try again.");}
  finally{if(requestIdentity===identity.current){lock.current=false;setBusy(false);}}
 }
 if(/^\/(admin|login|register|forgot-password|reset-password)/.test(pathname))return null;
 return <Dialog.Root open={open} onOpenChange={setOpen}>
  <GuideLauncher launcherRef={launcher} open={open} onToggle={()=>setOpen(value=>!value)} onClose={close}/>
  <Dialog.Portal>
   <Dialog.Overlay className="sh-guide-overlay"/>
   <Dialog.Content id="floating-guide" className="sh-guide-panel" onOpenAutoFocus={event=>{event.preventDefault();heading.current?.focus();}} onCloseAutoFocus={event=>{event.preventDefault();launcher.current?.focus();}}>
    <header className="sh-guide-header">
     <span className="sh-guide-emblem" aria-hidden="true"><Compass/></span>
     <div><Dialog.Title ref={heading} tabIndex={-1}>Guide</Dialog.Title><p>A clearer view of your matches</p></div>
     <Dialog.Close className="sh-guide-close" aria-label="Close Guide"><X aria-hidden="true"/></Dialog.Close>
    </header>
    <Dialog.Description className="sh-guide-notice"><Sparkles aria-hidden="true"/><span>Ask about your saved profile and next step. Guide should flag missing evidence; advice is not verification of a boat or listing.</span></Dialog.Description>
    <div className="sh-guide-content">
     <div className="sh-guide-welcome"><h3>Let’s make sense of your matches.</h3><p>Start with what matters to you. Choosing a question below fills the box; nothing is sent until you press Send.</p></div>
     {isAuthenticated&&<div className="sh-guide-prompts" aria-label="Suggested questions">{PROMPTS.map(prompt=><button key={prompt.label} type="button" disabled={busy} onClick={()=>{setInput(prompt.text);setError("");field.current?.focus();}}>{prompt.label}</button>)}</div>}
     <div className="sh-guide-conversation" role="log" aria-label="Guide conversation" aria-live="polite" aria-relevant="additions">
      {isAuthenticated&&messages.filter(m=>!m.hidden&&["user","assistant"].includes(m.role)&&typeof m.content==="string").map((m,i)=><div className="sh-guide-exchange" key={m.id||i}>{m.role==="user"?<p className="sh-guide-question"><span className="sr-only">You: </span>{m.content}</p>:<div className="sh-guide-answer"><p className="sh-guide-answer-label">Guide</p><p style={{whiteSpace:"pre-wrap"}}>{m.content}</p></div>}</div>)}
      {busy&&<p role="status">Guide is responding…</p>}
     </div><div ref={end}/>
    </div>
    {isAuthenticated?<form className="sh-guide-composer" onSubmit={send}>
     <label htmlFor="guide-question" className="sr-only">Message Guide</label>
     <div className="sh-guide-input-row"><input id="guide-question" ref={field} disabled={busy} value={input} onChange={e=>setInput(e.target.value)} maxLength={LIMIT} autoComplete="off" placeholder="Ask Guide…" aria-describedby="guide-send-note"/><button type="submit" disabled={busy||!input.trim()} aria-label="Send question"><ArrowUp aria-hidden="true"/><span>Send</span></button></div>
     {error&&<p className="sh-guide-error" role="alert">{error}</p>}
     <p id="guide-send-note">Your existing Guide conversation <span>{input.length}/{LIMIT}</span></p>
    </form>:<Link style={{padding:16,textDecoration:"underline"}} to={"/login?returnTo="+encodeURIComponent(pathname)}>Sign in to talk with Guide</Link>}
   </Dialog.Content>
  </Dialog.Portal>
 </Dialog.Root>;
}
