import React, { useMemo } from "react";
import { apportionActivityWeights } from "@/lib/activityWeights";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

// Parchment-toned palette for the pie slices — restrained, Heritage-appropriate.
// The largest share gets the brass accent; the rest get muted parchment tones.
const PARCHMENT_TONES = [
  "#d4c5a9", "#c9b896", "#bdaa83", "#b09c72", "#a38e62",
  "#967f52", "#897145", "#7c6338",
];
const BRASS = "#b08d57";

// ActivityWeightPie — a live pie chart with per-activity sliders.
// When the buyer moves a slider, the remaining slices normalize proportionally
// so the total always sums to 100. If only one activity is selected, it is
// weighted 100% automatically and the chart is skipped.
export default function ActivityWeightPie({ activities, weights, onChange }) {
  const acts = Array.isArray(activities) ? activities : [];
  const w = weights || {};

  // Also correct any historical weights before showing or editing them.
  const normalized = useMemo(() => apportionActivityWeights(acts, w), [acts, w]);

  const chartData = acts.map((a) => ({ name: a, value: normalized[a] || 0 }));
  const maxIdx = chartData.reduce((best, d, i) => (d.value > (chartData[best]?.value || 0) ? i : best), 0);

  const handleSlider = (activity, rawValue) => {
    const newVal = Math.max(0, Math.min(100, Math.round(rawValue)));
    if (acts.length <= 1) {
      onChange({ [activity]: 100 });
      return;
    }
    const others = acts.filter((a) => a !== activity);
    const otherWeights = apportionActivityWeights(others, normalized, 100 - newVal);
    onChange({ ...otherWeights, [activity]: newVal });
  };

  if (acts.length === 0) return null;
  if (acts.length === 1) {
    return (
      <div className="rounded-lg border border-border bg-parchment/30 p-4">
        <p className="text-sm text-muted-foreground">
          You selected <span className="font-medium text-foreground">{acts[0]}</span> — that's 100% of your time on the water.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-border bg-parchment/30 p-4 space-y-4">
      <div>
        <p className="text-sm font-medium font-serif mb-1">Which activities matter most?</p>
        <p className="text-xs text-muted-foreground">
          Give your main activity the largest share of your time on the water. Leave the shares equal if they matter equally. Your choices are saved with your profile for paid Match.
        </p>
      </div>
      <div className="flex flex-col sm:flex-row gap-4 items-center">
        <div className="w-40 h-40 shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={36}
                outerRadius={72}
                paddingAngle={1}
                stroke="hsl(var(--background))"
                strokeWidth={2}
              >
                {chartData.map((_, i) => (
                  <Cell key={i} fill={i === maxIdx ? BRASS : PARCHMENT_TONES[i % PARCHMENT_TONES.length]} />
                ))}
              </Pie>
              <Tooltip
                formatter={(v) => `${v}%`}
                contentStyle={{
                  background: "hsl(var(--popover))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                  fontSize: "0.75rem",
                  fontFamily: "var(--font-serif)",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex-1 w-full space-y-3">
          {acts.map((a, i) => (
            <div key={a} className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-sm font-serif">
                  <span
                    className="inline-block w-2.5 h-2.5 rounded-full"
                    style={{ background: i === maxIdx ? BRASS : PARCHMENT_TONES[i % PARCHMENT_TONES.length] }}
                  />
                  {a}
                </span>
                <span className="text-xs text-muted-foreground tabular-nums">{normalized[a] || 0}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={normalized[a] || 0}
                onChange={(e) => handleSlider(a, Number(e.target.value))}
                className="w-full accent-brass"
                aria-label={`${a} weight`}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}