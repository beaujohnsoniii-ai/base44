import React, { useEffect, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import Icon from "@/components/home-v2/Icon";
import { HELM_PATH } from "@/lib/tiers";
import "@/components/site-header.css";

// The header from site_v2/index.html, on every app page: a full-width white bar, the
// v16 logo directly at the top left (no card behind it), About / Approach / Resources
// at the true centre, and My Account then Log Out (Sign In when signed out) at the far
// right. Same markup and class names as the design; the rules live in site-header.css,
// scoped under .sh-site. Under 1024px the links fold into the design's full-screen menu.
// Like site.js, the bar turns solid after 40px and hides on a long scroll down.
const LINKS = [["About", "/#promise"], ["Approach", "/#how"], ["Resources", "/#journal"]];

export default function AppHeader() {
  const { isAuthenticated: authed, logout } = useAuth();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [solid, setSolid] = useState(false);
  const [hidden, setHidden] = useState(false);
  const lastY = useRef(0);

  const here = location.pathname + location.search;
  const authPage = /^\/(login|register|forgot-password|reset-password)/.test(location.pathname);
  const signInHref = "/login?returnTo=" + encodeURIComponent(authPage || here === "/" ? HELM_PATH : here);
  const accountHref = authed ? "/helm" : "/login?returnTo=%2Fhelm";

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setSolid(y > 40);
      if (y < lastY.current - 2 || y < 640) setHidden(false);
      else if (y > lastY.current + 2) setHidden(true);
      lastY.current = y;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [menuOpen]);

  useEffect(() => { setMenuOpen(false); }, [location.pathname]);

  const close = () => setMenuOpen(false);
  const hdrClass = "hdr hdr--white" + (solid || menuOpen ? " is-solid" : "") + (hidden && !menuOpen ? " is-hidden" : "");

  return (
    <div className={"sh-site" + (menuOpen ? " menu-open" : "")}>
      <header className={hdrClass} id="hdr">
        <div className="hdr__in">
          <Link className="brand brand--logo" id="logo" to="/" aria-label="SoundHeading home">
            <picture>
              <source type="image/svg+xml" srcSet="/site-v2/assets/img/logo_v16.svg" />
              <source type="image/webp" srcSet="/site-v2/assets/img/logo_v16.webp" />
              <img className="brand__logo" src="/site-v2/assets/img/logo_v16.svg" alt="SoundHeading — Independent Vessel Acquisition Advisory" width="326" height="160" decoding="async" fetchPriority="high" />
            </picture>
          </Link>

          <nav className="nav" aria-label="Primary">
            {LINKS.map(([label, href]) => <a key={label} href={href}>{label}</a>)}
          </nav>

          <div className="hdr__auth">
            <Link className="hdr__out hdr__acctlink" to={accountHref}>My Account</Link>
            <span className="hdr__div" aria-hidden="true"></span>
            {authed
              ? <button type="button" className="hdr__out auth-in" onClick={() => logout()}>Log Out</button>
              : <Link className="hdr__out auth-out" to={signInHref}>Sign In</Link>}
          </div>

          <button className="burger" id="burger" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen} aria-controls="menu" onClick={() => setMenuOpen(!menuOpen)}>
            <span></span><span></span>
          </button>
        </div>
      </header>

      <div className="menu" id="menu" aria-hidden={!menuOpen}>
        <nav className="menu__nav" aria-label="Mobile">
          {LINKS.map(([label, href], i) => <a key={label} href={href} onClick={close}><small>0{i + 1}</small>{label}</a>)}
          <Link to={accountHref} onClick={close}><small>04</small>My Account</Link>
          {authed
            ? <button type="button" className="auth-in" onClick={() => { close(); logout(); }}><small>05</small>Log Out</button>
            : <Link className="auth-out" to={signInHref} onClick={close}><small>05</small>Sign In</Link>}
        </nav>
        <Icon name="rose" className="menu__rose" id="app-menu-rose" />
      </div>
      <div className="sh-site__spacer" aria-hidden="true" />
    </div>
  );
}
