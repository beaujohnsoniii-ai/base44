import React from "react";
import {Link} from "react-router-dom";
import {journeyPaths,journeyStages} from "@/lib/journey";
import "@/components/dashboard.css";
import "@/components/journey-icons.css";
import "@/components/journey-shell.css";

// Uses the existing Match hero, artwork and navigation template.
export default function JourneyHeader({stage,intro}){
 return <>
  <header className="sh-dashboard-hero"><div><h1 className="font-display text-3xl md:text-4xl">{stage}</h1><p className="text-sm leading-relaxed">{intro}</p></div></header>
  <nav className="sh-journey-nav" aria-label="Your boat-buying journey">{journeyStages.map(x=><Link key={x} to={journeyPaths[x]} aria-current={x===stage?"page":undefined} className="sh-art-button" style={{"--icon-scale":x==="Analyze"?1.125:1}}><img className="sh-icon-art" src={"/images/journey/"+x.toLowerCase()+".webp"} alt="" width="360" height="360"/><span>{x}</span></Link>)}</nav>
 </>;
}
