import React, { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Check, X, Search, Plus } from "lucide-react";
import { base44 } from "@/api/base44Client";

// Multi-select of brand / manufacturer names the buyer keeps high on their list.
// The curated brand list is NOT auto-populated — it loads only after the buyer
// focuses the search field, so the last question stays light until they engage.
// Buyers can also add any custom brand name. Value is an array of strings.
export default function ManufacturerPicker({ value = [], onChange }) {
  const [pool, setPool] = useState([]);
  const [poolLoaded, setPoolLoaded] = useState(false);
  const [poolLoading, setPoolLoading] = useState(false);
  const [query, setQuery] = useState("");
  const [custom, setCustom] = useState("");
  const [activated, setActivated] = useState(false);

  const loadPool = () => {
    if (poolLoaded || poolLoading) return;
    setPoolLoading(true);
    base44.entities.Manufacturer.list("name", 600)
      .then((rows) =>
        setPool((rows || []).map((m) => m.name).filter(Boolean).sort((a, b) => a.localeCompare(b)))
      )
      .catch(() => setPool([]))
      .finally(() => {
        setPoolLoaded(true);
        setPoolLoading(false);
      });
  };

  const selected = Array.isArray(value) ? value : [];
  const isSelected = (name) =>
    selected.some((s) => s.toLowerCase() === name.toLowerCase());

  const toggle = (name) => {
    if (!name) return;
    if (isSelected(name)) {
      onChange(selected.filter((s) => s.toLowerCase() !== name.toLowerCase()));
    } else {
      onChange([...selected, name]);
    }
  };

  const addCustom = () => {
    const name = custom.trim();
    if (!name) return;
    toggle(name);
    setCustom("");
  };

  const q = query.trim().toLowerCase();
  const filtered = q ? pool.filter((n) => n.toLowerCase().includes(q)) : pool;
  const shown = filtered.slice(0, 80);

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="brand-search">Search brands</Label>
        <div className="relative mt-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            id="brand-search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => {
              setActivated(true);
              loadPool();
            }}
            placeholder="e.g. Boston Whaler, Grady-White, Bay Rider"
            className="pl-9"
          />
        </div>
      </div>

      {selected.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {selected.map((name) => (
            <span
              key={name}
              className="inline-flex items-center gap-1 rounded-full border border-accent bg-accent/10 text-accent text-xs px-3 py-1"
            >
              {name}
              <button
                type="button"
                onClick={() => toggle(name)}
                className="ml-0.5 hover:text-accent/70"
                aria-label={`Remove ${name}`}
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>
      )}

      {activated ? (
        <div className="max-h-64 overflow-y-auto rounded-md border border-border divide-y divide-border">
          {poolLoading ? (
            <p className="p-3 text-sm text-muted-foreground">Loading brands…</p>
          ) : shown.length === 0 ? (
            <p className="p-3 text-sm text-muted-foreground">
              No matching brands. Add a custom one below.
            </p>
          ) : (
            shown.map((name) => {
              const active = isSelected(name);
              return (
                <button
                  key={name}
                  type="button"
                  onClick={() => toggle(name)}
                  className={`flex items-center justify-between w-full text-left px-3 py-2 text-sm transition ${
                    active ? "bg-accent/10 text-accent" : "hover:bg-muted"
                  }`}
                >
                  {name}
                  {active && <Check className="w-4 h-4" />}
                </button>
              );
            })
          )}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">
          Click into the search box to browse the curated brand list, or add a brand yourself below.
        </p>
      )}

      <div className="flex gap-2">
        <Input
          value={custom}
          placeholder="Add a brand not listed"
          onChange={(e) => setCustom(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              addCustom();
            }
          }}
        />
        <button
          type="button"
          onClick={addCustom}
          className="shrink-0 inline-flex items-center gap-1 rounded-md border border-border px-3 text-sm hover:border-accent/50"
        >
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>
    </div>
  );
}