import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Sparkles, RefreshCw, AlertCircle, CheckCircle2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function PreliminaryFeedback({ existing, hasProfile, candidateCount = 0, onRefreshed }) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState(existing?.content || null);
  const hasEnough = candidateCount >= 3;

  const generate = async () => {
    if (!hasProfile) {
      toast({ title: "Complete your buyer profile first", variant: "destructive" });
      return;
    }
    if (!hasEnough) {
      toast({ title: "Save at least 3 candidate boats first", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const res = await base44.functions.invoke("generate-advisory", { type: "preliminary" });
      setFeedback(res?.data?.report?.content || null);
      onRefreshed?.(res?.data?.report);
    } catch (e) {
      toast({ title: "Could not generate feedback", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-accent" /> Preliminary Feedback
            </CardTitle>
            <CardDescription>Free — we confirm your priorities, flag missing info, and give a limited observation.</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={generate} disabled={loading || !hasProfile || !hasEnough}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            {feedback ? "Refresh" : "Get feedback"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {!hasProfile ? (
          <p className="text-sm text-muted-foreground">Complete your buyer profile to get preliminary feedback.</p>
        ) : !feedback ? (
          <p className="text-sm text-muted-foreground">
            {hasEnough
              ? "Generate your free preliminary feedback to see your confirmed priorities and what's still missing."
              : "Save at least 3 candidate boats, then generate your free preliminary feedback."}
          </p>
        ) : (
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-accent" /> Priorities confirmed</p>
              <ul className="mt-1 ml-6 list-disc text-sm text-muted-foreground space-y-0.5">
                {feedback.priorities_confirmed?.map((p, i) => <li key={i}>{p}</li>)}
              </ul>
            </div>
            <div>
              <p className="text-sm font-medium flex items-center gap-2"><AlertCircle className="w-4 h-4 text-amber-500" /> Missing information</p>
              <ul className="mt-1 ml-6 list-disc text-sm text-muted-foreground space-y-0.5">
                {feedback.missing_information?.map((p, i) => <li key={i}>{p}</li>)}
              </ul>
            </div>
            <div>
              <p className="text-sm font-medium">Preliminary observation</p>
              <p className="mt-1 text-sm text-muted-foreground">{feedback.preliminary_observation}</p>
            </div>
            <p className="text-xs text-muted-foreground border-t border-border pt-3">
              This is free preliminary feedback — not a ranking, recommendation, or cost analysis. Purchase a shortlist report for the full evaluation.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}