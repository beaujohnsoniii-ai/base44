import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, FileText, Waves } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EXPLORE_FREE, PLAN_TIERS } from "@/lib/stages";

function CompassRose({ className = "" }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1" aria-hidden="true">
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2 L14 12 L12 22 L10 12 Z" fill="currentColor" stroke="none" />
      <path d="M2 12 L12 14 L22 12 L12 10 Z" fill="currentColor" stroke="none" />
    </svg>
  );
}

function Eyebrow({ children }) {
  return (
    <p className="text-[11px] uppercase tracking-[0.3em] text-brass font-medium mb-4">
      {children}
    </p>
  );
}

const HOW_IT_WORKS = [
  { n: "01", title: "Build your profile", body: "Tell us how you boat, your experience, storage needs, and budget." },
  { n: "02", title: "Save candidates", body: "Save up to five listing links and explain what you like about each boat." },
  { n: "03", title: "See what's included", body: "Explore free starting points, then compare packages for more detailed model reviews." },
];

const BEHIND_IT = [
  { n: "I", title: "Ownership", body: "Running costs, everyday use, and recurring maintenance needs." },
  { n: "II", title: "Handling", body: "Seakeeping and handling for your intended waters and experience." },
  { n: "III", title: "Reliability", body: "Hull, engine, and system issues to investigate before purchase." },
  { n: "IV", title: "Maintenance", body: "Service intervals, parts availability, and upkeep costs." },
  { n: "V", title: "Construction", body: "Build methods, layout, and structural condition." },
  { n: "VI", title: "Insurance", body: "Coverage questions and risks to discuss with an insurer." },
];

const VESSEL_CLASSES = [
  { title: "Private boats", body: "Storage, towing, accommodations, running costs, and resale for personal or family use." },
  { title: "Charter boats", body: "Commercial requirements, operating costs, durability, layout, and insurance for charter use." },
  { title: "Yachts", body: "Coverage beyond 65 ft is planned for a future version, including crew, registration, marina requirements, and complex systems.", soon: true },
];

const PROMISE_POINTS = [
  "Your submitted boat might be the strongest choice — or a different model might fit better.",
  "We never force four picks when only one or two qualify.",
  "Each result is the strongest match within your criteria and the sources reviewed.",
  "A remedy is defined before purchase if the shortlist can't be delivered.",
];

export default function HomeBody({ showTools = true }) {
  const navigate = useNavigate();

  return (
    <>
      {/* Six tools */}
      {showTools && (
      <section id="services" className="max-w-6xl mx-auto px-4 py-12 md:py-14 scroll-mt-20">
        <div className="max-w-2xl mx-auto text-center">
          <Eyebrow>One Account · Six Tools</Eyebrow>
          <h2 className="font-display text-3xl md:text-4xl font-semibold leading-tight">
            Choose the help you need
          </h2>
          <p className="text-muted-foreground mt-4 leading-relaxed">
            Start with Match today. The rest of the toolkit will be added as it is ready.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-10">
          {[
            { name: "Match", body: "Find boats suited to your needs, experience, and budget.", ready: true },
            { name: "Analyze", body: "Review one boat in depth against your profile.", ready: false },
            { name: "Compare", body: "Compare candidate boats and their tradeoffs side by side.", ready: false },
            { name: "Ownership", body: "Estimate the costs of owning and operating a boat.", ready: false },
            { name: "Guide", body: "Follow the buying journey from search through closing.", ready: false },
            { name: "Private Advisory", body: "Get independent expert guidance on your purchase.", ready: false },
          ].map((tool, index) => (
            <div key={tool.name} className={`border bg-background p-5 md:p-6 ${tool.ready ? "border-brass/70" : "border-brass/25"}`}>
              <div className="flex items-center justify-between gap-3">
                <span className="font-display text-xl text-brass">0{index + 1}</span>
                <span className={`text-[10px] uppercase tracking-[0.18em] px-2.5 py-1 border ${tool.ready ? "text-primary border-primary/30" : "text-muted-foreground border-border"}`}>
                  {tool.ready ? "Available now" : "Coming soon"}
                </span>
              </div>
              <h3 className="font-display text-xl font-semibold mt-4">{tool.name}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{tool.body}</p>
            </div>
          ))}
        </div>
        <div className="text-center mt-8">
          <Button size="lg" variant="secondary" onClick={() => navigate("/register?returnTo=/tools")}>
            Create your account and choose a tool <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </section>
      )}

      {/* How it works */}
      <section id="how-it-works" className="max-w-6xl mx-auto px-4 py-12 md:py-14 scroll-mt-20">
        <div className="text-center max-w-2xl mx-auto">
          <Eyebrow>How It Works</Eyebrow>
          <h2 className="font-display text-3xl md:text-4xl font-semibold leading-tight">
            How Match works
          </h2>
          <p className="text-muted-foreground mt-4 leading-relaxed">
            Use your profile and saved boats to explore suitable models, compare trade-offs,
            and identify questions to resolve before buying.
          </p>
        </div>

        <div className="grid md:grid-cols-3 mt-8 divide-y md:divide-y-0 md:divide-x divide-brass/25">
          {HOW_IT_WORKS.map((s) => (
            <div key={s.n} className="px-6 py-6 md:py-0 first:pl-0 last:pr-0">
              <span className="font-display text-3xl text-brass">{s.n}</span>
              <h3 className="font-display text-xl font-semibold mt-3">{s.title}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{s.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Who's behind it — prospectus list */}
      <section id="about" className="border-t border-brass/20 bg-parchment scroll-mt-20">
        <div className="max-w-5xl mx-auto px-4 py-12 md:py-14">
          <div className="text-center max-w-2xl mx-auto">
            <Eyebrow>Our Approach</Eyebrow>
            <h2 className="font-display text-3xl md:text-4xl font-semibold leading-tight">
              What we consider
            </h2>
            <p className="text-muted-foreground mt-4 leading-relaxed">
              A useful boat review goes beyond the specification sheet. These practical
              considerations help frame the fit, costs, and checks a purchase requires.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 gap-x-8 mt-8">
            {BEHIND_IT.map((s) => (
              <div key={s.title} className="flex gap-5 py-5 border-b border-brass/20">
                <span className="font-display italic text-xl text-brass w-8 shrink-0">{s.n}</span>
                <div>
                  <h3 className="font-display text-lg font-semibold">{s.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{s.body}</p>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Vessel classes — three columns, vertical brass rules */}
      <section className="border-t border-brass/20">
        <div className="max-w-6xl mx-auto px-4 py-12 md:py-14">
          <div className="text-center max-w-2xl mx-auto">
            <Eyebrow>Vessel Types</Eyebrow>
            <h2 className="font-display text-3xl md:text-4xl font-semibold leading-tight">
              Private, charter, and future yacht coverage
            </h2>
            <p className="text-muted-foreground mt-4 leading-relaxed">
              The intended use changes the questions to ask and the costs to plan for.
            </p>
          </div>

          <div className="grid md:grid-cols-3 mt-8 divide-y md:divide-y-0 md:divide-x divide-brass/25">
            {VESSEL_CLASSES.map((c) => (
              <div key={c.title} className="px-6 py-6 md:py-0 text-center md:text-left">
                <CompassRose className="w-7 h-7 text-brass mx-auto md:mx-0 mb-4" />
                <h3 className="font-display text-xl font-semibold">{c.title}</h3>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{c.body}</p>
                {c.soon && (
                  <p className="mt-3 inline-block text-[10px] uppercase tracking-[0.2em] text-brass border border-brass/40 px-2 py-0.5">
                    Coming soon
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Packages */}
      <section id="packages" className="border-t border-brass/20 bg-parchment scroll-mt-20">
        <div className="max-w-6xl mx-auto px-4 py-12 md:py-14">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <Eyebrow>Packages</Eyebrow>
            <h2 className="font-display text-3xl md:text-4xl font-semibold leading-tight">
             Start free. Add detail when you need it.
            </h2>
            <p className="text-muted-foreground mt-4 leading-relaxed">
             Paid packages are one-time purchases for one active search, with no subscription.
             Upgrade payments are credited, up to $99 total to reach Captain.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Free */}
            <div className="bg-background border border-brass/30 p-5 md:p-6">
              <p className="text-[11px] uppercase tracking-[0.25em] text-brass font-medium">Deckhand</p>
              <p className="font-display text-3xl font-semibold mt-2">$0</p>
              <ul className="mt-5 space-y-3">
                {EXPLORE_FREE.map((s) => (
                  <li key={s.id} className="flex items-start gap-2.5 text-sm">
                    <span className="text-brass mt-1 shrink-0">◆</span>
                    <span className="leading-relaxed"><span className="font-medium">{s.name}.</span> {s.description}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* MATCH+ */}
            <div className="bg-background border border-brass/30 p-5 md:p-6">
              <p className="text-[11px] uppercase tracking-[0.25em] text-brass font-medium">Bosun</p>
              <p className="font-display text-3xl font-semibold mt-2">$9</p>
              <p className="text-xs text-muted-foreground mt-1">one time · credited toward higher tiers</p>
              <ul className="mt-5 space-y-3">
                {PLAN_TIERS[0].deliverables.map((d) => (
                  <li key={d} className="flex items-start gap-2.5 text-sm">
                    <span className="text-brass mt-1 shrink-0">◆</span>
                    <span className="leading-relaxed">{d}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Refined Match */}
            <div className="bg-background border border-brass/30 p-5 md:p-6">
              <p className="text-[11px] uppercase tracking-[0.25em] text-brass font-medium">First Mate</p>
              <p className="font-display text-3xl font-semibold mt-2">$29</p>
              <p className="text-xs text-muted-foreground mt-1">total · or $20 from Bosun</p>
              <ul className="mt-5 space-y-3">
                {PLAN_TIERS[1].deliverables.map((d) => (
                  <li key={d} className="flex items-start gap-2.5 text-sm">
                    <span className="text-brass mt-1 shrink-0">◆</span>
                    <span className="leading-relaxed">{d}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Market Match */}
            <div className="bg-background border-2 border-brass p-5 md:p-6 relative">
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-brass text-background text-[10px] uppercase tracking-[0.2em] font-medium px-3 py-1">Most comprehensive</span>
              <p className="text-[11px] uppercase tracking-[0.25em] text-brass font-medium">Captain</p>
              <p className="font-display text-3xl font-semibold mt-2">$99</p>
              <p className="text-xs text-muted-foreground mt-1">total · $90 from Bosun · $70 from First Mate</p>
              <ul className="mt-5 space-y-3">
                {PLAN_TIERS[2].deliverables.map((d) => (
                  <li key={d} className="flex items-start gap-2.5 text-sm">
                    <span className="text-brass mt-1 shrink-0">◆</span>
                    <span className="leading-relaxed">{d}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <p className="text-center text-muted-foreground mt-10 max-w-2xl mx-auto italic leading-relaxed">
            Captain customers can add listing evaluations ($19 / $49)
            or extend their search ($29 for 90 more days).
          </p>
        </div>
      </section>

      {/* Honest promise */}
      <section className="bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 py-12 md:py-14">
          <div className="text-center">
            <Eyebrow>What to Expect</Eyebrow>
            <h2 className="font-display text-3xl md:text-4xl font-semibold leading-tight">
              Fit, trade-offs, and evidence gaps
            </h2>
          </div>
          <p className="text-white/85 mt-6 max-w-2xl mx-auto leading-relaxed text-center">
            Use the results to narrow your search and plan further checks.
            Confirm the condition, configuration, price, and availability of any specific boat.
          </p>
          <ul className="grid sm:grid-cols-2 gap-x-8 gap-y-4 mt-8 list-none p-0">
            {PROMISE_POINTS.map((p) => (
              <li key={p} className="flex items-start gap-3 text-white/90">
                <span className="text-brass mt-1 shrink-0">◆</span>
                <span className="leading-relaxed">{p}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Sample report */}
      <section id="resources" className="bg-parchment scroll-mt-20">
        <div className="max-w-5xl mx-auto px-4 py-12 md:py-14">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <Eyebrow>Example Report</Eyebrow>
              <h2 className="font-display text-3xl md:text-4xl font-semibold leading-tight">
                What a report covers
              </h2>
              <p className="text-muted-foreground mt-4 leading-relaxed">
                Reports explain model fit, compromises, and evidence gaps. Depending on the
                package, they also include ownership estimates and listing reviews.
                This example shows the format; it is not a verified current listing.
              </p>
              <Button className="mt-8" onClick={() => navigate("/match")}>
                Build my profile <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>

            <div className="bg-background border border-brass/30 p-5 md:p-6">
              <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
                <FileText className="w-4 h-4 text-brass" /> Illustrative report excerpt
              </div>
              <p className="font-display text-lg font-semibold mt-3">
                Example buyer: Overnight cruising, $100k–$250k, family of 4
              </p>
              <div className="h-px bg-brass/30 my-5" />
              <dl className="space-y-5 text-sm">
                <div>
                  <dt className="font-display font-semibold">Example model: Cutwater 30 Pilot House</dt>
                  <dd className="text-muted-foreground mt-1">Illustrative purchase budget: $189,900. No current price or availability is verified here.</dd>
                </div>
                <div>
                  <dt className="font-display font-semibold">Why it fits</dt>
                  <dd className="text-muted-foreground mt-1">An enclosed helm and overnight accommodation are priorities for this example buyer. Verify the exact model and configuration.</dd>
                </div>
                <div>
                  <dt className="font-display font-semibold">Compromises &amp; evidence gaps</dt>
                  <dd className="text-muted-foreground mt-1">Check engine hours, survey findings, maintenance records, and any work due.</dd>
                </div>
                <div>
                  <dt className="font-display font-semibold">Illustrative annual ownership budget</dt>
                  <dd className="text-muted-foreground mt-1">Slip $4,800 · Insurance $1,400 · Maintenance $2,200 · Reserve $1,500</dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary text-primary-foreground">
        <div className="max-w-3xl mx-auto px-4 py-12 md:py-14 text-center">
          <CompassRose className="w-9 h-9 text-brass mx-auto" />
          <h2 className="font-display text-3xl md:text-4xl font-semibold mt-5 leading-tight">
            Start your boat search
          </h2>
          <p className="text-white/80 mt-3">Build your profile and save boats to consider.</p>
          <Button size="lg" variant="secondary" className="mt-8" onClick={() => navigate("/match")}>
            Start free <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </section>

      <footer className="border-t border-brass/20 bg-parchment">
        <div className="max-w-6xl mx-auto px-4 py-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground text-center sm:text-left">
          <div className="flex items-center gap-2">
            <Waves className="w-4 h-4 text-brass" />
            <span>Sound Heading · Independent Vessel Acquisition Advisory</span>
          </div>
          <p>© {new Date().getFullYear()} Sound Heading</p>
        </div>
      </footer>
    </>
  );
}