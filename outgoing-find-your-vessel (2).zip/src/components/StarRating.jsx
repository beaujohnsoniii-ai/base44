import React, { useState } from "react";
import { Star } from "lucide-react";

export default function StarRating({ value, onChange, size = 20 }) {
  const [hover, setHover] = useState(0);

  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => {
        const active = (hover || value) >= star;
        return (
          <button
            key={star}
            type="button"
            onClick={() => onChange?.(star)}
            onMouseEnter={() => setHover(star)}
            onMouseLeave={() => setHover(0)}
            className="p-0.5 rounded transition-colors hover:bg-muted/50"
            aria-label={`${star} star${star > 1 ? "s" : ""}`}
          >
            <Star
              style={{ width: size, height: size }}
              className={active ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30"}
            />
          </button>
        );
      })}
    </div>
  );
}