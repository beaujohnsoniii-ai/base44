import * as React from "react";
import * as SliderPrimitive from "@radix-ui/react-slider";
import { DEFAULT_PRICE_STEP, normalizePriceStep, roundPrice, zoomPriceWindow } from "@/lib/price-range";

// Dynamic price-range slider.
// The track shows a zoomable window over the full budget range. On release it
// auto-zooms around the chosen min/max, so fine adjustments ($100k or tighter)
// are easy instead of fighting the full $20M scale. Pushing a handle against
// the window edge keeps expanding the window while you hold the drag, so the
// price rolls on until you stop or reach the limit.
const TICKS = 1000;

const fmt = (p) =>
  p >= 1000000
    ? `$${(p / 1000000).toFixed(p % 1000000 === 0 ? 0 : 1)}M`
    : `$${Math.round(p / 1000)}k`;

export default function PriceRangeSlider({ min = 0, max = 20000000, step = DEFAULT_PRICE_STEP, value, onChange }) {
  const increment = normalizePriceStep(step);
  const r = (price) => roundPrice(price, increment);
  const [lo, hi] = value;
  const lo0 = Number(lo) || 0;
  const hi0 = Number(hi) || 0;

  const viewRef = React.useRef(zoomPriceWindow(lo0, hi0, min, max, increment));
  const [, force] = React.useReducer((n) => n + 1, 0);
  const setView = (v) => { viewRef.current = v; force(); };
  const view = viewRef.current;
  const zoomed = view.lo > min || view.hi < max;

  const valRef = React.useRef([lo0, hi0]);
  valRef.current = [lo0, hi0];
  const onChangeRef = React.useRef(onChange);
  onChangeRef.current = onChange;
  const pinRef = React.useRef(null);
  const [pinDir, setPinDir] = React.useState(null);

  // Re-zoom if the incoming selection falls outside the current window.
  React.useEffect(() => {
    const v = viewRef.current;
    if (lo0 < v.lo - 1 || hi0 > v.hi + 1) setView(zoomPriceWindow(lo0, hi0, min, max, increment));
     
  }, [lo0, hi0, min, max, increment]);

  const span = Math.max(view.hi - view.lo, increment);
  const tickToPrice = (t) => view.lo + (Math.min(Math.max(t, 0), TICKS) / TICKS) * span;
  const priceToTick = (p) =>
    Math.min(TICKS, Math.max(0, Math.round(((p - view.lo) / span) * TICKS)));

  const handleChange = (v) => {
    const vw = viewRef.current;
    const atHi = v[1] >= TICKS && vw.hi < max;
    const atLo = v[0] <= 0 && vw.lo > min;
    const dir = atHi ? "hi" : atLo ? "lo" : null;
    if (dir !== pinRef.current) {
      pinRef.current = dir;
      setPinDir(dir);
    }
    const [curLo, curHi] = valRef.current;
    if (dir === "hi") {
      onChangeRef.current(Math.min(curLo, vw.hi), Math.max(curLo, vw.hi));
      return;
    }
    if (dir === "lo") {
      onChangeRef.current(Math.min(vw.lo, curHi), Math.max(vw.lo, curHi));
      return;
    }
    const a = Math.max(min, Math.min(max, r(tickToPrice(v[0]))));
    const b = Math.max(min, Math.min(max, r(tickToPrice(v[1]))));
    onChangeRef.current(Math.min(a, b), Math.max(a, b));
  };

  const handleCommit = () => {
    pinRef.current = null;
    setPinDir(null);
    const [a, b] = valRef.current;
    setView(zoomPriceWindow(Math.min(a, b), Math.max(a, b), min, max, increment));
  };

  const resetFull = () => {
    pinRef.current = null;
    setPinDir(null);
    setView({ lo: min, hi: max });
  };

  // While a handle is pinned at a window edge, keep expanding the window so the
  // price rolls on until the buyer stops dragging or the limit is reached.
  React.useEffect(() => {
    if (!pinDir) return;
    const id = setInterval(() => {
      const vw = viewRef.current;
      const [curLo, curHi] = valRef.current;
      if (pinRef.current === "hi" && vw.hi < max) {
        const nHi = Math.min(max, r(vw.hi + (vw.hi - vw.lo) * 0.25));
        setView({ lo: vw.lo, hi: nHi });
        onChangeRef.current(Math.min(curLo, nHi), Math.max(curLo, nHi));
      } else if (pinRef.current === "lo" && vw.lo > min) {
        const nLo = Math.max(min, r(vw.lo - (vw.hi - vw.lo) * 0.25));
        setView({ lo: nLo, hi: vw.hi });
        onChangeRef.current(Math.min(nLo, curHi), Math.max(nLo, curHi));
      } else {
        pinRef.current = null;
        setPinDir(null);
      }
    }, 140);
    return () => clearInterval(id);
  }, [pinDir, min, max, increment]);

  const scaleLabels = [0, 0.25, 0.5, 0.75, 1].map((f) => fmt(view.lo + span * f));

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div className="text-left">
          <p className="text-xs text-muted-foreground">Minimum</p>
          <p className="text-lg font-semibold tabular-nums">${Number(lo).toLocaleString()}</p>
        </div>
        <span className="text-muted-foreground text-sm">to</span>
        <div className="text-right">
          <p className="text-xs text-muted-foreground">Maximum</p>
          <p className="text-lg font-semibold tabular-nums">${Number(hi).toLocaleString()}</p>
        </div>
      </div>
      <SliderPrimitive.Root
        className="relative flex w-full touch-none select-none items-center"
        min={0}
        max={TICKS}
        step={1}
        value={[priceToTick(lo0), priceToTick(hi0)]}
        onValueChange={handleChange}
        onValueCommit={handleCommit}
      >
        <SliderPrimitive.Track className="relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20">
          <SliderPrimitive.Range className="absolute h-full bg-primary" />
        </SliderPrimitive.Track>
        <SliderPrimitive.Thumb aria-label="Minimum price" className="block h-5 w-5 rounded-full border-2 border-primary bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50" />
        <SliderPrimitive.Thumb aria-label="Maximum price" className="block h-5 w-5 rounded-full border-2 border-primary bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50" />
      </SliderPrimitive.Root>
      <div className="flex justify-between text-xs text-muted-foreground mt-2">
        {scaleLabels.map((p, i) => (
          <span key={i}>{p}</span>
        ))}
      </div>
      <div className="flex items-center justify-between mt-2">
        <p className="text-xs text-muted-foreground">Zoomed to your range — drag past either edge to keep going.</p>
        {zoomed && (
          <button type="button" className="text-xs text-accent hover:underline ml-2 shrink-0" onClick={resetFull}>
            Full range
          </button>
        )}
      </div>
    </div>
  );
}