import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

// Cases whose stored counts do not match the tier's intended shape. Listed rather
// than averaged away, so a short pool or a misplaced mark stays visible.
export default function FunnelDeviationList({ deviations = [] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Cases off the intended shape ({deviations.length})</CardTitle>
        <CardDescription>
          Measured from this run's stored tier results. A short pool is a real finding and is never averaged into a pass.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {deviations.length === 0 ? (
          <p className="text-sm text-muted-foreground">Every case in this run matched its tier's intended pool size and marks.</p>
        ) : (
          <ul className="space-y-2 text-sm">
            {deviations.map((deviation, i) => (
              <li key={`${deviation.tier}-${i}`} className="flex flex-wrap items-baseline gap-x-2 gap-y-1 border-b border-border pb-2 last:border-b-0 last:pb-0">
                <span className="font-medium">{deviation.label}</span>
                <span className="text-muted-foreground">{deviation.profile}</span>
                <span className="tabular-nums">{deviation.problems.join("; ")}</span>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}