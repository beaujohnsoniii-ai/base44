import React from "react";
import { Badge } from "@/components/ui/badge";

// One tier of the funnel: the pool it generates, the share of that pool it marks,
// and how this run compares with the tier's intended shape. Bar widths come from
// the measured counts only — a tier with no cases shows its intended shape, never
// an invented number.
export default function FunnelTierBar({ tier, scaleMax = 1 }) {
  const { label, policy, cases, generated, marks, offPolicy } = tier;
  const shareOfPool = generated.typical > 0 ? Math.round((marks.typical / generated.typical) * 100) : 0;
  const poolWidth = generated.typical > 0 ? Math.max(6, Math.round((generated.typical / Math.max(scaleMax, 1)) * 100)) : 0;

  return (
    <div className="space-y-2 py-3 border-b border-border last:border-b-0">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="font-medium">{label}</span>
          {offPolicy > 0 && <Badge variant="outline" className="text-xs border-amber-300 text-amber-700">{offPolicy} off shape</Badge>}
        </div>
        {policy ? (
          <span className="text-xs text-muted-foreground">
            Intended: {policy.min}–{policy.max} results · {policy.marks} marked
          </span>
        ) : (
          <span className="text-xs text-muted-foreground">Not part of the current four-tier funnel</span>
        )}
      </div>

      {cases === 0 ? (
        <p className="text-sm text-muted-foreground">No cases for this tier in the selected run.</p>
      ) : (
        <>
          <div className="h-4 w-full rounded-full bg-muted" role="img" aria-label={`${label}: typically ${generated.typical} results, ${marks.typical} marked`}>
            <div className="flex h-4 items-stretch" style={{ width: `${poolWidth}%` }}>
              <div className="rounded-l-full bg-brass" style={{ width: `${shareOfPool}%` }} />
              <div className="flex-1 rounded-r-full bg-primary/25" />
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
            <span className="tabular-nums">
              Typically <span className="font-semibold">{generated.typical}</span> results per case
              {generated.min !== generated.max ? ` (range ${generated.min}–${generated.max})` : ""}
            </span>
            <span className="tabular-nums">
              <span className="font-semibold">{marks.typical}</span> marked
              {marks.min !== marks.max ? ` (range ${marks.min}–${marks.max})` : ""}
            </span>
            <span className="text-muted-foreground tabular-nums">
              {cases} case{cases === 1 ? "" : "s"} · {generated.total} results generated · {marks.total} marked
            </span>
          </div>
        </>
      )}
    </div>
  );
}