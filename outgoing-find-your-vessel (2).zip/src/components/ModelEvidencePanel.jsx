import React,{useState} from "react";
import {base44} from "@/api/base44Client";
import {Button} from "@/components/ui/button";
export default function ModelEvidencePanel({suggestion}){
 const [data,setData]=useState(null),[error,setError]=useState(""),[busy,setBusy]=useState(false),[description,setDescription]=useState(""),[sent,setSent]=useState(false);
 async function call(action){setBusy(true);setError("");try{const r=await base44.functions.invoke("hybrid-evidence",{action,suggestion_id:suggestion.id,description});const d=r.data||r;if(d.error)throw new Error(d.error);if(action==="status")setData(d);else setSent(true);}catch(e){setError(e.response?.data?.error||e.message||"Unable to load evidence.");}finally{setBusy(false);}}
 return <details className="my-3 border rounded p-3 text-sm"><summary className="cursor-pointer font-medium">Sources and data concerns</summary>
 <Button className="my-2" variant="outline" size="sm" disabled={busy} onClick={()=>call("status")}>Check evidence status</Button>
 {data?.report_recheck_required&&<p role="alert">Evidence changed since this result was generated. Regenerate your result before relying on its fit claims.</p>}
 {data?.review_pending&&<p>Admin review pending. A reported concern is not a confirmed correction.</p>}
 {data&&(data.fields||[]).map(v=><div key={v.field} className="my-2"><strong>{v.field}: </strong>{String(v.status).replaceAll("_"," ")} {v.status==="source_confirmed"&&<span>{v.value} {v.unit} · <a href={v.source_url} target="_blank" rel="noopener noreferrer" className="underline">Source</a> · {v.checked_at}</span>}{v.message&&<p>{v.message}</p>}</div>)}
 <label className="block mt-3">Report incorrect info<textarea className="block w-full border rounded p-2" maxLength={2000} value={description} onChange={e=>setDescription(e.target.value)} placeholder="Which specification looks wrong, and why? Include a source if available."/></label>
 <Button className="mt-2" size="sm" disabled={busy||sent||description.trim().length<10} onClick={()=>call("report")}>{sent?"Sent to admin":"Send concern to admin"}</Button>
 {error&&<p role="alert" className="text-red-700">{error}</p>}
 </details>;
}