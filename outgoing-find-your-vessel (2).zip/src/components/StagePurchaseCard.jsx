import React from "react";
import { CheckCircle2, ArrowRight, Sparkles, ShieldCheck, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";

export default function StagePurchaseCard({ stage, purchased, onPurchase, purchasing, hasActivation = false, flagged = false }) {
  return (
    <Card className={`flex flex-col ${stage.main ? "border-accent ring-1 ring-accent/30" : ""} ${purchased ? "border-accent" : ""} ${flagged && !purchased ? "border-amber-400/60" : ""}`}>
      {stage.main && (
        <div className="rounded-t-lg bg-accent/10 px-4 py-1.5 text-xs font-medium text-accent flex items-center gap-1">
          <Sparkles className="w-3 h-3" /> Most popular
        </div>
      )}
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            {stage.name}
            {stage.badge && (
              <span className="text-xs font-medium rounded-full bg-primary/10 text-primary px-2 py-0.5">{stage.badge}</span>
            )}
          </CardTitle>
          {purchased ? <CheckCircle2 className="w-5 h-5 text-accent" /> : null}
        </div>
        <CardDescription>{stage.tagline}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <p className="text-sm text-muted-foreground">{stage.description}</p>
        <ul className="mt-4 space-y-1.5">
          {stage.deliverables.map((d) => (
            <li key={d} className="flex items-start gap-2 text-sm">
              <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 shrink-0" />
              <span>{d}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex items-baseline gap-1 flex-wrap">
          {hasActivation && stage.credit_eligible ? (
            <>
              <span className="text-3xl font-heading font-semibold">${stage.price - 29}</span>
              <span className="text-sm text-muted-foreground line-through">${stage.price}</span>
              <span className="text-xs text-accent">activation credit applied</span>
            </>
          ) : (
            <>
              <span className="text-3xl font-heading font-semibold">${stage.price}</span>
              <span className="text-sm text-muted-foreground">pilot price</span>
            </>
          )}
        </div>
        <p className="mt-3 text-xs text-muted-foreground flex items-start gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 mt-0.5 shrink-0" />
          {stage.remedy}
        </p>
      </CardContent>
      <CardFooter>
        {purchased ? (
          <Button className="w-full" variant="secondary" disabled>
            Unlocked
          </Button>
        ) : flagged ? (
          <div className="w-full space-y-2">
            <Button className="w-full" variant="secondary" disabled>
              Resolve profile issues first
            </Button>
            <p className="text-xs text-amber-700 dark:text-amber-400 flex items-start gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              Your profile has potential issues to review. Adjust the flagged fields and re-run the advisor to unlock purchases — the results will improve significantly once corrected.
            </p>
          </div>
        ) : (
          <Button className="w-full" onClick={() => onPurchase(stage.id)} disabled={purchasing === stage.id}>
            {purchasing === stage.id ? "Redirecting…" : (
              <>Purchase <ArrowRight className="w-4 h-4 ml-2" /></>
            )}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}