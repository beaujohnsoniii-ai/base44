import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { confirmedFinalists, listingUrls } from "@/lib/compareCandidates";
import { ownerRecords } from "@/lib/matchCompareHandoff";
import { matchResultLink, safeResultUrl } from "@/lib/matchResultLink";

function safeBuyerLinks(values) {
  if (!Array.isArray(values)) return [];
  const links = [];
  for (const value of values.slice(0, 3)) {
    try {
      for (const url of listingUrls([String(value || "")])) {
        if (!links.includes(url)) links.push(url);
      }
    } catch {
      // Older malformed saved values must not become clickable links.
    }
  }
  return links;
}

// Read-only handoff. Compare saves the selection; viewing downstream pages
// never creates candidates, imports listings or invokes model analysis.
export default function SelectedCompareFinalists() {
  const [finalists, setFinalists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const user = await base44.auth.me();
        const [boats, spaces] = await Promise.all([
          ownerRecords(base44.entities.SavedBoat, user.id),
          base44.entities.CompareWorkspace.filter({ created_by_id: user.id }, "-created_date", 1),
        ]);
        if (active) {
          setFinalists(confirmedFinalists(boats, spaces?.[0] || null));
          setError("");
        }
      } catch {
        if (active) setError("Your saved Compare selection could not be loaded.");
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  return (
    <section className="space-y-4" aria-label="Selected Compare model candidates">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <div>
          <h2 className="text-xl font-heading">Your Compare shortlist</h2>
          <p className="text-sm text-muted-foreground">
            Only models you explicitly selected and saved in Compare appear here. This is not a verified listing comparison.
          </p>
        </div>
        <Link to="/compare" className="inline-block min-h-11 content-center underline">Edit in Compare</Link>
      </div>
      {loading ? (
        <p role="status">Loading your saved Compare selection…</p>
      ) : error ? (
        <div role="alert" className="rounded-xl border bg-white p-5">
          <p>{error}</p>
          <Link to="/compare" className="inline-block mt-2 underline">Open Compare</Link>
        </div>
      ) : finalists.length === 0 ? (
        <div className="rounded-xl border bg-white p-5">
          <p>No confirmed finalists yet. Select up to three saved model candidates in Compare and save your selection.</p>
          <Link to="/compare" className="inline-block mt-3 underline">Choose Compare finalists</Link>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-3">
          {finalists.map((boat, index) => {
            const userLinks = safeBuyerLinks(boat.listing_urls);
            const originalListing = safeResultUrl(boat.url);
            const matchLink = safeResultUrl(boat.original_match_url);
            return (
              <article key={boat.id} className="min-w-0 rounded-xl border bg-white p-5 space-y-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Model {index + 1} · Selected in Compare</p>
                <h3 className="text-lg font-semibold">{boat.title || [boat.make, boat.model, boat.year].filter(Boolean).join(" ") || "Saved model"}</h3>
                {boat.match?.summary && <p className="text-sm">{boat.match.summary}</p>}
                <p className="text-sm text-muted-foreground">{userLinks.length} buyer-added listing link{userLinks.length === 1 ? "" : "s"}. None has been independently evaluated here.</p>
                {userLinks.map((url, number) => (
                  <a key={url} className="block break-words underline text-sm" href={url} target="_blank" rel="noopener noreferrer">
                    Open pasted listing {number + 1}
                  </a>
                ))}
                {originalListing && <a className="block break-words underline text-sm" href={originalListing} target="_blank" rel="noopener noreferrer">Open originally saved URL (unverified)</a>}
                {matchLink && <a className="block break-words underline text-sm" href={matchLink} target="_blank" rel="noopener noreferrer">Open original Match research link</a>}
                {!originalListing && !matchLink && <a className="block underline text-sm" href={matchResultLink(boat)} target="_blank" rel="noopener noreferrer">Search this model</a>}
                {userLinks.length === 0 && !originalListing && <p className="text-xs text-muted-foreground">No actual boat-for-sale listing attached yet.</p>}
              </article>
            );
          })}
        </div>
      )}
      <p className="text-xs text-muted-foreground">
        Links and saved model notes are buyer-provided or research context. Availability, equipment, engine configuration, condition, price and seller claims require independent verification before purchase analysis.
      </p>
    </section>
  );
}
