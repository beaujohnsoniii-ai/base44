import React from "react";
import { normalizeListingUrl } from "@/lib/utils";

// Native user-gesture navigation preserves the current app tab and entered work.
// Embedded host restrictions may still block new tabs; never report a copied URL unless copied.
export default function ListingLink({href,children,className}){
 const url=normalizeListingUrl(href);if(!url)return null;
 return <a href={url} target="_blank" rel="noopener noreferrer" className={className}>{children}</a>;
}
