import React from "react";
import { Lock, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { higherTiers, nextTier, UPGRADES_OPEN, EARLY_ACCESS_HREF } from "@/lib/tiers";
import "@/components/tier-teaser.css";

// Locked preview of what the next tier adds, shown under the buyer's results.
// No sample models or numbers are invented: the ghost rows are blank bars.
// Upgrades are closed, so the action is a disabled "coming soon" button plus the
// single site CTA, "Request early access".
const GHOST = {
  match_plus: { rows: 4, caption: "A 10–14-model research pool informed by deeper questions and prior Likes; no recommendations marked." },
  refined_match: { rows: 3, caption: "The same models re-ranked, with 5–7 marked as recommended.", mark: "Recommended" },
  market_match: { rows: 3, caption: "Three finalists pulled to the top; the full model set stays visible.", mark: "Finalist" },
};

export default function TierTeaser({ plan = "free", showAll = false }) {
  const next = nextTier(plan);
  if (!next) return null;
  const ghost = GHOST[next.id];
  const later = showAll ? higherTiers(plan).slice(1) : [];
  return (
    <section className="sh-teaser" aria-label={`What ${next.name} adds`}>
      <div className="sh-teaser__head">
        <p className="sh-teaser__eyebrow"><Lock className="w-3.5 h-3.5" aria-hidden="true" /> Locked · {next.name} {next.priceLabel}</p>
        <h3 className="sh-teaser__title">{next.promise}</h3>
        <p className="sh-teaser__caption">{ghost.caption}</p>
      </div>
      <div className="sh-teaser__ghosts" aria-hidden="true">
        {Array.from({ length: ghost.rows }).map((_, i) => (
          <div key={i} className="sh-teaser__ghost">
            <span className="sh-teaser__rank">#{i + 1}</span>
            <span className="sh-teaser__bar sh-teaser__bar--title" />
            <span className="sh-teaser__bar" />
            {ghost.mark && i < 2 && <span className="sh-teaser__mark">{ghost.mark}</span>}
          </div>
        ))}
      </div>
      <div className="sh-teaser__actions">
        <Button disabled={!UPGRADES_OPEN} aria-disabled={!UPGRADES_OPEN} title="Upgrades open after launch. No payment is taken.">
          {next.name} · coming soon
        </Button>
        <a className="sh-teaser__link" href={EARLY_ACCESS_HREF}>Request early access <ArrowRight className="w-4 h-4" aria-hidden="true" /></a>
      </div>
      {later.length > 0 && (
        <ul className="sh-teaser__later">
          {later.map((t) => (
            <li key={t.id}><Lock className="w-3.5 h-3.5" aria-hidden="true" /> <strong>{t.name} {t.priceLabel}</strong> · {t.promise}</li>
          ))}
        </ul>
      )}
      <p className="sh-teaser__fine">Upgrades open after launch. Nothing is charged here.</p>
    </section>
  );
}
