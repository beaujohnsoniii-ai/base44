import React from "react";
import AppHeader from "@/components/AppHeader";
import "@/pages/Home.css";

// All historical Navbar variants use the same scoped, approved site header.
export default function Navbar({ variant = "coastal" } = {}) { void variant; return <AppHeader />; }
