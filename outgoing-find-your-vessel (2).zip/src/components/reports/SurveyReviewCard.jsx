import React from "react";
import { FileText, ShieldAlert, Scale, ListChecks, Gauge, CheckCircle2, XCircle, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const SEVERITY_STYLES = {
  critical: "bg-destructive/10 text-destructive border-destructive/30",
  significant: "bg-orange-500/10 text-orange-600 border-orange-500/30",
  moderate: "bg-accent/10 text-accent border-accent/30",
  minor: "bg-muted text-muted-foreground border-border",
};

const GO_STYLES = {
  go: { icon: CheckCircle2, className: "border-accent/30 bg-accent/10 text-accent", label: "Go" },
  go_with_conditions: { icon: AlertTriangle, className: "border-orange-500/30 bg-orange-500/10 text-orange-600", label: "Go — with conditions" },
  no_go: { icon: XCircle, className: "border-destructive/30 bg-destructive/10 text-destructive", label: "No go" },
};

export default function SurveyReviewCard({ content }) {
  const c = content || {};
  const go = GO_STYLES[c.go_no_go] || null;
  const GoIcon = go?.icon;

  return (
    <>
      {c.documents_reviewed?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><FileText className="w-5 h-5" /> Documents Reviewed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {c.documents_reviewed.map((d, i) => (
                <span key={i} className="rounded-full bg-muted border border-border px-3 py-1 text-sm">{d}</span>
              ))}
            </div>
            {c.vessel_identified && (
              <p className="text-sm text-muted-foreground mt-3">Vessel: {c.vessel_identified}</p>
            )}
          </CardContent>
        </Card>
      )}

      {go && (
        <Card className={`border ${go.className}`}>
          <CardContent className="p-5 flex items-start gap-3">
            {GoIcon && <GoIcon className="w-6 h-6 mt-0.5 shrink-0" />}
            <div>
              <p className="font-heading text-lg font-semibold">{go.label}</p>
              {c.go_no_go_reasoning && <p className="text-sm text-muted-foreground mt-1">{c.go_no_go_reasoning}</p>}
            </div>
          </CardContent>
        </Card>
      )}

      {c.red_flags?.length > 0 && (
        <Card className="border-destructive/30">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><ShieldAlert className="w-5 h-5 text-destructive" /> Red Flags</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="ml-5 list-disc text-sm space-y-1">
              {c.red_flags.map((r, i) => <li key={i}>{r}</li>)}
            </ul>
          </CardContent>
        </Card>
      )}

      {c.material_findings?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><Gauge className="w-5 h-5" /> Material Findings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {c.material_findings.map((f, i) => (
              <div key={i} className="rounded-lg border border-border p-3">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-medium">{f.finding}</p>
                  {f.severity && (
                    <span className={`text-xs rounded-full border px-2 py-0.5 ${SEVERITY_STYLES[f.severity] || SEVERITY_STYLES.minor}`}>
                      {f.severity}
                    </span>
                  )}
                </div>
                {f.implications && <p className="text-sm text-muted-foreground mt-1">{f.implications}</p>}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {c.cosmetic_or_minor?.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-lg">Cosmetic / Minor</CardTitle></CardHeader>
          <CardContent>
            <ul className="ml-5 list-disc text-sm space-y-1 text-muted-foreground">
              {c.cosmetic_or_minor.map((m, i) => <li key={i}>{m}</li>)}
            </ul>
          </CardContent>
        </Card>
      )}

      {c.renegotiation_points?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><Scale className="w-5 h-5" /> Renegotiation Points</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="ml-5 list-disc text-sm space-y-1">
              {c.renegotiation_points.map((r, i) => <li key={i}>{r}</li>)}
            </ul>
          </CardContent>
        </Card>
      )}

      {c.recommended_next_steps?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><ListChecks className="w-5 h-5" /> Recommended Next Steps</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="ml-5 list-disc text-sm space-y-1">
              {c.recommended_next_steps.map((s, i) => <li key={i}>{s}</li>)}
            </ul>
          </CardContent>
        </Card>
      )}
    </>
  );
}