import React from "react";
import { ExternalLink, BadgeCheck, MessageSquare, Scale, ClipboardCheck } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import ListingLink from "@/components/ListingLink";
import { boatLink } from "@/lib/utils";

const SELLER_LABEL = {
  broker: "Broker",
  dealership: "Dealership",
  private_seller: "Private seller",
  unclear: "Seller type unclear",
};

export default function IntroductionCard({ rec, rank }) {
  const c = rec || {};
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          {rank != null && <span className="text-muted-foreground font-normal">{rank}.</span>}
          <ListingLink href={boatLink(c)} className="hover:underline flex items-center gap-1">
            {c.title} <ExternalLink className="w-4 h-4" />
          </ListingLink>
        </CardTitle>
        <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
          {c.seller_type && (
            <span className="inline-flex items-center gap-1 rounded-full bg-accent/10 text-accent px-2 py-0.5 text-xs">
              <BadgeCheck className="w-3 h-3" /> {SELLER_LABEL[c.seller_type] || c.seller_type}
            </span>
          )}
          {c.asking_price && <span>· {c.asking_price}</span>}
        </div>
      </CardHeader>
      <CardContent className="space-y-4 text-sm">
        {c.approach && (
          <div>
            <p className="font-medium mb-1">How to approach</p>
            <p className="text-muted-foreground">{c.approach}</p>
          </div>
        )}
        {c.key_questions?.length > 0 && (
          <div>
            <p className="font-medium mb-1 flex items-center gap-1.5"><MessageSquare className="w-4 h-4" /> Key questions</p>
            <ul className="ml-5 list-disc space-y-1 text-muted-foreground">
              {c.key_questions.map((q, i) => <li key={i}>{q}</li>)}
            </ul>
          </div>
        )}
        {c.negotiation_leverage?.length > 0 && (
          <div>
            <p className="font-medium mb-1 flex items-center gap-1.5"><Scale className="w-4 h-4" /> Negotiation leverage</p>
            <ul className="ml-5 list-disc space-y-1 text-muted-foreground">
              {c.negotiation_leverage.map((q, i) => <li key={i}>{q}</li>)}
            </ul>
          </div>
        )}
        {c.what_to_verify?.length > 0 && (
          <div>
            <p className="font-medium mb-1 flex items-center gap-1.5"><ClipboardCheck className="w-4 h-4" /> What to verify before committing</p>
            <ul className="ml-5 list-disc space-y-1 text-muted-foreground">
              {c.what_to_verify.map((q, i) => <li key={i}>{q}</li>)}
            </ul>
          </div>
        )}
        {c.introduction_note && (
          <div className="rounded-lg bg-muted/40 border border-border p-3">
            <p className="font-medium mb-1">First-contact note</p>
            <p className="text-muted-foreground italic">{c.introduction_note}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}