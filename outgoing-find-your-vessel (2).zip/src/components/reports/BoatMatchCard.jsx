import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ExternalLink, CheckCircle2, AlertCircle, Wallet, ClipboardList, HelpCircle, Gauge } from "lucide-react";
import ListingLink from "@/components/ListingLink";
import { boatLink } from "@/lib/utils";
import { formatModelPriceGuidance } from "@/lib/modelPriceGuidance";

// Shared rendering for a single boat match across all paid tiers.
// Expects the boat-match object produced by the generate-advisory function:
// { title, link, asking_price, review_date, availability, match_strength,
//   key_specs: [{label, value}], fit_reasons, compromises,
//   cost_analysis: { annual_ownership_range, breakdown: [{category, estimate}] },
//   evidence_gaps, seller_questions }
export default function BoatMatchCard({ rec, rank, simulation = false }) {
  const link = boatLink(rec);
  const isModelGuidance = /model guidance|not a specific listing/i.test(String(rec.availability || ""));
  const isSearchLink = String(link).toLowerCase().includes("google.com/search");
  const linkLabel = isSearchLink ? "Search current model listings" : isModelGuidance ? "Explore available examples" : "View listing";
  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            {rank != null && (
              <span className="text-xs font-medium text-muted-foreground">#{rank}</span>
            )}
            <CardTitle className="text-lg">{rec.title}</CardTitle>
            <CardDescription className="flex flex-wrap gap-x-3 gap-y-1 mt-1">
              {isModelGuidance
                ? <span>{formatModelPriceGuidance(rec)}</span>
                : (rec.asking_price && <span>{rec.asking_price}</span>)}
              {rec.review_date && <span>Reviewed {rec.review_date}</span>}
              {rec.availability && <span>{isModelGuidance ? "Model recommendation — not a boat offered for sale" : `Availability: ${rec.availability}`}</span>}
            </CardDescription>
          </div>
          {rec.match_strength && (
            <span className="shrink-0 text-xs font-medium px-2.5 py-1 rounded-full bg-accent/10 text-accent whitespace-nowrap">
              {rec.match_strength}
            </span>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4 text-sm">
        {!simulation && <ListingLink
          href={link}
          className="inline-flex items-center gap-1 text-accent hover:underline"
        >
          {linkLabel} <ExternalLink className="w-3.5 h-3.5" />
        </ListingLink>}

        {rec.key_specs?.length > 0 && (
          <div>
            <p className="font-medium flex items-center gap-1.5"><Gauge className="w-4 h-4 text-accent" /> Key specifications</p>
            <dl className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
              {rec.key_specs.map((s, j) => (
                <div key={j}>
                  <dt className="text-xs text-muted-foreground">{s.label}</dt>
                  <dd className="font-medium">{s.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        )}

        {rec.fit_reasons?.length > 0 && (
          <div>
            <p className="font-medium flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-accent" /> Why it fits</p>
            <ul className="ml-6 list-disc text-muted-foreground space-y-0.5 mt-1">
              {rec.fit_reasons.map((r, j) => <li key={j}>{r}</li>)}
            </ul>
          </div>
        )}

        {rec.compromises?.length > 0 && (
          <div>
            <p className="font-medium flex items-center gap-1.5"><AlertCircle className="w-4 h-4 text-amber-500" /> Compromises & concerns</p>
            <ul className="ml-6 list-disc text-muted-foreground space-y-0.5 mt-1">
              {rec.compromises.map((r, j) => <li key={j}>{r}</li>)}
            </ul>
          </div>
        )}

        {rec.cost_analysis && (
          <div>
            <p className="font-medium flex items-center gap-1.5"><Wallet className="w-4 h-4 text-accent" /> Estimated cost analysis</p>
            {rec.cost_analysis.annual_ownership_range && (
              <p className="text-muted-foreground mt-1">
                Annual ownership: <span className="font-medium text-foreground">{rec.cost_analysis.annual_ownership_range}</span>
              </p>
            )}
            {rec.cost_analysis.breakdown?.length > 0 && (
              <div className="mt-2 rounded-lg border border-border overflow-hidden">
                <table className="w-full text-sm">
                  <tbody>
                    {rec.cost_analysis.breakdown.map((row, j) => (
                      <tr key={j} className={j % 2 === 1 ? "bg-muted/30" : ""}>
                        <td className="px-3 py-1.5 text-muted-foreground">{row.category}</td>
                        <td className="px-3 py-1.5 text-right font-medium">{row.estimate}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {rec.evidence_gaps?.length > 0 && (
          <div>
            <p className="font-medium flex items-center gap-1.5"><ClipboardList className="w-4 h-4 text-muted-foreground" /> Evidence gaps</p>
            <ul className="ml-6 list-disc text-muted-foreground space-y-0.5 mt-1">
              {rec.evidence_gaps.map((r, j) => <li key={j}>{r}</li>)}
            </ul>
          </div>
        )}

        {rec.seller_questions?.length > 0 && (
          <div>
            <p className="font-medium flex items-center gap-1.5"><HelpCircle className="w-4 h-4 text-muted-foreground" /> Seller questions & next steps</p>
            <ul className="ml-6 list-disc text-muted-foreground space-y-0.5 mt-1">
              {rec.seller_questions.map((r, j) => <li key={j}>{r}</li>)}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}