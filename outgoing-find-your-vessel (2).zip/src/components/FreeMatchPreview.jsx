import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { PLAN_TIERS } from "@/lib/stages";
import { tierName } from "@/lib/tiers";
import TierTeaser from "@/components/TierTeaser";
import { Link } from "react-router-dom";
import { Compass } from "lucide-react";
import { boatTypeNote } from "@/lib/boatTypes";
import "@/components/match-results.css";

export default function FreeMatchPreview({ profile, onChoose, onEdit, onSaveAccount = null, testing = false }) {
  const [result, setResult] = useState(null);
  const [error, setError] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const key = JSON.stringify(profile || {});
  useEffect(() => {
    let active = true;
    setError(false); setResult(null);
    base44.functions.invoke("preview-match", { activities: profile?.activities || [] })
      .then(res => { if (!active) return; setResult(res.data); })
      .catch(() => { if (active) setError(true); });
    return () => { active = false; };
  }, [key, attempt]);
  return <section className="space-y-5" aria-live="polite">
    <div>
      <p className="text-xs uppercase tracking-[0.18em] text-[#ad7927] font-semibold">Deckhand · $0</p>
      <h2 className="font-heading text-2xl mt-1">{result?.directions?.length ? `${result.directions.length} example results` : "Four example results"}</h2>
      {testing
        ? <p className="text-muted-foreground mt-2">Admin testing: pick a question set below to add questions and generate model matches.</p>
        : /* One shared intro above the four cards, in Beau's words (Oct 22). Cards stay neutral. */
          <p className="sh-deckhand-intro text-muted-foreground mt-2">These four illustrative example results show how SoundHeading works. Activity-related boat types appear first; additional general examples are labelled. They are not verified model recommendations. You can <Link to="/edit-profile" className="font-medium text-[#051c3a] underline underline-offset-4">change your buyer profile</Link> at any time, and the activity-related examples may change with your answers.</p>}
    </div>
    {error ? <div className="rounded-xl border bg-background p-5"><p>We could not load your starting points. Your answers are safe.</p><Button className="mt-3" onClick={() => setAttempt(v => v + 1)}>Try again</Button></div>
    : !result ? <p>Charting your starting points…</p> : <>
      <ol className="sh-match-list grid">
        {result.directions?.map((d, i) => <li key={d.id} className="sh-mcard" style={/** @type {React.CSSProperties} */ ({ "--i": i })}>
          <div className="sh-typecard">
            <span className="sh-mark" aria-hidden="true"><span className="sh-mark__ring" /><Compass /></span>
            <div className="sh-mcard__main">
              <p className="sh-match-eyebrow">Example {i + 1} · {d.example_kind === "general_example" ? "General illustration" : "Activity-related starting point"}</p>
              <h3 className="sh-mcard__title">{d.title}</h3>
              <p className="sh-mcard__summary" style={{ WebkitLineClamp: 2 }}>{boatTypeNote(d)}</p>
            </div>
          </div>
        </li>)}
      </ol>
      {!result.directions?.length && <div className="rounded-xl border bg-background p-5"><p>No examples are available right now. Your saved answers are unchanged.</p>{onEdit && <Button className="mt-3" onClick={onEdit}>Change my activities</Button>}</div>}
      {result.note && <p className="text-sm text-muted-foreground">{result.note}</p>}
    </>}
    {onSaveAccount ? <div className="flex flex-wrap items-center gap-3">
      <Button onClick={onSaveAccount}>Create an account to keep these</Button>
      {onEdit && <Button variant="outline" onClick={onEdit}>Change my answers</Button>}
    </div> : onEdit && <div className="flex flex-wrap items-center gap-3">
      <Button onClick={onEdit}>Sharpen my answers</Button>
    </div>}
    {testing ? <div className="border-t pt-5"><h3 className="font-semibold">Admin testing · question sets</h3>
      <p className="text-sm text-muted-foreground mt-2">All levels are open for testing. No payment is required.</p>
      <div className="flex flex-wrap gap-3 mt-4">{PLAN_TIERS.map(t => <Button key={t.id} variant="outline" onClick={() => onChoose(t.id)}>{tierName(t.id)} questions</Button>)}</div>
    </div> : <TierTeaser plan="free" showAll />}
  </section>;
}
