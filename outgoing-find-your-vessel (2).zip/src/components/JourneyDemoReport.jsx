import React, {useState} from "react";
import BoatMatchCard from "@/components/reports/BoatMatchCard";
import {Button} from "@/components/ui/button";
import {PLAN_TIERS} from "@/lib/stages";
import {demoReportRecord} from "@/lib/journey-demo.mjs";
export default function JourneyDemoReport({state,results}){
 const [entries,setEntries]=useState(["","",""]);
 const [evaluations,setEvaluations]=useState({});
 const tier=PLAN_TIERS.find(t=>t.id===state.plan);
 const market=state.plan==="market_match";
 const refined=state.plan==="refined_match";
 return <section className="space-y-6" aria-label="Simulated package report">
  <header className="border rounded-xl p-6 bg-white">
   <p className="text-amber-800 font-semibold">FICTIONAL DEMONSTRATION REPORT</p>
   <h2 className="font-heading text-3xl">{tier?.name || "Deckhand"} · {market?"Finalist comparison":refined?"Refined shortlist":"Expanded model guidance"}</h2>
   <p className="mt-3">All models, specifications, scores, price bands and ownership numbers in this preview are invented UI examples. They are not researched boats, estimates or purchasing advice.</p>
   <p className="mt-3">{results.length} demo {market?"finalists":refined?"shortlisted models":"models"}. Selected activities: {(state.profile.activities||[]).join(", ") || "Not entered"}. Entered area: {state.profile.operating_area || "Not entered"}.</p>
   <p>Entered purchase budget: USD {Number(state.profile.purchase_budget_min||0).toLocaleString()}–{Number(state.profile.purchase_budget_max||0).toLocaleString()}. Like history: {state.likes.length} temporary Likes. Simulated updates used: {state.updates}/{tier?.updates}.</p>
  </header>
  <section className="bg-white border rounded-xl p-6">
   <h3 className="font-heading text-xl">How to read this {market?"comparison":refined?"shortlist":"expanded set"}</h3>
   <p className="mt-2">{market?"Compare the three finalists across layout, ownership tradeoffs, evidence gaps and seller questions. The next section demonstrates the three listing evaluations included with this package.":refined?"Five examples show stronger and weaker tradeoffs side by side. Review the compromises and deal breakers before choosing a finalist.":"Ten examples demonstrate the expanded discovery set, with deeper questions and your temporary Likes reflected in review order."}</p>
   <ul className="list-disc pl-5 mt-3 space-y-2">
    <li>Primary use: {(state.profile.activities||[]).join(", ") || "not entered"}; this text is copied from your temporary answers.</li>
    <li>Must-haves: {state.profile.must_haves || "not entered at this tier"}.</li>
    <li>Unacceptable compromises: {state.profile.unacceptable_compromises || "not entered at this tier"}.</li>
    <li>Before a real recommendation: verify identity, actual configuration, physical limits, person rating, current comparable prices and ownership assumptions.</li>
   </ul>
  </section>
  {(refined||market)&&<section className="bg-white border rounded-xl p-6 overflow-x-auto">
   <h3 className="font-heading text-xl mb-3">Demo tradeoff comparison</h3>
   <table className="w-full text-sm"><thead><tr className="text-left border-b"><th className="p-2">Fictional model</th><th className="p-2">Illustrated advantage</th><th className="p-2">Compromise</th><th className="p-2">Fictional range vs entered maximum</th></tr></thead>
    <tbody>{results.map(b=><tr key={b.id} className="border-b"><td className="p-2">{b.title}</td><td className="p-2">{b.demo.strengths[0]}</td><td className="p-2">{b.demo.tradeoff}</td><td className="p-2">{b.demo.low>Number(state.profile.purchase_budget_max)?"Both endpoints above maximum":b.demo.high>Number(state.profile.purchase_budget_max)?"Upper endpoint above maximum":"Both endpoints within maximum"}</td></tr>)}</tbody>
   </table>
  </section>}
  {results.map(b=><BoatMatchCard key={b.id} rank={b.rank} rec={demoReportRecord(b,state.profile,state.plan)} simulation />)}
  {market&&<>
   <section className="bg-white border rounded-xl p-6 space-y-3">
    <h3 className="font-heading text-xl">Demo ownership assumptions</h3>
    <p>The illustrative annual low is 8% of each invented upper price, rounded to 100 USD; the illustrative high is 1.5 times that. This arbitrary arithmetic exists to test layout only and is not a rule for real boat costs.</p>
    <p>Demo breakdown: 40% maintenance, 40% insurance/storage and 20% fuel. Real ownership planning must use expected hours, local storage quotes, insurance, service schedule, fuel burn and condition-specific reserves.</p>
    <p>Your entered annual budget: {state.profile.annual_ownership_budget ? "USD "+Number(state.profile.annual_ownership_budget).toLocaleString() : "Not entered"}. Ownership horizon: {state.profile.ownership_horizon || "Not entered"}.</p>
   </section>
   <section className="bg-white border rounded-xl p-6 space-y-4">
    <h3 className="font-heading text-xl">Three simulated listing evaluations</h3>
    <p>Enter a demo listing description or URL in each slot. Nothing is fetched, saved or sent. Each output is explicitly fictional; it does not assess the entered listing.</p>
    <p>{Object.keys(evaluations).length} of {tier.listingEvals} simulated evaluations completed.</p>
    {entries.map((entry,i)=><div key={i} className="border rounded-lg p-4 space-y-3">
     <label className="block font-medium" htmlFor={"demo-listing-"+i}>Demo listing {i+1}</label>
     <input id={"demo-listing-"+i} className="w-full border rounded p-2" placeholder="Demo description or URL (not fetched)" value={entry} onChange={e=>setEntries(old=>old.map((v,j)=>i===j?e.target.value:v))} />
     <Button disabled={!entry.trim() || !!evaluations[i]} onClick={()=>setEvaluations(old=>({...old,[i]:true}))}>{evaluations[i]?"Simulated evaluation complete":"Simulate listing evaluation"}</Button>
     {evaluations[i]&&<div className="rounded bg-amber-50 p-4"><h4 className="font-semibold">FICTIONAL evaluation {i+1}</h4><p>Input recorded only in this page's memory. No listing was opened.</p><ul className="list-disc pl-5 mt-2"><li>Example identity check: request hull identification, year and engine serials.</li><li>Example condition review: inspect service records, hull and rigging; independent survey required.</li><li>Example pricing check: compare actual year, configuration and condition against current independent asking evidence.</li><li>Example next step: ask seller for maintenance history and schedule an inspection if the real evidence supports proceeding.</li></ul></div>}
    </div>)}
   </section>
  </>}
 </section>;
}
