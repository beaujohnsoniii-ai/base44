# One-model discovery proof — 2026-10-19

## Executed separately from the application

Target: saved Match model BlackJack 224, saved model year 2026. Existing saved BoatTrader URL was read as record metadata only; the marketplace was not requested.

Two bounded Firecrawl chat-connector searches (three results each, no automatic page scraping) excluded BoatTrader/YachtWorld/boats.com. The first returned category pages/social noise, so no candidate facts were accepted. A second dealer-restricted search found the independent Boatyard inventory entry. One basic inventory read supplied the detail link; one basic detail read returned HTTP 200. No enhanced/stealth proxy, login, challenge action, Actor, LLM extraction or automatic retry was used.

Discovery chain:
- https://www.theboatyardinc.com/inventory/
- https://www.theboatyardinc.com/inventory/2012-blackjack-224-cc-3928/

Observed at 2026-10-19T22:50:33Z; source metadata claims an update at 2026-10-15T10:39:45-05:00. Retrieval was requested with maxAge:0, proxy:basic, storeInCache:false and TLS validation. Provider reports basic proxy and HTTP 200. This is a fresh provider retrieval observation, not independent verification of seller availability or app backend capability. The page contains a footer reCAPTCHA widget; no challenge was solved or bypassed.

## Result and limitations

Seller-page claims: 2012 BlackJack 224 CC, stock 3928, Suzuki 250HP, 290 hours. Regular-price and sale-price claims differ ($47,995 and $39,995), so the canonical asking price is null. A dollar symbol does not independently establish USD, so currency remains null. Savings and related boats are not current asking prices. No manufacturer specifications, tow fit or finalist recommendation was inferred.

This is a model-family candidate. The 2012 source year differs from the 2026 saved model year, and the saved model is named 224 rather than 224 CC. No alias was silently certified. Shared make/model/year with the old BoatTrader link cannot prove the same individual boat. The dealer stock number is scoped to the dealer; no HIN association to the saved marketplace listing was established. Saved links, selected IDs and customer records were not changed.

An excerpt and retrieval/search receipts are retained in tests/fixtures/blackjack-broker-discovery-observation.json. Existing broker parser replay is executable without network:
`node --experimental-strip-types --test tests/firecrawl-broker-test.test.mjs`

The observed escaped Markdown stock label previously failed parsing. The existing scoped parser now accepts it, excludes related recommendations/savings, and keeps unestablished currency null. This is not an activation of live Compare retrieval or a rerun/reset of the spent Firecrawl backend test.

## Actual bounded cost

Two searches reported 2 credits each. Inventory and detail retrieval each reported 1 credit. Two accepted search feedback submissions refunded 1 credit each. Net recorded cost: 4 Firecrawl chat-connector credits; dollar cost not independently verified. Balance before these calls: 981 credits on a 1,000-credit plan. These are chat-connector receipts, not the application's Firecrawl credential or its uncertain attempt.

## Existing app capability and exact dependency

The application already contains Tavily basic search using TAVILY_API_KEY:
- research-provider-health: one max_results:1 basic search plus three model-list checks; not a listing search endpoint.
- hybrid-online: manufacturer research, basic search max_results:3, advanced extraction and separate Anthropic review calls; unsafe to reuse wholesale for listing discovery cost.
- run-manufacturer-trial: expired one-shot manufacturer trial; not reusable for listing discovery.

No supported authenticated function invocation tool is exposed in this task. No existing listing-search request can be safely executed through the connected Base44 tools; the developer CLI is not already authenticated and must not be used to obtain new credentials. Production Tavily quota/key validity is therefore unverified here. No new browser connection loop was attempted.

## Minimal next integration, after backend proof

1. Expose a supported authenticated invocation of one owned saved model through existing app access. Prove exactly one Tavily basic search, max_results:3, include_usage:true, no raw-page expansion, no LLM/automatic retries; record actual provider usage rather than calling the multi-provider health check.
2. Filter results against the known blocked marketplace denylist. Only server-reviewed independent source operations may be read; an indexed result is not source-access permission. Do not follow marketplace redirect/proxy routes to work around 403s.
3. Show a discovered boat as a new candidate with source/observation dates, price conflicts, currency/hours unknowns and model-family status. Let an explicit choice associate it with Compare; never replace an existing saved listing or claim same-vessel identity from model similarity.
4. Keep current Compare, Actor policy and research/workbook untouched until the deployed search/read operation is proven and usage is bounded. No scheduler or public rollout is needed for the proof.

No backend discovery activation is claimed. The immediate dependency is authenticated invocation of the existing application backend, not another scraper framework.
