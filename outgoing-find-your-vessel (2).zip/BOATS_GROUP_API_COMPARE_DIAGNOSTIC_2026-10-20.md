# SoundHeading — Official Boats Group Inventory API / Compare handoff
Prepared October 19, 2026 ET. Scope: listing-import/COMPARE only.

## Authority & public sources (read, not executed)
- Official Overview https://api.boats.com/docs/overview : REST inventory API, API key required on queries; JSON and vendor MIME version. Only publicly documented, NOT evidence of issued key or entitlement.
- Inventory details https://api.boats.com/docs/services/details?s=inventory : inventory-ID lookup `/inventory/{DocumentID}`, search `/inventory/search`, marketplace search keys `BtolID` (Boat Trader Online), `BcnaID` (boats.com), `YachtWorldID`. Note: documentation examples display http://; production HTTPS endpoint behavior is NOT established.
- Status https://api.boats.com/docs/status lists inventory Available, NOT a verified live licensed import.
- Boats Group licensing https://www.boatsgroup.com/service-agreement-and-policies/ sections 28.2 and 28.3. Specifically *Co-Brokerage API* restrictions: member eligibility, inventory display/disclaimer, limits on storage/data transformation, intended use advertising boats rather than an independent buyer-analysis product, key non-sharing, competitive-use constraints. Do NOT assume these are the specific standalone Web Services inventory license; obtain separately applicable written rights.
- Co-Brokerage description https://www.boatsgroup.com/solutions/co-brokerage-api/ says sales rep quotes pricing and offering.
- Official key request links to https://www.boatsgroup.com/about-us/contact-us/ (website form) and contact phone 1-877-354-4069. No verified direct recipient email to send to. Do not invent one.

## Read-only preparation performed in Base44 sandbox
- `base44/shared/boats-group-inventory-adapter.mjs` = disabled, no fetch, secret, billable call, data writes, or activation. Separates marketplace-specific IDs from selected user-supplied exact URLs. Returns a non-executable lookup plan and rejects unsupported, malicious, ambiguous URLs.
- Offline-only adapter normalizes typed *documentation-shaped synthetic* rows, requiring matching marketplace-specific row ID and model year, preserving raw field source evidence and currency/unit, withholding ambiguous engine hours, draft, loaded storage weight, unknown currencies, and hiding price when PriceHideInd is set.
- `tests/boats-group-inventory-adapter.test.mjs` uses fabricated local API-shaped records; these ARE NOT real data or a live API response. Five added tests.
- Full `npm run test:match`: 511 passed, 0 failed; `npm run build`: exit 0.
- Official API never called. No API key read or configured. No production connection, permission, provider bill, or subscription.
- Previous Compare fixes remain: index-title year quote, visible mismatch warnings, partial-evidence status, all carried under prior checkpoint 6ad6cffb0c615261c1d619a6.
- No changes to listing resolver selection, entitlement gate, dataset, research tasks, workbook, or publish state.

## Vendor access questions (get answers IN WRITING before enabling)
1. Is standalone `api.boats.com` Inventory Web Services offered to an independent buyer-advisory company, separate from the Co-Brokerage API program? Can a non-dealer paid subscription service import 1/3/9 user-submitted links and compare relevant attributes?
2. Specifically may SoundHeading ingest/show/summarize listing facts, retain evidence quotes and an audit trail, transform values to normalized fields, display excerpts, and allow end-user access? What credit/disclaimer/privacy/retention/deletion rules apply?
3. Is this use allowed across Boat Trader, boats.com, YachtWorld? Are some listing owners excluded? Can we access current sold/expired records only if authorized?
4. Does a modern BoatTrader trailing URL ID equal `BtolID` in live inventory? Does boats.com URL suffix equal `BcnaID`, and YachtWorld suffix `YachtWorldID`? Can vendor give a test response of an exact single record after authorization?
5. Confirm HTTPS base URL, JSON schema shape, key handoff/storage guidance, rate/spend caps, allowed domains, throttling, stable API version and support.
6. Pricing, one-time fees, recurring membership minimums, per-call and overage cost, and whether a time-limited trial/test key exists without subscription.
7. Does customer-facing paid vessel acquisition advice or comparative ranking conflict with prohibited competitive uses under the relevant agreement? Request tailored written permission.

## Current evidence and alternatives
- Current Base44 direct fetch for Blackfin and Sailfish got HTTP 403 (2 exact URLs). A user-authorized single Firecrawl stealth scrape of Blackfin also got HTTP 403 and one credit. No successful real-time full extraction.
- Indexed exact-URL BlackJack source excerpt gave 2012 year, title, Suzuki engine and 290 hours in text, but did NOT populate hours because lacks a fully qualified hours statement; partial evidence only. The two other screenshot URLs returned HTTP 403.
- Official API: high potential for structured source with ID link; medium feasibility pending issuance, mappings, commercial rights and measured success. Cost unknown.
- Explicit user paste/upload: no remote bot retrieval; useful if user can access the page and supplies text or images, but manual friction and incomplete structure. Mobile browser open tab cannot automatically expose DOM to web app.
- User-invoked browser extension/capture: technically plausible with opt-in and scoped permissions, not built or proven.
- Authorized dealer-provided feeds: potentially license-friendly, but does not cover every marketplace link and availability/price/scope unverified.
- Managed browsing: not proven to retrieve blocked markets, source access terms and costs unknown.
- Apify Actors: original source actor template and offline adapters don't demonstrate actual production imported record; not used.

## Next step / launch gate
Do not turn on official API or buy subscriptions until a license and capped trial key authorize the intended use. On issuance, run ONE authenticated, bounded exact-URL lookup; require matching marketplace ID, correct listing year and raw source-specific values. Log timing, fields and real invoice/credit costs. Only then repeat across 3 and 9 with explicit spend cap. Evaluate all results in Compare, not just unit tests. Preserve the paused manufacturer-model research workbook/release; separate decision brief due October 20 8AM ET. No launch/publication.
