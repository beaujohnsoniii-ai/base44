// Official Boats Group inventory API — offline mapping ONLY.
// Documentation: https://api.boats.com/docs/services/details?s=inventory
// Do not fetch, authenticate, enable, store vendor responses, or publish this
// adapter without written permission covering SoundHeading buyer-advisory use.
// The Co-Brokerage API's published restrictions do not establish that permission.
import { normalizePublicListingUrl } from "./remote-listing.ts";

export const BOATS_GROUP_API_RUNTIME = Object.freeze({
  enabled: false,
  activation_requires: ["written access agreement for SoundHeading", "issued API key",
    "permitted presentation/retention terms", "bounded call budget", "real ID-mapping proof"],
  purpose: "offline Compare integration planning only",
});

const routes = Object.freeze({
  "boattrader.com": {marketplace:"boattrader", query_field:"BtolID", path:/^\/boat\/(19\d{2}|20\d{2})-[a-z0-9-]+-(\d{5,12})\/?$/i},
  "yachtworld.com": {marketplace:"yachtworld", query_field:"YachtWorldID", path:/^\/yacht\/(19\d{2}|20\d{2})-[a-z0-9-]+-(\d{5,12})\/?$/i},
  "boats.com": {marketplace:"boats_com", query_field:"BcnaID", path:/^\/(?:power-boats|sail-boats|boat)\/(19\d{2}|20\d{2})-[a-z0-9-]+-(\d{5,12})\/?$/i},
});
export function identifyBoatsGroupListing(value) {
  const url = normalizePublicListingUrl(value);
  if (!url) return null;
  const parsed = new URL(url);
  if (parsed.search) return null;
  const route = routes[parsed.hostname.replace(/^www\./,"")];
  const match = route?.path.exec(parsed.pathname);
  if (!match) return null;
  return {marketplace:route.marketplace,query_field:route.query_field,
    source_url:url,listing_id:match[2],url_year_hint:Number(match[1])};
}
export function planBoatsGroupLookup(url) {
  const listing = identifyBoatsGroupListing(url);
  if (!listing) return {supported:false,executable:false,reason:"Not a recognized exact Boats Group listing URL"};
  return {supported:true,executable:false,listing,
    api_origin:"https://api.boats.com",resource:"/inventory/search",
    search_parameters:{[listing.query_field]:listing.listing_id,rows:1},
    caveats:["API key and a contract permitting buyer-advisory use are required.",
      "An indexed marketplace ID may not correspond to an active API record.",
      "Fields, response format, rates and ID mapping require live licensed validation.",
      "This object contains no API key and performs no network request."]};
}

const clean = value => typeof value==="string" && value.trim().length>0 && value.trim().length<=200 ? value.trim() : null;
const numeric = value => (typeof value==="number" || typeof value==="string" && /^\d+(?:\.\d+)?$/.test(value.trim()))
  && Number.isFinite(Number(value)) ? Number(value) : null;
const positive = value => {const n=numeric(value);return n!==null && n>0 ? n : null;};
const norm = value => String(value??"").toLowerCase().replace(/[^a-z0-9]+/g,"");
const measureFt = value => {
  const m = typeof value==="string" ? /^\s*(\d+(?:\.\d+)?)\s*(?:ft|feet|foot|')\s*$/i.exec(value) : null;
  return m && Number(m[1])>0 ? Number(m[1]) : null;
};
const price = value => {
  const m=typeof value==="string" ? /^\s*(\d+(?:\.\d{1,2})?)\s+([A-Z]{3})\s*$/.exec(value.replace(/,/g,"")) : null;
  return m && Number(m[1])>0 ? {value:Number(m[1]),currency:m[2]} : null;
};
export const BOATS_GROUP_COMPARE_FIELDS = Object.freeze([
  "make","model","year","asking_price","asking_price_currency","engine_hours",
  "overall_length_ft","beam_ft","draft_ft","storage_height_ft",
  "loaded_storage_weight_lb","passenger_capacity",
]);

export function normalizeBoatsGroupInventoryRow(row, listingUrl, options={}) {
  const identity=identifyBoatsGroupListing(listingUrl);
  if (!identity || !row || typeof row!=="object" || Array.isArray(row)
      || JSON.stringify(row).length>65536) return {status:"unsupported_or_invalid",exact_listing:false,
    facts:{},evidence:[],warnings:["No single validated inventory record was provided."],eligible:false};
  const facts={},evidence=[],warnings=[];
  const exactId = String(row[identity.query_field]??"");
  // Matching the marketplace-specific API ID is required; no reliance on
  // result order, saved model names, or another marketplace's ID.
  if (exactId !== identity.listing_id || !/^\d{5,12}$/.test(exactId)) {
    return {status:"identity_not_proven",exact_listing:false,source_url:identity.source_url,
      facts:{},evidence:[],warnings:["The response did not confirm the requested marketplace-specific listing ID."],eligible:false};
  }
  const observedYear = numeric(row.ModelYear);
  if (!Number.isInteger(observedYear) || observedYear !== identity.url_year_hint) {
    return {status:"identity_conflict",exact_listing:false,source_url:identity.source_url,
      facts:{},evidence:[],warnings:["The API model year is missing or conflicts with the listing URL. Verify before using any other data."],eligible:false};
  }
  const add=(field,value,jsonField,unit="",basis="unspecified")=>{
    if (value===null || value===undefined) return;
    facts[field]={value,unit,basis,provenance:"unverified_official_inventory_claim"};
    evidence.push({field,raw_field:jsonField,raw_value:row[jsonField],
      source_url:identity.source_url,marketplace_id:identity.listing_id,
      provenance:"boats_group_api_claim_not_live_verified"});
  };
  add("year",observedYear,"ModelYear","","listing_identity");
  add("make",clean(row.MakeString),"MakeString","","listing_identity");
  add("model",clean(row.Model),"Model","","listing_identity");
  const asking=price(row.Price);
  if (row.PriceHideInd === true || row.PriceHideInd === "true") warnings.push("Listing requests price not be shown.");
  else if (asking) {
    add("asking_price",asking.value,"Price",asking.currency);
    add("asking_price_currency",asking.currency,"Price");
  }
  add("overall_length_ft",measureFt(row.LengthOverall),"LengthOverall","ft","unspecified");
  add("beam_ft",measureFt(row.BeamMeasure),"BeamMeasure","ft","beam");
  const passengers=positive(row.MaximumNumberOfPassengersNumeric);
  if (Number.isSafeInteger(passengers)) add("passenger_capacity",passengers,"MaximumNumberOfPassengersNumeric","persons","seller_listing_claim");
  // TotalEngineHoursNumeric is aggregate, not per-engine hours. MaxDraft is
  // not defined as engine-down draft; LengthOverall is not rigged storage length.
  if (row.TotalEngineHoursNumeric!=null) warnings.push("Combined engine-hours figure is not verified as per-engine hours.");
  if (row.MaxDraft!=null) warnings.push("MaxDraft is not an established engine-down draft.");
  if (row.TotalPrice!=null && !asking) warnings.push("TotalPrice is not automatically treated as an asking price.");
  if (options.expected_make && facts.make && norm(facts.make.value)!==norm(options.expected_make))
    warnings.push("API make differs from the saved Match model.");
  if (options.expected_model && facts.model && norm(facts.model.value)!==norm(options.expected_model))
    warnings.push("API model differs from the saved Match model.");
  if (options.expected_year && Number(options.expected_year)!==observedYear)
    warnings.push("API listing year differs from the saved Match model's year; do not borrow saved-model specifications.");
  return {status:"offline_normalized_unlicensed",exact_listing:true,source_url:identity.source_url,
    marketplace:identity.marketplace,marketplace_id:identity.listing_id,api_status:"not_called",
    facts,evidence,warnings,nullable_facts:Object.fromEntries(BOATS_GROUP_COMPARE_FIELDS.map(f=>[f,facts[f]?.value??null])),
    eligible:false,production_approved:false,
    provenance:{provider:"Boats Group Inventory API",live_retrieval_verified:false,license_verified:false}};
}
