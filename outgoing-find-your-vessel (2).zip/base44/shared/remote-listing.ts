// Server-side guard for buyer-supplied listing links. These URLs are untrusted.
export function normalizePublicListingUrl(input: unknown): string | null {
  if (typeof input !== "string" || input.length > 2048) return null;
  try {
    const url = new URL(input.trim());
    if (url.protocol !== "https:" || url.username || url.password || url.port) return null;
    const host = url.hostname.toLowerCase().replace(/\.$/, "");
    if (!host.includes(".") || host.startsWith("[") || /^\d/.test(host) && /^\d[\d.]*$/.test(host)) return null;
    if (/(^|\.)(localhost|local|internal|lan|intranet|test|invalid|example|onion)$/.test(host)) return null;
    if (host === "home.arpa" || host.endsWith(".home.arpa") || host.endsWith(".localdomain")) return null;
    if (host.split(".").some(label => !label || label.length > 63)) return null;
    url.hash = "";
    return url.toString();
  } catch (_) { return null; }
}

function plainTextFromHtml(html: string): string {
  return html.replace(/<script[^>]*>[\s\S]*?<\/script>/gi," ")
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi," ")
    .replace(/<noscript[^>]*>[\s\S]*?<\/noscript>/gi," ")
    .replace(/<[^>]+>/g," ").replace(/&nbsp;/g," ").replace(/&amp;/g," ")
    .replace(/&#\d+;/g," ").replace(/\s+/g," ").trim().slice(0,8000);
}

// Reject nonpublic schemes/hosts and revalidate EVERY redirect before fetching.
// Limit content to 2 MiB to prevent oversized responses while allowing modern listing pages.
// Returns both plain text (for claim extraction) and raw HTML (for JSON-LD parsing).
export async function fetchPublicListing(
  url: string,
  options: { allowedHosts?: Set<string> } = {},
): Promise<{text: string; html: string; ok: boolean; error?: string; final_url?: string}> {
  let current = normalizePublicListingUrl(url);
  if (!current) return {text:"",html:"",ok:false,error:"Provide a public HTTPS listing URL"};
  const allowed = options.allowedHosts;
  const hostAllowed = (value: string) => !allowed || allowed.has(new URL(value).hostname.toLowerCase());
  if (!hostAllowed(current)) return {text:"",html:"",ok:false,error:"Listing host is not approved"};
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    for (let redirect = 0; redirect <= 3; redirect++) {
      const response = await fetch(current, {
        signal: controller.signal,
        redirect:"manual",
        headers: {Accept:"text/html,application/xhtml+xml"},
      });
      if ([301,302,303,307,308].includes(response.status)) {
        const location = response.headers.get("location");
        if (!location) return {text:"",html:"",ok:false,error:"Missing redirect destination"};
        current = normalizePublicListingUrl(new URL(location,current).toString());
        if (!current) return {text:"",html:"",ok:false,error:"Listing redirected to a restricted URL"};
        if (!hostAllowed(current)) return {text:"",html:"",ok:false,error:"Listing redirected outside the approved source"};
        continue;
      }
      if (!response.ok) return {text:"",html:"",ok:false,error:"HTTP " + response.status};
      const type = response.headers.get("content-type") || "";
      if (type && !/text\/html|application\/xhtml\+xml|text\/plain/i.test(type)) {
        return {text:"",html:"",ok:false,error:"Listing URL did not return a web page"};
      }
      const max = 2 * 1024 * 1024;
      const reader = response.body?.getReader();
      if (!reader) return {text:"",html:"",ok:false,error:"Listing page was empty"};
      const chunks: Uint8Array[] = [];
      let total = 0;
      while (true) {
        const next = await reader.read();
        if (next.done) break;
        total += next.value.byteLength;
        if (total > max) { await reader.cancel(); return {text:"",html:"",ok:false,error:"Listing page is too large"}; }
        chunks.push(next.value);
      }
      const bytes = new Uint8Array(total);
      let offset=0;
      for (const chunk of chunks) { bytes.set(chunk,offset); offset+=chunk.length; }
      const htmlText = new TextDecoder().decode(bytes);
      const text = plainTextFromHtml(htmlText);
      if (text.length < 100) return {text:"",html:"",ok:false,error:"Page content too short"};
      return {text,html:htmlText,ok:true,final_url:current};
    }
    return {text:"",html:"",ok:false,error:"Too many redirects"};
  } catch (e:any) {
    return {text:"",html:"",ok:false,error:e?.name==="AbortError" ? "Request timed out" : "Unable to fetch public listing"};
  } finally { clearTimeout(timer); }
}