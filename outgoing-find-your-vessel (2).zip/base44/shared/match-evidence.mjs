// MATCH evidence classification and buyer-facing flags.
//
// Two different questions are answered separately here, because they are not
// the same kind of problem:
//   1. Can a recorded fact decide whether a boat meets a buyer's stated limit?
//      (MATCH-critical vs optional)
//   2. Is that fact confirmed, unrecorded, or disputed by its sources?
//      (source_confirmed / missing / not_checked / conflict)
//
// Nothing in this module invents a value. An unrecorded fact stays unconfirmed,
// a source disagreement stays a blocker, and a specification tied to no stated
// buyer limit is simply not shown. Hard-limit exclusions are decided by
// physical-specs and propulsion screening and are never softened here: this
// module only labels and routes evidence, it never clears a limit.

// Field classes are about consequence, not about importance in general.
//   critical = a source-confirmed value in this field can decide whether the
//              model satisfies a limit the buyer actually stated, so a dispute
//              or a gap in it must stay visible.
//   optional = useful context that can never, on its own, decide fit.
export const MATCH_FIELD_CLASSES = {
  "LOA": { matchClass: "critical", constraint: "overall length", constraintId: "length", key: "rigged_overall_length_ft" },
  "Length w/ Bracket/Engines": { matchClass: "critical", constraint: "rigged overall length", constraintId: "length", key: "rigged_overall_length_ft" },
  "Beam": { matchClass: "critical", constraint: "beam", constraintId: "beam", key: "beam_ft" },
  "Draft Engines Down": { matchClass: "critical", constraint: "draft", constraintId: "draft", key: "draft_ft" },
  "Passenger Capacity": { matchClass: "critical", constraint: "passenger capacity", constraintId: "passengers", key: "passenger_capacity" },
  // Dry weight excludes fuel, engine fluids and gear, so it can never establish
  // a storage, lift or tow limit. It stays context, not a fit decision.
  "Dry Weight / Displacement": { matchClass: "optional", constraint: "dry weight", constraintId: null, key: "dry_weight_lb" },
  "Fuel Capacity (gal)": { matchClass: "optional", constraint: "fuel capacity", constraintId: null, key: "fuel_capacity_gal" },
};

const UNCLASSIFIED = { matchClass: "optional", constraint: "other specification", constraintId: null, key: null };

const MAXIMUM = "(?:max(?:imum)?|limit|cap|cannot\\s+exceed|must\\s+not\\s+exceed|no\\s+longer\\s+than|no\\s+more\\s+than|not\\s+over)";

function positiveNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : null;
}

// Which limits this buyer actually stated. A field with no matching stated
// limit is not flagged, which is how irrelevant specification noise is removed
// without hiding anything the buyer's own requirements depend on.
export function buyerConstraintIds(profile = {}) {
  const notes = String(profile?.storage_capacity || "");
  const stated = new Set();
  if (positiveNumber(profile?.hard_max_overall_length_ft) !== null ||
      new RegExp(MAXIMUM + "[^.]{0,25}(?:length|loa)", "i").test(notes) ||
      new RegExp("(?:length|loa)[^.]{0,25}" + MAXIMUM, "i").test(notes)) stated.add("length");
  if (positiveNumber(profile?.hard_max_beam_ft) !== null ||
      new RegExp(MAXIMUM + "[^.]{0,25}(?:beam|width)", "i").test(notes)) stated.add("beam");
  if (positiveNumber(profile?.hard_max_draft_ft) !== null) stated.add("draft");
  if (positiveNumber(profile?.passenger_count) !== null ||
      positiveNumber(profile?.occasional_passenger_count) !== null) stated.add("passengers");
  return stated;
}

// A conflicted fact carries no usable value into customer output.
export function classifyRecordedFields(fields = []) {
  return (Array.isArray(fields) ? fields : [])
    .filter(field => field && typeof field.field === "string" && field.field.trim())
    .map(field => {
      const meta = MATCH_FIELD_CLASSES[field.field] || UNCLASSIFIED;
      const status = ["source_confirmed", "conflict", "missing", "not_checked"].includes(field.status)
        ? field.status : "not_checked";
      return {
        field: field.field,
        matchClass: meta.matchClass,
        constraint: meta.constraint,
        constraintId: meta.constraintId,
        key: meta.key,
        status,
        value: status === "source_confirmed" ? (field.value ?? null) : null,
        unit: status === "source_confirmed" ? (field.unit ?? null) : null,
        source_url: status === "source_confirmed" && typeof field.source_url === "string" ? field.source_url : null,
        checked_at: status === "source_confirmed" ? (field.checked_at ?? null) : null,
      };
    });
}

function tally(rows) {
  return {
    total: rows.length,
    confirmed: rows.filter(row => row.status === "source_confirmed").length,
    unconfirmed: rows.filter(row => row.status === "missing" || row.status === "not_checked").length,
    disputed: rows.filter(row => row.status === "conflict").length,
  };
}

// A completeness report, never a completeness fix. Counts describe only what
// was already recorded; a gap is reported as a gap.
export function evidenceAudit({ fields = [], verifiedFields = [] } = {}) {
  const rows = classifyRecordedFields(fields);
  return {
    basis: "Counts recorded research only. An unrecorded specification is reported as unconfirmed and is never estimated.",
    critical: tally(rows.filter(row => row.matchClass === "critical")),
    optional: tally(rows.filter(row => row.matchClass !== "critical")),
    catalog_verified_fields: (Array.isArray(verifiedFields) ? verifiedFields : []).filter(f => typeof f === "string"),
    fields: rows,
  };
}

export function normalizeFlag(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

// Identical and near-identical notes are collapsed; the first wording wins.
export function dedupeFlags(list = []) {
  const seen = new Set();
  const out = [];
  for (const item of Array.isArray(list) ? list : []) {
    if (typeof item !== "string" || !item.trim()) continue;
    const key = normalizeFlag(item);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(item.trim());
  }
  return out;
}

const CONSTRAINT_KEYWORDS = {
  "overall length": ["overall length", "loa"],
  "rigged overall length": ["rigged overall length", "overall length", "loa"],
  "beam": ["beam"],
  "draft": ["draft"],
  "passenger capacity": ["passenger capacity", "persons", "passenger"],
};

function alreadyCovered(existing, constraint) {
  const keywords = CONSTRAINT_KEYWORDS[constraint] || [constraint];
  return (Array.isArray(existing) ? existing : []).some(note =>
    keywords.some(keyword => normalizeFlag(note).includes(normalizeFlag(keyword))));
}

// Buyer-facing evidence flags.
//   blockers     = a dispute on a limit the buyer stated. A true fit blocker;
//                  never suppressed.
//   verification = that limit is not confirmed for this model year yet. Shown
//                  once, and skipped when a screening note already says it.
// Specifications tied to no stated limit produce nothing at all.
export function buildEvidenceFlags({ fields = [], verifiedFields = [], profile = {}, existing = [] } = {}) {
  const audit = evidenceAudit({ fields, verifiedFields });
  const stated = buyerConstraintIds(profile);
  const seen = new Set((Array.isArray(existing) ? existing : []).map(normalizeFlag));
  const blockers = [];
  const verification = [];

  for (const row of audit.fields) {
    if (row.matchClass !== "critical") continue;
    if (!row.constraintId || !stated.has(row.constraintId)) continue;
    if (row.status === "conflict") {
      blockers.push(
        `${row.field}: independent sources disagree, so this model cannot be confirmed against your stated ${row.constraint} limit. Resolve the disagreement before relying on it.`,
      );
      continue;
    }
    if (row.status === "source_confirmed") continue;
    const note = `Confirm this model's ${row.constraint} from a published specification before relying on your stated limit.`;
    if (seen.has(normalizeFlag(note)) || alreadyCovered(existing, row.constraint)) continue;
    verification.push(note);
  }

  return { blockers: dedupeFlags(blockers), verification: dedupeFlags(verification), audit };
}