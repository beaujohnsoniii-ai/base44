import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const analyst = JSON.parse(readFileSync(new URL("../agents/boat_analyst.jsonc", import.meta.url), "utf8"));

test("Boat Analyst distinguishes model MATCH from buyer-submitted listings and legacy tiers", () => {
  assert.match(analyst.instructions, /MATCH recommends underlying boat models/);
  assert.match(analyst.instructions, /Saved boats are buyer-submitted leads, not verified live inventory/);
  assert.match(analyst.instructions, /installed optional equipment must never be presented as inherent facts/);
  assert.doesNotMatch(analyst.instructions, /Find My Boat \/ Model Shortlist \/ Private Advisory/);
});

test("Boat Analyst refuses invented safety and access claims", () => {
  assert.match(analyst.instructions, /independently confirmed passenger limit/);
  assert.match(analyst.instructions, /Missing or seller-only claims require verification/);
  assert.match(analyst.instructions, /excludes RIBs, jon boats, sailboats/);
  assert.ok(analyst.tool_configs.every(config => config.allowed_operations.every(op => op === "read")));
});
