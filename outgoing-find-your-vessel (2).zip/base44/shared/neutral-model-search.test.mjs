import test from 'node:test';
import assert from 'node:assert/strict';
import { modelSearchUrl } from './listing-links.ts';

function terms(url) {
  return new URL(url).searchParams.get('q');
}
test('neutral search includes the title when structured make and model are unknown', () => {
  assert.equal(terms(modelSearchUrl('2025 Parker 2520 XLD Sport Cabin')), 'Parker 2520 XLD Sport Cabin for sale');
});
test('neutral search uses make and model and does not over-restrict model years', () => {
  assert.equal(terms(modelSearchUrl('2025 Parker 2520 XLD', 'Parker', '2520 XLD')), 'Parker 2520 XLD for sale');
});
test('neutral search infers a model name from a known manufacturer and model title', () => {
  assert.equal(terms(modelSearchUrl('2025 Parker 2520 XLD', 'Parker')), 'Parker 2520 XLD for sale');
});
