import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const guide = fs.readFileSync('base44/shared/advisor-reasoning.ts', 'utf8');

test('ownership budget cannot be declared invalid because it exceeds boat price over several years', () => {
  assert.match(guide, /Do NOT flag a buyer merely because several years/);
  assert.doesNotMatch(guide, /ANNUAL-MAINTENANCE-VS-BUDGET FLAG/);
});

test('budget headroom is not a reason to recommend a larger boat', () => {
  assert.match(guide, /budget headroom as a benefit, not a defect/);
  assert.doesNotMatch(guide, /most quality 18 ft bay boats sell/);
});

test('lift safety margin is not specified as a universal percentage', () => {
  assert.match(guide, /determine adequate safety margin from the lift manufacturer/);
  assert.doesNotMatch(guide, /15% safety load rating/);
});

test('pilothouse category does not automatically rule out towing', () => {
  assert.match(guide, /some are readily trailerable/);
  assert.doesNotMatch(guide, /towing is usually not an option/);
});
