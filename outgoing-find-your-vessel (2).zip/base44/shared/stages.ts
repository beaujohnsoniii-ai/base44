// Authoritative paid-service catalog for SoundHeading.
//
// All packages are ONE-TIME purchases. No subscription or automatic renewal.
//
// Four tiers, each building on the last for a single active boat-buying search.
// The funnel keeps a WIDE pool and sharpens the recommendation inside it — the
// result counts and marks live in ./tier-results.mjs:
//   0. Free Discovery — $0. 4 broad starting directions with no deeper questions.
//   1. MATCH+ — $9. 10-14 models to look around with using deeper questions plus prior
//      Likes. Deliberately wide; nothing is marked as the recommendation.
//      3 matching updates over 30 days. The $9 is credited toward either higher tier.
//   2. Refined Match — $29 total ($20 upgrade from MATCH+). The same wide pool,
//      re-ranked by the deeper constraints and deal-breakers, with the leading 5-7
//      marked as the recommendation. 5 updates over 30 days.
//   3. Market Match — $99 total ($90 from MATCH+, $70 from Refined). The full pool
//      with the top 3 marked as finalists, detailed comparison, ownership-cost
//      estimates, 3 listing evaluations, and 10 updates over 90 days.
//
// Upgrade credits: prior package payments are credited toward upgrades for the same
// search. Total package payments never exceed $99 to reach Market Match (excluding
// add-ons and extensions). Upgrades replace the lower tier's remaining allowance with
// the higher tier's and start a new access window on the purchase date.
//
// The create-checkout function resolves price SERVER-SIDE from this map — the client
// only sends a productId, never a price.

export interface StageProduct {
  id: string;
  name: string;
  price: string; // amount CHARGED at checkout, major units, e.g. "9.00"
  tagline: string;
  description: string;
  credit_eligible: boolean; // true when a legacy activation/advisor credit may apply
  requires_plan?: string; // for upgrades/add-ons: the plan the buyer must already hold
  kind: "one_time";
}

// --- Tier normalization ---
// Legacy plan values map to the new tier structure so existing records keep working.
const LEGACY_PLAN_MAP: Record<string, string> = {
  initial_boat_match: "match_plus",
  buyer_pass: "market_match",
};

export function normalizePlan(plan: string | null | undefined): string {
  const p = String(plan || "free");
  return LEGACY_PLAN_MAP[p] || p;
}

export function isPaidPlan(plan: string | null | undefined): boolean {
  return tierRank(plan) > 0;
}

export const TIER_RANK: Record<string, number> = {
  free: 0,
  match_plus: 1,
  refined_match: 2,
  market_match: 3,
};

export function tierRank(plan: string | null | undefined): number {
  return TIER_RANK[normalizePlan(plan)] ?? 0;
}

// Report access is cumulative: Market Match includes Refined Match benefits.
// This is only one part of authorization; the server also checks legacy purchases.
export function planGrantsReport(plan: string | null | undefined, type: string): boolean {
  const rank = tierRank(plan);
  return (type === "top_pick" && rank >= TIER_RANK.refined_match)
    || (type === "top_three" && rank >= TIER_RANK.market_match);
}

// Legacy activation credit — kept so existing activation holders can spend it on the
// credit-eligible packages (refined_match, market_match).
export const ACTIVATION_CREDIT = 29;

// Update allowances per package, over the package's access window.
export const MATCH_PLUS_UPDATES = 3;
export const REFINED_UPDATES = 5;
export const MARKET_MATCH_UPDATES = 10;
// Legacy aliases (keep exports so existing imports don't break):
export const INITIAL_UPDATES = MATCH_PLUS_UPDATES;
export const BUYER_PASS_UPDATES = MARKET_MATCH_UPDATES;

// Access-window durations (days) per package.
export const MATCH_PLUS_ACCESS_DAYS = 30;
export const REFINED_ACCESS_DAYS = 30;
export const MARKET_MATCH_ACCESS_DAYS = 90;
// Legacy aliases:
export const INITIAL_ACCESS_DAYS = MATCH_PLUS_ACCESS_DAYS;
export const BUYER_PASS_ACCESS_DAYS = MARKET_MATCH_ACCESS_DAYS;

// Listing evaluations included with Market Match.
export const MARKET_MATCH_LISTING_EVALS = 3;
export const BUYER_PASS_LISTING_EVALS = MARKET_MATCH_LISTING_EVALS;

// Search extension: 90 more days + 10 more updates.
export const EXTENSION_ACCESS_DAYS = 90;
export const EXTENSION_UPDATES = 10;

// Legacy regeneration limits for the report regenerate flow.
export const TOP_THREE_REGENERATION_LIMIT = 10;
export const TOP_PICK_REGENERATION_LIMIT = 5;

export const STAGE_PRODUCTS: Record<string, StageProduct> = {
  // --- Direct package purchases (new tier names) ---
  match_plus: {
    id: "match_plus",
    name: "Bosun",
    price: "9.00",
    tagline: "10-14 models to look around with, using deeper questions plus your Likes",
    description:
      "Receive a wide set of 10-14 boat models to research, using additional high-value questions plus your previous Likes to sharpen the search. Nothing is marked as our recommendation at this level — this is the set to look around with. Includes the initial results plus three matching updates within 30 days. Your $9 is credited toward either higher tier.",
    credit_eligible: false,
    kind: "one_time",
  },
  refined_match: {
    id: "refined_match",
    name: "First Mate",
    price: "29.00",
    tagline: "The full 10-14 model set, re-ranked, with the leading 5-7 marked as your recommendation",
    description:
      "Receive the same wide pool of 10-14 boat models, re-ranked by your deeper answers on family use, storage, draft, towing and deal-breakers, with the leading 5-7 marked as your recommendation and every other model still visible with why it ranks where it does — detailed fit explanations, advantages, compromises, and potential deal breakers. Includes the initial report plus five updates within 30 days of purchasing this tier.",
    credit_eligible: true,
    kind: "one_time",
  },
  market_match: {
    id: "market_match",
    name: "Captain",
    price: "99.00",
    tagline: "Your top 3 finalists marked inside the full model set, with detailed comparison and ownership costs",
    description:
      "Receive the full model set with the top 3 marked as finalists, complete additional ownership-planning questions, and a detailed comparison of those finalists with ownership-cost estimates and stated assumptions, suitability concerns, seller questions, and recommended inspection topics. Includes evaluations of up to three specific boat listings you supply, plus ten updates during a 90-day access period.",
    credit_eligible: true,
    kind: "one_time",
  },

  // --- Upgrades (credit the prior package payment toward the higher tier) ---
  upgrade_match_plus_to_refined: {
    id: "upgrade_match_plus_to_refined",
    name: "Upgrade to First Mate",
    price: "20.00",
    tagline: "Credit your $9 Bosun payment toward the $29 package",
    description:
      "For Bosun customers. Credits your $9 payment in full toward the $29 First Mate package — you pay $20 additional and unlock the re-ranked full model set with the leading 5-7 marked as your recommendation, plus five updates over 30 days.",
    credit_eligible: false,
    requires_plan: "match_plus",
    kind: "one_time",
  },
  upgrade_match_plus_to_market: {
    id: "upgrade_match_plus_to_market",
    name: "Upgrade to Captain",
    price: "90.00",
    tagline: "Credit your $9 Bosun payment toward the $99 package",
    description:
      "For Bosun customers. Credits your $9 payment in full toward the $99 Captain package — you pay $90 additional and unlock the detailed finalist comparison, ownership-cost estimates, 3 listing evaluations, and ten updates over 90 days.",
    credit_eligible: false,
    requires_plan: "match_plus",
    kind: "one_time",
  },
  upgrade_refined_to_market: {
    id: "upgrade_refined_to_market",
    name: "Upgrade to Captain",
    price: "70.00",
    tagline: "Credit your $29 First Mate payment toward the $99 package",
    description:
      "For First Mate customers. Credits your $29 payment in full toward the $99 Captain package — you pay $70 additional and unlock the detailed finalist comparison, ownership-cost estimates, 3 listing evaluations, and ten updates over 90 days.",
    credit_eligible: false,
    requires_plan: "refined_match",
    kind: "one_time",
  },

  // --- Legacy product aliases (map to the same grants as the new products) ---
  initial_boat_match: {
    id: "initial_boat_match",
    name: "Bosun",
    price: "9.00",
    tagline: "10-14 models to look around with, using deeper questions plus your Likes",
    description:
      "Receive a wide set of 10-14 boat models to research, using additional high-value questions plus your previous Likes to sharpen the search. Nothing is marked as our recommendation at this level — this is the set to look around with. Includes the initial results plus three matching updates within 30 days. Your $9 is credited toward either higher tier.",
    credit_eligible: false,
    kind: "one_time",
  },
  buyer_pass: {
    id: "buyer_pass",
    name: "Captain",
    price: "99.00",
    tagline: "Your top 3 finalists marked inside the full model set, with detailed comparison and ownership costs",
    description:
      "Receive the full model set with the top 3 marked as finalists, complete additional ownership-planning questions, and a detailed comparison of those finalists with ownership-cost estimates and stated assumptions, suitability concerns, seller questions, and recommended inspection topics. Includes evaluations of up to three specific boat listings you supply, plus ten updates during a 90-day access period.",
    credit_eligible: true,
    kind: "one_time",
  },
  upgrade_initial_to_refined: {
    id: "upgrade_initial_to_refined",
    name: "Upgrade to First Mate",
    price: "20.00",
    tagline: "Credit your $9 Bosun payment toward the $29 package",
    description:
      "For Bosun customers. Credits your $9 payment in full toward the $29 First Mate package — you pay $20 additional and unlock the re-ranked full model set with the leading 5-7 marked as your recommendation, plus five updates over 30 days.",
    credit_eligible: false,
    requires_plan: "match_plus",
    kind: "one_time",
  },
  upgrade_initial_to_buyer: {
    id: "upgrade_initial_to_buyer",
    name: "Upgrade to Captain",
    price: "90.00",
    tagline: "Credit your $9 Bosun payment toward the $99 package",
    description:
      "For Bosun customers. Credits your $9 payment in full toward the $99 Captain package — you pay $90 additional and unlock the detailed finalist comparison, ownership-cost estimates, 3 listing evaluations, and ten updates over 90 days.",
    credit_eligible: false,
    requires_plan: "match_plus",
    kind: "one_time",
  },
  upgrade_refined_to_buyer: {
    id: "upgrade_refined_to_buyer",
    name: "Upgrade to Captain",
    price: "70.00",
    tagline: "Credit your $29 First Mate payment toward the $99 package",
    description:
      "For First Mate customers. Credits your $29 payment in full toward the $99 Captain package — you pay $70 additional and unlock the detailed finalist comparison, ownership-cost estimates, 3 listing evaluations, and ten updates over 90 days.",
    credit_eligible: false,
    requires_plan: "refined_match",
    kind: "one_time",
  },

  // --- Optional add-ons (Market Match only) ---
  listing_eval_1: {
    id: "listing_eval_1",
    name: "1 Additional Listing Evaluation",
    price: "19.00",
    tagline: "Evaluate one more specific boat listing",
    description:
      "For Captain customers. Add one additional listing evaluation beyond the three included with Captain. Evaluating a listing you already evaluated does not consume this allowance; evaluating a different listing does.",
    credit_eligible: false,
    requires_plan: "market_match",
    kind: "one_time",
  },
  listing_eval_3: {
    id: "listing_eval_3",
    name: "3 Additional Listing Evaluations",
    price: "49.00",
    tagline: "Evaluate three more specific boat listings",
    description:
      "For Captain customers. Add three additional listing evaluations beyond the three included with Captain. Evaluating a listing you already evaluated does not consume an allowance; evaluating a different listing does.",
    credit_eligible: false,
    requires_plan: "market_match",
    kind: "one_time",
  },
  search_extension: {
    id: "search_extension",
    name: "Search Extension",
    price: "29.00",
    tagline: "Extend your Captain for 90 more days and 10 more updates",
    description:
      "For Captain customers. Extend your existing Captain for another 90 days and receive ten additional updates to your matching results and existing reports. Extensions are purchased manually and do not automatically renew. Evaluations of new listings are purchased separately.",
    credit_eligible: false,
    requires_plan: "market_match",
    kind: "one_time",
  },
};

export function resolveStage(productId: string): StageProduct | null {
  return STAGE_PRODUCTS[productId] ?? null;
}