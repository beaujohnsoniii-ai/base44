// SoundHeading boat category taxonomy — shared labels, descriptions, and
// activity-to-category hints used by the advisor reasoning, the questionnaire,
// the relabeling function, and the admin review page.

export const CATEGORIES = [
  { value: "offshore_cc_dc", label: "Offshore CC / DC" },
  { value: "premium_performance_specialty", label: "Premium Performance / Specialty" },
  { value: "bay_flats_skiff", label: "Bay / Flats / Skiff" },
  { value: "pilothouse_express_utility", label: "Pilothouse / Express / Utility" },
  { value: "sportfishing_yacht_custom", label: "Sportfishing Yachts / Custom" },
  { value: "tow_sport", label: "Tow / Sport" },
  { value: "pontoon", label: "Pontoon" },
  { value: "cruiser_runabout", label: "Cruiser / Runabout" },
  { value: "power_catamaran", label: "Power Catamaran" },
  { value: "saltwater_fishing", label: "Saltwater Fishing" },
  { value: "trawler", label: "Trawler" },
  { value: "performance", label: "Performance" },
] as const;

export const CATEGORY_LABELS: Record<string, string> = Object.fromEntries(
  CATEGORIES.map((c) => [c.value, c.label])
);

export const CATEGORY_DESCRIPTIONS: Record<string, string> = {
  offshore_cc_dc: "Center consoles and dual consoles built for open-water fishing — offshore runs, rough water, and big-water angling.",
  premium_performance_specialty: "Lower-volume, high-build-quality specialists — hand-laid hulls, premium hardware, category-leading fit and finish.",
  bay_flats_skiff: "Shallow-water fishing boats — bay boats, flats skiffs, and technical poling skiffs for inshore and backwater angling.",
  pilothouse_express_utility: "Enclosed-helm boats for rough water and year-round use — pilothouse, express, and utility hulls.",
  sportfishing_yacht_custom: "Large sportfishermen and custom battlewagons — tournament-grade fishing systems, convertible interiors, diesel power.",
  tow_sport: "Wakeboard, wakesurf, and ski boats — ballast systems, surf gates, towers, and inboard drivetrains.",
  pontoon: "Pontoon and tri-toon platforms — stable, family-friendly, shallow-draft entertainment and cruising boats.",
  cruiser_runabout: "Day cruisers, bowriders, and cabin cruisers — family cruising, swimming, and occasional overnighting.",
  power_catamaran: "Twin-hull power catamarans — varied designs for fishing, cruising, diving and travel; space, ride, efficiency and range depend on the specific hull and power package.",
  saltwater_fishing: "Dedicated saltwater fishing boats not covered by offshore, bay, or sportfishing — multi-species coastal and nearshore fishing platforms.",
  trawler: "Displacement-hull trawlers and passage-makers — long-range, economical cruising with full-displacement hulls and semi-displacement variants.",
  performance: "High-performance go-fast boats and offshore racers — speed-focused hulls, big horsepower, and performance-oriented construction.",
};

// Categories that must always be human-reviewed even at high AI confidence —
// the high-stakes specialist buckets where a wrong label distorts advice most.
export const REVIEW_REQUIRED_CATEGORIES = new Set([
  "premium_performance_specialty",
  "sportfishing_yacht_custom",
  "trawler",
  "power_catamaran",
]);

// Map a buyer's selected activities to the boat categories most likely to fit.
// Used by loadManufacturerMap to filter the brief toward relevant builders.
export const ACTIVITY_CATEGORY_HINTS: Record<string, string[]> = {
  "Fishing": ["offshore_cc_dc", "bay_flats_skiff", "pilothouse_express_utility", "sportfishing_yacht_custom", "saltwater_fishing"],
  "Day cruising": ["cruiser_runabout", "pontoon", "power_catamaran"],
  "Overnight cruising": ["cruiser_runabout", "pilothouse_express_utility", "trawler", "power_catamaran"],
  "Watersports / tubing": ["tow_sport", "cruiser_runabout", "performance"],
  "Diving": ["offshore_cc_dc", "pilothouse_express_utility", "power_catamaran"],
  "Entertaining": ["pontoon", "cruiser_runabout", "power_catamaran"],
  "Commuting": ["cruiser_runabout", "pilothouse_express_utility", "power_catamaran"],
  "Liveaboard": ["cruiser_runabout", "pilothouse_express_utility", "trawler", "power_catamaran"],
};

export function categoriesForActivities(activities: string[]): string[] {
  if (!Array.isArray(activities) || activities.length === 0) return [];
  const set = new Set<string>();
  for (const a of activities) {
    const hints = ACTIVITY_CATEGORY_HINTS[a];
    if (hints) hints.forEach((h) => set.add(h));
  }
  return [...set];
}