// Page-aware PDF extraction: no full-document context is sent to a model.
// Lazy load with the package scheme required by Base44's Deno backend.
async function pdfLibrary() {
 return import('npm:pdfjs-dist@4.10.38/legacy/build/pdf.mjs');
}
export const normalizeSpec = s => String(s||'').replace(/[’‘]/g,"'").replace(/[“”]/g,'"').replace(/\s+/g,' ').trim().toLowerCase();
export function isolatePdfPage(pages,{model,year,sourceUrl}) {
 const exact = normalizeSpec(model);
 const hits = [];
 for (const page of pages) {
  const text = normalizeSpec(page.text);
  if (!text.includes(exact)) continue;
  const headings = (text.match(/\b(?:2520|2820)\s+(?:xld|xl)\b/g)||[]);
  // Same page with multiple distinct variants is unsafe unless table is separately anchored.
  if (new Set(headings).size>1) continue;
  const header=/length\s+loa\s+passenger\s+rating\s+beam\s+hull\s+draft/i;
  const table = header.exec(page.text);
  if (!table) continue;
  const tail = page.text.slice(table.index+table[0].length);
  const rows=tail.split(/\n/).map(x=>x.trim()).filter(Boolean);
  // Table rows must be isolated; if parser flattens the table, refuse to guess.
  const data=rows.find(x=>/^\d{2}\s*[’']\s*\d{0,2}\s*[”"]?\s+/.test(x));
  if (!data || rows.filter(x=>/^\d{2}\s*[’']\s*\d{0,2}\s*[”"]?\s+/.test(x)).length!==1) continue;
  hits.push({ok:true,model,year,page:page.page,row_id:`page-${page.page}-spec-1`,source_url:sourceUrl,heading:model,table_header:table[0],row_text:data});
 }
 return hits.length===1?hits[0]:{ok:false,reason:hits.length?'Multiple candidate pages/rows':'No unambiguous exact-model page and spec row'};
}
export async function readPdfPages(bytes,{maxPages=90}={}) {
 const {getDocument}=await pdfLibrary();
 const task=getDocument({data:new Uint8Array(bytes),useSystemFonts:true,disableFontFace:true});
 const doc=await task.promise;
 try {
  if(doc.numPages>maxPages) throw new Error('PDF page cap exceeded');
  const pages=[];
  for(let i=1;i<=doc.numPages;i++) {
   const page=await doc.getPage(i); const content=await page.getTextContent();
   const lines=new Map();
   for(const item of content.items){if(typeof item.str!=='string')continue;
    const y=Math.round(item.transform?.[5]||0);const x=item.transform?.[4]||0;
    if(!lines.has(y))lines.set(y,[]);lines.get(y).push({x,text:item.str});
   }
   const text=[...lines.entries()].sort((a,b)=>b[0]-a[0]).map(([,items])=>items.sort((a,b)=>a.x-b.x).map(t=>t.text).join(' ')).join('\n');
   pages.push({page:i,text});
  }
  return pages;
 } finally {await doc.destroy();}
}
export function verifyClaimAgainstRow(claim,source) {
 if(!source?.ok||claim.source_page!==source.page||claim.source_row_id!==source.row_id||claim.source_model_year!==source.year)return false;
 if(!claim.field||!claim.unit||!claim.measurement_basis||!claim.exact_quote||claim.value==null)return false;
 const quote=normalizeSpec(claim.exact_quote),row=normalizeSpec(source.row_text);
 return quote.length>=4 && row.includes(quote) && quote.includes(normalizeSpec(String(claim.value)).replace(/\s+/g,'')) ;
}
