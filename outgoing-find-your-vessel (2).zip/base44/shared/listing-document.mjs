import {extractListingClaims} from "./listing-claims.mjs";
import {normalizePublicListingUrl} from "./remote-listing.ts";
export const LISTING_FIELDS=["make","model","year","asking_price","asking_price_currency","engine_hours","overall_length_ft","beam_ft","draft_ft","storage_height_ft","loaded_storage_weight_lb","passenger_capacity"];
export const nullableListingFacts=facts=>Object.fromEntries(LISTING_FIELDS.map(k=>[k,facts?.[k]?.value??null]));
const plain=html=>html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi," ").replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi," ").replace(/<[^>]*>/g," ").replace(/&nbsp;/g," ").replace(/&amp;/g,"&").replace(/\s+/g," ").trim().slice(0,16000);
const val=x=>typeof x==="string"?x:typeof x?.name==="string"?x.name:null;
export function extractListingDocument(doc){
 const html=typeof doc.html==="string"?doc.html:"";
 if(new TextEncoder().encode(html).length>262144)throw Error("Document too large");
 const text=html?plain(html):String(doc.text||"").slice(0,16000);
 const fallback=extractListingClaims(text),nodes=[],scripts=[];
 if(html){
  const re=/<script\b[^>]*type\s*=\s*["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  for(const m of html.matchAll(re)){
   if(scripts.length>=8)break;const index=scripts.length;scripts.push(m[1]);
   try{let count=0;const walk=(x,path,depth)=>{if(++count>128||depth>8||!x||typeof x!=="object")return;
    if(Array.isArray(x)){x.slice(0,30).forEach((n,i)=>walk(n,path+"["+i+"]",depth+1));return;}
    const types=Array.isArray(x["@type"])?x["@type"]:[x["@type"]];
    if(types.some(t=>/^(Boat|Vehicle|Product)$/i.test(String(t))))nodes.push({node:x,path,script_index:index});
    if(x["@graph"])walk(x["@graph"],path+".@graph",depth+1);if(x.mainEntity)walk(x.mainEntity,path+".mainEntity",depth+1);
   };walk(JSON.parse(m[1]),"$",0);}catch{/* Malformed JSON-LD is not executable code. */}
  }
 }
 const canonical=normalizePublicListingUrl(doc.final_url);
 const matching=nodes.filter(({node})=>[node.url,node["@id"]].some(u=>normalizePublicListingUrl(u)===canonical));
 const candidates=matching.length?matching:nodes.filter(({node})=>!node.url&&!node["@id"]);
 if(candidates.length>1)return {text,extraction:{page_kind:"unknown",facts:[]},evidence:[],ambiguity:"Multiple listing objects; no individual boat selected."};
 if(candidates.length!==1)return {text,extraction:fallback,evidence:[],association_text:text,ambiguity:null};
 const {node,path,script_index}=candidates[0],quote=JSON.stringify(node),facts=[],evidence=[];
 const add=(field,value,unit="",fieldPath=field,q=quote)=>{
  if(value===null||value===undefined||value==="")return;
  facts.push({field,value,unit,quote:q,basis:"unspecified"});
  evidence.push({field,format:"jsonld",script_index,json_path:path+"."+fieldPath,source_url:canonical,quote:q,value});
 };
 add("make",val(node.brand)||val(node.manufacturer),"",node.brand?"brand":"manufacturer");
 add("model",val(node.model));
 const yr=node.vehicleModelDate??node.modelDate; if(/^(19|20)\d{2}$/.test(String(yr)))add("year",Number(yr),"",node.vehicleModelDate?"vehicleModelDate":"modelDate");
 const offers=Array.isArray(node.offers)?node.offers:[node.offers];
 const validOffers=offers.filter(o=>o&&typeof o==="object"&&/^[A-Z]{3}$/.test(String(o.priceCurrency))&&Number.isFinite(Number(o.price))&&Number(o.price)>0);
 const priceClaims=new Set(validOffers.map(o=>o.priceCurrency+":"+Number(o.price)));
 if(priceClaims.size===1){const offer=validOffers[0];add("asking_price",Number(offer.price),offer.priceCurrency,"offers.price",JSON.stringify(offer));add("asking_price_currency",offer.priceCurrency,"","offers.priceCurrency",JSON.stringify(offer));}
 // Explicit engine-hours only; mileage, engine displacement and generic usage are not hours.
 if(node.engineHours!=null&&/^\d+(?:\.\d+)?$/.test(String(node.engineHours))&&Number.isFinite(Number(node.engineHours))&&Number(node.engineHours)>=0)add("engine_hours",Number(node.engineHours),"h","engineHours");
 const by=new Map(facts.map(f=>[f.field,f]));const conflicts=[];
 // Page-wide fallback fields cannot be attached to a selected structured entity.
 if(priceClaims.size>1){by.delete("asking_price");by.delete("asking_price_currency");conflicts.push("asking_price");}
 const entity_associations=[];
 for(const value of (Array.isArray(node.sameAs)?node.sameAs:[node.sameAs])){const u=normalizePublicListingUrl(value);if(u)entity_associations.push({kind:"entity_same_as",url:u,json_path:path+".sameAs",quote:JSON.stringify({sameAs:value})});}
 for(const item of (Array.isArray(node.identifier)?node.identifier:[node.identifier]))if(item&&typeof item==="object"&&String(item.propertyID).toLowerCase()==="boattrader"&&/^\d+$/.test(String(item.value)))entity_associations.push({kind:"entity_marketplace_id",marketplace:"boattrader",id:String(item.value),json_path:path+".identifier",quote:JSON.stringify(item)});
 const stock=typeof node.sku==="string"?{value:node.sku,quote:JSON.stringify({sku:node.sku}),provenance:"structured_entity_claim"}:null;
 return {text:text+"\n"+quote,entity_associations,entity_stock:stock,extraction:{page_kind:by.has("make")&&by.has("model")?"listing":"unknown",facts:[...by.values()]},evidence,conflicts,ambiguity:null};
}
