import { normalizePublicListingUrl } from "./remote-listing.ts";

const text = value => String(value ?? "").replace(/\s+/g, " ").trim();
const norm = value => text(value).toLowerCase().replace(/[^a-z0-9]+/g, "");
const cap = (value, max) => text(value).slice(0, max);

function sameListingUrl(a, b) {
  const left = normalizePublicListingUrl(a), right = normalizePublicListingUrl(b);
  if (!left || !right) return false;
  const x = new URL(left), y = new URL(right);
  const path = url => url.pathname.replace(/\/+$/, "").toLowerCase();
  return x.hostname.toLowerCase() === y.hostname.toLowerCase() && path(x) === path(y);
}

export function extractIndexedListingExcerpt(source, input) {
  const title = cap(source.title, 500);
  const excerpt = cap(source.content, 8000);
  const joined = (title + "\n" + excerpt).trim();
  const expectedMake = text(input.expected_make), expectedModel = text(input.expected_model);
  if (!expectedMake || !expectedModel || !norm(joined).includes(norm(expectedMake)) || !norm(joined).includes(norm(expectedModel))) {
    return { page_kind: "unknown", facts: [] };
  }
  const quote = title || cap(excerpt, 800);
  const facts = [
    { field: "make", value: expectedMake, quote, unit: "", basis: "listing_identity" },
    { field: "model", value: expectedModel, quote, unit: "", basis: "listing_identity" },
  ];
  const addNumber = (field, match, unit = "", basis = "unspecified") => {
    if (!match) return;
    const value = Number(String(match[1]).replace(/,/g, ""));
    if (Number.isFinite(value) && value >= 0) facts.push({ field, value, quote: cap(match[0], 800), unit, basis });
  };
  // A bare four-digit year is not enough quoted context, and years elsewhere in
  // the excerpt may describe other boats. Only use a unique year in the
  // exact-result title alongside the expected make and model.
  const titleYears = [...title.matchAll(/\b((?:19|20)\d{2})\b/g)];
  if (titleYears.length === 1 && norm(title).includes(norm(expectedMake)) && norm(title).includes(norm(expectedModel))) {
    facts.push({ field: "year", value: Number(titleYears[0][1]), quote: title, unit: "", basis: "listing_identity" });
  }
  const price = joined.match(/(?:\bUSD\s*)?\$\s*([\d,]+(?:\.\d{1,2})?)/i);
  addNumber("asking_price", price, "USD");
  if (price) facts.push({ field: "asking_price_currency", value: "USD", quote: cap(price[0], 800), unit: "", basis: "unspecified" });
  addNumber("engine_hours", joined.match(/\bengine(?:\(s\))?\s*hours?\s*[:\-]?\s*(\d+(?:\.\d+)?)\b/i), "h");
  addNumber("beam_ft", joined.match(/\bbeam\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*(?:ft|feet|'|\.ft)\b/i), "ft", "beam");
  addNumber("draft_ft", joined.match(/\b(?:engine.down draft|draft\s*\(engine down\))\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*(?:ft|feet|')\b/i), "ft", "engine_down");
  addNumber("passenger_capacity", joined.match(/\b(?:capacity|seating(?:\s+for)?|room\s+for)\s*[:\-]?\s*(\d+)\s*(?:persons?|passengers?|onboard)?\b/i), "persons");
  return { page_kind: "listing", facts };
}

export async function searchExactListingExcerpt(url, input, signal, request = globalThis.fetch) {
  const key = globalThis.Deno?.env?.get?.("TAVILY_API_KEY")?.trim();
  if (!key || typeof request !== "function") return { ok: false, error: "Indexed fallback unavailable" };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 4500);
  const abort = () => controller.abort();
  signal?.addEventListener?.("abort", abort, { once: true });
  try {
    const response = await request("https://api.tavily.com/search", {
      method: "POST",
      signal: controller.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: key,
        query: `"${url}" "${text(input.expected_make)} ${text(input.expected_model)}"`,
        search_depth: "basic",
        max_results: 3,
        include_answer: false,
        include_images: false,
      }),
    });
    if (!response.ok) return { ok: false, error: "Indexed fallback HTTP " + response.status };
    const body = await response.json();
    const match = Array.isArray(body?.results) ? body.results.find(row => sameListingUrl(row?.url, url)) : null;
    if (!match) return { ok: false, error: "No exact indexed result" };
    const source = { title: cap(match.title, 500), content: cap(match.content, 8000), url };
    const extraction = extractIndexedListingExcerpt(source, input);
    if (extraction.page_kind !== "listing") return { ok: false, error: "Indexed result identity did not match" };
    return {
      ok: true,
      text: (source.title + "\n" + source.content).trim(),
      extraction,
      evidence: {
        provider: "tavily",
        provenance: "indexed_search_excerpt",
        source_url: url,
        title: source.title,
        excerpt: cap(source.content, 1600),
        retrieved_at: new Date().toISOString(),
      },
    };
  } catch (error) {
    return { ok: false, error: error?.name === "AbortError" ? "Indexed fallback timed out" : "Indexed fallback failed" };
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener?.("abort", abort);
  }
}
