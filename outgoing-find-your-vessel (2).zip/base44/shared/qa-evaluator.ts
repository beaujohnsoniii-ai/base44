// SoundHeading MATCH QA — AI evaluator for qualitative assessment.
//
// Evaluates a profile's full tier progression in a single LLM call (cost control).
// The evaluator is allowed to say UNCERTAIN — EXPERT REVIEW REQUIRED rather than
// pretending to know specialized marine facts.
//
// Only called for cases that pass programmatic checks (or have only minor issues).
// Cases with RED programmatic checks are flagged directly without AI evaluation.
//
// Imported by the run-match-qa backend function only.

export interface AIScorecardDimension {
  name: string;
  rating: "good" | "acceptable" | "concern" | "bad";
  notes: string;
}

export interface AIEvaluationResult {
  scorecard: {
    dimensions: AIScorecardDimension[];
    per_tier: {
      tier: string;
      concern_level: "green" | "yellow" | "red" | "uncertain";
      summary: string;
    }[];
    progression_assessment: string;
    overall_concern_level: "green" | "yellow" | "red" | "uncertain";
    overall_summary: string;
    uncertain_areas: string[];
  };
  concern_level: "green" | "yellow" | "red" | "uncertain";
  summary: string;
}

const EVAL_SCHEMA = {
  type: "object",
  properties: {
    scorecard: {
      type: "object",
      properties: {
        dimensions: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              rating: { type: "string", enum: ["good", "acceptable", "concern", "bad"] },
              notes: { type: "string" },
            },
            required: ["name", "rating", "notes"],
          },
        },
        per_tier: {
          type: "array",
          items: {
            type: "object",
            properties: {
              tier: { type: "string" },
              concern_level: { type: "string", enum: ["green", "yellow", "red", "uncertain"] },
              summary: { type: "string" },
            },
            required: ["tier", "concern_level", "summary"],
          },
        },
        progression_assessment: { type: "string" },
        overall_concern_level: { type: "string", enum: ["green", "yellow", "red", "uncertain"] },
        overall_summary: { type: "string" },
        uncertain_areas: { type: "array", items: { type: "string" } },
      },
      required: ["dimensions", "per_tier", "progression_assessment", "overall_concern_level", "overall_summary"],
    },
  },
  required: ["scorecard"],
};

function tierLabel(tier: string): string {
  return ({
    free: "Free Discovery",
    match_plus: "MATCH+ ($9)",
    refined_match: "Refined Match ($29)",
    market_match: "Market Match ($99)",
  } as Record<string, string>)[tier] || tier;
}

// MATCH suggestions describe models/generations, not boats advertised for sale.
// A legacy asking_price field is NOT usable model-level price evidence.
function modelPriceForQa(s: any): string {
  const min = Number(s?.price_range_min);
  const max = Number(s?.price_range_max);
  if (!Number.isFinite(min) || min <= 0 || !Number.isFinite(max) || max < min) {
    return "model price unverified";
  }
  const context = String(s?.price_range_context || "").trim();
  return `estimated model range $${min.toLocaleString("en-US")}–$${max.toLocaleString("en-US")}${context ? ` (${context})` : " (generation/year/market context missing)"}`;
}

function summarizeSuggestions(suggestions: any[]): string {
  if (!suggestions?.length) return "(no suggestions returned)";
  return suggestions.map((s, i) =>
    `${i + 1}. ${s.title || "Unknown"} — ${modelPriceForQa(s)} — Fit ${typeof s.suitability_score === "number" ? s.suitability_score : "unverified"}/100 — ${s.why_suggested || ""} | matches: ${(s.match?.matches || []).join("; ")} | gaps: ${(s.match?.gaps || []).join("; ")} | verification: ${(s.verification_required || []).join("; ") || "none"}`,
  ).join("\n");
}

function summarizeLikes(likedModels: any[]): string {
  if (!likedModels?.length) return "(none)";
  return likedModels.map(lm => `- ${lm.title} (liked at ${lm.liked_at_tier})`).join("\n");
}

function summarizeProgrammaticChecks(checks: any, concernLevel: string): string {
  const c = checks || {};
  const parts = [`concern: ${concernLevel}`];
  if (!c.count_compliant) parts.push(`count: ${c.count_actual} (expected ${c.count_min}-${c.count_max})`);
  if (c.budget_violations?.length) parts.push(`budget violations: ${c.budget_violations.length}`);
  if (c.size_violations?.length) parts.push(`preferred-size deviations (soft, not hard failures): ${c.size_violations.length}`);
  if (c.storage_violations?.length) parts.push(`storage violations: ${c.storage_violations.length}`);
  if (c.duplicate_models?.length) parts.push(`duplicates: ${c.duplicate_models.length}`);
  if (c.hard_constraint_violations?.length) parts.push(`hard-constraint violations: ${c.hard_constraint_violations.length}`);
  if (c.like_override_detected) parts.push(`like-override detected`);
  if (c.score_violations?.length) parts.push(`score-integrity violations: ${c.score_violations.length}`);
  if (c.verification_flags?.length) parts.push(`verification flags: ${c.verification_flags.length}`);
  return parts.join(", ");
}

// Evaluate a profile's full tier progression in a single LLM call.
export async function evaluateProfile(
  base44: any,
  profile: any,
  tierResults: { tier: string; suggestions: any[]; likedModels: any[]; programmaticChecks: any; programmaticConcernLevel: string }[],
): Promise<AIEvaluationResult> {
  const profileSummary = JSON.stringify({
    vessel_class: profile.vessel_class,
    activities: profile.activities,
    activity_weights: profile.activity_weights,
    operating_area: profile.operating_area,
    experience_level: profile.experience_level,
    previously_owned_boats: profile.previously_owned_boats,
    passenger_count: profile.passenger_count,
    occasional_passenger_count: profile.occasional_passenger_count,
    family_use: profile.family_use,
    overnight_requirements: profile.overnight_requirements,
    storage: profile.storage,
    storage_capacity: profile.storage_capacity,
    hard_max_overall_length_ft: profile.hard_max_overall_length_ft,
    hard_max_beam_ft: profile.hard_max_beam_ft,
    hard_max_height_ft: profile.hard_max_height_ft,
    hard_max_storage_weight_lb: profile.hard_max_storage_weight_lb,
    boat_size_range: profile.boat_size_range,
    draft: profile.draft,
    hard_max_draft_ft: profile.hard_max_draft_ft,
    towing: profile.towing,
    tow_capacity_lb: profile.tow_capacity_lb,
    budget: [profile.purchase_budget_min, profile.purchase_budget_max],
    annual_ownership_budget: profile.annual_ownership_budget,
    ownership_horizon: profile.ownership_horizon,
    must_haves: profile.must_haves,
    preferences: profile.preferences,
    unacceptable_compromises: profile.unacceptable_compromises,
    priorities: profile.priorities,
    preferred_manufacturers: profile.preferred_manufacturers,
    open_to_project_boats: profile.open_to_project_boats,
  });

  const tierSections = tierResults.map(tr => {
    const label = tierLabel(tr.tier);
    return `=== ${label} ===
Programmatic checks: ${summarizeProgrammaticChecks(tr.programmaticChecks, tr.programmaticConcernLevel)}
Likes before this tier: ${summarizeLikes(tr.likedModels)}
Suggestions (${tr.suggestions?.length || 0}):
${summarizeSuggestions(tr.suggestions)}`;
  }).join("\n\n");

  const prompt = `You are a QA evaluator for SoundHeading, an impartial boat-buying advisory platform. You are evaluating the MATCH recommendation engine's output for a test buyer across all four tiers (Free Discovery → MATCH+ → Refined Match → Market Match).

Your job is to evaluate whether the recommendations genuinely fit this buyer's profile, whether the tier progression makes sense, and whether the advisor is reasoning well. You are NOT the advisor — you are reviewing its work.

CRITICAL: You are allowed to say UNCERTAIN when you lack specialized marine knowledge. Do NOT pretend to know facts about specific boat models, hull types, or manufacturer reputations that you cannot verify. When uncertain, say "UNCERTAIN — EXPERT REVIEW REQUIRED" and explain what you cannot verify.

MODEL-LEVEL PRICE AND EQUIPMENT: These are recommendations of boat MODELS, not advertised individual boats. Judge broad, sourced generation/year model price ranges when supplied; an unverified or missing range is a verification gap, not a reason to invent an asking price or conclude a model is unaffordable. Ignore legacy asking_price for these suggestions. Do not treat joystick, bow thruster, electronics, windlass, shower, Seakeeper, or other optional configuration-specific equipment as guaranteed installed or inherently required; separately check model suitability versus later listing verification. Numeric speed, fuel burn and range need exact test/source and engine configuration.

TIER FAIRNESS: The full buyer profile below is for test review; earlier tiers do not have access to all of its answers. Free has basic boat class, preferred size, area, selected activities, experience, storage type and maximum purchase budget. MATCH+ adds activity weighting, normal/occasional passenger counts, prior boats, manufacturers and budget minimum. Refined adds family, detailed storage/physical limits, draft, towing, project tolerance, must-haves, preferences and deal-breakers. Market Match adds annual cost budget, ownership horizon, ranked priorities and explicit overnight requirements. Do not penalize a lower tier for failing to use a later-tier preference it could not yet see. However, no tier may affirmatively violate a known genuine hard/safety/facility limit, and any missing material fact must be flagged for verification.

EVALUATE THESE DIMENSIONS (rate each as good / acceptable / concern / bad):
1. Activity/use fit: Do the suggested boats match what the buyer actually does with a boat? Respect activity_weights when supplied: the dominant activity should drive platform/hull/layout fit, while secondary activities separate otherwise close candidates. Do not treat all selected activities as equally important when explicit weights exist.
2. Operating-area suitability: Are the boats appropriate for the buyer's waters?
3. Passenger/family suitability: Optimize layout and comfort around passenger_count as the normal everyday group. If occasional_passenger_count is supplied, use it as a peak-use accommodation check without letting rare larger groups force an oversized boat. Distinguish comfortable fit from verified legal passenger/capacity limits.
4. Storage suitability: Do the boats fit the buyer's storage type and capacity?
5. Towing suitability: If the buyer tows, compare realistic loaded trailered weight only against an actual tow rating the buyer supplied. NEVER infer a tow ceiling from vehicle type/name, boat length, or generic vehicle class. If towing matters but the buyer supplied no actual rating, mark compatibility as needing verification rather than assuming pass/fail. Skip if not trailer-stored.
6. Experience-level suitability: Are the boats appropriate for the buyer's experience?
7. Ownership complexity/cost suitability: Are the boats reasonable for the buyer's annual budget and horizon?
8. Ranking logic: Are the boats ordered from strongest to weakest fit? boat_size_range is a preferred range, not a hard boundary: a slightly outside-range boat may rank higher when it is materially better and all true physical limits are satisfied. Do not penalize that merely for crossing the preferred range.
9. Appropriate influence of Likes: Did later tiers incorporate prior Likes without letting them override hard constraints?
10. Recommendation diversity: Are different manufacturers represented when multiple makes fit?
11. Explanation/reasoning quality: Are the why_suggested and match fields specific and honest?
12. Compromise identification: Are gaps and compromises identified honestly?
13. Excessive confidence: Does the advisor present unverified specs/prices as confirmed? Treat verification_required as an intentional safeguard, not automatically as a recommendation defect. A problem exists when a material unknown is silently assumed, when a hard-limit fact is unknown without a verification flag, or when the recommendation language claims certainty despite the flag.
14. Score integrity: Does the fit score agree with the stated reasoning and tradeoffs? The deterministic programmatic checker validates arithmetic/caps; here evaluate whether the relative scoring is substantively believable. Do not treat a 1-2 point difference as meaningful precision.

TIER PROGRESSION — evaluate whether paid refinement actually improves the recommendation:
- Free → MATCH+: Did the deeper questions (activity mix, passengers, prior boats, preferred brands) improve the picks?
- MATCH+ → Refined Match: Did the deeper constraints (family use, storage capacity, draft, towing, must-haves, deal-breakers) narrow to stronger matches?
- Refined Match → Market Match: Did the deepest answers (ownership horizon, annual budget, priorities, overnight needs) sharpen to the best finalists?
- Flag cases where: a paid tier barely changes despite important new info, a higher tier scores worse, newly unlocked information appears ignored, Likes appear ignored or overweighted, newly learned constraints are violated, or recommendations churn dramatically without a defensible reason.
- Do NOT require arbitrary change for the sake of change. If the previous recommendation remains the best boat after additional information, retaining it can be correct.

CONCERN LEVELS:
- GREEN: Recommendations genuinely fit the buyer's profile. Minor issues only.
- YELLOW: Notable concerns that an expert should review. The recommendations might be OK but something seems off.
- RED: Clear problems — hard-constraint violations, terrible fits, or the advisor is clearly not reasoning about this buyer.
- UNCERTAIN: You lack the specialized marine knowledge to evaluate. Expert review required.

Be concise but specific. Reference the buyer's actual profile fields when explaining your ratings.

BUYER PROFILE:
${profileSummary}

TIER RESULTS:
${tierSections}

Return your evaluation as a structured scorecard with per-dimension ratings, per-tier concern levels and summaries, a progression assessment, an overall concern level, and a list of uncertain areas.`;

  try {
    const result: any = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: EVAL_SCHEMA,
    });
    const scorecard = result?.scorecard || result;
    return {
      scorecard,
      concern_level: scorecard?.overall_concern_level || "uncertain",
      summary: scorecard?.overall_summary || "",
    };
  } catch (e) {
    console.error("qa-evaluator: evaluation failed", e);
    return {
      scorecard: { dimensions: [], per_tier: [], progression_assessment: "Evaluation failed", overall_concern_level: "uncertain", overall_summary: "AI evaluation call failed", uncertain_areas: ["AI evaluation error"] },
      concern_level: "uncertain",
      summary: "AI evaluation call failed",
    };
  }
}