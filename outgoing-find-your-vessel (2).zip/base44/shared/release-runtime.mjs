// Backend-only proposed release service. Repository operations are injected.
// No Base44 writes, providers, credentials, or browser dependencies.
import { createHash } from 'node:crypto';
const copy = value => structuredClone(value);
export function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k => JSON.stringify(k)+':'+canonical(value[k])).join(',') + '}';
  if (value === undefined || (typeof value === 'number' && !Number.isFinite(value))) throw Error('Non-JSON payload');
  return JSON.stringify(value);
}
export const digest = value => createHash('sha256').update(canonical(value)).digest('hex');
const admin = user => { if (!user || user.role !== 'admin') throw Error('Admin required'); };
const validId = id => typeof id === 'string' && /^[a-zA-Z0-9_-]{1,160}$/.test(id);
function checkManifest(m) {
  if (!validId(m.release_id) || !/^[a-f0-9]{64}$/.test(m.source_sha256) || !/^[a-f0-9]{64}$/.test(m.payload_sha256) || !/^[a-f0-9]{64}$/.test(m.validation_sha256) ||
      !Number.isSafeInteger(m.record_count) || m.record_count <= 0 || !Number.isSafeInteger(m.observation_count) || m.observation_count < 0)
    throw Error('Invalid manifest');
}
function checkRecord(record) {
  if (!validId(record.generation_id) || !record.make || !record.model || !Array.isArray(record.observations)) throw Error('Invalid record');
  const ids = new Set();
  for (const o of record.observations) {
    if (!validId(o.decision_id) || ids.has(o.decision_id) || !o.scope || o.value == null || o.physical_fit_eligible !== false ||
        o.verification !== 'source_scoped_reference_not_independently_reverified' || !o.audit_rows?.length || !o.source_observations?.length)
      throw Error('Invalid scoped observation');
    if (o.audit_rows.length !== o.source_observations.length || o.audit_rows.some((id,i) => id !== o.source_observations[i].audit_row)) throw Error('Audit provenance mismatch');
    ids.add(o.decision_id);
  }
}
export function payloadDigest(records) {
  return digest([...records].sort((a,b)=>a.generation_id.localeCompare(b.generation_id)).map(r=>({generation_id:r.generation_id,record_sha256:digest(r)})));
}
export class ReleaseService {
  constructor(repository) { this.repo = repository; }
  async stage(user, manifest, records) {
    admin(user); checkManifest(manifest);
    const old = await this.repo.getRelease(manifest.release_id);
    if (old && digest(old.manifest) !== digest(manifest)) throw Error('Release identity collision');
    const ids = new Set();
    for (const record of records) { checkRecord(record); if (ids.has(record.generation_id)) throw Error('Duplicate generation'); ids.add(record.generation_id); }
    if (!old) await this.repo.createRelease({manifest:copy(manifest),sealed:false});
    for (const record of records) {
      const existing = await this.repo.getRecord(manifest.release_id,record.generation_id);
      if (existing) { if (digest(existing)!==digest(record)) throw Error('Record identity collision'); continue; }
      if (old?.sealed) throw Error('Sealed release');
      await this.repo.putRecord(manifest.release_id,copy(record));
    }
    return {release_id:manifest.release_id,staged:records.length};
  }
  async verify(releaseId) {
    const release = await this.repo.getRelease(releaseId);
    if (!release) throw Error('Missing release');
    checkManifest(release.manifest);
    const records = await this.repo.listRecords(releaseId); // Repository must exhaust pages or throw.
    if (records.length !== release.manifest.record_count || new Set(records.map(r=>r.generation_id)).size !== records.length) throw Error('Incomplete or duplicate release');
    records.forEach(checkRecord);
    if (records.reduce((n,r)=>n+r.observations.length,0)!==release.manifest.observation_count || payloadDigest(records)!==release.manifest.payload_sha256) throw Error('Payload validation failed');
    return {release,records};
  }
  async seal(user, releaseId) {
    admin(user); const {release}=await this.verify(releaseId);
    if (!release.sealed) await this.repo.sealRelease(releaseId);
    return {release_id:releaseId,sealed:true};
  }
  async promote(user, releaseId, expectedRevision) {
    admin(user); const {release}=await this.verify(releaseId);
    if (!release.sealed) throw Error('Release not sealed');
    // Authorization belongs in the release service, not solely in one HTTP
    // entry point. Rollback and any future callers must honor the same gate.
    if (!release.approved) throw Error('Release approval required');
    const pointer=await this.repo.getPointer();
    if ((pointer?.revision??0)!==expectedRevision) throw Error('Stale promotion');
    // Actual persistence must supply verified conditional-write semantics OR a
    // separately enforced single publisher. This mock contract is not evidence
    // that Base44 supports compare-and-swap.
    await this.repo.swapPointer(expectedRevision,{release_id:releaseId,previous_release_id:pointer?.release_id??null,revision:expectedRevision+1});
    return this.repo.getPointer();
  }
  async rollback(user, expectedRevision) {
    admin(user); const p=await this.repo.getPointer();
    if (!p?.previous_release_id) throw Error('No retained rollback release');
    return this.promote(user,p.previous_release_id,expectedRevision);
  }
  async pin() {
    const pointer=await this.repo.getPointer();
    if (!pointer?.release_id) throw Error('No active release');
    const {release,records}=await this.verify(pointer.release_id);
    if (!release.sealed) throw Error('Active release not sealed');
    // Request-owned copy: later pointer/store edits cannot change this context.
    return copy({release_id:pointer.release_id,revision:pointer.revision,records});
  }
}
const secretParam = /^(api[_-]?key|key|access[_-]?token|token|auth|authorization|signature|sig|secret|password|credential|expires?|policy|awsaccesskeyid|x-amz-.+|x-goog-.+)$/i;
function sourceUrls(value) {
  return String(value??'').split(/\s+/).filter(Boolean).filter(url=>{
    try { const u=new URL(url); return u.protocol==='https:' && !u.username && !u.password && !u.port && !u.hash &&
      /^[a-z0-9.-]+\.[a-z]{2,}$/i.test(u.hostname) && !/(^|\.)(localhost|local|internal|test|example|invalid)$/.test(u.hostname) &&
      !/^\d+(\.\d+){3}$/.test(u.hostname) && ![...u.searchParams.keys()].some(k=>secretParam.test(k)); } catch {return false;}
  });
}
export function customerEvidence(context,generationId) {
  const record=context.records.find(r=>r.generation_id===generationId);
  if (!record || record.reference_route!=='model_reference') return null;
  return {release_id:context.release_id,generation_id:record.generation_id,make:record.make,model:record.model,generation_label:record.generation_label??null,
    observations:record.observations.flatMap(o=>{
      const sources=[...new Set(o.source_observations.flatMap(s=>sourceUrls(s.source_url)))];
      // Drop overlong qualifiers instead of truncating away safety context.
      // Generic machine scopes require original audit definitions in backend
      // reasoning. They are not sufficient standalone customer qualifications.
      // customer_scope is a separately reviewed rendering, not provider output.
      if (!sources.length || o.customer_scope_reviewed!==true || typeof o.customer_scope!=='string' || !o.customer_scope || o.customer_scope.length>6000 || (typeof o.value==='string'&&o.value.length>6000)) return [];
      return [{field:o.field,value:o.value,scope:o.customer_scope,source_urls:sources,physical_fit_eligible:false,verification:'source_scoped_reference_not_independently_reverified'}];
    })};
}