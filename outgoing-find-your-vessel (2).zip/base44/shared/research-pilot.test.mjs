import test from 'node:test';
import assert from 'node:assert/strict';
import { sanitizePilotRows } from './research-pilot.ts';

const manufacturer = 'Example Marine';
const sources = [
  { url: 'https://example.com/models/280-center-console', title: 'Example Marine 280 Center Console', content: 'The 280 Center Console has an overall length of 28 ft.' },
  { url: 'https://example.com/models/310', title: 'Example Marine 310', content: '310 offshore model' },
];

test('pilot accepts only source-linked model candidates into unverified staging', () => {
  const { staged, rejected } = sanitizePilotRows({ models: [
    { model: '280 Center Console', source_url: sources[0].url, facts: { loa_ft: 28, vessel_type: 'center console' } },
    { model: 'Imaginary 990', source_url: sources[0].url, facts: { loa_ft: 40 } },
    { model: '310', source_url: 'https://invented.example/310', facts: { loa_ft: 31 } },
  ] }, sources, manufacturer);
  assert.equal(staged.length, 1);
  assert.equal(rejected.length, 2);
  assert.equal(staged[0].status, 'staged');
  assert.match(staged[0].verification_notes, /UNVERIFIED/);
  assert.equal(staged[0].facts.loa_ft, 28);
});

test('pilot excludes RIBs and over-65-foot models', () => {
  const { staged } = sanitizePilotRows({ models: [
    { model: '310', source_url: sources[1].url, facts: { vessel_type: 'RIB' } },
    { model: '280 Center Console', source_url: sources[0].url, facts: { loa_ft: 68 } },
  ] }, sources, manufacturer);
  assert.equal(staged.length, 0);
});

test('another manufacturer using the same model name is not misattributed in staging', () => {
  const competingBuilderSource = [{
    url: 'https://competitor.example/models/310',
    title: 'Competitor Boats 310',
    content: 'The Competitor Boats 310 is a new center console. Beam: 10 ft.',
  }];
  const { staged, rejected } = sanitizePilotRows({ models: [{
    model: '310', source_url: competingBuilderSource[0].url,
    facts: { beam_ft: 10 },
  }] }, competingBuilderSource, manufacturer);
  assert.equal(staged.length, 0);
  assert.deepEqual(rejected, ['manufacturer identity not supported by retrieved source']);
});

test('a manufacturer official hostname may establish identity without an exact name in the excerpt', () => {
  const officialSource = [{
    url: 'https://examplemarine.com/models/310',
    title: '310 Offshore',
    content: 'Our 310 offshore center console has a beam of 10 ft.',
  }];
  const { staged } = sanitizePilotRows({ models: [{
    model: '310 Offshore', source_url: officialSource[0].url,
    facts: { beam_ft: 10 },
  }] }, officialSource, manufacturer);
  assert.equal(staged.length, 1);
  assert.equal(staged[0].facts.beam_ft, 10);
});

test('a model appearing only in a URL slug is not treated as verified source evidence', () => {
  const urlOnly = [{
    url: 'https://example.com/fake-model-390',
    title: 'Example Marine Model Catalog',
    content: 'Browse our full powerboat range.',
  }];
  const { staged, rejected } = sanitizePilotRows({ models: [
    { model: 'fake model 390', source_url: urlOnly[0].url, facts: { loa_ft: 39 } },
  ] }, urlOnly, manufacturer);
  assert.equal(staged.length, 0);
  assert.equal(rejected.length, 1);
});

test('implausible draft or beam values are omitted rather than becoming model facts', () => {
  const { staged } = sanitizePilotRows({ models: [
    { model: '280 Center Console', source_url: sources[0].url, facts: { loa_ft: 28, beam_ft: 48, draft_ft: 30, fuel_gal: 220 } },
  ] }, sources, manufacturer);
  assert.equal(staged.length, 1);
  assert.deepEqual(staged[0].facts, { loa_ft: 28 }); // 220 gal was asserted by AI, not present in cited source.
});

test('numeric facts require a corresponding value, label, and unit in the cited snippet', () => {
  const withSpecs = [{
    url: sources[0].url,
    title: 'Example Marine 280 Center Console',
    content: 'Length overall: 28 ft; Beam: 9.5 ft; Draft: 1.5 feet; Fuel capacity: 220 gallons.',
  }];
  const { staged } = sanitizePilotRows({ models: [{
    model: '280 Center Console', source_url: withSpecs[0].url,
    facts: { loa_ft: 28, beam_ft: 9.5, draft_ft: 1.5, fuel_gal: 220 },
  }] }, withSpecs, manufacturer);
  assert.deepEqual(staged[0].facts, { loa_ft: 28, beam_ft: 9.5, draft_ft: 1.5, fuel_gal: 220 });
});

test('missing overall length cannot borrow beam or draft numbers from the next labeled field', () => {
  const evidence = [{
    url: 'https://examplemarine.com/models/280',
    title: 'Example Marine 280 Center Console',
    content: 'Length overall: not published, Beam: 9.5 ft, Draft: 1.5 ft, Fuel: 120 gallons.',
  }];
  const { staged } = sanitizePilotRows({ models: [{
    model: '280 Center Console', source_url: evidence[0].url,
    facts: { loa_ft: 9.5, beam_ft: 9.5, draft_ft: 1.5, fuel_gal: 120 },
  }] }, evidence, manufacturer);
  assert.equal(staged.length, 1);
  assert.deepEqual(staged[0].facts, { beam_ft: 9.5, draft_ft: 1.5, fuel_gal: 120 });
});

test('reverse-order dimensions cannot borrow a number from a preceding field', () => {
  const evidence = [{
    url: 'https://examplemarine.com/models/280',
    title: 'Example Marine 280 Center Console',
    content: 'Beam: 9.5 ft, length overall unavailable. Draft: 1.5 ft.',
  }];
  const { staged } = sanitizePilotRows({ models: [{
    model: '280 Center Console', source_url: evidence[0].url,
    facts: { loa_ft: 9.5, beam_ft: 9.5, draft_ft: 1.5 },
  }] }, evidence, manufacturer);
  assert.equal(staged.length, 1);
  assert.deepEqual(staged[0].facts, { beam_ft: 9.5, draft_ft: 1.5 });
});

test('a generic hull length is not falsely promoted to overall length', () => {
  const source = [{
    url: 'https://examplemarine.com/models/280',
    title: 'Example Marine 280 Center Console',
    content: 'Length: 28 ft; Hull length: 27 ft; Beam: 9 ft.',
  }];
  const { staged } = sanitizePilotRows({ models: [{
    model: '280 Center Console', source_url: source[0].url,
    facts: { loa_ft: 28, beam_ft: 9 },
  }] }, source, manufacturer);
  assert.equal(staged.length, 1);
  assert.deepEqual(staged[0].facts, { beam_ft: 9 });
});

test('pilot numeric evidence cannot match a fragment of a decimal value', () => {
  const decimalSpecs = [{
    url: 'https://example.com/model-280',
    title: 'Example Marine 280 Center Console',
    content: 'Draft: 0.5 ft; Beam: 9.5 ft; Length overall: 28.5 ft; Fuel: 250 gallons.'
  }];
  const { staged } = sanitizePilotRows({ models: [{
    model: '280 Center Console', source_url: decimalSpecs[0].url,
    facts: { draft_ft: 5, beam_ft: 5, loa_ft: 8.5, fuel_gal: 50 }
  }] }, decimalSpecs, manufacturer);
  assert.equal(staged.length, 1);
  assert.deepEqual(staged[0].facts, {});
});

test('pilot rejects a plausible but unsupported beam or fuel claim', () => {
  const { staged } = sanitizePilotRows({ models: [{
    model: '280 Center Console', source_url: sources[0].url,
    facts: { loa_ft: 28, beam_ft: 9.5, fuel_gal: 220 },
  }] }, sources, manufacturer);
  assert.deepEqual(staged[0].facts, { loa_ft: 28 });
});

test('pilot refuses unsafe source URLs even when the search result includes them', () => {
  const unsafe = [
    'http://example.com/model-310',
    'https://localhost/model-310',
    'https://127.0.0.1/model-310',
    'https://user:password@example.com/model-310',
    'https://research.internal/model-310',
    'https://example.com:444/model-310',
    'https://example.com/model-310?api_key=should-not-store',
    'https://example.com/model-310?X-Amz-Signature=should-not-store',
    'https://example.com/model-310#access_token=should-not-store',
    'https://example..com/model-310',
  ];
  for (const url of unsafe) {
    const { staged, rejected } = sanitizePilotRows({
      models: [{ model: '310', source_url: url, facts: { loa_ft: 31 } }],
    }, [{ url, title: 'Example Marine 310', content: 'Length: 31 ft' }], manufacturer);
    assert.equal(staged.length, 0, url);
    assert.equal(rejected.length, 1, url);
  }
});

test('a lookalike hostname is not manufacturer identity evidence', () => {
  for (const url of [
    'https://examplemarine.com.evil.test/models/310',
    'https://notexamplemarine.com/models/310',
    'https://examplemarine.com.scam.test/models/310',
  ]) {
    const { staged, rejected } = sanitizePilotRows({ models: [{
      model: '310 Offshore', source_url: url,
      facts: { beam_ft: 10 },
    }] }, [{
      url, title: '310 Offshore',
      content: 'The 310 Offshore has a beam of 10 ft.',
    }], manufacturer);
    assert.equal(staged.length, 0, url);
    assert.deepEqual(rejected, ['manufacturer identity not supported by retrieved source'], url);
  }
});

test('a straightforward official-looking www hostname is allowed into unverified staging', () => {
  const url = 'https://www.examplemarine.com/models/310';
  const { staged } = sanitizePilotRows({ models: [{
    model: '310 Offshore', source_url: url, facts: { beam_ft: 10 },
  }] }, [{
    url, title: '310 Offshore', content: 'The 310 Offshore has a beam of 10 ft.',
  }], manufacturer);
  assert.equal(staged.length, 1);
  assert.equal(staged[0].facts.beam_ft, 10);
  assert.equal(staged[0].status, 'staged'); // Domain pattern alone is never full verification.
});

test('excluded boat types appearing in source titles cannot slip past a blank vessel_type', () => {
  for (const type of ['RIB', 'RIBs', 'Sailboat', 'Jon boat']) {
    const url = 'https://examplemarine.com/models/320';
    const { staged, rejected } = sanitizePilotRows({ models: [{
      model: '320', source_url: url, facts: {},
    }] }, [{url, title: 'Example Marine 320 ' + type, content: 'Our newest 320 model.'}], manufacturer);
    assert.equal(staged.length, 0, type);
    assert.ok(rejected.includes('out-of-scope vessel'), type);
  }
});

test('pilot deduplicates models and rejects nonsensical numeric facts', () => {
  const { staged, rejected } = sanitizePilotRows({ models: [
    { model: '310', source_url: sources[1].url, facts: { loa_ft: -5, beam_ft: 1000 } },
    { model: '310', source_url: sources[1].url, facts: { loa_ft: 31 } },
  ] }, sources, manufacturer);
  assert.equal(staged.length, 1);
  assert.deepEqual(staged[0].facts, {});
  assert.equal(rejected.length, 1);
});
