// MODEL MATCH recommends hulls/model generations, not a particular boat's options.
// Unless independently proved standard for that generation, equipment such as
// radar, windlasses and gyros cannot be promised as included in every example.
// Qualified optional/retrofit statements remain intact.
const INSTALLED_OPTION_ASSERTION =
  /\b(?:(?:(?:comes|supplied|ships?|delivered)\s+(?:standard\s+)?with|includes|has|features|equipped\s+with|fitted\s+with)\s+(?:a\s+|an\s+|the\s+)?(?:factory[- ]installed\s+|standard\s+|integrated\s+|built[- ]in\s+)?|(?:standard|factory[- ]installed|built[- ]in)\s+)(?:joystick|bow\s+thruster|windlass|seakeeper|gyro\s+stabilizer|radar|chartplotter|shower)\b/i;

// Equipment-first claims ("radar is included", "windlass is standard") and
// compound equipment adjectives must be checked as carefully as "has radar".
const REVERSE_INSTALLED_OPTION_ASSERTION =
  /\b(?:joystick|bow\s+thruster|windlass|seakeeper|gyro\s+stabilizer|radar|chartplotter|shower)(?:\s+(?:system|steering|unit|package))?\s+(?:is|are)\s+(?:standard|included|installed|fitted|factory[- ]installed|integrated|built[- ]in)\b|\b(?:joystick|bow\s+thruster|windlass|seakeeper|gyro\s+stabilizer|radar|chartplotter|shower)[- ]equipped\b/i;

const QUALIFIED_OPTION =
  /\b(?:optional|option|if\s+equipped|verify|confirm|may\s+have|may\s+be\s+equipped|can\s+be\s+equipped|available\s+(?:as|with)|some\s+examples|retrofit|aftermarket|listing[- ]specific|depending\s+on\s+(?:the\s+)?(?:model\s+)?(?:year|package|configuration))\b/i;

const WITHHELD =
  "Optional equipment varies by model year and individual boat; verify factory availability and retrofit feasibility.";

// A qualification attached to a different piece of equipment must not
// excuse an unrelated assertion in the same sentence. Split contrasting and
// independently coordinated clauses before checking their qualifications.
const OPTION_CLAUSE_BOUNDARY =
  /[.;\n]+|\b(?:but|whereas|while|although|however)\b|\s+and\s+(?=(?:(?:the|this|a|an|some|other)\s+)?(?:radar|joystick|windlass|seakeeper|shower|chartplotter|bow\s+thruster)\s+(?:is|are|has|includes|may|can)\b)/i;

export function containsUnqualifiedModelEquipmentClaim(value: unknown): boolean {
  return typeof value === "string" && value.split(OPTION_CLAUSE_BOUNDARY).some(part =>
    (INSTALLED_OPTION_ASSERTION.test(part) || REVERSE_INSTALLED_OPTION_ASSERTION.test(part)) && !QUALIFIED_OPTION.test(part)
  );
}

export function withholdUnqualifiedModelEquipmentClaims(input: unknown): {
  text: string;
  withheld: boolean;
} {
  if (typeof input !== "string" || !input.trim()) {
    return { text: typeof input === "string" ? input : "", withheld: false };
  }
  const chunks = input.split(/(?<=[.!?])\s+(?=[A-Z0-9])|[;\n]+/);
  let withheld = false;
  const result = chunks.map(chunk => {
    if (!containsUnqualifiedModelEquipmentClaim(chunk)) return chunk.trim();
    withheld = true;
    return WITHHELD;
  });
  return {
    text: result.filter((chunk, index) => chunk && (index === 0 || chunk !== result[index - 1])).join(" ").trim(),
    withheld,
  };
}
