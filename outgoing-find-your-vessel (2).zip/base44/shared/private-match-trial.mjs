// Isolated recorded-evidence trial. No network, SDK, provider, persistence or live-MATCH imports.
const physicalFields = [
  ["hard_max_overall_length_ft", "overall_length_ft", "ft", "rigged_overall"],
  ["hard_max_beam_ft", "beam_ft", "ft", "maximum_beam"],
  ["hard_max_height_ft", "storage_height_ft", "ft", "stored_height"],
  ["hard_max_storage_weight_lb", "loaded_storage_weight_lb", "lb", "loaded_storage"],
  ["hard_max_draft_ft", "draft_ft", "ft", "operating_draft"],
  ["tow_capacity_lb", "trailered_weight_lb", "lb", "loaded_trailer"],
];
const positive = value => typeof value === "number" && Number.isFinite(value) && value > 0;
const sourceOK = value => typeof value === "string" && /^https?:\/\//.test(value);
export function verifiedApplicable(evidence, unit, basis) {
  return !!evidence && positive(evidence.value) && evidence.unit === unit
    && evidence.status === "verified" && evidence.applicability === "applicable"
    && evidence.measurement_basis === basis && sourceOK(evidence.source_url)
    && typeof evidence.source_quote === "string" && evidence.source_quote.trim().length > 0
    && Number.isFinite(Date.parse(evidence.verified_at));
}
export function screenTrialPhysical(boat, profile) {
  const checks = [];
  for (const [profileField, field, unit, basis] of physicalFields) {
    if (!positive(profile[profileField])) continue;
    if (field === "trailered_weight_lb" && profile.storage !== "trailer") continue;
    const evidence = boat.field_evidence?.[field] ?? null;
    const verified = verifiedApplicable(evidence, unit, basis);
    checks.push({
      field, limit: profile[profileField], unit, evidence,
      state: !verified ? "provisional" : evidence.value > profile[profileField] ? "over_limit" : "within_limit",
      reason: !verified ? "Missing, conflicting, estimated or configuration/basis-inapplicable evidence; physical fit is not confirmed."
        : evidence.value > profile[profileField] ? "Verified applicable measurement exceeds the buyer's hard maximum."
        : "Verified applicable measurement is within this supplied maximum.",
    });
  }
  return {
    excluded: checks.some(c => c.state === "over_limit"), checks,
    status: checks.some(c => c.state === "over_limit") ? "excluded"
      : checks.length === 0 ? "no_structured_limits" : checks.some(c => c.state === "provisional") ? "provisional" : "verified_limits_within",
    notes: [
      "Physical screening covers supplied structured limits only; it is not a safety or overall suitability certification.",
      ...(profile.draft && !positive(profile.hard_max_draft_ft) ? ["Free-text draft requirement needs confirmation; it was not silently converted to a hard maximum."] : []),
      ...(profile.storage_capacity ? ["Free-text facility notes require manual review in this isolated trial."] : []),
    ],
  };
}
export function evaluateTrialMarket(market = {}, profile = {}, asOf = "2026-10-15T00:00:00Z") {
  const seen = new Set();
  const audit = [];
  const eligible = [];
  for (const comp of market.comparables || []) {
    const date = Date.parse(comp.retrieved_at);
    const age = Date.parse(asOf) - date;
    const key = String(comp.dedup_key || comp.source_url || "").trim();
    let rejection = null;
    if (comp.match_status !== "matched") rejection = "Comparable configuration/generation is not confirmed matched";
    else if (!sourceOK(comp.source_url) || !Number.isFinite(date)) rejection = "Missing source or retrieval date";
    else if (age > 30 * 86400000 || age < -86400000) rejection = "Outside the trial's 30-day observation window";
    else if (comp.currency !== "USD" || !positive(comp.asking_price)) rejection = "Missing positive USD asking price; no currency conversion or static price fallback";
    else if (!key || seen.has(key)) rejection = "Duplicate comparable";
    if (!rejection) { seen.add(key); eligible.push(comp); }
    audit.push({ ...comp, included_in_range: !rejection, exclusion_reason: rejection });
  }
  const prices = eligible.map(c => c.asking_price);
  const low = prices.length ? Math.min(...prices) : null;
  const high = prices.length ? Math.max(...prices) : null;
  const min = positive(profile.purchase_budget_min) ? profile.purchase_budget_min : 0;
  const max = positive(profile.purchase_budget_max) ? profile.purchase_budget_max : null;
  const thin = eligible.length < 3;
  let state = "unknown";
  if (low !== null && max !== null) {
    if (low > max) state = "over_budget";
    else if (high < min) state = "below_budget_minimum";
    else if (low >= min && high <= max) state = "fully_within";
    else state = "overlaps";
  }
  return {
    source_kind: "recorded_current_listing_asking_prices", currency: "USD",
    observed_at: asOf, low, high, comparable_count: eligible.length, budget_state: state,
    provisional: thin || state === "unknown", coverage: thin ? "thin" : "bounded_sample",
    low_relative_to_budget_max: low === null || max === null ? null : low - max,
    high_relative_to_budget_max: high === null || max === null ? null : high - max,
    criteria: market.criteria || {}, comparables: audit,
    notes: ["Observed asking prices, not sale values, appraisals or a market-wide estimate.",
      "Both range endpoints are compared against the buyer's budget. No outlier trimming or static catalog price fallback.",
      ...(thin ? ["Fewer than three matched independent listings: range is provisional."] : []),
      ...(market.notes || [])],
  };
}
export function runPrivateMatchTrial(profile, boats, options = {}) {
  if (!profile?.id) throw new Error("An existing selected BuyerProfile is required.");
  if (!Array.isArray(boats) || boats.length < 1 || boats.length > 15) throw new Error("Trial requires 1–15 recorded boats.");
  const asOf = options.as_of || "2026-10-15T00:00:00Z";
  const results = boats.map(boat => ({
    ...boat,
    physical: screenTrialPhysical(boat, profile),
    market: evaluateTrialMarket(boat.market_evidence, profile, asOf),
    manual_review: [
      "Confirm normal and occasional passenger capacity for the actual configuration.",
      "Review activities, operating area, must-haves, condition and ownership costs; these are not scored by this bounded trial.",
    ],
  }));
  // A review order, not a fabricated 0–100 recommendation score.
  const order = { fully_within: 0, overlaps: 1, below_budget_minimum: 2, unknown: 3, over_budget: 4 };
  results.sort((a, b) => Number(a.physical.excluded) - Number(b.physical.excluded)
    || order[a.market.budget_state] - order[b.market.budget_state]
    || b.market.comparable_count - a.market.comparable_count
    || String(a.id).localeCompare(String(b.id)));
  return {
    mode: "private_recorded_evidence_trial", automated_hybrid: false, provider_calls: 0, entity_writes: 0,
    profile_id: profile.id, as_of: asOf,
    scope: "Deterministic physical and current asking-range review. Manual evidence fixture, not the live automated MATCH engine.",
    ranking_basis: "Review order: non-excluded first, then budget-range state and matched-comparable coverage. No overall suitability score.",
    profile: Object.fromEntries(["id", "boat_size_range", "operating_area", "activities", "activity_weights", "passenger_count", "occasional_passenger_count", "storage", "draft", "storage_capacity", "purchase_budget_min", "purchase_budget_max", "must_haves", "preferences", "unacceptable_compromises", ...physicalFields.map(f=>f[0])].filter(k=>profile[k] !== undefined).map(k=>[k,profile[k]])),
    summary: { boats: results.length, physical_exclusions: results.filter(r=>r.physical.excluded).length,
      provisional_physical: results.filter(r=>r.physical.status === "provisional").length,
      provisional_market: results.filter(r=>r.market.provisional).length },
    results: results.map((r, i) => ({ ...r, review_order: i + 1 })),
  };
}
