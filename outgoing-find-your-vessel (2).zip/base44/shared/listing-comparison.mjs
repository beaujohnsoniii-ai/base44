// Exact-listing evidence only. Seller statements are not manufacturer verification.
const norm=s=>String(s??"").toLowerCase().replace(/[^a-z0-9]+/g,"");
const space=s=>String(s??"").replace(/\s+/g," ").trim();
const FIELDS=new Set(["make","model","year","asking_price","asking_price_currency","engine_hours","overall_length_ft","beam_ft","draft_ft","storage_height_ft","loaded_storage_weight_lb","passenger_capacity"]);
export function selectListingInputs(models,selectedIds,normalize){
 if(!Array.isArray(selectedIds)||!selectedIds.length||selectedIds.length>3||new Set(selectedIds).size!==selectedIds.length)throw Error("Save a selection of one to three models first.");
 const out=[],seen=new Set();
 for(const id of selectedIds){
  const model=models.find(m=>m.id===id);if(!model)throw Error("A selected model is unavailable.");
  const urls=model.listing_urls||[];if(!Array.isArray(urls)||urls.length>3)throw Error("Save at most three listing URLs per model.");
  for(const raw of urls){const url=normalize(raw);if(!url)throw Error("Use public HTTPS listing URLs.");
   const u=new URL(url);if(/(^|\.)(google\.[a-z.]+|bing\.com|duckduckgo\.com)$/.test(u.hostname)&&/search|^\/$/.test(u.pathname))throw Error("Paste an actual seller listing URL, not a search results page.");
   if(seen.has(url))continue;seen.add(url);out.push({url,model_id:model.id,model_title:model.title||[model.make,model.model].filter(Boolean).join(" "),expected_make:model.make||"",expected_model:model.model||"",expected_year:model.year||null});
  }
 }
 if(!out.length||out.length>9)throw Error("Save one to nine actual listing URLs before comparing.");
 return out;
}
export function acceptQuotedFacts(text,extraction){
 const facts={},rejected=[];const source=space(text);
 for(const f of Array.isArray(extraction?.facts)?extraction.facts.slice(0,20):[]){
  if(!FIELDS.has(f?.field)||facts[f.field])continue;
  const quote=space(f.quote);
  let valid=quote.length>=5&&quote.length<=1600&&source.includes(quote);
  if(typeof f.value==="number"){const numbers=(quote.match(/\d[\d,]*(?:\.\d+)?/g)||[]).map(x=>Number(x.replace(/,/g,"")));valid=valid&&Number.isFinite(f.value)&&(f.value>0||f.field==="engine_hours"&&f.value===0)&&numbers.some(x=>Math.abs(x-f.value)<0.000001);}
  else valid=valid&&typeof f.value==="string"&&f.value.length<=200&&norm(quote).includes(norm(f.value));
  if(["overall_length_ft","beam_ft","draft_ft","storage_height_ft"].includes(f.field))valid=valid&&f.unit==="ft"&&/\bft\b|feet|foot|'/i.test(quote);
  if(f.field==="asking_price")valid=valid&&((/^[A-Z]{3}$/.test(f.unit)&&quote.includes(f.unit))||(f.unit==="$"&&quote.includes("$")));
  if(f.field==="engine_hours")valid=valid&&f.unit==="h"&&/engineHours|engine\s*hours/i.test(quote);
  if(f.field==="passenger_capacity")valid=valid&&Number.isSafeInteger(f.value)&&/persons?|passengers?|people|onboard|seating/i.test(quote);
  if(f.field==="loaded_storage_weight_lb")valid=valid&&f.unit==="lb"&&/\blbs?\b|pounds/i.test(quote);
  if(!valid){rejected.push(f.field);continue;}
  facts[f.field]={value:f.value,quote,unit:String(f.unit||""),basis:String(f.basis||"unspecified"),provenance:"unverified_listing_claim"};
 }
 return {facts,rejected};
}
export function assessListing(profile,input,text,extraction){
 if(extraction?.page_kind!=="listing")return {...input,status:"not_a_readable_listing",reason:"The returned page could not be established as an individual boat listing.",facts:{},checks:[],concerns:[],unknowns:["Exact listing evidence is unavailable."],eligible:false};
 const {facts,rejected}=acceptQuotedFacts(text,extraction),checks=[],concerns=[],unknowns=[];
 const compare=(field,profileField,label,basis)=>{
  const cap=Number(profile[profileField]);if(!Number.isFinite(cap)||cap<=0)return;
  const fact=facts[field];
  if(!fact||(basis&&fact.basis!==basis)){unknowns.push(label+": the required measurement or definition is not established.");checks.push({criterion:label,status:"unknown",profile_limit:cap});return;}
  const conflict=Number(fact.value)>cap;
  checks.push({criterion:label,status:conflict?"potential_conflict":"seller_claim_within_limit",profile_limit:cap,listing_value:fact.value,quote:fact.quote});
  if(conflict)concerns.push(label+": listing claims "+fact.value+"; your limit is "+cap+". Confirm the measurement before rejecting or proceeding.");
 };
 if(facts.asking_price&&facts.asking_price.unit!=="USD"&&Number(profile.purchase_budget_max)>0){checks.push({criterion:"Asking-price budget",status:"unknown"});unknowns.push("Listing currency differs from the USD buyer budget; no exchange rate or budget fit was inferred.");}
 else compare("asking_price","purchase_budget_max","Asking-price budget");
 compare("overall_length_ft","hard_max_overall_length_ft","Rigged overall length","rigged_overall");
 compare("beam_ft","hard_max_beam_ft","Beam");
 compare("draft_ft","hard_max_draft_ft","Engine-down draft","engine_down");
 compare("storage_height_ft","hard_max_height_ft","Storage height","storage_height");
 compare("loaded_storage_weight_lb","hard_max_storage_weight_lb","Loaded storage weight","loaded_storage_weight");
 if(Number(profile.tow_capacity_lb)>0){checks.push({criterion:"Trailering weight",status:"unknown",profile_limit:Number(profile.tow_capacity_lb)});unknowns.push("Loaded boat, trailer and equipment weight is not established; towing fit cannot be claimed.");}
 if(Number(profile.passenger_count)>0){const f=facts.passenger_capacity;if(!f){unknowns.push("Manufacturer passenger rating is not established by the listing.");checks.push({criterion:"Passenger capacity",status:"unknown"});}else{const conflict=f.value<Number(profile.passenger_count);checks.push({criterion:"Passenger capacity",status:conflict?"potential_conflict":"seller_claim_within_limit",listing_value:f.value,profile_minimum:Number(profile.passenger_count),quote:f.quote});if(conflict)concerns.push("Listing claims fewer passengers than your regular party; manufacturer capacity must be confirmed.");}}
 const identityKnown=Boolean(facts.make&&facts.model);
 let identityConflict=false;
 if(!identityKnown)unknowns.push("The exact listing make/model could not be established.");
 else if(norm(facts.make.value)!==norm(input.expected_make)||norm(facts.model.value)!==norm(input.expected_model)){identityConflict=true;concerns.push("Listing identity differs from the saved model: "+facts.make.value+" "+facts.model.value+". Do not borrow the saved model's year or specifications; confirm identity or alias.");}
 const expectedYear=Number(input.expected_year);
 if(facts.year&&Number.isInteger(expectedYear)&&expectedYear>=1900&&expectedYear<=2100&&Number(facts.year.value)!==expectedYear){
  identityConflict=true;
  concerns.push("Listing year "+facts.year.value+" differs from saved Match model year "+expectedYear+". This may be a different model generation. Never apply the saved model-year specifications to this listing.");
 }
 if(rejected.length)unknowns.push("Unsupported extracted fields were withheld: "+rejected.join(", ")+".");
 if(!facts.year)unknowns.push("Listing model year is not established.");
 unknowns.push("Condition, availability, installed options, operating suitability and unstructured preferences need further verification.");
 const assessed=checks.filter(c=>c.status!=="unknown").length;
 const structured_checks_complete=identityKnown&&!identityConflict&&checks.length>0&&checks.every(c=>c.status==="seller_claim_within_limit");
 const eligible=false; // No finalist eligibility until a sufficient-evidence standard is implemented and tested.
 return {...input,status:Object.keys(facts).length?"partial_evidence":"insufficient_evidence",facts,checks,concerns,unknowns,eligible,structured_checks_complete,evidence_coverage:assessed,qualification:"Seller-page claims only; no verified physical-fit, safety or availability certification."};
}
export function recommendFinalists(results){
 return {finalist_urls:[],status:"withheld",basis:"Listing facts and structured checks are evidence only, not a suitability ranking.",provisional:false,explanation:"Finalist recommendations are unavailable until a sufficient-evidence standard is implemented and tested."};
}
export async function evaluateReadableListings(profile,inputs,sources,extract){
 const out=[];
 for(let i=0;i<inputs.length;i++){
  const input=inputs[i],source=sources[i];
  if(!source.ok){out.push({...input,status:"unreadable",reason:source.error||"Listing page unavailable",facts:{},checks:[],concerns:[],unknowns:["No exact-page facts were retrieved. No alternative listing or model facts were substituted."],eligible:false});continue;}
  if(/captcha|access denied|verify (?:that )?you are human|unusual traffic|enable javascript to continue/i.test(source.text)&&source.text.length<2500){out.push({...input,status:"unreadable",reason:"Access challenge or blocked page",facts:{},checks:[],concerns:[],unknowns:["Exact listing evidence unavailable."],eligible:false});continue;}
  try{const extraction=await extract(source.text,input);out.push(assessListing(profile,input,source.text,extraction));}
  catch{out.push({...input,status:"extraction_failed",reason:"The exact page could not be reliably interpreted.",facts:{},checks:[],concerns:[],unknowns:["No unsupported facts were filled in."],eligible:false});}
 }
 return {results:out,recommendation:recommendFinalists(out)};
}
