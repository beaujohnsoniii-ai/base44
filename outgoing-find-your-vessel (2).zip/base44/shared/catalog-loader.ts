// Fetch the published, independently reviewed model evidence in bounded pages.
// A one-page 500-record query silently penalizes older models once the catalog grows.
// This loader is intentionally all-or-nothing: a failed later page must not be
// mistaken for a complete catalog. Callers may safely fall back to provisional
// MATCH facts and verification warnings rather than treating missing data as false.
export const CATALOG_PAGE_SIZE = 500;
export const CATALOG_MAX_PAGES = 20; // 10,000 records; explicitly report any cap.

export const MATCH_CATALOG_FIELDS = [
  "id", "manufacturer_name", "model_name", "model_aliases", "year_start", "year_end",
  "production_status", "verification_status",
  "rigged_overall_length_ft", "beam_ft", "draft_ft", "storage_height_ft",
  "storage_weight_lb", "trailered_weight_lb", "passenger_capacity",
  "fact_sources",
];

export interface CatalogLoadResult {
  records: any[];
  pagesRead: number;
  truncated: boolean;
}

export async function loadPublishedMatchCatalog(
  entity: { filter: (...args: any[]) => Promise<any[]> },
  maxPages = CATALOG_MAX_PAGES,
): Promise<CatalogLoadResult> {
  if (!Number.isInteger(maxPages) || maxPages < 1 || maxPages > CATALOG_MAX_PAGES) {
    throw new Error("Invalid published catalog page limit");
  }
  const records: any[] = [];
  const seenIds = new Set<string>();
  for (let pageIndex = 0; pageIndex < maxPages; pageIndex++) {
    const page = await entity.filter(
      { verification_status: "published" },
      "-created_date", CATALOG_PAGE_SIZE, pageIndex * CATALOG_PAGE_SIZE,
      MATCH_CATALOG_FIELDS,
    );
    if (!Array.isArray(page) || page.length > CATALOG_PAGE_SIZE) {
      throw new Error("Published catalog response is not a valid bounded page");
    }
    for (const item of page) {
      // Status checks apply even if the backend unexpectedly ignores the filter.
      if (item?.verification_status !== "published" || !item?.id) continue;
      if (seenIds.has(item.id)) continue;
      seenIds.add(item.id);
      records.push(item);
    }
    if (page.length < CATALOG_PAGE_SIZE) {
      return { records, pagesRead: pageIndex + 1, truncated: false };
    }
  }
  // Exactly-max-sized catalogs are conservatively marked potentially partial.
  // Missing records must remain unverified; they are never proof of nonexistence.
  return { records, pagesRead: maxPages, truncated: true };
}
