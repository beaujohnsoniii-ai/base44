import { normalizePublicListingUrl, fetchPublicListing } from "./remote-listing.ts";
import { extractListingDocument, nullableListingFacts } from "./listing-document.mjs";
import { assessListing, recommendFinalists } from "./listing-comparison.mjs";
import { searchExactListingExcerpt } from "./indexed-listing-fallback.mjs";
import { resolveCapturedListing } from "./captured-listing.mjs";

// Approved listing sources for automatic import. Only these domains are fetched.
// All other URLs are saved with a warning but never retrieved automatically.
const APPROVED_HOSTS = new Set([
  "www.boats.com", "boats.com",
  "www.boattrader.com", "boattrader.com",
  "www.yachtworld.com", "yachtworld.com",
]);

const now = () => new Date().toISOString();

export function isApprovedListingUrl(url) {
  const normalized = normalizePublicListingUrl(url);
  if (!normalized) return null;
  const host = new URL(normalized).hostname.toLowerCase();
  return APPROVED_HOSTS.has(host) ? normalized : null;
}

function unavailable(input, status, reason, unknowns, url) {
  return {
    ...input,
    status,
    reason,
    facts: {},
    nullable_facts: nullableListingFacts({}),
    checks: [],
    concerns: [],
    unknowns,
    eligible: false,
    resolution: { original_url: url || input.url, source_url: url || input.url, checked_at: now(), status },
  };
}

async function resolveIndexedFallback(profile, input, url, signal, options = {}) {
  const budget = options.fallbackBudget || { remaining: 1 };
  if (budget.remaining <= 0) return null;
  budget.remaining -= 1;
  const search = options.searchExactListingExcerpt || searchExactListingExcerpt;
  const indexed = await search(url, input, signal);
  if (!indexed?.ok) return null;
  const assessment = assessListing(profile, input, indexed.text, indexed.extraction);
  assessment.nullable_facts = nullableListingFacts(assessment.facts);
  for (const fact of Object.values(assessment.facts || {})) fact.provenance = "indexed_search_excerpt";
  assessment.source_evidence = indexed.evidence;
  assessment.resolution = {
    original_url: url,
    source_url: url,
    retrieved_at: indexed.evidence?.retrieved_at || now(),
    checked_at: now(),
    status: assessment.status,
    transport: "indexed_search",
    provider: indexed.evidence?.provider || "tavily",
  };
  return assessment;
}

export async function resolveApprovedListing(profile, input, signal, options = {}) {
  const publicUrl = normalizePublicListingUrl(input.url);
  if (publicUrl && options.capturedText) {
    signal?.throwIfAborted();
    return resolveCapturedListing(profile, input, publicUrl, options.capturedText);
  }
  const url = isApprovedListingUrl(input.url);
  if (!url) {
    return unavailable(
      input,
      "unsupported_source",
      "Only boats.com, boattrader.com, and yachtworld.com links can be imported automatically.",
      ["This link was saved but not imported automatically. You can still compare it manually."],
      input.url,
    );
  }

  signal?.throwIfAborted();
  const fetched = await fetchPublicListing(url, { allowedHosts: APPROVED_HOSTS });
  signal?.throwIfAborted();

  if (!fetched.ok) {
    const indexed = await resolveIndexedFallback(profile, input, url, signal, options);
    if (indexed) return indexed;
    return unavailable(
      input,
      "fetch_failed",
      fetched.error || "The listing page could not be retrieved.",
      ["This link was saved but the page could not be read automatically. You can still compare it manually."],
      url,
    );
  }

  // Detect access challenges and bot protection pages.
  if (/captcha|access denied|verify (?:that )?you are human|unusual traffic|enable javascript to continue/i.test(fetched.text) && fetched.text.length < 2500) {
    const indexed = await resolveIndexedFallback(profile, input, url, signal, options);
    if (indexed) return indexed;
    return unavailable(
      input,
      "access_blocked",
      "The listing page showed an access challenge.",
      ["This link was saved but the page is protected by an access challenge. You can still compare it manually."],
      url,
    );
  }

  const finalUrl = fetched.final_url || url;
  const doc = { html: fetched.html || "", text: fetched.text, final_url: finalUrl, url, retrieved_at: now() };
  let parsed;
  try {
    parsed = extractListingDocument(doc);
  } catch {
    return unavailable(
      input,
      "extraction_failed",
      "The listing page could not be reliably interpreted.",
      ["This link was saved but the page content could not be parsed. You can still compare it manually."],
      url,
    );
  }

  if (parsed.ambiguity) {
    return unavailable(
      input,
      "ambiguous_listing",
      parsed.ambiguity,
      ["This link was saved but the page contains multiple listings. Paste a direct link to a single boat."],
      url,
    );
  }

  const assessment = assessListing(profile, input, parsed.text, parsed.extraction);
  assessment.nullable_facts = nullableListingFacts(assessment.facts);
  assessment.resolution = {
    original_url: url,
    source_url: finalUrl,
    retrieved_at: doc.retrieved_at,
    checked_at: now(),
    status: assessment.status,
  };
  return assessment;
}

export async function resolveApprovedListings(profile, inputs, signal, options = {}) {
  const results = [];
  // One explicit Compare action can make at most three paid indexed-search calls.
  // There are no automatic retries; remaining blocked URLs stay unresolved.
  const fallbackBudget = { remaining: 3 };
  for (const input of inputs) {
    signal?.throwIfAborted();
    const url = normalizePublicListingUrl(input.url);
    const capturedText = url ? options.capturedByUrl?.get(url) : null;
    results.push(await resolveApprovedListing(profile, input, signal, { fallbackBudget, capturedText }));
  }
  return {
    results,
    recommendation: recommendFinalists(results),
    resolver_available: true,
    retrieval_available: true,
  };
}