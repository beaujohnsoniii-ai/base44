import test from "node:test";
import assert from "node:assert/strict";
import {
  CATALOG_PAGE_SIZE, CATALOG_MAX_PAGES, MATCH_CATALOG_FIELDS,
  loadPublishedMatchCatalog,
} from "./catalog-loader.ts";
import { findPublishedCatalogEvidence } from "./catalog-grounding.ts";

function published(i) {
  return {
    id: "model-" + i, manufacturer_name: "Brand", model_name: "Model " + i,
    year_start: 2022, year_end: 2026, verification_status: "published",
    beam_ft: 9, fact_sources: {
      beam_ft: {
        status: "verified", source_url: "https://manufacturer.example.org/boats",
        measurement_basis: "beam", source_model_year: 2026,
      },
    },
  };
}

function fixture(records) {
  const calls = [];
  return {
    calls,
    entity: {
      async filter(query, sort, limit, skip, fields) {
        calls.push({ query, sort, limit, skip, fields });
        return records.filter(r => r.verification_status === query.verification_status)
          .slice(skip, skip + limit);
      },
    },
  };
}

test("published catalog reads beyond the former 500-record boundary for model grounding", async () => {
  const { calls, entity } = fixture(Array.from({ length: 501 }, (_, i) => published(i)));
  const result = await loadPublishedMatchCatalog(entity);
  assert.equal(result.records.length, 501);
  assert.equal(result.pagesRead, 2);
  assert.equal(result.truncated, false);
  assert.deepEqual(calls.map(c => c.skip), [0, 500]);
  assert.ok(calls.every(c => c.limit === CATALOG_PAGE_SIZE));
  assert.ok(calls.every(c => c.query.verification_status === "published"));
  assert.ok(calls.every(c => c.fields.includes("fact_sources")));
  assert.ok(calls.every(c => c.fields.includes("model_aliases")));
  assert.ok(MATCH_CATALOG_FIELDS.includes("passenger_capacity"));
  const evidence = findPublishedCatalogEvidence(
    { make: "Brand", model: "Model 500", year: 2026 }, result.records,
  );
  assert.equal(evidence?.id, "model-500");
  assert.equal(evidence?.facts.beam_ft, 9);
});

test("empty catalog is distinguishable from a failed catalog lookup", async () => {
  const { entity } = fixture([]);
  assert.deepEqual(await loadPublishedMatchCatalog(entity), {
    records: [], pagesRead: 1, truncated: false,
  });
  await assert.rejects(
    loadPublishedMatchCatalog({ filter: async () => { throw Error("database unavailable"); } }),
    /database unavailable/,
  );
});

test("failed later page propagates rather than silently returning incomplete grounding", async () => {
  let calls = 0;
  await assert.rejects(loadPublishedMatchCatalog({
    async filter() {
      calls++;
      if (calls === 1) return Array.from({ length: 500 }, (_, i) => published(i));
      throw Error("page 2 unavailable");
    },
  }), /page 2 unavailable/);
  assert.equal(calls, 2);
});

test("non-published records and duplicate IDs never become additional evidence", async () => {
  const result = await loadPublishedMatchCatalog({
    filter: async () => [
      published(1), published(1),
      { ...published(2), verification_status: "needs_review" },
      { ...published(3), id: "" },
    ],
  });
  assert.deepEqual(result.records.map(r => r.id), ["model-1"]);
});

test("catalog respects a bounded page cap and explicitly reports possible truncation", async () => {
  const { calls, entity } = fixture(Array.from({ length: 900 }, (_, i) => published(i)));
  const result = await loadPublishedMatchCatalog(entity, 1);
  assert.equal(result.records.length, 500);
  assert.equal(result.truncated, true);
  assert.equal(result.pagesRead, 1);
  assert.equal(calls.length, 1);
  assert.equal(CATALOG_MAX_PAGES, 20);
  await assert.rejects(loadPublishedMatchCatalog(entity, 0), /Invalid/);
  await assert.rejects(loadPublishedMatchCatalog(entity, 21), /Invalid/);
});

test("malformed page response is an explicit failure", async () => {
  await assert.rejects(
    loadPublishedMatchCatalog({ filter: async () => ({ items: [] }) }),
    /valid bounded page/,
  );
});
