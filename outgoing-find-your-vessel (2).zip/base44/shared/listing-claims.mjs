// Conservative exact-page parser: no provider calls, model-spec substitution or unit inference.
export function extractListingClaims(text){
 const facts=[];const add=(field,re,unit="",basis="unspecified")=>{const m=text.match(re);if(m)facts.push({field,value:unit||field==="year"?Number(m[1].replace(/,/g,"")):m[1].trim(),quote:m[0],unit,basis});};
 add("make",/\bMake\s*[:\-]\s*([A-Za-z][A-Za-z ]{1,55})(?=\s+(?:Model|Year|Price)\b|[|;\n])/i);
 add("model",/\bModel\s*[:\-]\s*([A-Za-z0-9][A-Za-z0-9 .-]{1,65})(?=\s+(?:Make|Year|Price)\b|[|;\n])/i);
 add("year",/\bYear\s*[:\-]\s*((?:19|20)\d{2})\b/i);
 add("asking_price",/\b(?:Asking price|Price)\s*[:\-]?\s*USD\s*\$?\s*([\d,]+(?:\.\d{1,2})?)/i,"USD");
 add("beam_ft",/\bBeam\s*[:\-]\s*(\d+(?:\.\d+)?)\s*(?:ft|feet)\b/i,"ft","beam");
 add("draft_ft",/\b(?:Engine.down draft|Draft\s*\(engine down\))\s*[:\-]\s*(\d+(?:\.\d+)?)\s*(?:ft|feet)\b/i,"ft","engine_down");
 add("overall_length_ft",/\bRigged overall length\s*[:\-]\s*(\d+(?:\.\d+)?)\s*(?:ft|feet)\b/i,"ft","rigged_overall");
 add("passenger_capacity",/\b(?:Capacity|Maximum)\s*[:\-]?\s*(\d+)\s*(?:persons|passengers)\b/i,"persons");
 add("engine_hours",/\bEngine\s+hours\s*[:\-]\s*(\d+(?:\.\d+)?)\b/i,"h");
 const price=facts.find(f=>f.field==="asking_price");if(price)facts.push({field:"asking_price_currency",value:"USD",quote:price.quote,unit:""});
 return {page_kind:facts.some(f=>f.field==="make")&&facts.some(f=>f.field==="model")&&/price|for sale|listing|seller/i.test(text)?"listing":"unknown",facts};
}
