// Conservative bridge between the independently reviewed model catalog and
// LLM-proposed MATCH candidates. "Published" is necessary, but not enough
// to certify every numeric field: each usable fact needs its own source proof.
// No catalog match is an evidence gap, NEVER evidence that a model does not exist.
import { safeSource } from "./hybrid-evidence.mjs";

export interface VerifiedCatalogFacts {
  rigged_overall_length_ft?: number;
  beam_ft?: number;
  draft_ft?: number;
  storage_height_ft?: number;
  storage_weight_lb?: number;
  trailered_weight_lb?: number;
  passenger_capacity?: number;
}

export interface CatalogMatch {
  id: string;
  facts: VerifiedCatalogFacts;
  // Only ever populated from a reviewer-recorded licence on the catalog
  // record. An unlicensed or unnamed image stays a placeholder.
  image?: { url: string; license: string };
}

function cleanIdentity(value: unknown): string {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

// MATCH may abbreviate a model name (e.g. omit the reviewed layout suffix),
// but prefix/fuzzy matching would dangerously confuse engineering variants.
// Permit only exact model identity or aliases explicitly reviewed on a
// published catalog record. Alias collisions remain ambiguous and unusable.
function modelIdentityMatches(record: any, candidateModel: string): boolean {
  const names = [record?.model_name, ...(Array.isArray(record?.model_aliases)
    ? record.model_aliases.filter((alias: unknown) => typeof alias === "string") : [])];
  return names.some(name => cleanIdentity(name) === candidateModel);
}

function validYear(value: unknown): number | null {
  const n = Number(value);
  return Number.isInteger(n) && n >= 1900 && n <= 2100 ? n : null;
}

function yearApplies(record: any, year: number): boolean {
  const start = validYear(record?.year_start);
  const end = validYear(record?.year_end);
  if ((start !== null && end !== null && end < start) ||
      (start !== null && year < start) || (end !== null && year > end)) return false;
  // A manufacturer's published MY2027 specification can prove a measurement
  // for MY2027 even if the generation inception year is not established.
  // Never fabricate that inception year or carry the measurement to MY2026.
  // A year-unknown record qualifies only if at least one supported field has
  // independent proof applicable to THIS exact candidate year.
  if (start === null) {
    const fields: Array<keyof VerifiedCatalogFacts> = [
      "rigged_overall_length_ft", "beam_ft", "draft_ft", "storage_height_ft",
      "storage_weight_lb", "trailered_weight_lb", "passenger_capacity",
    ];
    return fields.some(field => trustedNumber(record, field, year) !== undefined);
  }
  if (end !== null) return true;
  // Open-ended generations do not imply an old/discontinued model is still
  // current. A verified model-year-specific measurement can still be used for
  // its proven year, independently of the model's present production status.
  const verifiedForYear = ([
    "rigged_overall_length_ft", "beam_ft", "draft_ft", "storage_height_ft",
    "storage_weight_lb", "trailered_weight_lb", "passenger_capacity",
  ] as Array<keyof VerifiedCatalogFacts>).some(field => trustedNumber(record, field, year) !== undefined);
  if (verifiedForYear) return true;
  // Otherwise only a current/announced open generation can match the
  // present or immediately upcoming year; numeric facts still need proof.
  return (record?.production_status === "current" || record?.production_status === "announced") &&
    year <= new Date().getUTCFullYear() + 1;
}

// A checked status on a catalog field is insufficient if the recorded
// citation is not a real, public HTTPS source. Do not accept credentials in
// URLs, localhost/private naming, IP literals, or nonstandard ports as proof.
function isPublicEvidenceUrl(value: unknown): boolean {
  // Use the same public-source predicate as workbook verification, so a
  // placeholder/reserved host cannot certify a real marina/towing limit here
  // while being rejected everywhere else in the research pipeline.
  return typeof value === "string" && value.length <= 4096 && safeSource(value);
}

// A MY2027 manufacturer page cannot automatically certify the same spec
// for MY2025 merely because a catalog entry spans both model years.
// Reviewers can explicitly certify a verified field for a year interval,
// otherwise a documented source_model_year applies only to that year.
// A field without explicit model-year or reviewed year-range evidence cannot
// certify any candidate year. This is deliberately stricter than older drafts:
// there are no published production catalog records to grandfather, and a
// source URL alone never proves cross-generation applicability.
function fieldAppliesToYear(proof: any, candidateYear: number): boolean {
  const hasStart = proof.applicable_year_start !== undefined && proof.applicable_year_start !== null;
  const hasEnd = proof.applicable_year_end !== undefined && proof.applicable_year_end !== null;
  const rawSourceYear = proof.source_model_year;
  const hasSourceYear = rawSourceYear !== undefined && rawSourceYear !== null && rawSourceYear !== "";

  if (hasStart || hasEnd) {
    // A one-sided or inverted applicability interval is not sufficient proof.
    if (!hasStart || !hasEnd) return false;
    const start = validYear(proof.applicable_year_start);
    const end = validYear(proof.applicable_year_end);
    if (start === null || end === null || end < start || candidateYear < start || candidateYear > end) return false;
    if (hasSourceYear) {
      const sourceYear = validYear(rawSourceYear);
      if (sourceYear === null || sourceYear < start || sourceYear > end) return false;
    }
    return true;
  }
  if (hasSourceYear) return validYear(rawSourceYear) === candidateYear;
  return false;
}

function trustedNumber(record: any, field: keyof VerifiedCatalogFacts, candidateYear: number): number | undefined {
  const value = record?.[field];
  const number = typeof value === "number" ? value : null;
  if (number === null || !Number.isFinite(number) || number <= 0) return undefined;
  if (field === "passenger_capacity" && !Number.isSafeInteger(number)) return undefined;
  const proof = record?.fact_sources?.[field];
  if (!proof || proof.status !== "verified" ||
      (proof.applicability && proof.applicability !== "applicable") ||
      !isPublicEvidenceUrl(proof.source_url) ||
      !fieldAppliesToYear(proof, candidateYear)) return undefined;

  // A verified URL alone does not prove the units or meaning of a source
  // measurement. Wrong-unit values must never clear a marina, tow, or
  // passenger-capacity verification warning. Missing unit metadata remains
  // compatible with our ft/lb catalog schema; explicit conflicting units do not.
  const declaredUnit = proof.unit ?? proof.units;
  if (declaredUnit !== undefined && declaredUnit !== null && String(declaredUnit).trim()) {
    const unit = String(declaredUnit).trim().toLowerCase();
    const allowed = field === "passenger_capacity"
      ? ["person", "persons", "passenger", "passengers", "people"]
      : field.endsWith("_lb")
        ? ["lb", "lbs", "pound", "pounds"]
        : ["ft", "foot", "feet"];
    if (!allowed.includes(unit)) return undefined;
  }

  const basis = String(proof.measurement_basis || "").trim().toLowerCase().replace(/[\s-]+/g, "_");
  // Hull length and bridge clearance are not a boat's rigged/storage dimensions.
  if (field === "rigged_overall_length_ft" && basis !== "rigged_overall") return undefined;
  if (field === "beam_ft" && !["beam", "overall_beam", "maximum_beam", "max_beam"].includes(basis)) return undefined;
  // An engine-up/hull-only draft cannot certify the operating draft.
  if (field === "draft_ft" && !["draft", "operating_draft", "draft_engines_down"].includes(basis)) return undefined;
  // Seat count and number of berths are not a manufacturer's persons rating.
  if (field === "passenger_capacity" &&
      !["us_persons_rating", "manufacturer_persons_rating", "manufacturer_person_rating",
        "persons_rating", "max_persons", "maximum_persons", "rated_person_capacity"].includes(basis)) return undefined;
  if (field === "storage_weight_lb" && !["loaded_storage", "loaded_operating", "storage", "operating"].includes(basis)) return undefined;
  if (field === "trailered_weight_lb" && basis !== "trailered_total") return undefined;
  if (field === "storage_height_ft" && !["stored_overall", "on_trailer"].includes(basis)) return undefined;
  return number;
}

export function findPublishedCatalogEvidence(candidate: any, catalog: any[]): CatalogMatch | null {
  const make = cleanIdentity(candidate?.make);
  const model = cleanIdentity(candidate?.model);
  const year = validYear(candidate?.year);
  if (!make || !model || year === null || !Array.isArray(catalog)) return null;

  const matching = catalog.filter(record =>
    record?.verification_status === "published" &&
    typeof record.id === "string" && !!record.id &&
    cleanIdentity(record.manufacturer_name) === make &&
    modelIdentityMatches(record, model) &&
    yearApplies(record, year)
  );
  // Duplicate/overlapping generations are ambiguous until resolved by review.
  if (matching.length !== 1) return null;
  const record = matching[0];
  const facts: VerifiedCatalogFacts = {};
  const fields: Array<keyof VerifiedCatalogFacts> = [
    "rigged_overall_length_ft", "beam_ft", "draft_ft", "storage_height_ft",
    "storage_weight_lb", "trailered_weight_lb", "passenger_capacity",
  ];
  for (const field of fields) {
    const value = trustedNumber(record, field, year);
    if (value !== undefined) facts[field] = value;
  }
  const image = licensedImage(record);
  return { id: record.id, facts, ...(image ? { image } : {}) };
}

// A model photo is shown only when the published catalog record carries both a
// public image URL and an explicit licence recorded by a reviewer. Nothing is
// inferred from the presence of a URL alone.
function licensedImage(record: any): { url: string; license: string } | null {
  const url = record?.image_url;
  const license = String(record?.image_license || "").trim();
  return typeof url === "string" && isPublicEvidenceUrl(url) && license
    ? { url, license }
    : null;
}

// Source-proof readiness can be inspected before a reviewer publishes a catalog entry.
// This is a diagnostic only; production lookup also requires published status.
export function previewCatalogProofReadiness(record: any, forYear?: unknown) {
  const fields: Array<keyof VerifiedCatalogFacts> = [
    "rigged_overall_length_ft", "beam_ft", "draft_ft", "storage_height_ft",
    "storage_weight_lb", "trailered_weight_lb", "passenger_capacity",
  ];
  const year = validYear(forYear) ?? validYear(record?.year_start) ?? validYear(record?.year_end);
  const presentFields = fields.filter(field =>
    typeof record?.[field] === "number" && Number.isFinite(record[field]) && record[field] > 0
  );
  const usableFields = year !== null && yearApplies(record, year)
    ? presentFields.filter(field => trustedNumber(record, field, year) !== undefined)
    : [];
  const usableSet = new Set(usableFields);
  return {
    year,
    presentFields,
    usableFields,
    blockedFields: presentFields.filter(field => !usableSet.has(field)),
  };
}

export function applyCatalogEvidence(candidate: any, evidence: CatalogMatch | null): any {
  // Verification markers are server-owned. An LLM-generated candidate must
  // never retain self-declared catalog IDs or field-level proof, even if no
  // matching published record exists or its proof is ambiguous.
  const sanitized = { ...(candidate || {}) };
  delete sanitized.__catalog_model_id;
  delete sanitized.__catalog_verified_fields;
  // Image identity is server-owned too: an LLM-supplied photo or licence claim
  // is discarded rather than shown to a buyer.
  delete sanitized.image_url;
  delete sanitized.image_license;
  if (!evidence) return { ...sanitized, __catalog_verified_fields: [] };
  const facts = evidence.facts;
  return {
    ...sanitized,
    // Trusted published field evidence overrides unverified LLM measurements.
    ...(facts.rigged_overall_length_ft !== undefined ? { overall_length_ft: facts.rigged_overall_length_ft } : {}),
    ...(facts.beam_ft !== undefined ? { beam_ft: facts.beam_ft } : {}),
    ...(facts.draft_ft !== undefined ? { draft_ft: facts.draft_ft } : {}),
    ...(facts.storage_height_ft !== undefined ? { storage_height_ft: facts.storage_height_ft } : {}),
    ...(facts.storage_weight_lb !== undefined ? { loaded_storage_weight_lb: facts.storage_weight_lb } : {}),
    ...(facts.trailered_weight_lb !== undefined ? { trailered_weight_lb: facts.trailered_weight_lb } : {}),
    ...(facts.passenger_capacity !== undefined ? { passenger_capacity: facts.passenger_capacity } : {}),
    __catalog_model_id: evidence.id,
    // Per-field proof; publication status alone does not verify every spec.
    __catalog_verified_fields: Object.keys(facts),
    ...(evidence.image ? { image_url: evidence.image.url, image_license: evidence.image.license } : {}),
  };
}