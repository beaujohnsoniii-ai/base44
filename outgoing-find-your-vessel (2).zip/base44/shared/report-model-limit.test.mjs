import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { limitMarketFinalists } from "./report-model-limit.ts";

test("Market Match has a strict three-model ceiling even if AI returns four", () => {
  const candidates = ["A", "B", "C", "D"].map(model => ({ make: "Builder", model, title: model }));
  assert.deepEqual(limitMarketFinalists(candidates).map(r => r.model), ["A", "B", "C"]);
});

test("repeat models across example years cannot occupy two finalist slots", () => {
  const ranked = [
    { make: "Parker", model: "2520 SC", year: 2005, title: "2005 Parker 2520 SC" },
    { make: "PARKER", model: "2520-SC", year: 2010, title: "2010 Parker 2520 SC" },
    { make: "Grady-White", model: "Express 330", title: "Grady-White Express 330" },
    { make: "Boston Whaler", model: "285 Conquest", title: "Boston Whaler 285 Conquest" },
  ];
  assert.deepEqual(limitMarketFinalists(ranked).map(r => r.model), ["2520 SC", "Express 330", "285 Conquest"]);
});

test("fewer supported finalists remain fewer; no blank or fabricated entries", () => {
  assert.deepEqual(limitMarketFinalists(undefined), []);
  assert.deepEqual(limitMarketFinalists([null, {}, { title: "One documented model" }]),
    [{ title: "One documented model" }]);
});

test("Market Match prompt, schema and result handling use the same three-model limit", () => {
  const src = readFileSync(new URL("../functions/generate-advisory/entry.ts", import.meta.url), "utf8");
  const marketSchema = src.slice(src.indexOf("const TOP_THREE_SCHEMA ="), src.indexOf("// Private Advisory"));
  const marketStart = src.indexOf('if (type === "top_three") {');
  const marketPrompt = src.slice(marketStart, src.indexOf('if (type === "introductions") {', marketStart));
  assert.match(marketSchema, /maxItems:\s*3/);
  assert.match(marketPrompt, /AT MOST THREE strongest distinct boat MODELS/);
  assert.doesNotMatch(marketPrompt, /THREE or FOUR|3-4 boat matches/);
  assert.match(src, /content\.recommendations = limitMarketFinalists\(content\?\.recommendations\)/);
});
