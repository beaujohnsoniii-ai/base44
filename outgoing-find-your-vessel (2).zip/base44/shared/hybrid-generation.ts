import { customerFields, datasetCatalog, maskConflicts, identity } from "./hybrid-evidence.mjs";
// Request-scoped bounded work. A limit never means a skipped fact was verified.
export function makeHybridResolver(db:any,inputCatalog:any[]) {
 const cache=new Map<string,any>();
 return async function(candidates:any[]){
  const catalog=[...inputCatalog], out=[];
  for(const candidate of candidates.slice(0,30)){
   const key=identity(candidate.make)+"|"+identity(candidate.model);
   let found=cache.get(key);
   if(!found){
    const rows=await db.entities.ResearchDataset.filter({manufacturer:String(candidate.make||""),model:String(candidate.model||"")},"-workbook_version",50);
    let issues=await db.entities.DataReviewIssue.filter({manufacturer:String(candidate.make||""),model:String(candidate.model||""),status:"open"},"-created_date",100);
    const checkState="reference_only"; // Reuse stored research; no automatic web checks during matching.
    found={rows,issues,checkState};cache.set(key,found);
   }
   catalog.push(...datasetCatalog(found.rows));
   const fields=customerFields(found.rows,Number(candidate.year),found.issues);
   // A disputed fact is a real fit blocker; an unrecorded fact is only
   // unconfirmed evidence. They must never share one marker, and only the
   // conflict marker may downgrade a result. Buyer-facing wording is built
   // later, where the buyer's stated limits are known: a field-level record
   // name is not something to show a customer.
   const conflict=fields.some((f:any)=>f.status==="conflict");
   // Pending means partial evidence on a model that IS recorded: a stored
   // record with an unconfirmed field. No record at all is a coverage gap
   // reported by the engine's own identity and screening notes, not a partial
   // workbook entry.
   const recorded=found.rows.length>0;
   const unconfirmed=recorded&&fields.some((f:any)=>f.status==="missing"||f.status==="not_checked");
   out.push({...candidate,__hybrid_fields:fields,__hybrid_conflict:conflict,__hybrid_pending:unconfirmed,
    // The resolver adds no customer-facing wording of its own: it carries the
    // candidate's existing notes unchanged, and field-level evidence rides
    // along in __hybrid_fields for the profile-aware flag builder.
    verification_required:Array.isArray(candidate.verification_required)?[...candidate.verification_required]:[]});
  }
  const allIssues=[...cache.values()].flatMap(x=>x.issues);
  const unique=Array.from(new Map(catalog.map(r=>[r.id,r])).values());
  return {candidates:out,catalog:maskConflicts(unique,allIssues)};
 };
}