import test from 'node:test';
import assert from 'node:assert/strict';
import { runProgrammaticChecks } from './qa-programmatic.ts';
import { MATCH_SCORE_CAPS, SUGGEST_SCHEMA, selectTopModelCandidates, tierBudgetSummary, generateRecommendations } from './suggest-engine.ts';
import { filterByBudget } from './advisor-reasoning.ts';
import { screenPhysicalCandidate } from './physical-specs.ts';

const boat = (extra={}) => ({
  title:'Test 32',make:'Test',model:'32',specs:'Length 32 ft',
  suitability_score:0,
  score_breakdown:Object.fromEntries(Object.keys(MATCH_SCORE_CAPS).map(k=>[k,0])),
  verification_required:[],...extra
});
const check=(b,p)=>runProgrammaticChecks([b],p,'market_match',[]);

test('preferred size is soft',()=>{
  const r=check(boat(),{boat_size_range:'18_24'});
  assert.ok(r.checks.size_violations.length);
  assert.equal(r.checks.hard_constraint_violations.length,0);
});
test('unflagged unknown overall length fails QA',()=>{
  assert.equal(check(boat(),{hard_max_overall_length_ft:33}).concern_level,'red');
});
test('flagged unknown overall length is not assumed verified',()=>{
  const r=check(boat({verification_required:['Verify rigged overall length']}),{hard_max_overall_length_ft:33});
  assert.equal(r.checks.hard_constraint_violations.length,0);
  assert.equal(r.checks.verification_flags.length,1);
});

test('unverified reported oversize is a review warning rather than false verified hard failure',()=>{
  const r=check(boat({
    specs:'Overall length 36 ft',
    verification_required:['Verify rigged overall length before confirming slip fit'],
  }),{hard_max_overall_length_ft:33});
  assert.deepEqual(r.checks.hard_constraint_violations,[]);
  assert.equal(r.concern_level,'yellow');
  assert.ok(r.checks.physical_verification_gaps.some(v=>/36.*above.*33/i.test(v)));
});

test('only independently reviewed field-level evidence proves a hard length exceedance',()=>{
  const r=check(boat({
    specs:'Overall length 36 ft',
    verification_required:['Verify rigged overall length'],
    __catalog_verified_fields:['rigged_overall_length_ft'],
  }),{hard_max_overall_length_ft:33});
  assert.equal(r.concern_level,'red');
  assert.ok(r.checks.hard_constraint_violations.some(v=>/independently verified.*36.*33/.test(v)));
});

test('written marina maximum uses same verified measurement gate as structured limits',()=>{
  const profile={storage_capacity:'30 ft max overall length'};
  const unverified=check(boat({
    specs:'Overall length 33 ft',
    verification_required:['Verify rigged overall length'],
  }),profile);
  assert.deepEqual(unverified.checks.hard_constraint_violations,[]);
  assert.ok(unverified.checks.physical_verification_gaps.length);
  const confirmed=check(boat({
    specs:'Overall length 33 ft',
    __catalog_verified_fields:['rigged_overall_length_ft'],
  }),profile);
  assert.equal(confirmed.concern_level,'red');
});

test('provisional over-limit beam draft storage weight and tow weight require evidence before hard exclusion',()=>{
  const cases=[
    [{hard_max_beam_ft:9},'Beam 10 ft','beam'],
    [{hard_max_draft_ft:1.5},'Draft 2 ft','draft'],
    [{hard_max_storage_weight_lb:5000},'Loaded weight 6500 lb','loaded storage weight'],
    [{storage:'trailer',tow_capacity_lb:6000},'Trailered weight 7500 lb','trailered weight'],
  ];
  for (const [profile,spec,label] of cases) {
    const b=boat({specs:spec, verification_required:[`Verify ${label} before confirming fit`]});
    const r=check(b,profile);
    assert.deepEqual(r.checks.hard_constraint_violations,[],spec);
    assert.ok(r.checks.physical_verification_gaps.length,spec);
  }
});
test('slip-kept boat does not inherit tow ceiling',()=>{
  const r=check(boat({specs:'Length 32 ft · Trailered weight 7000 lb'}),{storage:'marina_slip',tow_capacity_lb:6000});
  assert.equal(r.checks.hard_constraint_violations.length,0);
});
test('trailer-kept boat respects actual tow ceiling',()=>{
  assert.equal(check(boat({specs:'Length 32 ft · Trailered weight 7000 lb'}),{storage:'trailer',tow_capacity_lb:6000}).concern_level,'red');
});
test('invalid suitability total fails QA',()=>{
  assert.equal(check(boat({suitability_score:99}),{}).concern_level,'red');
});

test('overnight hard requirements apply only after Market Match unlocks them',()=>{
  const profile={overnight_requirements:'Need to sleep 4 for weekend trips; real berths required'};
  for (const tier of ['free','match_plus','refined_match']) {
    const r=runProgrammaticChecks([boat({title:'Test Center Console'})],profile,tier,[]);
    assert.deepEqual(r.checks.overnight_violations,[]);
    assert.deepEqual(r.checks.hard_constraint_violations,[]);
  }
  const market=runProgrammaticChecks([boat({title:'Test Center Console'})],profile,'market_match',[]);
  assert.equal(market.concern_level,'red');
  assert.equal(market.checks.overnight_violations.length,1);
});

test('a required head for day trips is not a required sleeping berth',()=>{
  const r=check(boat({title:'Test Center Console'}),{overnight_requirements:'Need a head for day trips; overnight optional'});
  assert.deepEqual(r.checks.overnight_violations,[]);
});
test('occasional overnight preference does not create a berth hard limit',()=>{
  const r=check(boat({title:'Test Center Console'}),{overnight_requirements:'Occasional overnight preferred, not needed'});
  assert.deepEqual(r.checks.overnight_violations,[]);
});
test('explicit need to sleep aboard rejects an open boat without berths',()=>{
  const r=check(boat({title:'Test Center Console'}),{overnight_requirements:'Need to sleep 4 on weekend trips; real berths required'});
  assert.ok(r.checks.overnight_violations.length);
  assert.equal(r.concern_level,'red');
});
test('explicit overnight equipment requirement is not treated as optional',()=>{
  const r=check(boat({title:'Test Center Console'}),{overnight_requirements:'Generator required for overnight use'});
  assert.ok(r.checks.overnight_violations.length);
});
test('day-trip electrical requirement does not imply an overnight berth',()=>{
  const r=check(boat({title:'Test Center Console'}),{overnight_requirements:'Generator required for day trips to power appliances'});
  assert.deepEqual(r.checks.overnight_violations,[]);
});
test('separate hard overnight requirement overrides an earlier ordinary-day-use preference',()=>{
  const r=check(boat({title:'Test Center Console'}),{overnight_requirements:'I do not need to sleep aboard routinely, but must sleep 4 on weekend trips'});
  assert.ok(r.checks.overnight_violations.length);
});
test('marketing mention of overnight without berths does not prove sleeping fit',()=>{
  const r=check(boat({title:'Test Center Console',why_suggested:'Overnight trips are possible with a console head only'}),{overnight_requirements:'Need to sleep 4'});
  assert.ok(r.checks.overnight_violations.length);
});
test('verified-sounding berth description avoids the simple open-boat heuristic',()=>{
  const r=check(boat({title:'Test Center Console',why_suggested:'Enclosed cabin with two real berths'}),{overnight_requirements:'Need to sleep aboard'});
  assert.deepEqual(r.checks.overnight_violations,[]);
});

test('structured generation requires complete scoring and verification fields',()=>{
  const item=SUGGEST_SCHEMA.properties.suggestions.items;
  assert.ok(item.required.includes('score_breakdown'));
  assert.ok(item.required.includes('verification_required'));
  assert.deepEqual(item.properties.score_breakdown.required,Object.keys(MATCH_SCORE_CAPS));
});

const fullScore = (activityPoints) => Object.fromEntries(Object.keys(MATCH_SCORE_CAPS).map(key => [key, key === 'activities_use' ? activityPoints : 0]));

test('selection ranks before the tier cap rather than losing later stronger fits',()=>{
  const input=[
    {make:'A',model:'Low',score_breakdown:fullScore(5)},
    {make:'B',model:'High',score_breakdown:fullScore(24)},
    {make:'C',model:'Middle',score_breakdown:fullScore(15)},
  ];
  assert.deepEqual(selectTopModelCandidates(input,2).map(s=>s.model),['High','Middle']);
  assert.equal(input[0].model,'Low'); // Selection does not mutate the LLM output.
});

test('selection retains the strongest duplicate make/model variant',()=>{
  const input=[
    {make:'Test',model:'32',year:2020,score_breakdown:fullScore(8)},
    {make:'Other',model:'28',score_breakdown:fullScore(18)},
    {make:'Test',model:'32',year:2023,score_breakdown:fullScore(23)},
  ];
  const selected=selectTopModelCandidates(input,2);
  assert.equal(selected[0].year,2023);
  assert.deepEqual(selected.map(s=>s.model),['32','28']);
});

test('selection caps invalid score components and keeps ties stable',()=>{
  const input=[
    {make:'A',model:'One',score_breakdown:fullScore(999)},
    {make:'B',model:'Two',score_breakdown:fullScore(25)},
    {make:'C',model:'Three',score_breakdown:fullScore(-50)},
  ];
  assert.deepEqual(selectTopModelCandidates(input,2).map(s=>s.model),['One','Two']);
});

test('unqualified performance in the displayed MATCH summary is reviewed',()=>{
  const result=check(boat({match:{summary:'Cruises at 28 knots',matches:[],gaps:[]}}),{});
  assert.equal(result.checks.performance_claim_review.length,1);
  assert.equal(result.concern_level,'yellow');
});

test('unqualified performance in engine and specification descriptions is reviewed',()=>{
  const result=check(boat({engines:'Twin outboards, 1.8 MPG',specs:'Length 32 ft'}),{});
  assert.equal(result.checks.performance_claim_review.length,1);
});

test('performance evidence in another field cannot qualify an unsupported claim',()=>{
  const result=check(boat({
    summary:'This model will cruise at 32 knots.',
    specs:'Published manufacturer test report, engine configuration: twin 300 hp outboards.',
  }),{});
  assert.equal(result.checks.performance_claim_review.length,1);
});

test('model price guidance only excludes a fully above-budget range',()=>{
  const items=[
    {model:'Too expensive',price_range_min:110000,price_range_max:150000},
    {model:'Overlaps',price_range_min:80000,price_range_max:130000},
    {model:'Unverified',asking_price:125000},
    {model:'Below preferred minimum',price_range_min:25000,price_range_max:40000},
  ];
  const result=filterByBudget(items,75000,100000,(s)=>s.model==='Too expensive' ? 110000 : null);
  assert.deepEqual(result.removed.map(s=>s.model),['Too expensive']);
  assert.deepEqual(result.kept.map(s=>s.model),['Overlaps','Unverified','Below preferred minimum']);
});

test('an LLM price band above budget cannot silently remove a model',()=>{
  const input=[
    {model:'Possibly pricey',price_range_min:135000,price_range_max:155000,price_range_context:'2020-2023 US used market',price_range_verified:true},
    {model:'Unknown price',asking_price:225000},
  ];
  const result=filterByBudget(input,null,100000);
  assert.deepEqual(result.removed,[]);
  assert.deepEqual(result.kept,input);
  // A provider-supplied "verified" flag is not independent evidence.
  const forged=filterByBudget(input,null,100000,()=>null);
  assert.deepEqual(forged.removed,[]);
});

test('a paid budget minimum does not leak into free-tier matching',()=>{
  const profile={purchase_budget_min:80000,purchase_budget_max:140000};
  assert.deepEqual(tierBudgetSummary(profile,'free'),[null,140000]);
  assert.deepEqual(tierBudgetSummary(profile,'match_plus'),[80000,140000]);
});

test('unverified above-budget model estimates are price-review warnings, not hard exclusions',()=>{
  const candidate=boat({
    price_range_min:110000,price_range_max:130000,
    price_range_verified:true, // A model-generated claim must never establish source trust.
    price_range_context:'2020–2024 US used examples',
    verification_required:['Verify market price and budget before buying.'],
  });
  const result=check(candidate,{purchase_budget_max:100000});
  assert.equal(result.concern_level,'yellow');
  assert.deepEqual(result.checks.budget_violations,[]);
  assert.ok(result.checks.price_verification_gaps.some(s=>/starts above.*budget/i.test(s)));
  const liked=runProgrammaticChecks([candidate],{purchase_budget_max:100000},'market_match',[{make:'Test',model:'32'}]);
  assert.equal(liked.checks.like_override_detected,false);
  const unknown=check(boat({asking_price:150000}),{purchase_budget_max:100000});
  assert.deepEqual(unknown.checks.budget_violations,[]);
});

test('independently reviewed model lower bound remains an absolute QA budget constraint',()=>{
  const candidate=boat({price_range_min:85000,price_range_max:130000});
  const result=runProgrammaticChecks(
    [candidate],{purchase_budget_max:100000},'market_match',
    [{make:'Test',model:'32'}],()=>110000,
  );
  assert.equal(result.concern_level,'red');
  assert.equal(result.checks.budget_violations.length,1);
  assert.equal(result.checks.like_override_detected,true);
  assert.ok(result.checks.hard_constraint_violations.some(s=>/Budget:/i.test(s)));
});

test('a contextual but unverified below-budget model band still requires price verification',()=>{
  const r=check(boat({price_range_min:50000,price_range_max:80000,price_range_context:'2019–2022 US used examples'}),{purchase_budget_max:100000});
  assert.equal(r.checks.budget_violations.length,0);
  assert.ok(r.checks.price_verification_gaps.some(s=>/independent market-verification/i.test(s)));
});

test('a generic price verification warning cannot hide missing generation or market context',()=>{
  const r=check(boat({
    price_range_min:50000,
    price_range_max:80000,
    price_range_context:'',
    verification_required:['Verify market price against budget before buying.'],
  }),{purchase_budget_max:100000});
  assert.equal(r.checks.budget_violations.length,0);
  assert.ok(r.checks.price_verification_gaps.some(s=>/lacks generation\/year\/market context/i.test(s)));
  assert.equal(r.concern_level,'yellow');
});

test('price context and an explicit verification flag satisfy model price QA warning',()=>{
  const r=check(boat({
    price_range_min:50000,
    price_range_max:80000,
    price_range_context:'2019–2022 US used market estimate',
    verification_required:['Verify market price against current model-year evidence.'],
  }),{purchase_budget_max:100000});
  assert.deepEqual(r.checks.price_verification_gaps,[]);
});

test('MATCH generation contract preserves model-vs-listing and optional-equipment safeguards',async()=>{
  let prompt='';
  const client={asServiceRole:{integrations:{Core:{InvokeLLM:async args=>{
    prompt=args.prompt;
    return {suggestions:[],contradiction:{flagged:true,conflicts:[],explanation:'No verified fit',closest_alternatives:[]}};
  }}}}};
  await generateRecommendations(client,{
    profile:{vessel_class:'power',purchase_budget_max:100000,boat_size_range:'25_30'},
    plan:'free',tierFields:{matchPlus:new Set(),refinedMatch:new Set(),marketMatch:new Set()},
    manufacturerMap:{brief:'',list:[]},likedModels:[],savedBoats:[],existingSuggestions:[],
    isFirstPaidGeneration:false,hadContradiction:false,refresh:false,contradictionRerunCount:0,
  });
  assert.match(prompt,/MODEL VS OPTIONS:/);
  assert.match(prompt,/PERFORMANCE CAUTION:/);
  assert.match(prompt,/documented limited-production and custom-sportfishing hull series/);
  assert.match(prompt,/one-off custom boat without a substantiated model\/design family belongs in later listing-specific analysis/);
  assert.match(prompt,/not specific listings/i);
  assert.match(prompt,/price_range_min and price_range_max/);
  assert.match(prompt,/never generate a single-dollar point estimate/i);
  assert.doesNotMatch(prompt,/est\. \$45,000/);
  assert.match(prompt,/do not target a fixed percentage of the budget/i);
});

test('long-form fuel economy or speed triggers the same QA review as abbreviated units', () => {
  for (const copy of ['Fuel burn 20 gallons per hour', 'Has a 31-knot cruise', '450-mile range']) {
    const result = check(boat({why_suggested: copy}), {});
    assert.equal(result.checks.performance_claim_review.length, 1, copy);
    assert.equal(result.concern_level, 'yellow', copy);
  }
});

test('optional equipment claims are reviewed across every buyer-visible MATCH field', () => {
  for (const extra of [
    { engines: 'Twin 300 hp outboards; includes joystick' },
    { specs: 'Length 32 ft; factory-installed windlass' },
    { match: { matches: [], gaps: ['The model comes with Seakeeper'] } },
    { match: { summary: 'Features radar', matches: [], gaps: [] } },
  ]) {
    const result = check(boat(extra), {});
    assert.equal(result.checks.optional_equipment_review.length, 1, JSON.stringify(extra));
    assert.equal(result.concern_level, 'yellow', JSON.stringify(extra));
  }
});

test('separately qualified optional equipment does not assert installed equipment', () => {
  const result = check(boat({
    why_suggested: 'This model may have an optional windlass.',
    engines: 'Outboards; verify joystick if equipped on a specific listing.',
    match: { matches: ['Radar is optional equipment.'], gaps: [] },
  }), {});
  assert.deepEqual(result.checks.optional_equipment_review, []);
});

test('qualifying one field does not excuse unsupported equipment promises in another', () => {
  const result = check(boat({
    why_suggested: 'Joystick is an option and must be verified.',
    engines: 'Includes joystick.',
  }), {});
  assert.equal(result.checks.optional_equipment_review.length, 1);
});
