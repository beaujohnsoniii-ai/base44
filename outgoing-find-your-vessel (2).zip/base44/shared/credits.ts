// Manages advisor credits — issued when a recommendation isn't possible due to contradictory
// constraints, with a 30-day expiration. Applied to future advisory stage purchases instead
// of a refund. The buyer adjusts their profile and re-runs the advisor; the credit ensures
// they don't pay for a report they couldn't use.

const CREDIT_DAYS = 30;
export const ADVISOR_CREDIT_AMOUNT = 29;

// Check whether a credit expiration date is still in the future.
export function isCreditValid(expiresAt: string | null | undefined): boolean {
  if (!expiresAt) return false;
  const expires = new Date(expiresAt);
  if (isNaN(expires.getTime())) return false;
  return expires.getTime() > Date.now();
}

// Issue an advisor credit with a 30-day expiration on the buyer's profile.
// Called when the advisor flags a contradictory profile and cannot produce a recommendation.
export async function issueAdvisorCredit(
  base44: any,
  profileId: string,
  amount: number = ADVISOR_CREDIT_AMOUNT,
): Promise<void> {
  const expires = new Date();
  expires.setDate(expires.getDate() + CREDIT_DAYS);
  try {
    await base44.asServiceRole.entities.BuyerProfile.update(profileId, {
      advisor_credit: amount,
      advisor_credit_expires: expires.toISOString(),
    });
  } catch (e) {
    console.error("credits: failed to issue advisor credit", e);
  }
}

// Resolve the valid (non-expired) advisor credit for a user by loading their active profile.
// Returns the credit amount and the profile id (needed to consume the credit after purchase).
// If the credit has expired, zeroes it out so it doesn't show as available.
export async function resolveAdvisorCredit(
  base44: any,
  userId: string,
): Promise<{ amount: number; profileId: string | null }> {
  try {
    const profiles = await base44.asServiceRole.entities.BuyerProfile.filter(
      { created_by_id: userId, status: "active" },
      "-created_date",
      1,
    );
    const profile = profiles?.[0];
    if (!profile) return { amount: 0, profileId: null };

    const amount = Number(profile.advisor_credit) || 0;
    const expiresAt = profile.advisor_credit_expires;

    if (amount > 0 && isCreditValid(expiresAt)) {
      return { amount, profileId: profile.id };
    }

    // Credit expired — zero it out so it doesn't show as available.
    if (amount > 0 && !isCreditValid(expiresAt)) {
      try {
        await base44.asServiceRole.entities.BuyerProfile.update(profile.id, {
          advisor_credit: 0,
          advisor_credit_expires: null,
        });
      } catch (e) {
        console.error("credits: failed to expire stale credit", e);
      }
    }

    return { amount: 0, profileId: null };
  } catch (e) {
    console.error("credits: failed to resolve advisor credit", e);
    return { amount: 0, profileId: null };
  }
}

// Consume the advisor credit on a profile (set to 0) after it's been applied to a purchase.
export async function consumeAdvisorCredit(
  base44: any,
  profileId: string,
): Promise<void> {
  try {
    await base44.asServiceRole.entities.BuyerProfile.update(profileId, {
      advisor_credit: 0,
      advisor_credit_expires: null,
    });
  } catch (e) {
    console.error("credits: failed to consume advisor credit", e);
  }
}