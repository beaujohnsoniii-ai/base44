import test from 'node:test';
import assert from 'node:assert/strict';
import { screenPhysicalCandidate, explicitStorageLengthCapFt } from './physical-specs.ts';

const screen = (candidate, profile) => screenPhysicalCandidate(candidate, profile);
const verified = (candidate, ...fields) => ({ ...candidate, __catalog_verified_fields: fields });

test('preferred size alone never acts as a physical hard limit', () => {
  assert.equal(screen({length:'32 ft'}, {boat_size_range:'18_24'}).excluded, false);
});
test('unverified nominal length above actual maximum needs verification, not exclusion', () => {
  const r=screen({length:'31 ft'}, {hard_max_overall_length_ft:30});
  assert.equal(r.excluded,false);
  assert.match(r.verification_required.join(' '),/rigged overall length/);
});
test('hull length below cap requires rigged length verification', () => {
  const r=screen({length:'29 ft'}, {hard_max_overall_length_ft:30});
  assert.equal(r.excluded,false);
  assert.match(r.verification_required.join(' '),/rigged overall length/);
});
test('known over-limit overall length is rejected', () => {
  assert.equal(screen(verified({overall_length_ft:31.5}, 'rigged_overall_length_ft'), {hard_max_overall_length_ft:30}).excluded,true);
});
test('storage note and structured limits use the stricter cap', () => {
  assert.equal(screen(verified({overall_length_ft:29}, 'rigged_overall_length_ft'), {hard_max_overall_length_ft:35,storage_capacity:'Maximum length 28 ft'}).excluded,true);
});
test('explicit LOA restrictions become hard caps regardless of phrasing', () => {
  for (const note of ['Max LOA 30 ft', 'maximum overall length of 30 ft', '30 ft LOA maximum', '30 ft max overall length']) {
    assert.equal(explicitStorageLengthCapFt(note), 30, note);
    assert.equal(screen(verified({overall_length_ft:31}, 'rigged_overall_length_ft'), {storage_capacity:note}).excluded, true, note);
  }
});
test('slip size alone does not manufacture a maximum boat length', () => {
  assert.equal(explicitStorageLengthCapFt('I have a 30 ft slip at the marina'), null);
  assert.equal(screen({overall_length_ft:31}, {storage_capacity:'I have a 30 ft slip at the marina'}).excluded, false);
});
test('marina length limits recognize alternative maximum wording', () => {
  for (const note of ['No more than 30 ft overall', 'Must not exceed 30 ft', 'At most 30 ft LOA']) {
    assert.equal(explicitStorageLengthCapFt(note), 30, note);
    assert.equal(screen(verified({overall_length_ft:31}, 'rigged_overall_length_ft'), {storage_capacity:note}).excluded, true, note);
  }
});
test('feet and inches marina caps retain the extra six inches', () => {
  for (const note of ['30\' 6" max LOA', 'No more than 30\' 6" overall']) {
    assert.equal(explicitStorageLengthCapFt(note), 30.5, note);
    assert.equal(screen({overall_length_ft:30.4}, {storage_capacity:note}).excluded, false, note);
    assert.equal(screen(verified({overall_length_ft:30.6}, 'rigged_overall_length_ft'), {storage_capacity:note}).excluded, true, note);
  }
});
test('draft beam and storage height reject known overages', () => {
  const r=screen(verified({draft_ft:1.5,beam_ft:9.6,storage_height_ft:10}, 'draft_ft', 'beam_ft', 'storage_height_ft'), {hard_max_draft_ft:1,hard_max_beam_ft:9.5,hard_max_height_ft:9});
  assert.equal(r.reasons.length,3);
});
test('loaded weight above lift capacity is rejected', () => {
  assert.equal(screen(verified({loaded_storage_weight_lb:6500}, 'storage_weight_lb'), {hard_max_storage_weight_lb:6000}).excluded,true);
});
test('actual trailer weight over supplied tow ceiling is rejected', () => {
  assert.equal(screen(verified({trailered_weight_lb:7000}, 'trailered_weight_lb'), {storage:'trailer',tow_capacity_lb:6000}).excluded,true);
});
test('tow ceiling is not applied to slip-kept boats', () => {
  assert.equal(screen({trailered_weight_lb:7000}, {storage:'marina_slip',tow_capacity_lb:6000}).excluded,false);
});
test('unknown trailered weight must be verified', () => {
  const r=screen({length:'24 ft'}, {storage:'trailer',tow_capacity_lb:6000});
  assert.equal(r.excluded,false);
  assert.match(r.verification_required.join(' '),/trailered weight/);
});
test('unknown buyer tow rating never creates an assumed ceiling', () => {
  const r=screen({length:'35 ft',trailered_weight_lb:20000}, {storage:'trailer',towing:'rating unknown'});
  assert.equal(r.excluded,false);
  assert.match(r.verification_required.join(' '),/actual tow-vehicle rating/);
});

test('unknown tow rating and unknown loaded trailer weight both require verification',()=>{
  const r=screen({length:'24 ft'}, {storage:'trailer'});
  assert.equal(r.excluded,false);
  assert.match(r.verification_required.join(' '),/actual tow-vehicle rating/);
  assert.match(r.verification_required.join(' '),/trailered weight/);
});
test('LLM supplied source URL is not proof of verified dimensions', () => {
  const r=screen({overall_length_ft:29,beam_ft:9,spec_source_url:'https://example.com/specs'}, {hard_max_overall_length_ft:30,hard_max_beam_ft:9.5});
  assert.equal(r.excluded,false);
  assert.match(r.verification_required.join(' '),/rigged overall length/);
  assert.match(r.verification_required.join(' '),/beam/);
});

test('beam, height, clearance and draft caps cannot masquerade as LOA caps', () => {
  const otherDimensionNotes = [
    'max 10 ft beam', 'beam max 10 ft', 'maximum 12 ft height',
    'height max 12 ft', 'maximum 8 ft clearance', 'draft max 2 ft',
    'max 18 inches draft',
  ];
  for (const note of otherDimensionNotes) {
    assert.equal(explicitStorageLengthCapFt(note), null, note);
    assert.equal(screen({overall_length_ft:25}, {storage_capacity:note}).excluded, false, note);
  }
});

test('mixed facility dimensions use the real length ceiling, not the beam cap', () => {
  const note = 'Max 10 ft beam; max 30 ft overall length';
  assert.equal(explicitStorageLengthCapFt(note), 30);
  assert.equal(screen({overall_length_ft:28,beam_ft:9.5}, {storage_capacity:note}).excluded, false);
  assert.equal(screen(verified({overall_length_ft:31,beam_ft:9.5}, 'rigged_overall_length_ft', 'beam_ft'), {storage_capacity:note}).excluded, true);
});
