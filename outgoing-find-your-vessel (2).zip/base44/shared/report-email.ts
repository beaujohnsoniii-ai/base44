// Formats a generated advisory report into an HTML email body so it can be delivered
// to the buyer for offline review. Handles all four report types: preliminary, top_pick,
// top_three, and private_advisory.

import { STAGE_PRODUCTS } from "./stages.ts";

function esc(s: unknown): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function bulletList(items?: string[]): string {
  if (!items?.length) return "";
  return `<ul style="margin:6px 0;padding-left:20px;">${items
    .map((i) => `<li style="margin:2px 0;">${esc(i)}</li>`)
    .join("")}</ul>`;
}

function section(title: string, body: string): string {
  if (!body) return "";
  return `<h4 style="margin:16px 0 4px;font-size:14px;color:#0f172a;">${esc(title)}</h4>${body}`;
}

function para(text: string): string {
  return `<p style="font-size:14px;margin:4px 0;">${esc(text)}</p>`;
}

function boatMatchHtml(rec: any, rank?: number): string {
  if (!rec) return "";
  const parts: string[] = [];
  parts.push(`<div style="margin:20px 0;padding:18px;border:1px solid #e2e8f0;border-radius:8px;background:#f8fafc;">`);
  if (rank) parts.push(`<div style="color:#64748b;font-size:12px;margin-bottom:4px;">Rank #${rank}</div>`);
  parts.push(`<h3 style="margin:0 0 6px;font-size:17px;color:#0f172a;">${esc(rec.title)}</h3>`);

  const meta: string[] = [];
  if (rec.asking_price) meta.push(esc(rec.asking_price));
  if (rec.review_date) meta.push(`Reviewed ${esc(rec.review_date)}`);
  if (rec.availability) meta.push(`Availability: ${esc(rec.availability)}`);
  if (rec.match_strength) meta.push(`<strong>${esc(rec.match_strength)}</strong>`);
  if (meta.length) parts.push(`<p style="margin:0 0 8px;font-size:13px;color:#475569;">${meta.join(" · ")}</p>`);

  if (rec.link) {
    parts.push(`<p style="margin:0 0 8px;font-size:13px;"><a href="${esc(rec.link)}" style="color:#0e7490;">Find listings</a></p>`);
  }

  if (rec.key_specs?.length) {
    const rows = rec.key_specs
      .map((s: any) => `<tr><td style="padding:2px 12px 2px 0;color:#64748b;font-size:13px;">${esc(s.label)}</td><td style="padding:2px 0;font-size:13px;font-weight:600;">${esc(s.value)}</td></tr>`)
      .join("");
    parts.push(section("Key specifications", `<table style="border-collapse:collapse;">${rows}</table>`));
  }

  if (rec.fit_reasons?.length) parts.push(section("Why it fits", bulletList(rec.fit_reasons)));
  if (rec.compromises?.length) parts.push(section("Compromises & concerns", bulletList(rec.compromises)));

  if (rec.cost_analysis) {
    let body = "";
    if (rec.cost_analysis.annual_ownership_range) {
      body += `<p style="margin:4px 0;font-size:13px;">Annual ownership: <strong>${esc(rec.cost_analysis.annual_ownership_range)}</strong></p>`;
    }
    if (rec.cost_analysis.breakdown?.length) {
      const rows = rec.cost_analysis.breakdown
        .map((r: any) => `<tr><td style="padding:2px 12px 2px 0;color:#64748b;font-size:13px;">${esc(r.category)}</td><td style="padding:2px 0;font-size:13px;text-align:right;">${esc(r.estimate)}</td></tr>`)
        .join("");
      body += `<table style="border-collapse:collapse;margin-top:4px;">${rows}</table>`;
    }
    if (body) parts.push(section("Estimated cost analysis", body));
  }

  if (rec.evidence_gaps?.length) parts.push(section("Evidence gaps", bulletList(rec.evidence_gaps)));
  if (rec.seller_questions?.length) parts.push(section("Seller questions & next steps", bulletList(rec.seller_questions)));

  parts.push(`</div>`);
  return parts.join("");
}

export function formatReportEmail(type: string, content: any): { subject: string; html: string } {
  const name = type === "preliminary" ? "Preliminary Feedback" : STAGE_PRODUCTS[type]?.name ?? "Advisory Report";
  const subject = `Your SoundHeading ${name} report is ready`;

  const body: string[] = [];
  body.push(`<p style="margin:0 0 16px;font-size:14px;color:#475569;">Your ${esc(name)} report is below.</p>`);

  if (content.buyer_priorities?.length) {
    body.push(section("Buyer priorities used", bulletList(content.buyer_priorities)));
  }

  if (type === "preliminary") {
    if (content.priorities_confirmed?.length) body.push(section("Priorities confirmed", bulletList(content.priorities_confirmed)));
    if (content.missing_information?.length) body.push(section("Missing information", bulletList(content.missing_information)));
    if (content.preliminary_observation) body.push(section("Preliminary observation", para(content.preliminary_observation)));
  } else {
    if (type === "private_advisory" && content.consultation_briefing) {
      body.push(section("Consultation briefing", para(content.consultation_briefing)));
    }

    const boats = type === "top_pick" ? (content.recommendation ? [content.recommendation] : []) : (content.recommendations || []);
    boats.forEach((rec: any, i: number) => body.push(boatMatchHtml(rec, type === "top_three" ? i + 1 : undefined)));

    if (type === "top_three" && content.comparison) body.push(section("How they compare", para(content.comparison)));
    if (type === "top_three" && content.investigation_priorities?.length) body.push(section("Investigation priorities", bulletList(content.investigation_priorities)));
    if (type === "private_advisory" && content.discussion_topics?.length) body.push(section("Discussion topics for your consultation", bulletList(content.discussion_topics)));
    if (type === "private_advisory" && content.follow_up_scope) body.push(section("Follow-up scope", para(content.follow_up_scope)));
  }

  if (content.overall_assessment) body.push(section("Overall assessment", para(content.overall_assessment)));
  if (content.remedy_note) body.push(section("If the shortlist can't be delivered", para(content.remedy_note)));

  body.push(
    `<hr style="margin:24px 0;border:none;border-top:1px solid #e2e8f0;" /><p style="font-size:12px;color:#94a3b8;">These are the strongest matches found within your criteria and the sources reviewed — not a claim of the best boat across the entire market. Availability is advertised unless independently confirmed. Remote review cannot establish condition; arrange a survey before purchase.</p>`
  );

  const html = `<!DOCTYPE html><html><body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#1e293b;max-width:600px;margin:0 auto;">
  <h2 style="margin:0 0 4px;font-size:22px;color:#0f172a;">SoundHeading</h2>
  <p style="margin:0 0 16px;font-size:13px;color:#94a3b8;">Independent boat-buying advisory</p>
  ${body.join("")}
</body></html>`;

  return { subject, html };
}