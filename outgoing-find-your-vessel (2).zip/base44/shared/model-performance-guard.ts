// MODEL MATCH must not print an LLM's unsourced, configuration-dependent
// numerical performance as though it describes every boat of a hull model.
// Later listing analysis or a separately source-reviewed engine/test record
// may present performance with its documented configuration and conditions.

// Keep this predicate shared with QA: common marine copy uses both
// abbreviations ("1.8 MPG", "32-knot") and long-form units ("22 gallons
// per hour", "28 miles per hour", "450-mile range"). None of these figures
// belongs in an unsourced model-level MATCH recommendation.
const NUMERIC_PERFORMANCE =
  /\b\d+(?:\.\d+)?\s*(?:[-–]\s*)?(?:mpg|gph|mph|knots?|kts?|kt|nmi|nm|nautical\s+miles?|miles?\s+per\s+hour|(?:nautical\s+)?miles?\s+per\s+gallon|gallons?\s+(?:of\s+fuel\s+)?per\s+hour|(?:nmi?|mi)\s*\/\s*gal)\b|\b(?:cruis(?:e|es|ed|ing)|top\s+speed|maximum\s+speed|(?:cruising|fuel|operating|travel)\s+range|fuel\s+burn|fuel\s+economy|fuel\s+consumption)\b[^.;\n]{0,28}\b\d+(?:\.\d+)?\b|\brange\s*(?:(?:of|about|approximately)\s+)?\d+(?:\.\d+)?\s*(?:nmi|nm|nautical\s+miles?|miles?|mi|km)\b|\b\d+(?:\.\d+)?\s*[-–]?\s*(?:nautical\s+)?miles?\s+(?:of\s+)?range\b/i;

export function containsNumericMarinePerformanceClaim(value: unknown): boolean {
  return typeof value === "string" && NUMERIC_PERFORMANCE.test(value);
}

const WITHHELD_MESSAGE = "Configuration-specific speed, range and fuel economy require independent published test evidence.";

export function withholdUnverifiedModelPerformance(input: unknown): {
  text: string;
  withheld: boolean;
} {
  if (typeof input !== "string" || !input.trim()) {
    return { text: typeof input === "string" ? input : "", withheld: false };
  }
  // Keep independent factual sentences (e.g. berths, hull, cockpit) intact.
  // We split on end punctuation followed by a new sentence, not decimal points.
  const chunks = input.split(/(?<=[.!?])\s+(?=[A-Z0-9])|[;\n]+/);
  let withheld = false;
  const result = chunks.map(chunk => {
    if (!containsNumericMarinePerformanceClaim(chunk)) return chunk.trim();
    withheld = true;
    return WITHHELD_MESSAGE;
  });
  return {
    text: result.filter((chunk, index) => chunk && (index === 0 || chunk !== result[index - 1])).join(" ").trim(),
    withheld,
  };
}
