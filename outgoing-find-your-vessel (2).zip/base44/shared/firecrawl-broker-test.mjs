export const BROKER_TEST_URL="https://www.theboatyardinc.com/inventory/2012-blackjack-224-cc-3928/";
export const FIRECRAWL_ENDPOINT="https://api.firecrawl.dev/v2/scrape";
export const BROKER_APPROVAL="soundheading-firecrawl-broker-basic-20261019-01";
export const BASIC_OPTIONS=Object.freeze({url:BROKER_TEST_URL,formats:["markdown"],proxy:"basic",maxAge:0,storeInCache:false,onlyMainContent:true,timeout:20000,skipTlsVerification:false});
const exact=u=>{try{return new URL(u).href===BROKER_TEST_URL;}catch{return false;}};
export function summarizeBrokerResponse(payload){
 const data=payload?.data,meta=data?.metadata||{},rawText=data?.markdown;
 const text=typeof rawText==="string"?rawText.split(/^##\s+You May Also Like\b/im)[0]:rawText;
 if(payload?.success!==true||typeof text!=="string"||meta.statusCode!==200)return {status:"unavailable",reason:"Provider did not return a readable successful page.",facts:null};
 if(!exact(meta.sourceURL)||!exact(meta.url))return {status:"source_unconfirmed",reason:"Provider final/source URL metadata did not establish the exact approved page.",facts:null};
 const heading=text.split("\n").find(line=>/^\s*#{1,3}\s+.*2012\s+black\s?jack\s+224\b/i.test(line));
 const stock=text.match(/\bStock\s*(?:number|no\.?)?\s*[#:\\\s*-]*3928\b/i);
 if(!heading||!stock)return {status:"identity_unconfirmed",reason:"The page heading and stock evidence did not establish the approved individual boat.",facts:null};
 const currency=/\bUSD\b/.test(text)?"USD":null;
 const prices=[...text.matchAll(/\$\s*([\d,]+(?:\.\d{1,2})?)/g)].filter(m=>!/\bYou\s+Save\b/i.test(text.slice(text.lastIndexOf("\n",m.index)+1,m.index))).map(m=>({value:Number(m[1].replaceAll(",","")),currency,quote:text.slice(Math.max(0,m.index-45),Math.min(text.length,m.index+m[0].length+45))})).filter(p=>p.value>=1000&&p.value<=1000000).slice(0,15);
 const distinct=new Set(prices.map(p=>p.value));
 const hours=[...text.matchAll(/\b(\d{1,5})\s*(?:hrs?|hours)\b/gi)].map(m=>({value:Number(m[1]),quote:m[0]}));
 const uniqueHours=[...new Set(hours.map(h=>h.value))];
 const engine=text.match(/\bSuzuki\b[^\n]{0,60}\b250(?:HP)?\b|\b250(?:HP)?\b[^\n]{0,60}\bSuzuki\b/i);
 return {status:"retrieved_for_admin_review",facts:{year:2012,make:"BlackJack",model:"224 CC",stock_number:"3928",asking_price:distinct.size===1&&currency?prices[0].value:null,currency:distinct.size===1?currency:null,engine_hours:uniqueHours.length===1?uniqueHours[0]:null,engine_description:engine?.[0]||null},
 evidence:{heading:heading.trim(),stock:stock[0],price_claims:prices,hours_claims:hours.slice(0,5),engine_quote:engine?.[0]||null},
 currency_unconfirmed:currency===null,price_conflict:distinct.size>1,qualification:"Broker-page seller claims only. Price conflicts remain unresolved; no Compare match or finalist recommendation."};
}
// Only fixed codes and stages leave this adapter; never retain exception messages or bodies.
export function brokerFailureDiagnostic(error,stage,httpStatus=null,elapsedMs=0){
 const allowedStages=["provider_fetch","provider_response","provider_read","provider_parse","provider_summary","ledger_complete"];
 const message=typeof error?.message==="string"?error.message:"";
 const fixed=["FIRECRAWL_KEY_MISSING","FIRECRAWL_EMPTY_RESPONSE","FIRECRAWL_RESPONSE_TOO_LARGE","FIRECRAWL_INVALID_JSON"];
 const http=/^FIRECRAWL_HTTP_([1-5]\d{2})$/.exec(message);
 const code=http?"PROVIDER_HTTP_ERROR":fixed.includes(message)?message:error?.name==="AbortError"?"ABORTED":stage==="ledger_complete"?"LEDGER_WRITE_FAILED":"UNCLASSIFIED_RUNTIME_ERROR";
 return {stage:allowedStages.includes(stage)?stage:"provider_fetch",code,http_status:http?Number(http[1]):Number.isInteger(httpStatus)&&httpStatus>=100&&httpStatus<=599?httpStatus:null,elapsed_ms:Math.max(0,Math.round(elapsedMs)),provider_receipt_confirmed:false,billing_confirmed:false};
}
export async function scrapeApprovedBroker(key,signal,fetcher=fetch,onStage=()=>{}){
 if(typeof key!=="string"||!key.trim())throw Error("FIRECRAWL_KEY_MISSING");
 const controller=new AbortController();const abort=()=>controller.abort();signal?.throwIfAborted();signal?.addEventListener("abort",abort,{once:true});
 const timer=setTimeout(abort,25000);
 try{
  onStage("provider_fetch");
  const response=await fetcher(FIRECRAWL_ENDPOINT,{method:"POST",redirect:"error",headers:{Authorization:"Bearer "+key.trim(),"Content-Type":"application/json"},body:JSON.stringify(BASIC_OPTIONS),signal:controller.signal});
  onStage("provider_response",response.status);
  if(!response.ok)throw Error("FIRECRAWL_HTTP_"+response.status);
  onStage("provider_read",response.status);
  const reader=response.body?.getReader();if(!reader)throw Error("FIRECRAWL_EMPTY_RESPONSE");
  const chunks=[];let count=0;
  while(true){const next=await reader.read();if(next.done)break;count+=next.value.byteLength;if(count>524288){await reader.cancel();throw Error("FIRECRAWL_RESPONSE_TOO_LARGE");}chunks.push(next.value);}
  const bytes=new Uint8Array(count);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  onStage("provider_parse",response.status);
  let payload;try{payload=JSON.parse(new TextDecoder().decode(bytes));}catch{throw Error("FIRECRAWL_INVALID_JSON");}
  signal?.throwIfAborted();
  onStage("provider_summary",response.status);
  const summary=summarizeBrokerResponse(payload);
  return {...summary,provenance:{requested_url:BROKER_TEST_URL,source_url:payload?.data?.metadata?.sourceURL||null,final_url:payload?.data?.metadata?.url||null,retrieved_at:new Date().toISOString(),provider:"Firecrawl",operation:"v2/scrape",mode:"basic",max_age:0,stored_in_provider_cache:false,provider_credit_cost:payload?.data?.metadata?.provider?.creditsCost??null},page_excerpt:typeof payload?.data?.markdown==="string"?payload.data.markdown.slice(0,10000):null};
 }finally{clearTimeout(timer);signal?.removeEventListener("abort",abort);}
}
