// Routing policy for source-backed research. Models are reviewers, never primary sources.
export const CRITICAL_FIELDS = new Set([
  "LOA", "Length w/ Bracket/Engines", "Beam", "Draft Engines Up",
  "Draft Engines Down", "Dry Weight / Displacement", "Passenger Capacity",
  "Max Rated HP",
]);
export function verificationRoute({field, comparison, sourceTrusted, generationCertain, conflictingEvidence} = {}) {
  if (!sourceTrusted || !generationCertain) return {provider: "manual", mayAutoApply: false, reason: "Source or generation not established"};
  if (conflictingEvidence || comparison === "different") return {provider: "grok_second_opinion", mayAutoApply: false, reason: "Disputed source evidence requires independent review"};
  if (CRITICAL_FIELDS.has(field)) return {provider: "grok_second_opinion", mayAutoApply: false, reason: "Buyer-critical specification requires independent review"};
  if (comparison === "same" || comparison === "missing") return {provider: "claude_primary", mayAutoApply: true, reason: "Eligible for existing two-pass primary-source validation"};
  return {provider: "manual", mayAutoApply: false, reason: "Unsupported comparison"};
}
