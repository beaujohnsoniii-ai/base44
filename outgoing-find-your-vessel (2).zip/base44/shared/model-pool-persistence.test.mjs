import test from 'node:test';
import assert from 'node:assert/strict';
import { createReplacementPool } from './model-pool-persistence.ts';

test('successful replacement inserts all candidates and makes no cleanup calls', async () => {
  const deleted = [];
  const records = await createReplacementPool(
    ['A', 'B'],
    async (title) => ({ id: title, title }),
    async (id) => { deleted.push(id); },
  );
  assert.deepEqual(records.map((r) => r.id), ['A', 'B']);
  assert.deepEqual(deleted, []);
});

test('failed second insert removes the known new records without touching prior pool', async () => {
  const removed = [];
  const originalPool = ['old-1', 'old-2'];
  await assert.rejects(() => createReplacementPool(
    ['new-1', 'new-2'],
    async (id) => {
      if (id === 'new-2') throw new Error('write failed');
      return { id };
    },
    async (id) => { removed.push(id); },
  ), /write failed/);
  assert.deepEqual(removed, ['new-1']);
  assert.deepEqual(originalPool, ['old-1', 'old-2']);
});

test('rollback tries every known insert and identifies an incomplete cleanup', async () => {
  const attempted = [];
  await assert.rejects(() => createReplacementPool(
    ['new-1', 'new-2', 'new-3'],
    async (id) => {
      if (id === 'new-3') throw new Error('write failed');
      return { id };
    },
    async (id) => {
      attempted.push(id);
      if (id === 'new-2') throw new Error('remove failed');
    },
  ), /cleanup was incomplete/);
  assert.deepEqual(attempted, ['new-2', 'new-1']);
});

test('an insert without a confirmed record ID cannot proceed to pool retirement', async () => {
  await assert.rejects(() => createReplacementPool(
    ['new-1'],
    async () => ({}),
    async () => { throw new Error('should not know which record to delete'); },
  ), /returned no ID/);
});
