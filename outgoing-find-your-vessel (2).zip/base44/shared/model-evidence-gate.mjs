// Fail-closed gate for AI-proposed numeric facts extracted from multi-model sources.
// A heading near a value is not proof of row membership; only an explicitly
// isolated single-model table may enter review. Never auto-publish from this gate.
export function isolateModelEvidence(raw, { model, otherModels = [] } = {}) {
  if (typeof raw !== 'string' || !model) return { ok: false, reason: 'No document or model identity' };
  const normalize = x => String(x).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const wanted = normalize(model);
  const lines = raw.split(/\r?\n/);
  const matches = [];
  for (let i = 0; i < lines.length; i++) {
    if (normalize(lines[i]).includes(wanted)) matches.push(i);
  }
  if (!matches.length) return { ok: false, reason: 'Exact model heading not located' };
  // PDF-to-markdown conversion does not guarantee row/page boundaries.
  // Collect only a tiny contextual diagnostic, NOT a verified specification row.
  const context = matches.slice(0, 4).map(i => lines.slice(Math.max(0,i-2), Math.min(lines.length,i+5)).join('\n'));
  const foreign = otherModels.filter(name => context.some(c => normalize(c).includes(normalize(name))));
  return { ok: false, reason: foreign.length ? 'Adjacent model present; page/row isolation required' : 'PDF page and specification-row identity not proven', model, context: context.map(c=>c.slice(0,800)) };
}
export function validateModelClaims({ claims, model, year, isolatedSource }) {
  if (!isolatedSource?.ok || isolatedSource.model !== model || isolatedSource.year !== year || !isolatedSource.page || !isolatedSource.row_id) {
    return { approved: [], rejected: (claims || []).map(c=>({field:c.field,reason:'Unproven model/page/table row'})) };
  }
  const approved=[], rejected=[];
  for (const c of claims || []) {
    if (c.source_model_year !== year || c.source_page !== isolatedSource.page || c.source_row_id !== isolatedSource.row_id || !c.exact_quote || !c.measurement_basis || !c.unit || c.value == null) {
      rejected.push({field:c.field,reason:'Missing field-level source provenance'});
    } else approved.push(c);
  }
  return {approved,rejected};
}
