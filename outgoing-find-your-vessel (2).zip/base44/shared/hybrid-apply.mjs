import { FIELDS, normalizeResolution, safeSource } from "./hybrid-evidence.mjs";
import { verificationRoute } from "./research-verification-policy.mjs";
// Two agreeing source readings are required; conflicts remain human-review work.
export async function applyCrossChecked(db, row, issueId, evidence, firstClaims) {
 const fresh=await db.entities.ResearchDataset.get(row.id);
 const reviews={...fresh.field_reviews}, applied=[], pending=[];
 const issues=await db.entities.DataReviewIssue.filter({dataset_id:row.id,status:"open"},"-created_date",100);
 const primary=String(fresh.raw_fields?.["Primary Manufacturer Source"]||"").match(/https:\/\/[^\s,;]+/g)||[];
 const trusted=safeSource(evidence.source_url)&&primary.some(u=> {
  try{return new URL(u).hostname.replace(/^www\./,"")===new URL(evidence.source_url).hostname.replace(/^www\./,"");}catch{return false;}
 });
 for(const c of evidence.claims||[]) {
  const a=firstClaims?.find(x=>x.field===c.field),meta=FIELDS[c.field],before=reviews[c.field];
  const blocked=issues.some(i=>(i.field===c.field||i.field==="General")&&["conflict","customer_report"].includes(i.kind));
  const old=fresh.raw_fields?.[c.field],missing=old===null||old===undefined||old==="";
  const matching=a&&a.value===c.value&&a.unit===c.unit&&a.basis===c.basis&&a.model_year===c.model_year;
  const agreement=c.comparison==="same"&&a?.comparison==="same"&&!missing&&Math.abs(Number(old)-c.value)<0.00001;
  const addition=missing&&c.comparison==="missing"&&a?.comparison==="missing";
  // An explicitly excluded workbook value needs investigation, even if a number is published.
  const excluded=addition&&/unsupported|conflict|exclud/i.test(String(fresh.raw_fields?.["Verification Status"]||""));
  const route=verificationRoute({field:c.field,comparison:c.comparison,sourceTrusted:trusted,generationCertain:Number.isInteger(c.model_year),conflictingEvidence:blocked});
  if(!route.mayAutoApply||!trusted||!meta||!matching||(!agreement&&!addition)||excluded||blocked||before?.status==="conflict"||
     (before?.status==="source_confirmed"&&(before.value!==c.value||before.year_start!==c.model_year||before.year_end!==c.model_year))||
     !Number.isInteger(c.model_year)||!c.quote?.trim()||!a.quote?.trim()||
     (evidence.source_pages?.length&&!evidence.source_pages.includes(c.page))) {pending.push(c.field);continue;}
  let next;
  try {next=normalizeResolution(c.field,{status:"source_confirmed",value:c.value,unit:c.unit,basis:c.basis,
   year_start:c.model_year,year_end:c.model_year,source_url:evidence.source_url,quote:c.quote,source_reviewed:true,
   notes:"Automatically cross-checked against the primary source in two passes. "+c.reason},evidence.checked_at);}
  catch{pending.push(c.field);continue;}
  if(before?.issue_id===issueId){applied.push(c.field);continue;}
  next={...next,automated:true,issue_id:issueId,page:c.page,source_kind:evidence.source_kind,
   ...(c.field==="Dry Weight / Displacement"?{engines_included:"unknown",batteries_included:"unknown",weight_use:"published_dry_weight_only"}:{})};
  const audit=await db.entities.DataReviewAudit.create({dataset_id:row.id,issue_id:issueId,field:c.field,
   reviewer_id:"automatic_cross_check",before:before||{status:"not_checked",workbook_value:old??null},after:next});
  reviews[c.field]={...next,audit_id:audit.id};
  await db.entities.ResearchDataset.update(row.id,{field_reviews:reviews});
  applied.push(c.field);
 }
 return {applied,pending};
}
