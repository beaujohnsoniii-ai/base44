// Bounds the response even if a platform read stalls. Work must check the signal
// between reads; this cannot cancel an SDK request already in flight.
export async function withCompareDeadline(work, milliseconds=10000){
 const controller=new AbortController();let timer;
 const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(new Error("COMPARE_DEADLINE"));},milliseconds);});
 try{return await Promise.race([Promise.resolve().then(()=>work(controller.signal)),timeout]);}
 finally{clearTimeout(timer);}
}
