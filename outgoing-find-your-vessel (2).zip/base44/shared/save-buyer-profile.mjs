import { applyPastLikeChoice } from "./liked-preferences.mjs";
import { profileInputFingerprint } from "./profile-input-fingerprint.mjs";
import { DEFAULT_FIELD_TIERS } from "./question-tier-defaults.mjs";
const fields = new Set([...Object.keys(DEFAULT_FIELD_TIERS), "hard_max_overall_length_ft", "hard_max_beam_ft", "hard_max_height_ft", "hard_max_storage_weight_lb", "hard_max_draft_ft", "tow_capacity_lb", "match_question_tier", "status"]);
export class ProfileSaveError extends Error { constructor(message, status = 409) { super(message); this.status = status; } }
export async function saveBuyerProfile(client, user, input, { onlyIfMissing = false, resetContext = false } = {}) {
  if (!user?.id) throw new ProfileSaveError("Unauthorized", 401);
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new ProfileSaveError("Invalid profile", 400);
  const patch = Object.fromEntries(Object.entries(input).filter(([key]) => fields.has(key)));
  const profiles = client.asServiceRole.entities.BuyerProfile;
  const find = async () => (await profiles.filter({ created_by_id: user.id }, "-created_date", 1))?.[0];
  const update = async existing => {
    applyPastLikeChoice(existing, patch, input);
    const next = { ...existing, ...patch };
    if (resetContext || await profileInputFingerprint(existing) !== await profileInputFingerprint(next)) {
      // A new context preserves account history while invalidating its inferred preferences.
      patch.match_context_id = crypto.randomUUID();
    }
    applyPastLikeChoice(existing, patch, resetContext && (existing.past_likes_context_id || input.use_past_likes === true) ? { use_past_likes: false } : input);
    return profiles.update(existing.id, patch);
  };
  const existing = await find();
  if (existing) return onlyIfMissing ? existing : update(existing);
  if (!patch.experience_level || typeof patch.experience_level !== "string") throw new ProfileSaveError("Complete your experience level before saving.", 400);
  // User already exists. A plain single id makes updateMany a conditional atomic
  // claim on Base44. Never use upsert for this: concurrent upserts may duplicate.
  const claim = await client.asServiceRole.entities.User.updateMany(
    { id: user.id, profile_creation_claim: { $in: [null, ""] } },
    { $set: { profile_creation_claim: "claimed" } },
  );
  if (claim?.updated !== 1) {
    const saved = await find();
    if (saved) return onlyIfMissing ? saved : update(saved);
    throw new ProfileSaveError("Profile creation is already in progress or needs recovery. Your answers are retained. Reload before retrying; no second profile was created.");
  }
  // Check again after claiming: an earlier request may have just completed.
  const saved = await find();
  if (saved) return onlyIfMissing ? saved : update(saved);
  // The claim intentionally never expires or auto-releases. If a create times
  // out after a database commit, releasing it would allow a duplicate on retry.
  // Recovery first searches this owner's records; never delete customer data.
  patch.match_context_id = crypto.randomUUID();
  applyPastLikeChoice(null, patch, input);
  return profiles.create({ ...patch, created_by_id: user.id, created_by: user.email });
}
