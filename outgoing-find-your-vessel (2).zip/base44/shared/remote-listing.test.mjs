import test from "node:test";
import assert from "node:assert/strict";
import { normalizePublicListingUrl, fetchPublicListing } from "./remote-listing.ts";

test("public HTTPS listing URLs are allowed", () => {
  assert.equal(normalizePublicListingUrl("https://www.boattrader.com/boat/123"), "https://www.boattrader.com/boat/123");
  assert.equal(normalizePublicListingUrl("https://www.yachtworld.com/yacht/123#details"), "https://www.yachtworld.com/yacht/123");
});
test("local targets, credentials and non-HTTPS schemes are rejected", () => {
  const inputs=[
    "http://www.boattrader.com/boat/123",
    "file:///etc/passwd",
    "https://127.0.0.1/foo",
    "https://169.254.169.254/latest/meta-data",
    "https://10.0.0.5/admin",
    "https://[::1]/",
    "https://localhost/admin",
    "https://server.internal/admin",
    "https://server.local/admin",
    "https://user:pass@www.boattrader.com/boat",
    "https://www.boattrader.com:8080/boat",
    "https://0x7f000001/",
    "not a URL",
  ];
  for(const input of inputs) assert.equal(normalizePublicListingUrl(input),null,input);
});
test("a redirect to a private address is rejected without fetching the destination",async()=>{
  const original=globalThis.fetch;
  const called=[];
  globalThis.fetch=async(url)=>{
    called.push(String(url));
    return new Response(null,{status:302,headers:{location:"http://127.0.0.1/private"}});
  };
  try {
    const result=await fetchPublicListing("https://www.boattrader.com/boat/123");
    assert.equal(result.ok,false);
    assert.match(result.error,/restricted/i);
    assert.equal(called.length,1);
  } finally {globalThis.fetch=original;}
});
test("an approved-source redirect cannot escape the allowlist",async()=>{
  const original=globalThis.fetch;
  let calls=0;
  globalThis.fetch=async()=>{
    calls++;
    return new Response(null,{status:302,headers:{location:"https://dealer.com/boat/123"}});
  };
  try {
    const result=await fetchPublicListing("https://www.boattrader.com/boat/123",{allowedHosts:new Set(["www.boattrader.com"])});
    assert.equal(result.ok,false);
    assert.match(result.error,/outside the approved source/i);
    assert.equal(calls,1);
  } finally {globalThis.fetch=original;}
});

test("a normal public redirect with HTML succeeds",async()=>{
  const original=globalThis.fetch;
  let calls=0;
  globalThis.fetch=async()=>{
    calls++;
    if(calls===1)return new Response(null,{status:301,headers:{location:"/boat/123"}});
    return new Response("<html><body>"+ "Boat specifications and model details ".repeat(7)+"</body></html>",{headers:{"content-type":"text/html"}});
  };
  try {
    const result=await fetchPublicListing("https://www.boattrader.com/");
    assert.equal(result.ok,true);
    assert.equal(calls,2);
    assert.match(result.text,/Boat specifications/);
  } finally {globalThis.fetch=original;}
});
test("non-HTML responses are not loaded as listing pages",async()=>{
  const original=globalThis.fetch;
  globalThis.fetch=async()=>new Response("%PDF",{headers:{"content-type":"application/pdf"}});
  try {
    const result=await fetchPublicListing("https://www.boattrader.com/listing");
    assert.equal(result.ok,false);
    assert.match(result.error,/web page/);
  } finally {globalThis.fetch=original;}
});
