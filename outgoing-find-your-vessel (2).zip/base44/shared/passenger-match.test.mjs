import test from 'node:test';
import assert from 'node:assert/strict';
import { screenPhysicalCandidate } from './physical-specs.ts';
import { runProgrammaticChecks } from './qa-programmatic.ts';
import { MATCH_SCORE_CAPS, generateRecommendations } from './suggest-engine.ts';

const sample = (fields={}) => ({
 title:'Model X',make:'Test',model:'X',specs:'Length 24 ft',
 suitability_score:0,
 score_breakdown:Object.fromEntries(Object.keys(MATCH_SCORE_CAPS).map(k=>[k,0])),
 verification_required:[],...fields
});

test('unverified capacity below normal party is held for checking, not fabricated as a hard violation',()=>{
 const screened=screenPhysicalCandidate({passenger_capacity:4},{passenger_count:5});
 assert.equal(screened.excluded,false);
 assert.match(screened.verification_required.join(' '),/safe passenger capacity for normal group/i);
 const qa=runProgrammaticChecks([sample({passenger_capacity:4})],{passenger_count:5},'match_plus',[]);
 assert.equal(qa.concern_level,'yellow');
 assert.equal(qa.checks.passenger_violations.length,0);
 assert.match(qa.checks.passenger_verification_gaps.join(' '),/unverified reported person limit 4/);
});

test('passenger QA distinguishes verified published limits from provisional reported numbers',()=>{
 const profile={passenger_count:5,occasional_passenger_count:9};
 const provisional=runProgrammaticChecks([sample({
   passenger_capacity:6,
   specs:'Length 24 ft · Unverified passenger limit 6 (confirm manufacturer rating)',
 })],profile,'match_plus',[]);
 assert.equal(provisional.checks.passenger_violations.length,0);
 assert.equal(provisional.checks.passenger_verification_gaps.length,1);
 assert.match(provisional.checks.occasional_passenger_notes[0],/unverified reported 6-person limit/i);

 const published=runProgrammaticChecks([sample({
   passenger_capacity:8,
   specs:'Length 24 ft · Published passenger limit 8 (source-verified; loading and conditions still matter)',
 })],{passenger_count:5,occasional_passenger_count:7},'match_plus',[]);
 assert.deepEqual(published.checks.passenger_verification_gaps,[]);
 assert.deepEqual(published.checks.passenger_violations,[]);
 assert.deepEqual(published.checks.occasional_passenger_notes,[]);

 const falseLabel=runProgrammaticChecks([sample({
   passenger_capacity:4,
   specs:'Length 24 ft · Unverified passenger limit 4 (confirm manufacturer rating)',
 })],{passenger_count:5},'match_plus',[]);
 assert.equal(falseLabel.concern_level,'yellow'); // Unverified is pending, not a hard failure.
 assert.deepEqual(falseLabel.checks.passenger_violations,[]);
 assert.match(falseLabel.checks.passenger_verification_gaps[0],/unverified reported person limit/i);
});

test('unknown passenger limit requires verification, not fabricated exclusion',()=>{
 const screened=screenPhysicalCandidate({},{passenger_count:5});
 assert.equal(screened.excluded,false);
 assert.match(screened.verification_required.join(' '),/passenger capacity/i);
 const qa=runProgrammaticChecks([sample()],{passenger_count:5},'match_plus',[]);
 assert.equal(qa.concern_level,'yellow');
 assert.equal(qa.checks.passenger_verification_gaps.length,1);
});

test('occasional group warning does not override everyday group',()=>{
 const screened=screenPhysicalCandidate({passenger_capacity:6},{passenger_count:4,occasional_passenger_count:8});
 assert.equal(screened.excluded,false);
 assert.match(screened.verification_required.join(' '),/Occasional group of 8 exceeds/);
 const qa=runProgrammaticChecks([sample({passenger_capacity:6,verification_required:screened.verification_required})],{passenger_count:4,occasional_passenger_count:8},'match_plus',[]);
 assert.equal(qa.checks.passenger_violations.length,0);
 assert.equal(qa.checks.occasional_passenger_notes.length,1);
});

test('free tier QA ignores stored paid passenger answers',()=>{
 const qa=runProgrammaticChecks([sample({passenger_capacity:4})],{passenger_count:5,occasional_passenger_count:8},'free',[]);
 assert.equal(qa.checks.passenger_violations.length,0);
 assert.equal(qa.checks.passenger_verification_gaps.length,0);
 assert.equal(qa.checks.occasional_passenger_notes.length,0);
});

test('free generation screens without stored paid passenger counts',async()=>{
 const entry={title:'Test 24',make:'Test',model:'24',year:2022,passenger_capacity:4,
 score_breakdown:Object.fromEntries(Object.keys(MATCH_SCORE_CAPS).map(k=>[k,0])),
 verification_required:[],why_suggested:'Test',summary:'Test'};
 const client={asServiceRole:{integrations:{Core:{InvokeLLM:async()=>({
 suggestions:[entry],
 contradiction:{flagged:true,conflicts:[],explanation:'Limited pool',closest_alternatives:[]}
 })}}}};
 const common={
 profile:{boat_size_range:'20_25',vessel_class:'power',passenger_count:5,occasional_passenger_count:8},
 tierFields:{matchPlus:new Set(['passenger_count','occasional_passenger_count']),refinedMatch:new Set(),marketMatch:new Set()},
 manufacturerMap:{brief:'',list:[]},likedModels:[],savedBoats:[],existingSuggestions:[],
 isFirstPaidGeneration:false,hadContradiction:false,refresh:false,contradictionRerunCount:0
 };
 const free=await generateRecommendations(client,{...common,plan:'free'});
 const paid=await generateRecommendations(client,{...common,plan:'match_plus'});
 assert.equal(free.suggestions.length,1);
 assert.equal(free.suggestions[0].passenger_capacity,4);
 assert.equal(paid.suggestions.length,1);
 assert.match(paid.suggestions[0].verification_required.join(' '),/safe passenger capacity for normal group/i);
});
