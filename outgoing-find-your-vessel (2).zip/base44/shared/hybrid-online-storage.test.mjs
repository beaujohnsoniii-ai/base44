import test from "node:test";
import assert from "node:assert/strict";
import { sourceDocumentMetadata } from "./hybrid-online.ts";

test("large extracted source documents are not persisted into research audit records", () => {
  const sourceText = "UNTRUSTED_SOURCE_BODY_".repeat(2900);
  const metadata = sourceDocumentMetadata(sourceText);
  assert.deepEqual(metadata, { source_text_characters: sourceText.length });
  assert.equal(Object.hasOwn(metadata, "source_text"), false);
  assert.ok(JSON.stringify(metadata).length < 100, "Only compact metadata should be stored");
});

test("empty extracted text has a truthful size count", () => {
  assert.deepEqual(sourceDocumentMetadata(""), { source_text_characters: 0 });
});
