import test from "node:test";
import assert from "node:assert/strict";
import { normalizeQARunParams } from "./qa-run-params.ts";

test("QA defaults are bounded and preserve golden mode", () => {
  assert.deepEqual(normalizeQARunParams({}), { mode:"golden", batchSize:25, maxProfiles:0, notes:"" });
});
test("QA accepts a small admin-requested sample", () => {
  const result = normalizeQARunParams({mode:"mixed",batch_size:3,max_profiles:4,notes:"pilot"});
  assert.equal(result.batchSize,3);
  assert.equal(result.maxProfiles,4);
});
test("QA rejects invalid modes and unsafe batch/profile limits", () => {
  for (const input of [{mode:"all"},{batch_size:-1},{batch_size:1000},{batch_size:"abc"},{max_profiles:1000},{max_profiles:-2},{max_profiles:1.5}]) {
    assert.throws(()=>normalizeQARunParams(input), RangeError);
  }
});
test("QA truncates excessively long notes", () => {
  assert.equal(normalizeQARunParams({notes:"a".repeat(2000)}).notes.length,500);
});
