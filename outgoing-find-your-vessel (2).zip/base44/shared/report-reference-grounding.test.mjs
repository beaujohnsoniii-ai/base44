import test from 'node:test';
import assert from 'node:assert/strict';
import { groundReportReferences } from './report-reference-grounding.ts';

test('related Parker variants do not reuse another listing or AI price', () => {
  const report = { recommendations: [{title:'Parker 2520 XLD', asking_price:'$200,000', availability:'confirmed'}] };
  const old = [{title:'Parker 2520 XL', url:'https://www.boats.com/boat/2520-xl', asking_price:99000}];
  assert.equal(groundReportReferences(report,'top_pick',old,[]).ok,true);
  assert.match(report.recommendations[0].link,/google.com\/search/);
  assert.equal(report.recommendations[0].asking_price,'');
  assert.match(report.recommendations[0].availability,/Model guidance/);
});

test('exact saved listing binds the source URL and its own asking price only', () => {
  const report = { recommendations: [{title:'Parker 2520 XL', asking_price:'$200', availability:'confirmed'}] };
  const old = [{title:'Parker 2520 XL', url:'https://www.boats.com/boat/2520-xl', asking_price:99000}];
  assert.equal(groundReportReferences(report,'top_pick',old,[]).ok,true);
  assert.equal(report.recommendations[0].link,old[0].url);
  assert.match(report.recommendations[0].asking_price,/99,000/);
  assert.match(report.recommendations[0].availability,/unverified/);
});

test('Market Match is model-first even when a saved listing title matches', () => {
  const report = { recommendations: [{title:'Parker 2520 XL', asking_price:'$200', availability:'advertised'}] };
  const old = [{title:'Parker 2520 XL', url:'https://www.boats.com/boat/2520-xl', asking_price:99000}];
  assert.equal(groundReportReferences(report,'top_three',old,[]).ok,true);
  assert.match(report.recommendations[0].link,/google.com\/search/);
  assert.equal(report.recommendations[0].asking_price,'');
});

test('two saved listings with the same title are ambiguous', () => {
  const report = { recommendations: [{title:'Parker 2520 XL', asking_price:'$200'}] };
  const old = [{title:'Parker 2520 XL',url:'https://www.boats.com/boat/1'}, {title:'Parker 2520 XL',url:'https://www.boats.com/boat/2'}];
  assert.equal(groundReportReferences(report,'top_pick',old,[]).ok,true);
  assert.match(report.recommendations[0].link,/google.com\/search/);
  assert.equal(report.recommendations[0].asking_price,'');
});

test('seller introductions require unique exact buyer-submitted links', () => {
  const report = {introductions:[{title:'Parker 2520 XLD'}]};
  assert.equal(groundReportReferences(report,'introductions',[{title:'Parker 2520 XL',url:'https://www.boats.com/boat/1'}],[]).ok,false);
  const exact = {introductions:[{title:'Parker 2520 XL'}]};
  assert.equal(groundReportReferences(exact,'introductions',[{title:'Parker 2520 XL',url:'https://www.boats.com/boat/1',asking_price:95000}],[]).ok,true);
  assert.equal(exact.introductions[0].link,'https://www.boats.com/boat/1');
});

test('untrusted or non-HTTPS buyer URL falls back to model research instead of a listing', () => {
  const report = {recommendations:[{title:'Parker 2520 XL',asking_price:'$123,000'}]};
  const saved = [{title:'Parker 2520 XL',url:'http://www.boats.com/boat/example',asking_price:99000}];
  assert.equal(groundReportReferences(report,'top_pick',saved,[]).ok,true);
  assert.match(report.recommendations[0].link,/google.com\/search/);
  assert.equal(report.recommendations[0].asking_price,'');
});

test('seller introductions fail closed if two buyer boats cannot be uniquely linked', () => {
  const report = {introductions:[{title:'Parker 2520 XL'},{title:'Parker 2520 XL'}]};
  const saved = [
    {id:'a',title:'Parker 2520 XL',url:'https://www.boats.com/boat/one'},
    {id:'b',title:'Parker 2520 XL',url:'https://www.boats.com/boat/two'},
  ];
  assert.equal(groundReportReferences(report,'introductions',saved,[]).ok,false);
});
