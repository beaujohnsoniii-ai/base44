import test from "node:test";
import assert from "node:assert/strict";
import {
  containsUnqualifiedModelEquipmentClaim,
  withholdUnqualifiedModelEquipmentClaims,
} from "./model-options-guard.ts";

test("unverified standard equipment is withheld without losing independent model facts", () => {
  const original = "The pilothouse has twin berths. It comes standard with a windlass. The hull has a full-height windshield.";
  const guarded = withholdUnqualifiedModelEquipmentClaims(original);
  assert.equal(guarded.withheld, true);
  assert.match(guarded.text, /pilothouse has twin berths/i);
  assert.match(guarded.text, /full-height windshield/i);
  assert.doesNotMatch(guarded.text, /comes standard with a windlass/i);
  assert.match(guarded.text, /verify factory availability/i);
});

test("conditional model equipment remains a legitimate possibility to verify", () => {
  for (const qualified of [
    "Some examples include radar.",
    "A joystick may be equipped as a factory option.",
    "This model can be equipped with a bow thruster.",
    "If equipped, the boat has a Seakeeper.",
    "The model includes an optional shower.",
  ]) {
    const guarded = withholdUnqualifiedModelEquipmentClaims(qualified);
    assert.equal(guarded.withheld, false, qualified);
    assert.equal(guarded.text, qualified);
  }
});

test("equipment assertions in engines, specs and reasoning are detectable", () => {
  for (const claim of [
    "Twin outboards; includes joystick",
    "Length 32 ft; factory-installed windlass",
    "The model has radar.",
    "Includes a chartplotter.",
    "Comes with a Seakeeper.",
  ]) {
    assert.equal(containsUnqualifiedModelEquipmentClaim(claim), true, claim);
    assert.equal(withholdUnqualifiedModelEquipmentClaims(claim).withheld, true, claim);
  }
});

test("a qualification for different equipment cannot excuse an unverified installed claim", () => {
  for (const mixed of [
    "This model includes a windlass, but radar is optional.",
    "Comes standard with a joystick while Seakeeper is only an option.",
    "The model has radar and the windlass is optional.",
  ]) {
    assert.equal(containsUnqualifiedModelEquipmentClaim(mixed), true, mixed);
    const guarded = withholdUnqualifiedModelEquipmentClaims(mixed);
    assert.equal(guarded.withheld, true, mixed);
    assert.doesNotMatch(guarded.text, /includes a windlass|standard with a joystick|model has radar/i);
  }
  const qualified = "Some examples include radar, but others are not equipped.";
  assert.equal(containsUnqualifiedModelEquipmentClaim(qualified), false);
  assert.equal(withholdUnqualifiedModelEquipmentClaims(qualified).withheld, false);
});

test("equipment-first and ship-with assertions cannot evade model option checks", () => {
  for (const claim of [
    "A bow thruster is standard.",
    "The windlass is factory installed.",
    "Radar is included on every boat.",
    "All hulls ship with a Seakeeper.",
    "The model is radar-equipped.",
    "The chartplotter system is integrated.",
    "Every example is gyro stabilizer-equipped.",
  ]) {
    assert.equal(containsUnqualifiedModelEquipmentClaim(claim), true, claim);
    assert.equal(withholdUnqualifiedModelEquipmentClaims(claim).withheld, true, claim);
  }
});

test("legitimate option qualifications remain visible in reverse equipment claims", () => {
  for (const claim of [
    "Radar is included if equipped with the navigation package.",
    "The windlass is standard depending on the model year.",
    "Some examples are bow thruster-equipped.",
    "Seakeeper is installed as an option.",
    "The joystick package may be equipped as an option.",
  ]) {
    assert.equal(containsUnqualifiedModelEquipmentClaim(claim), false, claim);
    assert.equal(withholdUnqualifiedModelEquipmentClaims(claim).withheld, false, claim);
  }
});

test("inherent model identity and structurally standard characteristics are not treated as add-ons", () => {
  const reason = "The boat has a pilothouse and twin fixed berths. Features a deep cockpit for fishing.";
  const guarded = withholdUnqualifiedModelEquipmentClaims(reason);
  assert.equal(guarded.withheld, false);
  assert.equal(guarded.text, reason);
});
