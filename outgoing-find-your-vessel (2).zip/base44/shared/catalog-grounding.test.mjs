import test from "node:test";
import assert from "node:assert/strict";
import { findPublishedCatalogEvidence, applyCatalogEvidence } from "./catalog-grounding.ts";
import { screenPhysicalCandidate } from "./physical-specs.ts";

function record(overrides = {}) {
  return {
    id: "pub-1", verification_status: "published", manufacturer_name: "Sailfish",
    model_name: "232 CC", year_start: 2025, year_end: 2027,
    rigged_overall_length_ft: 23.5, beam_ft: 8.5, storage_weight_lb: 4400,
    fact_sources: {
      rigged_overall_length_ft: { status: "verified", applicability: "applicable", source_url: "https://example.org/boats", measurement_basis: "rigged_overall", source_model_year: 2026 },
      beam_ft: { status: "verified", source_url: "https://example.org/boats", measurement_basis: "beam", source_model_year: 2026 },
      storage_weight_lb: { status: "verified", source_url: "https://example.org/boats", measurement_basis: "dry", source_model_year: 2026 },
    },
    ...overrides,
  };
}

test("reviewed published model/year facts override unsupported LLM measurements", () => {
  const boat = { make: "Sailfish", model: "232CC", year: 2026, overall_length_ft: 21, beam_ft: 8 };
  const evidence = findPublishedCatalogEvidence(boat, [record()]);
  assert.equal(evidence?.id, "pub-1");
  assert.equal(evidence?.facts.rigged_overall_length_ft, 23.5);
  assert.equal(evidence?.facts.storage_weight_lb, undefined);
  const reviewed = applyCatalogEvidence(boat, evidence);
  assert.equal(reviewed.overall_length_ft, 23.5);
  assert.equal(reviewed.beam_ft, 8.5);
  const physical = screenPhysicalCandidate(reviewed, { hard_max_overall_length_ft: 23 });
  assert.equal(physical.excluded, true);
  assert.match(physical.reasons.join(" "), /23.5 exceeds hard maximum 23/);
});

test("reviewer-approved aliases allow exact model names without merging hull variants", () => {
  const parker = record({
    manufacturer_name: "Parker",
    model_name: "2520 XLD Sport Cabin",
    model_aliases: ["2520 XLD", "2520 XLD SC"],
    year_start: 2025,
    year_end: 2025,
    beam_ft: 9.5,
    fact_sources: {
      beam_ft: {
        status: "verified",
        source_url: "https://parkerboats.com/assets/documents/2025-Boat-Brochure-v2.pdf",
        measurement_basis: "beam",
        source_model_year: 2025,
      },
    },
  });
  const find = (model, records = [parker]) =>
    findPublishedCatalogEvidence({ make: "Parker", model, year: 2025 }, records);
  assert.equal(find("2520 XLD")?.facts.beam_ft, 9.5);
  assert.equal(find("2520 XLD SC")?.id, "pub-1");
  assert.equal(find("2520 XL"), null, "Older XL must never inherit 2025 XLD specifications");
  assert.equal(find("2520 XLD Sport"), null, "No fuzzy prefix or partial-name matching");
  assert.equal(find("2520 XLD", [{ ...parker, model_aliases: undefined }]), null);
  assert.equal(find("2520 XLD", [{ ...parker, verification_status: "verified" }]), null);
  assert.equal(find("2520 XLD", [
    parker, { ...parker, id: "ambiguous-2", model_name: "2520 XLD", model_aliases: [] },
  ]), null, "Overlapping published aliases remain unresolved, not silently selected");
});

test("a published source URL with no year applicability cannot certify physical limits", () => {
  const boat = { make: "Sailfish", model: "232 CC", year: 2026, beam_ft: 8.5 };
  const unscopedProof = {
    status: "verified", source_url: "https://manufacturer.example.org/specifications",
    measurement_basis: "beam", unit: "ft",
  };
  const evidence = findPublishedCatalogEvidence(boat, [record({
    fact_sources: { beam_ft: unscopedProof },
  })]);
  assert.equal(evidence?.id, "pub-1");
  assert.equal(evidence?.facts.beam_ft, undefined);
  const reviewed = applyCatalogEvidence(boat, evidence);
  const result = screenPhysicalCandidate(reviewed, { hard_max_beam_ft: 9 });
  assert.match(result.verification_required.join(" "), /beam/);

  const singleYear = findPublishedCatalogEvidence(boat, [record({
    fact_sources: { beam_ft: { ...unscopedProof, source_model_year: 2026 } },
  })]);
  assert.equal(singleYear?.facts.beam_ft, 8.5);

  const incompleteRange = findPublishedCatalogEvidence(boat, [record({
    fact_sources: { beam_ft: { ...unscopedProof, applicable_year_start: 2025 } },
  })]);
  assert.equal(incompleteRange?.facts.beam_ft, undefined);
});

test("draft and loaded weight remain unverified without field-level proof", () => {
  const boat = { make: "Sailfish", model: "232 CC", year: 2026, draft_ft: 2, loaded_storage_weight_lb: 5500 };
  const evidence = findPublishedCatalogEvidence(boat, [record({ draft_ft: 1 })]);
  const reviewed = applyCatalogEvidence(boat, evidence);
  assert.equal(reviewed.draft_ft, 2);
  assert.equal(reviewed.loaded_storage_weight_lb, 5500);
});

test("unpublished and off-year records are never treated as verified", () => {
  const boat = { make: "Sailfish", model: "232 CC", year: 2026 };
  assert.equal(findPublishedCatalogEvidence(boat, [record({ verification_status: "verified" })]), null);
  assert.equal(findPublishedCatalogEvidence(boat, [record({ verification_status: "staged" })]), null);
  assert.equal(findPublishedCatalogEvidence({ ...boat, year: 2024 }, [record()]), null);
  assert.equal(findPublishedCatalogEvidence({ ...boat, make: "Other" }, [record()]), null);
});

test("two matching published generations or unspecified year are ambiguous", () => {
  const boat = { make: "Sailfish", model: "232 CC", year: 2026 };
  assert.equal(findPublishedCatalogEvidence(boat, [record(), record({ id: "pub-2" })]), null);
  assert.equal(findPublishedCatalogEvidence({ ...boat, year: undefined }, [record()]), null);
  // Unknown generation start without applicable field-level proof cannot pass.
  assert.equal(findPublishedCatalogEvidence(boat, [record({
    year_start: null,
    fact_sources: {
      beam_ft: { status: "verified", source_url: "https://example.org/boats", measurement_basis: "beam" },
    },
  })]), null);
});

test("single manufacturer model-year proof works without inventing a generation inception year", () => {
  const source = record({
    year_start: null, year_end: null, production_status: "current",
    beam_ft: 8.5,
    fact_sources: {
      beam_ft: {
        status: "verified", source_url: "https://sailfishboats.com/model/232-center-console-family-fishing-boat",
        measurement_basis: "beam", source_model_year: 2027, unit: "ft",
      },
    },
  });
  const current = findPublishedCatalogEvidence({ make: "Sailfish", model: "232 CC", year: 2027 }, [source]);
  assert.equal(current?.facts.beam_ft, 8.5);
  assert.equal(findPublishedCatalogEvidence({ make: "Sailfish", model: "232 CC", year: 2026 }, [source]), null);
  assert.equal(findPublishedCatalogEvidence({ make: "Sailfish", model: "232 CC", year: 2028 }, [source]), null);
  // Publication state is a separate human-controlled launch gate.
  assert.equal(findPublishedCatalogEvidence({ make: "Sailfish", model: "232 CC", year: 2027 },
    [{ ...source, verification_status: "staged" }]), null);
  // Contradictory recorded generation boundaries remain disqualifying.
  assert.equal(findPublishedCatalogEvidence({ make: "Sailfish", model: "232 CC", year: 2027 },
    [{ ...source, year_start: 2028, year_end: 2027 }]), null);
});

test("open-ended generations do not assert ongoing production but exact archived year evidence still applies", () => {
  const now = new Date().getUTCFullYear();
  const boat = { make: "Sailfish", model: "232 CC", year: now };
  const open = { year_start: now - 4, year_end: null };
  // A dated, source-qualified 2026 spec can support a 2026 fact even if the
  // model is discontinued now. It is not evidence of continuing production.
  assert.equal(findPublishedCatalogEvidence(boat, [record({ ...open, production_status: "discontinued" })])?.facts.beam_ft, 8.5);
  // A page from an earlier year cannot prove newer years without reviewed
  // cross-year applicability. An unknown/discontinued open end is not a year
  // range; production_status=current is needed to identify the generation
  // while the individual measurement still must be proven for that year.
  const earlierOnly = record({
    ...open,
    fact_sources: {
      beam_ft: { status: "verified", source_url: "https://example.org/boats", measurement_basis: "beam", source_model_year: now - 1 },
    },
  });
  assert.equal(findPublishedCatalogEvidence(boat, [{ ...earlierOnly, production_status: "unknown" }]), null);
  assert.equal(findPublishedCatalogEvidence(boat, [{ ...earlierOnly, production_status: "discontinued" }]), null);
  assert.ok(findPublishedCatalogEvidence(boat, [{ ...earlierOnly, production_status: "current" }]));
  assert.ok(findPublishedCatalogEvidence({ ...boat, year: now + 1 }, [{ ...earlierOnly, production_status: "current" }]));
  assert.equal(findPublishedCatalogEvidence({ ...boat, year: now + 2 }, [{ ...earlierOnly, production_status: "current" }]), null);
});

test("source-verified catalog measurements clear only the corresponding physical verification flags", () => {
  const proof = (measurement_basis) => ({ status: "verified", applicability: "applicable", source_url: "https://example.org/official", measurement_basis, source_model_year: 2026 });
  const source = record({
    draft_ft: 1.5, passenger_capacity: 8, storage_height_ft: 9.2,
    storage_weight_lb: 4800, trailered_weight_lb: 5500,
    fact_sources: {
      rigged_overall_length_ft: proof("rigged_overall"), beam_ft: proof("beam"),
      draft_ft: proof("draft"), passenger_capacity: proof("US persons rating"),
      storage_height_ft: proof("on_trailer"), storage_weight_lb: proof("loaded_storage"),
      trailered_weight_lb: proof("trailered_total"),
    },
  });
  const boat = { make: "Sailfish", model: "232 CC", year: 2026, loaded_storage_weight_lb: 2000 };
  const evidence = findPublishedCatalogEvidence(boat, [source]);
  const reviewed = applyCatalogEvidence(boat, evidence);
  assert.equal(reviewed.loaded_storage_weight_lb, 4800);
  const result = screenPhysicalCandidate(reviewed, {
    hard_max_overall_length_ft: 24, hard_max_beam_ft: 9,
    hard_max_draft_ft: 2, hard_max_height_ft: 10, hard_max_storage_weight_lb: 5000,
    storage: "trailer", tow_capacity_lb: 6000, passenger_count: 4, occasional_passenger_count: 8,
  });
  assert.equal(result.excluded, false);
  assert.deepEqual(result.verification_required, []);
});

test("untrusted catalog identity and proof markers cannot survive MATCH catalog review", () => {
  const claimed = {
    overall_length_ft: 23, beam_ft: 8.5,
    __catalog_model_id: "fabricated-catalog-id",
    __catalog_verified_fields: ["rigged_overall_length_ft", "beam_ft"],
  };
  const unmatched = applyCatalogEvidence(claimed, null);
  assert.equal(Object.hasOwn(unmatched, "__catalog_model_id"), false);
  assert.deepEqual(unmatched.__catalog_verified_fields, []);
  const physical = screenPhysicalCandidate(unmatched, { hard_max_overall_length_ft: 24, hard_max_beam_ft: 9 });
  assert.match(physical.verification_required.join(" "), /rigged overall length/);
  assert.match(physical.verification_required.join(" "), /beam/);
  const matched = applyCatalogEvidence(claimed, { id: "published-record", facts: { beam_ft: 8.7 } });
  assert.equal(matched.__catalog_model_id, "published-record");
  assert.deepEqual(matched.__catalog_verified_fields, ["beam_ft"]);
  assert.equal(matched.beam_ft, 8.7);
  assert.equal(claimed.__catalog_model_id, "fabricated-catalog-id");
});

test("a published spec is not source-verified by private, insecure or credential-bearing URLs", () => {
  const boat = { make: "Sailfish", model: "232 CC", year: 2026 };
  const badUrls = [
    "http://example.org/specifications",
    "https://localhost/specifications",
    "https://marine.internal/specifications",
    "https://manufacturer.example/specifications",
    "https://manufacturer.test/specifications",
    "https://manufacturer.invalid/specifications",
    "https://manufacturer.local/specifications",
    "https://example.org./specifications",
    "https://example.org/" + "a".repeat(4100),
    "https://127.0.0.1/specifications",
    "https://[::1]/specifications",
    "https://example.org@other.example/specifications",
    "https://example.org:8443/specifications",
    "https://example..org/specifications",
    "https://example.org/specifications?key=dummy",
    "https://example.org/specifications?" + ["access", "token"].join("_") + "=dummy",
    "https://example.org/specifications?" + ["X-Amz", "Signature"].join("-") + "=dummy",
    "https://example.org/specifications#token=dummy",
  ];
  for (const source_url of badUrls) {
    const proof = { status: "verified", source_url, measurement_basis: "beam", source_model_year: 2026 };
    const evidence = findPublishedCatalogEvidence(boat, [record({ fact_sources: { beam_ft: proof } })]);
    assert.equal(evidence?.facts.beam_ft, undefined, `Unsafe URL must not establish beam: ${source_url}`);
  }
  const secure = findPublishedCatalogEvidence(boat, [record({
    fact_sources: { beam_ft: { status: "verified", source_url: "https://manufacturer.example.org/specifications", measurement_basis: "beam", source_model_year: 2026 } },
  })]);
  assert.equal(secure?.facts.beam_ft, 8.5);
  const withPublicQuery = findPublishedCatalogEvidence(boat, [record({
    fact_sources: { beam_ft: { status: "verified", source_url: "https://manufacturer.example.org/specifications?view=technical", measurement_basis: "beam", source_model_year: 2026 } },
  })]);
  assert.equal(withPublicQuery?.facts.beam_ft, 8.5);
});

test("seats, berths, and fractional counts never certify a published passenger limit", () => {
  const boat = { make: "Sailfish", model: "232 CC", year: 2026 };
  const verified = (basis, unit = "persons") => ({
    status: "verified", applicability: "applicable",
    source_url: "https://manufacturer.example.org/specifications",
    measurement_basis: basis, unit, source_model_year: 2026,
  });
  for (const basis of ["seating_capacity", "number_of_berths", "head_count", ""]) {
    const evidence = findPublishedCatalogEvidence(boat, [record({
      passenger_capacity: 12,
      fact_sources: { passenger_capacity: verified(basis) },
    })]);
    assert.equal(evidence?.facts.passenger_capacity, undefined, `Not a rated person limit: ${basis}`);
  }
  const validEvidence = findPublishedCatalogEvidence(boat, [record({
    passenger_capacity: 12,
    fact_sources: { passenger_capacity: verified("US persons rating") },
  })]);
  assert.equal(validEvidence?.facts.passenger_capacity, 12);

  for (const passenger_capacity of [4.5, NaN, -1]) {
    const evidence = findPublishedCatalogEvidence(boat, [record({
      passenger_capacity, fact_sources: { passenger_capacity: verified("US persons rating") },
    })]);
    assert.equal(evidence?.facts.passenger_capacity, undefined);
  }
});

test("catalog field units cannot silently mix metric lengths or weights into US units", () => {
  const boat = { make: "Sailfish", model: "232 CC", year: 2026 };
  const verified = (basis, unit) => ({
    status: "verified", applicability: "applicable",
    source_url: "https://manufacturer.example.org/specifications", measurement_basis: basis, unit, source_model_year: 2026,
  });
  const evidence = findPublishedCatalogEvidence(boat, [record({
    beam_ft: 2.6, draft_ft: 0.5, storage_weight_lb: 2200,
    fact_sources: {
      beam_ft: verified("beam", "m"),
      draft_ft: verified("draft", "cm"),
      storage_weight_lb: verified("loaded_storage", "kg"),
    },
  })]);
  assert.equal(evidence?.facts.beam_ft, undefined);
  assert.equal(evidence?.facts.draft_ft, undefined);
  assert.equal(evidence?.facts.storage_weight_lb, undefined);

  const compatible = findPublishedCatalogEvidence(boat, [record({
    draft_ft: 1.5, storage_weight_lb: 4800,
    fact_sources: {
      beam_ft: verified("beam", "ft"),
      draft_ft: verified("operating draft", "feet"),
      storage_weight_lb: verified("loaded_storage", "lbs"),
    },
  })]);
  assert.equal(compatible?.facts.beam_ft, 8.5);
  assert.equal(compatible?.facts.draft_ft, 1.5);
  assert.equal(compatible?.facts.storage_weight_lb, 4800);
});


test("model-year proof cannot certify an earlier generation year", () => {
  const boat = { make: "Sailfish", model: "232 CC", year: 2026 };
  const base = record({
    fact_sources: {
      rigged_overall_length_ft: {
        status: "verified", source_url: "https://example.org/model",
        measurement_basis: "rigged_overall", source_model_year: 2027,
      },
    },
  });
  const earlier = findPublishedCatalogEvidence(boat, [base]);
  assert.equal(earlier?.facts.rigged_overall_length_ft, undefined);
  assert.equal(findPublishedCatalogEvidence({ ...boat, year: 2027 }, [base])?.facts.rigged_overall_length_ft, 23.5);
  const ranged = record({
    fact_sources: {
      rigged_overall_length_ft: {
        status: "verified", source_url: "https://example.org/model",
        measurement_basis: "rigged_overall", source_model_year: 2027,
        applicable_year_start: 2025, applicable_year_end: 2027,
      },
    },
  });
  assert.equal(findPublishedCatalogEvidence(boat, [ranged])?.facts.rigged_overall_length_ft, 23.5);
  for (const invalid of [
    { source_model_year: 2027, applicable_year_start: 2025 },
    { source_model_year: 2027, applicable_year_end: 2027 },
    { source_model_year: 2027, applicable_year_start: 2027, applicable_year_end: 2027 },
    { source_model_year: 2024, applicable_year_start: 2025, applicable_year_end: 2027 },
    { source_model_year: "unknown" },
  ]) {
    const proof = { status: "verified", source_url: "https://example.org/model", measurement_basis: "rigged_overall", ...invalid };
    const unqualified = record({ fact_sources: { rigged_overall_length_ft: proof } });
    assert.equal(findPublishedCatalogEvidence(boat, [unqualified])?.facts.rigged_overall_length_ft, undefined, JSON.stringify(invalid));
  }
});

test("hull-only draft and hull beam cannot clear operating/access constraints", () => {
  const boat = { make: "Sailfish", model: "232 CC", year: 2026 };
  const verified = basis => ({
    status: "verified", source_url: "https://manufacturer.example.org/specifications",
    measurement_basis: basis, unit: "ft", source_model_year: 2026,
  });
  const evidence = findPublishedCatalogEvidence(boat, [record({
    draft_ft: 1.5,
    fact_sources: {
      beam_ft: verified("hull_beam"),
      draft_ft: verified("draft engines up"),
    },
  })]);
  assert.equal(evidence?.facts.beam_ft, undefined);
  assert.equal(evidence?.facts.draft_ft, undefined);
  const reviewed = applyCatalogEvidence({ ...boat, beam_ft: 8.5, draft_ft: 1.5 }, evidence);
  const check = screenPhysicalCandidate(reviewed, {
    hard_max_beam_ft: 9, hard_max_draft_ft: 2,
  });
  assert.equal(check.excluded, false);
  assert.match(check.verification_required.join(" "), /beam/);
  assert.match(check.verification_required.join(" "), /draft/);
});
