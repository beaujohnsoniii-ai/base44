// Guardrails for an explicitly admin-triggered, low-volume model research pilot.
// No endpoint calls or database writes occur in this pure module.
export const PILOT_MANUFACTURERS = ["Sailfish", "Blackfin", "Parker", "Grady-White", "Boston Whaler"] as const;
export const PILOT_DAILY_LIMIT = 2;

export function validatePilotRequest(body: any): { manufacturer: string | null; error: string | null } {
  if (!body || body.confirm_paid_api_usage !== true) {
    return { manufacturer: null, error: "Explicit confirmation of paid provider usage is required." };
  }
  const name = String(body.manufacturer ?? "").trim();
  const manufacturer = PILOT_MANUFACTURERS.find(m => m.toLowerCase() === name.toLowerCase());
  if (!manufacturer) return { manufacturer: null, error: "Choose an approved pilot manufacturer." };
  return { manufacturer, error: null };
}

export function pilotJobsToday(jobs: any[], isoDay: string): number {
  return (Array.isArray(jobs) ? jobs : []).filter(job =>
    job?.job_type === "model_pilot" &&
    String(job?.started_at || job?.created_date || "").startsWith(isoDay)
  ).length;
}

export function parsePilotModelOutput(input: unknown): unknown {
  const raw = String(input ?? "").trim();
  const normalized = raw.replace(/^\x60\x60\x60(?:json)?\s*/i, "").replace(/\s*\x60\x60\x60$/, "").trim();
  const parsed = JSON.parse(normalized);
  if (!parsed || typeof parsed !== "object" || !Array.isArray((parsed as any).models)) {
    throw new Error("Research extraction did not provide a models array.");
  }
  return parsed;
}
