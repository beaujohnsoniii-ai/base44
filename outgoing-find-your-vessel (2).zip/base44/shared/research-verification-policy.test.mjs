import test from "node:test";
import assert from "node:assert/strict";
import { verificationRoute } from "./research-verification-policy.mjs";
test("missing trusted optional field may enter Claude two-pass review", () => {
 assert.deepEqual(verificationRoute({field:"Fuel Capacity (gal)",comparison:"missing",sourceTrusted:true,generationCertain:true}).mayAutoApply,true);
});
test("critical specs and conflicts cannot auto-publish from Claude alone", () => {
 for (const args of [
  {field:"Beam",comparison:"missing",sourceTrusted:true,generationCertain:true},
  {field:"Fuel Capacity (gal)",comparison:"different",sourceTrusted:true,generationCertain:true},
  {field:"Fuel Capacity (gal)",comparison:"same",sourceTrusted:false,generationCertain:true},
  {field:"Fuel Capacity (gal)",comparison:"same",sourceTrusted:true,generationCertain:false},
 ]) assert.equal(verificationRoute(args).mayAutoApply,false);
});
