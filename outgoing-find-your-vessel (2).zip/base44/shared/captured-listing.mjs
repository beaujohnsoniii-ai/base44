import { nullableListingFacts } from "./listing-document.mjs";
import { assessListing } from "./listing-comparison.mjs";

export const CAPTURE_LIMITS = Object.freeze({ per_listing_chars: 16000, total_chars: 64000, listings: 9 });

const clean = value => String(value ?? "").replace(/\u0000/g, "").replace(/\r\n?/g, "\n").trim();
const norm = value => clean(value).toLowerCase().replace(/[^a-z0-9]+/g, "");
const cap = (value, max) => clean(value).slice(0, max);
const snippet = (text, match, radius = 180) => {
  const index = typeof match === "number" ? match : text.toLowerCase().indexOf(String(match || "").toLowerCase());
  if (index < 0) return cap(text, radius * 2);
  return text.slice(Math.max(0, index - radius), Math.min(text.length, index + radius)).replace(/\s+/g, " ").trim();
};

export function normalizeCapturedListings(rows, allowedUrls, normalizeUrl) {
  if (rows == null) return new Map();
  if (!Array.isArray(rows) || rows.length > CAPTURE_LIMITS.listings) throw Error("Invalid listing capture payload.");
  const allowed = new Set(allowedUrls);
  const captures = new Map();
  let total = 0;
  for (const row of rows) {
    const text = clean(row?.text);
    if (!text) continue;
    if (text.length > CAPTURE_LIMITS.per_listing_chars) throw Error("Copied listing text is too long.");
    total += text.length;
    if (total > CAPTURE_LIMITS.total_chars) throw Error("Copied listing text exceeds the Compare limit.");
    const url = normalizeUrl(row?.url);
    if (!url || !allowed.has(url) || captures.has(url)) throw Error("Copied listing text did not match one saved listing URL.");
    captures.set(url, text);
  }
  return captures;
}

export function extractCapturedListingText(value, input) {
  const text = clean(value).slice(0, CAPTURE_LIMITS.per_listing_chars);
  const make = clean(input?.expected_make);
  const model = clean(input?.expected_model);
  const makeAt = norm(text).indexOf(norm(make));
  const modelAt = norm(text).indexOf(norm(model));
  const listingSignal = /\b(?:stock|serial|price|for sale|condition|availability|dealer|location|request pricing|call for price)\b/i.test(text);
  if (text.length < 80 || !make || !model || makeAt < 0 || modelAt < 0 || !listingSignal) return { page_kind: "unknown", facts: [] };

  const facts = [
    { field: "make", value: make, quote: snippet(text, make), unit: "", basis: "listing_identity" },
    { field: "model", value: model, quote: snippet(text, model), unit: "", basis: "listing_identity" },
  ];
  const addNumber = (field, match, unit = "", basis = "unspecified") => {
    if (!match) return;
    const number = Number(String(match[1]).replace(/,/g, ""));
    if (Number.isFinite(number) && number >= 0) facts.push({ field, value: number, quote: snippet(text, match.index), unit, basis });
  };
  const years = [...text.matchAll(/\b((?:19|20)\d{2})\b/g)];
  const uniqueYears = [...new Set(years.map(match => match[1]))];
  if (uniqueYears.length === 1) facts.push({ field: "year", value: Number(uniqueYears[0]), quote: snippet(text, years[0].index), unit: "", basis: "listing_identity" });
  const price = text.match(/\$\s*([\d,]+(?:\.\d{1,2})?)/i);
  const priceQuote = price ? snippet(text, price.index) : "";
  const explicitUsd = /\bUSD\b/i.test(priceQuote);
  addNumber("asking_price", price, explicitUsd ? "USD" : "$");
  if (price && explicitUsd) facts.push({ field: "asking_price_currency", value: "USD", quote: priceQuote, unit: "", basis: "unspecified" });
  addNumber("engine_hours", text.match(/\bengine(?:\(s\))?\s*hours?\s*[:\-]?\s*(\d+(?:\.\d+)?)\b/i), "h");
  addNumber("overall_length_ft", text.match(/\b(?:length overall|overall length|length)\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*(?:ft|feet|')\b/i), "ft", "displayed_length");
  addNumber("beam_ft", text.match(/\bbeam\s*[:\-]?\s*(\d+(?:\.\d+)?)[.\s]*(?:ft|feet|')\b/i), "ft", "beam");
  addNumber("draft_ft", text.match(/\b(?:engine.down draft|draft\s*\(engine down\))\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*(?:ft|feet|')\b/i), "ft", "engine_down");
  addNumber("passenger_capacity", text.match(/\b(?:capacity|maximum|seating(?:\s+for)?|room\s+for|up\s+to)\s*[:\-]?\s*(\d+)\s*(?:persons?|passengers?|people)?\b/i), "persons");
  return { page_kind: "listing", facts };
}

export function resolveCapturedListing(profile, input, url, capturedText) {
  const text = clean(capturedText);
  const extraction = extractCapturedListingText(text, input);
  if (extraction.page_kind !== "listing") {
    return {
      ...input,
      status: "capture_insufficient_evidence",
      reason: "Copied text did not establish this exact listing's make, model, and listing context.",
      facts: {},
      nullable_facts: nullableListingFacts({}),
      checks: [],
      concerns: [],
      unknowns: ["No network request was made. Copy the visible listing details for this exact URL, including make, model and listing context such as price, stock, dealer or location."],
      eligible: false,
      source_evidence: { provider: "buyer", provenance: "user_supplied_capture", source_url: url, excerpt: cap(text, 1600) },
      resolution: { original_url: url, source_url: url, checked_at: new Date().toISOString(), status: "capture_insufficient_evidence", transport: "user_capture", provider: "buyer" },
    };
  }
  const assessment = assessListing(profile, input, text, extraction);
  assessment.nullable_facts = nullableListingFacts(assessment.facts);
  for (const fact of Object.values(assessment.facts || {})) fact.provenance = "user_supplied_capture";
  const checkedAt = new Date().toISOString();
  assessment.source_evidence = { provider: "buyer", provenance: "user_supplied_capture", source_url: url, excerpt: cap(text, 1600), retrieved_at: checkedAt };
  assessment.resolution = { original_url: url, source_url: url, checked_at: checkedAt, retrieved_at: checkedAt, status: assessment.status, transport: "user_capture", provider: "buyer" };
  return assessment;
}
