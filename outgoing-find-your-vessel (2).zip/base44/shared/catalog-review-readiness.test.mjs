import test from "node:test";
import assert from "node:assert/strict";
import { previewCatalogProofReadiness, findPublishedCatalogEvidence } from "./catalog-grounding.ts";

test("admin proof preview exposes non-machine-readable 2025 brochure metadata without publishing it", () => {
  const record = {
    id: "parker-preview",
    verification_status: "verified",
    manufacturer_name: "Parker",
    model_name: "2520 XLD Sport Cabin",
    year_start: 2025,
    year_end: 2025,
    beam_ft: 9.5,
    passenger_capacity: 12,
    dry_weight_lb: 5800,
    loa_ft: 33.0833333333,
    fact_sources: {
      beam_ft: { url: "https://www.parkerboats.com/assets/documents/2025-Boat-Brochure-v2.pdf", document_model_year: 2025 },
      passenger_capacity: { url: "https://www.parkerboats.com/assets/documents/2025-Boat-Brochure-v2.pdf", document_model_year: 2025 },
    },
  };
  const preview = previewCatalogProofReadiness(record);
  assert.equal(preview.year, 2025);
  assert.deepEqual(preview.presentFields, ["beam_ft", "passenger_capacity"]);
  assert.deepEqual(preview.usableFields, []);
  assert.deepEqual(preview.blockedFields, ["beam_ft", "passenger_capacity"]);
  assert.equal(findPublishedCatalogEvidence({ make: "Parker", model: "2520 XLD Sport Cabin", year: 2025 }, [record]), null);
});

test("preview validates the exact model year and per-field source proof", () => {
  const record = {
    id: "preview",
    verification_status: "verified",
    year_start: 2025,
    year_end: 2026,
    beam_ft: 9.5,
    passenger_capacity: 12,
    fact_sources: {
      beam_ft: {
        status: "verified", source_url: "https://manufacturer.example.org/official",
        measurement_basis: "beam", unit: "ft", source_model_year: 2025,
      },
      passenger_capacity: {
        status: "verified", source_url: "https://manufacturer.example.org/official",
        measurement_basis: "seating_capacity", source_model_year: 2025,
      },
    },
  };
  assert.deepEqual(previewCatalogProofReadiness(record, 2025).usableFields, ["beam_ft"]);
  assert.deepEqual(previewCatalogProofReadiness(record, 2025).blockedFields, ["passenger_capacity"]);
  assert.deepEqual(previewCatalogProofReadiness(record, 2026).usableFields, []);
  assert.deepEqual(previewCatalogProofReadiness(record, 2024).usableFields, []);
  assert.equal(previewCatalogProofReadiness({ ...record, year_start: null, year_end: null, fact_sources: {} }).year, null);
});
