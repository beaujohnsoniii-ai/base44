import test from "node:test";
import assert from "node:assert/strict";
import { evaluateProfile } from "./qa-evaluator.ts";

async function capture(profile, suggestions) {
  let captured = "";
  const client = {asServiceRole:{integrations:{Core:{InvokeLLM:async ({prompt})=>{
    captured = prompt;
    return {scorecard:{overall_concern_level:"green",overall_summary:"Mock evaluation"}};
  }}}}};
  const result = await evaluateProfile(client,profile,[{
    tier:"market_match",suggestions,likedModels:[],programmaticChecks:{count_compliant:true},programmaticConcernLevel:"green"
  }]);
  assert.equal(result.concern_level,"green");
  return captured;
}

test("QA evaluator uses model/generation price ranges, never legacy listing asking prices",async()=>{
  const prompt = await capture({purchase_budget_max:150000},[
    {title:"Sample 27",asking_price:98000,price_range_min:75000,price_range_max:130000,
     price_range_context:"2019-2023 used US market",suitability_score:84,match:{matches:[],gaps:[]},verification_required:[]},
    {title:"Sample 28",asking_price:55555,match:{matches:[],gaps:[]},verification_required:[]}
  ]);
  assert.match(prompt,/estimated model range \$75,000–\$130,000 \(2019-2023 used US market\)/);
  assert.match(prompt,/Sample 28 — model price unverified/);
  assert.doesNotMatch(prompt,/est\. \$98,000/);
  assert.doesNotMatch(prompt,/est\. \$55,555/);
});
test("QA evaluator sees real physical constraints and respects tier boundaries",async()=>{
  const prompt=await capture({
    passenger_count:3,occasional_passenger_count:7,
    hard_max_overall_length_ft:30,hard_max_beam_ft:9.5,hard_max_height_ft:12,
    hard_max_storage_weight_lb:11000,hard_max_draft_ft:1.75,
    tow_capacity_lb:9000
  },[]);
  for(const exact of ['"occasional_passenger_count":7','"hard_max_overall_length_ft":30','"hard_max_beam_ft":9.5','"hard_max_height_ft":12','"hard_max_storage_weight_lb":11000','"hard_max_draft_ft":1.75','"tow_capacity_lb":9000']) {
    assert.ok(prompt.includes(exact),exact);
  }
  assert.match(prompt,/TIER FAIRNESS:/);
  assert.match(prompt,/Do not penalize a lower tier/);
  assert.match(prompt,/MODEL-LEVEL PRICE AND EQUIPMENT:/);
});
