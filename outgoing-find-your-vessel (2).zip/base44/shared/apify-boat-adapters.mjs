import {normalizePublicListingUrl} from "./remote-listing.ts";
import {LISTING_FIELDS,nullableListingFacts} from "./listing-document.mjs";
import {assessListing} from "./listing-comparison.mjs";

// Pure contracts/normalizers only: no fetch, SDK, secrets, Actor execution or writes.
export const APIFY_BOAT_ACTORS=Object.freeze({
 boattrader:Object.freeze({id:"copious_atoll/boat-trader-scraper",exact_link:false,engine_hours:false}),
 yachtworld:Object.freeze({id:"getascraper/yachtworld-scraper",exact_link:true,engine_hours:"optional"})
});
export const APIFY_LISTING_RUNTIME=Object.freeze({enabled:false,reason:"No authorized account, budget, source-access and server transport have been established."});
function detailUrl(raw,market){
 const value=normalizePublicListingUrl(raw);if(!value)return null;
 const u=new URL(value);if(u.search||u.hash)return null;
 const host=market==="yachtworld"?"yachtworld.com":"boattrader.com";
 if(![host,"www."+host].includes(u.hostname))return null;
 const match=u.pathname.match(market==="yachtworld"?/^\/yacht\/(\d{4})-[a-z0-9-]+-(\d+)\/?$/i:/^\/boat\/(\d{4})-[a-z0-9-]+-(\d+)\/?$/i)
  ||(market==="boattrader"?u.pathname.match(/^\/boats\/(\d{4})\/[a-z0-9-]+\/[a-z0-9-]+\/(\d+)\/?$/i):null);
 return match?{url:value,id:match[2],year:Number(match[1])}:null;
}
export function planApifyListingRequest(market,options={}){
 const actor=APIFY_BOAT_ACTORS[market];if(!actor)throw Error("Unsupported boat Actor.");
 if(!options||typeof options!=="object"||Array.isArray(options))throw Error("Invalid request options.");
 if(market==="yachtworld"){
  if(Object.keys(options).some(k=>k!=="url"))throw Error("Only one exact YachtWorld URL is supported.");
  const listing=detailUrl(options.url,market);if(!listing)throw Error("Use one public YachtWorld boat-detail URL.");
  return {actor_id:actor.id,mode:"exact_listing_candidate",executable:false,
   input:{startUrls:[{url:listing.url}],fetchDetails:true,maxItems:1,onlyNewOrChanged:false,proxyConfiguration:{useApifyProxy:false}},
   caveats:["startUrls are documented as extra pages; returned rows still require exact URL/ID validation.","maxItems is an output limit, not a spending guarantee."]};
 }
 if(Object.hasOwn(options,"url")||Object.hasOwn(options,"listingUrl")||Object.hasOwn(options,"startUrls"))
  return {actor_id:actor.id,mode:"unsupported_exact_link",executable:false,input:null,reason:"This Actor documents discovery filters, not an exact-listing URL input."};
 if(Object.keys(options).some(k=>!["boatType","minPrice","maxPrice"].includes(k)))throw Error("Unsupported discovery option.");
 const boatType=options.boatType??"all";if(!["all","power","sail","pontoon","fishing","pwc"].includes(boatType))throw Error("Invalid boat type.");
 const input={boatType,maxPages:1};
 for(const k of ["minPrice","maxPrice"])if(options[k]!==undefined){if(!Number.isSafeInteger(options[k])||options[k]<0)throw Error("Prices must be nonnegative USD integers.");input[k]=options[k];}
 if(input.minPrice!==undefined&&input.maxPrice!==undefined&&input.minPrice>input.maxPrice)throw Error("Invalid price range.");
 return {actor_id:actor.id,mode:"discovery_only",executable:false,input,caveats:["One search page may return many paid results; no one-listing or engine-hours guarantee.","Discovery results do not establish a saved individual boat."]};
}
const string=v=>typeof v==="string"&&v.trim()&&v.length<=200?v.trim():null;
const numeric=v=>typeof v==="number"&&Number.isFinite(v)?v:null;
function amount(v,units){
 if(typeof v==="number")return Number.isFinite(v)&&v>=0?v:null;
 if(typeof v!=="string")return null;
 const m=v.trim().match(new RegExp("^(\\d+(?:\\.\\d+)?)\\s*(?:"+units+")?$","i"));
 return m?Number(m[1]):null;
}
export function normalizeApifyBoatRow(market,row,{requested_url=null,observed_at=null}={}){
 const actor=APIFY_BOAT_ACTORS[market];if(!actor)throw Error("Unsupported boat Actor.");
 if(!row||typeof row!=="object"||Array.isArray(row)||JSON.stringify(row).length>65536)throw Error("Invalid or oversized Actor row.");
 const yw=market==="yachtworld",identity=detailUrl(yw?row.listingUrl:row.listing_url,market),requested=detailUrl(requested_url,market);
 const id=String((yw?row.listingId:row.listing_id)??"");
 const validIdentity=identity&&/^\d+$/.test(id)&&identity.id===id;
 const facts=Object.fromEntries(LISTING_FIELDS.map(f=>[f,null])),evidence=[],warnings=[];
 const add=(field,value,path,unit="",basis="unspecified")=>{
  if(value===null||value===undefined)return;
  facts[field]={value,unit,basis,provenance:"unverified_actor_listing_claim"};
  evidence.push({field,value,unit,actor_id:actor.id,json_path:"$."+path,source_url:identity?.url??null,
   raw_value:row[path],currency_basis:field==="asking_price"&&!yw?"Actor documentation specifies USD":null});
 };
 if(validIdentity){
  // YachtWorld's published output has no distinct make field. Do not infer it from a saved model or title.
  if(!yw)add("make",string(row.make),"make");
  add("model",string(row.model),"model");
  const year=/^(19|20)\d{2}$/.test(String(row.year))?Number(row.year):null;
  if(year&&year===identity.year)add("year",year,"year");else warnings.push("Listing year is missing or conflicts with its URL.");
  const price=numeric(row.price),currency=yw?(/^[A-Z]{3}$/.test(row.priceCurrency)?row.priceCurrency:null):"USD";
  if(price!==null&&price>0&&currency){add("asking_price",price,"price",currency);if(yw)add("asking_price_currency",currency,"priceCurrency");else{facts.asking_price_currency={value:currency,unit:"",basis:"actor_documented_currency",provenance:"unverified_actor_listing_claim"};evidence.push({field:"asking_price_currency",value:currency,actor_id:actor.id,json_path:null,source_url:identity.url,raw_value:null,currency_basis:"Actor documentation specifies USD"});}}
  const length=typeof (yw?row.lengthFt:row.length)==="string"&&/^\s*\d+(?:\.\d+)?\s*(ft|feet|foot|')\s*$/i.test(yw?row.lengthFt:row.length)?amount((yw?row.lengthFt:row.length).replace(/'\s*$/,"ft"),"ft|feet|foot"):null;
  if(length>0)add("overall_length_ft",length,yw?"lengthFt":"length","ft","unspecified");
  if(yw)add("engine_hours",amount(row.engineHours,"h|hr|hrs|hours"),"engineHours","h");
 }else warnings.push("Actor row URL and listing ID do not establish one marketplace listing; all facts withheld.");
 const exact=Boolean(yw&&validIdentity&&requested&&requested.url===identity.url&&facts.year);
 if(yw&&!facts.make)warnings.push("Actor output does not establish make; no title or saved-model inference applied.");
 if(!yw)warnings.push("Discovery only; exact-link mode and engine hours are unsupported by this Actor.");
 if(requested_url&&!exact)warnings.push("This row is not accepted as evidence for the requested saved listing.");
 const stamp=typeof (yw?row.scrapedAt:null)==="string"&&Number.isFinite(Date.parse(row.scrapedAt))?row.scrapedAt:null;
 return {schema_version:"apify-boat-claim-v1",actor_id:actor.id,marketplace:market,status:!validIdentity?"identity_unconfirmed":exact?"exact_url_actor_claim":"discovery_only",
  exact_listing:exact,source_url:identity?.url??null,listing_id:validIdentity?id:null,requested_url:requested?.url??null,
  facts,nullable_facts:nullableListingFacts(facts),field_evidence:evidence,warnings,
  source_metadata:{title:string(row.title),seller:string(yw?(row.brokerName||row.sellerName):row.dealer_name),
   location:string(yw?row.location:[row.city,row.state].filter(v=>typeof v==="string").join(", ")),engine_description:yw?string(row.engine):null},
  provenance:{provider:"Apify community Actor",actor_id:actor.id,provider_scraped_at:stamp,
   observed_at:typeof observed_at==="string"&&Number.isFinite(Date.parse(observed_at))?observed_at:null,
   live_retrieval_verified:false,source_permission_verified:false},
  eligible:false};
}
// Offline bridge into the existing Compare evaluator. Quotes are normalized Actor
// claims, never represented as direct page quotations or manufacturer facts.
export function assessApifyBoatRow(profile,input,market,row,context={}){
 const record=normalizeApifyBoatRow(market,row,{...context,requested_url:input.url});
 if(!record.exact_listing)return {...input,status:record.status,facts:{},nullable_facts:nullableListingFacts({}),checks:[],concerns:[],unknowns:record.warnings,eligible:false,actor_record:record};
 const claims=Object.entries(record.facts).filter(([,v])=>v).map(([field,fact])=>{
  const label=field==="engine_hours"?"engineHours":field;
  const quote=JSON.stringify({[label]:fact.value,unit:fact.unit});
  return {field,...fact,quote};
 });
 const result=assessListing(profile,input,claims.map(f=>f.quote).join("\n"),{page_kind:"listing",facts:claims});
 for(const fact of Object.values(result.facts))fact.provenance="unverified_actor_listing_claim";
 return {...result,nullable_facts:nullableListingFacts(result.facts),field_evidence:record.field_evidence,
  actor_record:record,unknowns:[...result.unknowns,...record.warnings],
  qualification:"Community Actor claims only; no live retrieval, source-access, identity completeness, availability or physical-fit verification.",eligible:false};
}
