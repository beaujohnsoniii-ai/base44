import test from 'node:test';
import assert from 'node:assert/strict';
import { isolateModelEvidence, validateModelClaims } from './model-evidence-gate.mjs';
test('2520 heading cannot authenticate neighboring 2820 specification row',()=>{
 const raw='2520 XLD SC\n25 ft cabin\n2820 XLD SC\nLength LOA Passenger Beam Hull Draft Dry Weight\n28’ 35’9” 12 9’6” 18” 6400 lbs';
 const isolation=isolateModelEvidence(raw,{model:'2520 XLD',otherModels:['2820 XLD']});
 assert.equal(isolation.ok,false);
 const result=validateModelClaims({model:'2520 XLD',year:2025,isolatedSource:isolation,claims:[{field:'LOA',value:'35\'9"',source_model_year:2025,exact_quote:'28’ 35’9”'}]});
 assert.equal(result.approved.length,0);assert.equal(result.rejected.length,1);
});
test('unisolated or wrong-year sources cannot approve numeric fields',()=>{
 for (const source of [null,{ok:true,model:'2820 XLD',year:2025,page:35,row_id:'a'},{ok:true,model:'2520 XLD',year:2024,page:35,row_id:'a'}]) {
  assert.equal(validateModelClaims({model:'2520 XLD',year:2025,isolatedSource:source,claims:[{field:'beam',value:9.5}]}).approved.length,0);
 }
});
test('isolated fields require matching page, row, year and measurement basis',()=>{
 const source={ok:true,model:'2520 XLD',year:2025,page:35,row_id:'2520'};
 const result=validateModelClaims({model:'2520 XLD',year:2025,isolatedSource:source,claims:[{field:'beam',value:9.5,unit:'ft',measurement_basis:'beam',source_model_year:2025,source_page:35,source_row_id:'2820',exact_quote:'9 ft 6 in'}]});
 assert.equal(result.approved.length,0);
});
