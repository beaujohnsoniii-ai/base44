// Default tier assignments for questionnaire fields — the four-level gating that
// separates Free Discovery from MATCH+ ($9), Refined Match ($29), and Market Match ($99).
// The admin can override these via the QuestionConfig entity; these are the fallback
// when the entity is unavailable or unset.
//
// Keep these in sync with FIELD_TIERS in src/lib/question-fields.js.

import { DEFAULT_FIELD_TIERS } from "./question-tier-defaults.mjs";
const fieldsAt = (tier: string) => Object.entries(DEFAULT_FIELD_TIERS).filter(([, value]) => value === tier).map(([key]) => key);
export const DEFAULT_MATCH_PLUS_FIELDS = fieldsAt("match_plus");
export const DEFAULT_REFINED_MATCH_FIELDS = fieldsAt("refined_match");
export const DEFAULT_MARKET_MATCH_FIELDS = fieldsAt("market_match");

// Load the admin-configured question tiers, falling back to the hardcoded defaults.
export async function loadQuestionTiers(base44: any) {
  try {
    const cfg = await base44.asServiceRole.entities.QuestionConfig.list("-created_date", 1);
    const c = cfg?.[0];
    const mp = Array.isArray(c?.match_plus_fields) ? c.match_plus_fields : DEFAULT_MATCH_PLUS_FIELDS;
    const rm = Array.isArray(c?.refined_match_fields) ? c.refined_match_fields : DEFAULT_REFINED_MATCH_FIELDS;
    const mm = Array.isArray(c?.market_match_fields) ? c.market_match_fields : DEFAULT_MARKET_MATCH_FIELDS;
    return {
      matchPlus: new Set(mp.map((f: string) => String(f))),
      refinedMatch: new Set(rm.map((f: string) => String(f))),
      marketMatch: new Set(mm.map((f: string) => String(f))),
    };
  } catch (_) {
    return {
      matchPlus: new Set(DEFAULT_MATCH_PLUS_FIELDS),
      refinedMatch: new Set(DEFAULT_REFINED_MATCH_FIELDS),
      marketMatch: new Set(DEFAULT_MARKET_MATCH_FIELDS),
    };
  }
}