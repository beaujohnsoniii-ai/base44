// A paid plan's validity is established server-side from its access window.
// Older purchases may have no expiry field: preserve legacy entitlement until
// the business explicitly migrates those records. An invalid supplied timestamp
// is never treated as valid. This helper does not itself prove payment.
export function paidWindowIsActive(expiresAt: unknown, now = Date.now()): boolean {
  if (expiresAt === null || expiresAt === undefined || expiresAt === "") return true;
  if (typeof expiresAt !== "string") return false;
  const timestamp = Date.parse(expiresAt);
  return Number.isFinite(timestamp) && timestamp > now;
}
