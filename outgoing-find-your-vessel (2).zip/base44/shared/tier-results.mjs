// SoundHeading MATCH result shape — the single source of truth for how many
// models a tier returns and how many of them that tier marks as its recommendation.
//
// The funnel is breadth-then-refinement, NOT fewer-and-fewer results:
//   free          $0  → 4 broad starting directions (teasers only)
//   match_plus    $9  → 10-14 models to look around with (nothing marked)
//   refined_match $29 → the same wide pool, re-ranked, leading 5-7 marked
//   market_match  $99 → the same wide pool, re-ranked, top 3 marked as finalists
//
// Every model stays visible at Refined and Market so the buyer can see the whole
// consideration set and why each model sits where it does. The deeper answers
// change the ORDER and which models are marked, not the width of the pool.
//
// Consumers (import this — never re-type a tier count):
//   base44/shared/suggest-engine.ts   prompt counts + highlight marking
//   base44/shared/qa-programmatic.ts  count and highlight compliance checks
//   base44/functions/suggest-boats    persists each result's mark
//
// The frontend cannot import across the boundary, so it keeps a display mirror
// in src/lib/tier-results.js (package copy, results presentation, admin screens
// and the isolated demo/trial journeys). The two are checked for parity in
// tests/tier-results-parity.test.mjs — change a number on both sides.

export const TIER_RESULT_COUNTS = {
  free: { suggestCount: 4, minCount: 4, highlightCount: 0 },
  match_plus: { suggestCount: 14, minCount: 10, highlightCount: 0 },
  refined_match: { suggestCount: 14, minCount: 10, highlightCount: 7 },
  market_match: { suggestCount: 14, minCount: 10, highlightCount: 3 },
};

/** Counts for a normalized plan, falling back to the free tier. */
export function tierResultCounts(plan) {
  return TIER_RESULT_COUNTS[plan] || TIER_RESULT_COUNTS.free;
}

/** How many of a tier's ranked results carry its recommendation mark (0 = none). */
export function tierHighlightCount(plan) {
  return tierResultCounts(plan).highlightCount;
}

/**
 * Mark the leading results of an already rank-ordered list for a tier.
 * Used by the isolated demo/trial journeys so they present the same shape as
 * production; the engine marks its own shaped records the same way.
 */
export function markTierHighlights(rows, plan) {
  const count = tierHighlightCount(plan);
  return (Array.isArray(rows) ? rows : []).map((row, index) => ({ ...row, highlighted: index < count }));
}