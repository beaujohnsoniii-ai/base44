import test from 'node:test';
import assert from 'node:assert/strict';
import { savedModelCandidate } from '../../src/lib/modelCandidate.js';

test('saving a MATCH model does not invent a for-sale listing', () => {
  const candidate = savedModelCandidate({
    title: 'Example 28', make: 'Example', model: '28', year: 2027,
    link: 'https://example.com/advertised-boat', source: 'Listing site',
    asking_price: 112000, price_range_min: 90000, price_range_max: 130000,
    engines: 'Twin 200 hp on reference test', specs: 'Published test load: 8000 lb',
    match: { summary: 'Strong family dayboat fit' },
  });
  assert.deepEqual([candidate.url, candidate.source, candidate.asking_price, candidate.engines, candidate.specs], ['', '', null, '', '']);
  assert.equal(candidate.analyzed, false);
  assert.equal(candidate.make, 'Example');
  assert.equal(candidate.model, '28');
  assert.equal(candidate.match.summary, 'Strong family dayboat fit');
  assert.match(candidate.attraction_comment, /No individual listing/);
});

test('saved model can be identified even without a title; listing fields still remain empty', () => {
  const candidate = savedModelCandidate({ make: 'Sea Test', model: '24', year: 2025 });
  assert.equal(candidate.title, 'Sea Test 24 2025');
  assert.equal(candidate.url, '');
  assert.equal(candidate.asking_price, null);
});
