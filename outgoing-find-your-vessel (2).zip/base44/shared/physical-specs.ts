// Strict parsers for physical MATCH constraints.
// Never treat an unlabeled number, hull length, or bridge clearance as proof
// of a rigged overall-length or storage-height limit.
// A numeric passenger count produced by an LLM is not a verified manufacturer
// rating. Only the independently reviewed catalog may supply that provenance.
export function formatPassengerCapacitySpec(value: unknown, sourceVerified: boolean): string {
  const capacity = Number(value);
  if (!Number.isSafeInteger(capacity) || capacity <= 0) return "";
  return sourceVerified
    ? `Published passenger limit ${capacity} (source-verified; loading and conditions still matter)`
    : `Unverified passenger limit ${capacity} (confirm manufacturer rating)`;
}

export function parseFeet(value: string): number | null {
  const ft = value.match(/^\s*(\d+(?:\.\d+)?)\s*(?:ft|feet|foot|')\s*(?:(\d+(?:\.\d+)?)\s*(?:inches|inch|in|"))?/i);
  if (ft) return Number(ft[1]) + (ft[2] ? Number(ft[2]) / 12 : 0);
  const inches = value.match(/^\s*(\d+(?:\.\d+)?)\s*(?:inches|inch|in|")/i);
  return inches ? Number(inches[1]) / 12 : null;
}

export function parseLabeledFeet(specs: string, labelPattern: string): number | null {
  const label = new RegExp("(?:^|\\b)(?:" + labelPattern + ")\\s*[:=\\-]?\\s*((?:\\d+(?:\\.\\d+)?\\s*(?:ft|feet|foot|'|inches|inch|in|\\\"))(?:\\s*\\d+(?:\\.\\d+)?\\s*(?:inches|inch|in|\\\"))?)", "i");
  const m = String(specs || "").match(label);
  return m ? parseFeet(m[1]) : null;
}

export function parseRiggedOverallLengthFt(specs: string): number | null {
  return parseLabeledFeet(specs, "overall\\s+length|length\\s+overall|rigged\\s+(?:overall\\s+)?length|rigged\\s+loa");
}

export function parseLabeledWeightLb(specs: string, labelPattern: string): number | null {
  const regex = new RegExp("(?:^|\\b)(?:" + labelPattern + ")\\s*[:=\\-]?\\s*(\\d[\\d,]*(?:\\.\\d+)?)\\s*(?:lb|lbs|pounds)\\b", "i");
  const m = String(specs || "").match(regex);
  return m ? Number(m[1].replace(/,/g, "")) : null;
}

export function explicitStorageLengthCapFt(notes: string): number | null {
  const text = String(notes || "");
  // A named 30-foot slip is not necessarily a 30-foot absolute vessel limit.
  // Only phrases that explicitly impose a maximum may become hard filters.
  // Include feet-and-inches restrictions (e.g. "30' 6\" max LOA") so a
  // 30.5-ft marina ceiling is not silently rounded down to 30 ft.
  const amount = "(\\d+(?:\\.\\d+)?\\s*(?:ft|feet|foot|')\\s*(?:\\d+(?:\\.\\d+)?\\s*(?:inches|inch|in|\\\"))?)";
  const cap = "(?:maximum|max|limit|cap|cannot\\s+exceed|must\\s+not\\s+exceed|no\\s+longer\\s+than|no\\s+more\\s+than|not\\s+over|at\\s+most)";
  const label = "(?:(?:overall\\s+)?(?:boat\\s+)?(?:length|loa)\\s*)?";
  const patterns = [
    new RegExp(cap + "\\s*" + label + "(?:of\\s*)?" + amount, "gi"),
    new RegExp(amount + "\\s*" + label + cap + "\\b", "gi"),
    new RegExp(amount + "\\s*" + cap + "\\s*" + label + "(?:length|loa)\\b", "gi"),
  ];
  const limits: number[] = [];
  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) {
      const start = match.index ?? 0;
      const end = start + match[0].length;
      const preceding = text.slice(Math.max(0, start - 30), start);
      const following = text.slice(end, end + 35);
      // A facility note such as "beam max 10 ft" or "max 12 ft height"
      // is NOT a vessel-length ceiling. The generic "max 30 ft" shorthand
      // is allowed only when it is not clearly attached to another dimension.
      const otherDimension = "(?:beam|width|height|clearance|draft|depth|weight|displacement)";
      if (new RegExp(otherDimension + "\\s*$", "i").test(preceding)) continue;
      if (new RegExp("^\\s*(?:of\\s+)?(?:" + otherDimension + ")\\b", "i").test(following)) continue;
      const value = parseFeet(match[1]);
      if (value !== null && value > 0) limits.push(value);
    }
  }
  return limits.length ? Math.min(...limits) : null;
}


// Read only clearly stated facility limits from legacy free-text answers.
// A "30 ft slip" or "10 ft beam" without maximum wording is descriptive,
// not proof that the marina imposes that ceiling.
export function explicitStorageDimensionCapFt(notes: string, kind: "beam" | "height"): number | null {
  const text = String(notes || "");
  const label = kind === "beam" ? "(?:beam|width)" : "(?:storage\\s+height|overall\\s+height|height|clearance)";
  const amount = "(\\d+(?:\\.\\d+)?\\s*(?:ft|feet|foot|')\\s*(?:\\d+(?:\\.\\d+)?\\s*(?:inches|inch|in|\\\"))?|\\d+(?:\\.\\d+)?\\s*(?:inches|inch|in|\\\"))";
  const max = "(?:max(?:imum)?|limit|cap|cannot\\s+exceed|must\\s+not\\s+exceed|no\\s+more\\s+than)";
  const patterns = [
    new RegExp("\\b" + max + "\\s+" + label + "\\s*(?:of|:|=)?\\s*" + amount, "gi"),
    new RegExp("\\b" + label + "\\s+" + max + "\\s*(?:of|:|=)?\\s*" + amount, "gi"),
    new RegExp("\\b" + amount + "\\s+" + max + "\\s+" + label + "\\b", "gi"),
    new RegExp("\\b" + amount + "\\s+" + label + "\\s+" + max + "\\b", "gi"),
  ];
  const limits: number[] = [];
  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) {
      const value = parseFeet(match[1]);
      if (value !== null && value > 0) limits.push(value);
    }
  }
  return limits.length ? Math.min(...limits) : null;
}

// Lift capacity in pounds is a hard storage-weight ceiling. Never infer it
// from a lift model name, boat size, or an unlabeled number.
export function explicitLiftCapacityLb(notes: string): number | null {
  const text = String(notes || "");
  const weight = "(\\d[\\d,]*(?:\\.\\d+)?)\\s*(?:lb|lbs|pounds)\\b";
  const patterns = [
    new RegExp("\\b(?:lift|hoist)\\s+(?:rated\\s+)?(?:capacity|rating|limit|max(?:imum)?)\\s*(?:of|:|=)?\\s*" + weight, "gi"),
    new RegExp("\\b" + weight + "\\s+(?:lift|hoist)\\s*(?:capacity|rating|limit|max(?:imum)?)?\\b", "gi"),
    new RegExp("\\b(?:max(?:imum)?|limit|cap)\\s+(?:loaded|storage|lift)\\s+(?:weight|capacity)\\s*(?:of|:|=)?\\s*" + weight, "gi"),
  ];
  const limits: number[] = [];
  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) {
      const value = Number(match[1].replace(/,/g, ""));
      if (Number.isFinite(value) && value > 0) limits.push(value);
    }
  }
  return limits.length ? Math.min(...limits) : null;
}

// Deterministic screening for the limited physical facts available from a
// recommendation. Exclude a candidate only for a known over-limit value;
// missing or unverified facts become visible verification requirements.
export function screenPhysicalCandidate(candidate: any, profile: any): {
  excluded: boolean; reasons: string[]; verification_required: string[];
} {
  const reasons: string[] = [];
  const verification_required: string[] = Array.isArray(candidate.verification_required)
    ? [...candidate.verification_required] : [];
  const specs = String(candidate.specs || "");
  // Source URLs supplied by an LLM are not proof of the numeric specifications.
  // Only the catalog evidence bridge adds field-level verification markers.
  const verifiedFields = new Set<string>(
    Array.isArray(candidate.__catalog_verified_fields) ? candidate.__catalog_verified_fields : [],
  );
  const positive = (value: unknown): number | null => {
    const n = Number(value);
    return Number.isFinite(n) && n > 0 ? n : null;
  };
  const verify = (label: string) => {
    if (!verification_required.some(v => v.toLowerCase().includes(label.toLowerCase()))) {
      verification_required.push(`Verify ${label} against published model specifications before confirming physical fit.`);
    }
  };
  const test = (label: string, limit: number | null, actual: number | null, catalogField?: string) => {
    if (limit === null) return;
    // A model number invented or misread by the LLM must not eliminate a
    // genuinely viable boat. Only independently verified, applicable catalog
    // measurements establish an over-limit hard failure. Treat every other
    // number (including a claimed exceedance) as requiring verification.
    if (actual !== null && catalogField && verifiedFields.has(catalogField)) {
      if (actual > limit) reasons.push(`${label}: ${actual} exceeds hard maximum ${limit}`);
    } else {
      verify(label);
    }
  };

  const lengthCaps = [positive(profile.hard_max_overall_length_ft), explicitStorageLengthCapFt(String(profile.storage_capacity || ""))].filter((n): n is number => n !== null);
  const lengthLimit = lengthCaps.length ? Math.min(...lengthCaps) : null;
  const overall = positive(candidate.overall_length_ft) ?? parseRiggedOverallLengthFt(specs);
  const listed = parseFeet(String(candidate.length || "")) ?? parseLabeledFeet(specs, "length");
  // Product scope is independent of a buyer's preferred size. A known boat
  // length above 65 ft is out of scope even when no facility cap was supplied.
  const knownLengths = [overall, listed].filter((n): n is number => n !== null);
  if (knownLengths.some(n => n > 65)) {
    reasons.push(`SoundHeading v1 scope: known vessel length exceeds 65 ft`);
  }
  // A generic category (e.g. center_console) must not hide an excluded type
  // explicitly named in the model title or more specific type field.
  const explicitType = [candidate.boat_type, candidate.category, candidate.title, candidate.model]
    .filter(Boolean).join(" ");
  if (/\b(?:RIB\b|R\.I\.B\.(?=\W|$)|rigid[- ]hull inflatable\b|rigid inflatable\b|sailboat\b|jon boat\b)/i.test(explicitType)) {
    reasons.push(`SoundHeading v1 scope: excluded vessel type`);
  }
  if (lengthLimit !== null) {
    if (overall !== null) test("rigged overall length", lengthLimit, overall, "rigged_overall_length_ft");
    else verify("rigged overall length");
    // LLM-reported "length" might mean hull length, nominal model size or LOA;
    // even if it exceeds the cap, it cannot certify rigged overall dimensions.
  }

  const draft = positive(candidate.draft_ft) ?? parseFeet(String(candidate.draft || ""))
    ?? parseLabeledFeet(specs, "draft");
  test("draft", positive(profile.hard_max_draft_ft), draft, "draft_ft");
  const storageNotes = String(profile.storage_capacity || "");
  const tighter = (...values: Array<number | null>): number | null => {
    const known = values.filter((n): n is number => n !== null);
    return known.length ? Math.min(...known) : null;
  };
  test("beam", tighter(positive(profile.hard_max_beam_ft), explicitStorageDimensionCapFt(storageNotes, "beam")),
    positive(candidate.beam_ft) ?? parseLabeledFeet(specs, "beam"), "beam_ft");
  test("storage height", tighter(positive(profile.hard_max_height_ft), explicitStorageDimensionCapFt(storageNotes, "height")),
    positive(candidate.storage_height_ft) ?? parseLabeledFeet(specs, "storage\\s+height|overall\\s+height|height\\s+on\\s+trailer|trailer\\s+height"), "storage_height_ft");
  test("loaded storage weight", tighter(positive(profile.hard_max_storage_weight_lb), explicitLiftCapacityLb(storageNotes)),
    positive(candidate.loaded_storage_weight_lb) ?? parseLabeledWeightLb(specs, "(?:loaded|operating|storage)\\s+(?:weight|displacement)"), "storage_weight_lb");
  if (profile.storage === "trailer") {
    if (positive(profile.tow_capacity_lb) === null) {
      verify("actual tow-vehicle rating");
      const weight = positive(candidate.trailered_weight_lb)
        ?? parseLabeledWeightLb(specs, "(?:trailer(?:ed)?|tow(?:ing)?)\\s+weight");
      if (weight === null) verify("trailered weight");
    }
    test("trailered weight", positive(profile.tow_capacity_lb),
      positive(candidate.trailered_weight_lb) ?? parseLabeledWeightLb(specs, "(?:trailer(?:ed)?|tow(?:ing)?)\\s+weight"), "trailered_weight_lb");
  }

  // A published person limit is a model-level safety constraint, not the same
  // as comfortable seating or the number of people shown in marketing photos.
  // Many larger recreational boats have no comparable published person rating;
  // missing capacity must be checked, never guessed from size or seating.
  const normalParty = positive(profile.passenger_count);
  const occasionalParty = positive(profile.occasional_passenger_count);
  const publishedCapacity = positive(candidate.passenger_capacity);
  const capacityVerified = verifiedFields.has("passenger_capacity");
  if (normalParty !== null) {
    if (publishedCapacity !== null && publishedCapacity < normalParty && capacityVerified) {
      reasons.push(`passenger capacity: source-verified published maximum ${publishedCapacity} is below normal group ${normalParty}`);
    } else if (!capacityVerified) {
      // Unverified low numbers must not exclude a valid model, nor can
      // unverified high numbers establish safe legal or comfortable loading.
      verify("safe passenger capacity for normal group");
    }
  }
  if (occasionalParty !== null && publishedCapacity !== null && publishedCapacity < occasionalParty) {
    verification_required.push(
      capacityVerified
        ? `Occasional group of ${occasionalParty} exceeds the source-verified ${publishedCapacity}-person limit; do not carry this group together.`
        : `Occasional group of ${occasionalParty} exceeds the unverified reported ${publishedCapacity}-person limit; confirm the applicable manufacturer rating before carrying this group.`
    );
  } else if (occasionalParty !== null && !capacityVerified) {
    verify("safe passenger capacity for occasional group");
  }

  return { excluded: reasons.length > 0, reasons, verification_required: [...new Set(verification_required)] };
}
