import {planApifyListingRequest,normalizeApifyBoatRow} from "./apify-boat-adapters.mjs";
const ACTOR="getascraper/yachtworld-scraper",ORIGIN="https://api.apify.com";
export const APIFY_TEST_POLICY=Object.freeze({enabled:false,approval_id:null,approved_url:null,max_total_charge_usd:null,
 source_permission_reference:null,source_permission_valid_until:null,atomic_reservation_verified:false,build:null});
const failure=code=>Object.assign(new Error(code),{safe_code:code});
const validId=id=>typeof id==="string"&&/^[a-zA-Z0-9]{8,40}$/.test(id);
export function validateApifyTestPolicy(policy){
 if(policy?.enabled!==true)return "disabled";
 if(!Number.isFinite(policy.max_total_charge_usd)||policy.max_total_charge_usd<=0||policy.max_total_charge_usd>0.10)return "budget_required";
 if(typeof policy.approval_id!=="string"||!policy.approval_id.trim())return "approval_required";
 if(!policy.source_permission_reference||!(Date.parse(policy.source_permission_valid_until)>Date.now()))return "source_permission_required";
 if(policy.atomic_reservation_verified!==true)return "atomic_reservation_unverified";
 if(typeof policy.build!=="string"||!/^\d+\.\d+\.\d+$/.test(policy.build))return "pinned_build_required";
 try{planApifyListingRequest("yachtworld",{url:policy.approved_url});}catch{return "approved_detail_url_required";}
 return null;
}
async function jsonResponse(response){
 if(!response.ok)throw failure("HTTP_"+response.status);
 const reader=response.body?.getReader();if(!reader)throw failure("EMPTY_RESPONSE");
 const chunks=[];let count=0;
 while(true){const n=await reader.read();if(n.done)break;count+=n.value.byteLength;if(count>262144){await reader.cancel();throw failure("RESPONSE_TOO_LARGE");}chunks.push(n.value);}
 const bytes=new Uint8Array(count);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}
 try{return JSON.parse(new TextDecoder().decode(bytes));}catch{throw failure("INVALID_JSON");}
}
// Exactly one run-start request. No SDK retries, provider restarts, polling or
// follow-up run. Fixed API origin, bearer header, redirect:error, bounded reads.
// Invocation is only through guardedApifyListingTest after reservation.
export async function startApprovedYachtWorldTest({policy,key,signal,fetcher=fetch,onStage=()=>{}}){
 const blocked=validateApifyTestPolicy(policy);if(blocked)throw failure("POLICY_BLOCKED");
 if(typeof key!=="string"||!key.trim())throw failure("KEY_MISSING");
 const plan=planApifyListingRequest("yachtworld",{url:policy.approved_url});
 const url=new URL("/v2/actors/getascraper~yachtworld-scraper/runs",ORIGIN);
 url.search=new URLSearchParams({maxTotalChargeUsd:String(policy.max_total_charge_usd),maxItems:"1",timeout:"60",waitForFinish:"20",restartOnError:"false",build:policy.build}).toString();
 const controller=new AbortController(),abort=()=>controller.abort();signal?.throwIfAborted();signal?.addEventListener("abort",abort,{once:true});const timer=setTimeout(abort,25000);
 const headers={Authorization:"Bearer "+key.trim(),"Content-Type":"application/json"};
 try{
  onStage("run_request");
  const payload=await jsonResponse(await fetcher(url.href,{method:"POST",headers,redirect:"error",body:JSON.stringify(plan.input),signal:controller.signal}));
  const run=payload?.data;
  if(!validId(run?.id))throw failure("INVALID_RUN_RESPONSE");
  const receipt={run_id:run.id,run_status:typeof run.status==="string"?run.status.slice(0,40):"unknown",
   reported_usage_usd:typeof run.usageTotalUsd==="number"&&Number.isFinite(run.usageTotalUsd)?run.usageTotalUsd:null,billing_final_confirmed:false};
  onStage("run_received",receipt);
  // Validate the provider echoed the requested charge/time/item/build controls.
  if(run.options?.maxTotalChargeUsd!==policy.max_total_charge_usd||run.options?.maxItems!==1||run.options?.timeoutSecs!==60||run.buildNumber!==policy.build)
   throw failure("RUN_LIMITS_UNCONFIRMED");
  if(run.status!=="SUCCEEDED")throw failure("RUN_NOT_CONFIRMED_SUCCEEDED");
  if(!validId(run.defaultDatasetId))throw failure("INVALID_DATASET_ID");
  controller.signal.throwIfAborted();onStage("dataset_read");
  const dataUrl=new URL("/v2/datasets/"+run.defaultDatasetId+"/items",ORIGIN);dataUrl.search=new URLSearchParams({format:"json",clean:"true",limit:"2"}).toString();
  const rows=await jsonResponse(await fetcher(dataUrl.href,{method:"GET",headers,redirect:"error",signal:controller.signal}));
  if(!Array.isArray(rows)||rows.length!==1)throw failure("EXPECTED_ONE_EXACT_ROW");
  const record=normalizeApifyBoatRow("yachtworld",rows[0],{requested_url:policy.approved_url,observed_at:new Date().toISOString()});
  if(!record.exact_listing)throw failure("EXACT_LISTING_UNCONFIRMED");
  return {receipt,record};
 }finally{clearTimeout(timer);signal?.removeEventListener("abort",abort);}
}
export async function guardedApifyListingTest({client,getSecret,action="status",policy=APIFY_TEST_POLICY,signal,fetcher=fetch}){
 let user;try{user=await client.auth.me();}catch{return {status:401,body:{error:"Sign in first"}};}
 if(!user)return {status:401,body:{error:"Sign in first"}};
 if(user.role!=="admin")return {status:403,body:{error:"Admin access required"}};
 if(!["status","run_approved_test"].includes(action))return {status:400,body:{error:"Unsupported action"}};
 const blocked=validateApifyTestPolicy(policy);
 if(action==="status")return {status:200,body:{enabled:policy.enabled===true,blocker:blocked,key_configured:Boolean(getSecret()),secret_name:"APIFY_API_TOKEN",actor_id:ACTOR,automatic_runs:false}};
 if(blocked)return {status:409,body:{error:"Test disabled: "+blocked}};
 signal?.throwIfAborted();
 const key=getSecret();if(typeof key!=="string"||!key.trim())return {status:503,body:{error:"APIFY_API_TOKEN is not configured; no provider call made"}};
 // This dedicated store is intentionally not provisioned or seeded by this patch.
 // Production remains blocked until its atomic conditional-update contract is verified.
 const ledger=client.asServiceRole?.entities?.ApifyListingTestApproval;
 if(!ledger)return {status:409,body:{error:"Dedicated test approval store unavailable"}};
 const rows=await ledger.filter({approval_id:policy.approval_id},"-created_date",2);
 if(rows.length!==1)return {status:409,body:{error:"Unique approved test reservation required"}};
 const slot=rows[0],stamp=Date.now();
 if(slot.owner_id!==user.id||slot.actor_id!==ACTOR||slot.approved_url!==policy.approved_url||slot.max_calls!==1||slot.max_items!==1||
  slot.max_total_charge_usd!==policy.max_total_charge_usd||slot.source_permission_reference!==policy.source_permission_reference||
  !(Date.parse(slot.expires_at)>stamp)||slot.status!=="ready")
  return {status:409,body:{error:"Test scope unavailable or already spent"}};
 const nonce=crypto.randomUUID();
 const reserved=await ledger.updateMany({id:slot.id,approval_id:policy.approval_id,status:"ready",owner_id:user.id,max_calls:1},
  {$set:{status:"reserved",request_nonce:nonce,reserved_at:new Date().toISOString()}});
 if(reserved?.success!==true||reserved.updated!==1)return {status:409,body:{error:"Reservation not confirmed; no provider call made"}};
 const confirmed=await ledger.get(slot.id);
 if(confirmed.status!=="reserved"||confirmed.request_nonce!==nonce)return {status:409,body:{error:"Reservation readback failed; no provider call made"}};
 let stage="reserved",receipt=null;const started=Date.now();
 try{
  signal?.throwIfAborted();
  const result=await startApprovedYachtWorldTest({policy,key,signal,fetcher,onStage:(next,run)=>{stage=next;if(run)receipt=run;}});
  stage="ledger_complete";
  await ledger.update(slot.id,{status:"complete",completed_at:new Date().toISOString(),result});
  return {status:200,body:{test_status:"complete",result}};
 }catch(error){
  // Whitelist only adapter-generated fixed codes; never log or retain raw errors.
  const candidate=error?.safe_code;
  const allowed=/^(HTTP_[1-5]\d{2}|EMPTY_RESPONSE|RESPONSE_TOO_LARGE|INVALID_JSON|POLICY_BLOCKED|KEY_MISSING|INVALID_RUN_RESPONSE|RUN_LIMITS_UNCONFIRMED|RUN_NOT_CONFIRMED_SUCCEEDED|INVALID_DATASET_ID|EXPECTED_ONE_EXACT_ROW|EXACT_LISTING_UNCONFIRMED)$/;
  const diagnostic={stage,code:typeof candidate==="string"&&allowed.test(candidate)?candidate:error?.name==="AbortError"?"ABORTED":"UNCLASSIFIED_RUNTIME_ERROR",
   elapsed_ms:Date.now()-started,receipt,billing_final_confirmed:false};
  try{await ledger.update(slot.id,{status:"uncertain",completed_at:new Date().toISOString(),diagnostic});}
  catch{return {status:502,body:{test_status:"reserved_or_uncertain",error:"Completion could not be saved. Keep reservation spent; do not rerun.",diagnostic}};}
  return {status:502,body:{test_status:"uncertain",error:"Attempt unconfirmed and spent; do not rerun.",diagnostic}};
 }
}
