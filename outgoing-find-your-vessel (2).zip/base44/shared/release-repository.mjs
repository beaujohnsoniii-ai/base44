import {digest} from './release-runtime.mjs';
async function one(entity,query){const rows=await entity.filter(query,'id',2);if(rows.length>1)throw Error('Duplicate release identity');return rows[0]??null;}
export function releaseRepository(db){
 const releases=db.entities.ResearchRelease,records=db.entities.ResearchReleaseRecord,pointers=db.entities.ResearchReleasePointer;
 return {
  async getRelease(id){const row=await one(releases,{release_id:id});return row?{...row,manifest:row.manifest}:null;},
  async createRelease(r){if(await one(releases,{release_id:r.manifest.release_id}))throw Error('Release exists');return releases.create({release_id:r.manifest.release_id,manifest:r.manifest,sealed:false,approved:false});},
  async getRecord(id,gid){const row=await one(records,{release_id:id,generation_id:gid});if(!row)return null;if(digest(row.payload)!==row.record_sha256)throw Error('Stored record hash mismatch');return row.payload;},
  async putRecord(id,payload){const release=await one(releases,{release_id:id});if(!release||release.sealed)throw Error('Release sealed or absent');if(await one(records,{release_id:id,generation_id:payload.generation_id}))throw Error('Record already exists');return records.create({release_id:id,generation_id:payload.generation_id,record_sha256:digest(payload),payload});},
  async listRecords(id){const out=[];for(let skip=0;skip<20000;skip+=500){const page=await records.filter({release_id:id},'generation_id',500,skip);for(const row of page){if(digest(row.payload)!==row.record_sha256)throw Error('Stored record hash mismatch');out.push(row.payload);}if(page.length<500)return out;}throw Error('Release exceeds pagination bound');},
  async sealRelease(id){const row=await one(releases,{release_id:id});if(!row)throw Error('Missing release');return releases.update(row.id,{sealed:true,sealed_at:new Date().toISOString()});},
  async getPointer(){return one(pointers,{key:'active'});},
  async swapPointer(expected,next){
   const row=await one(pointers,{key:'active'});
   // Deliberately fail closed. Standard entity.update has no verified CAS.
   // Enabling this flag alone is insufficient; the repository still refuses
   // pointer writes until an actual conditional primitive is installed/tested.
   if(!row?.activation_enabled)throw Error('Activation gate closed');
   throw Error('Conditional pointer writes not verified; activation remains blocked');
  },
  async approve(id,user){const row=await one(releases,{release_id:id});if(!row?.sealed)throw Error('Seal release before approval');return releases.update(row.id,{approved:true,approved_by:user.id,approved_at:new Date().toISOString()});},
  async backup(id,skip=0){const release=await one(releases,{release_id:id});if(!release)throw Error('Missing release');const rows=await records.filter({release_id:id},'generation_id',100,skip);return {release,records:rows.map(r=>({release_id:r.release_id,generation_id:r.generation_id,record_sha256:r.record_sha256,payload:r.payload})),next_skip:rows.length===100?skip+100:null,pointer:await one(pointers,{key:'active'})};}
 };
}