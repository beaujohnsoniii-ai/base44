// MATCH recommends model/generation families, not individual used boats.
// Never render an LLM's unsupported seller asking price or engine-hour count
// as if it were an attribute of every boat of that model.
// These checks are intentionally narrow: broad MODEL price ranges, factory
// power ratings, length, fuel tank capacity and maintenance intervals remain.
const LISTING_SPECIFIC_CLAIMS = [
  /\b(?:engines?|motors?|outboards?)\s*(?:have|has|had|with|show(?:s|ing)?|at|reported(?:ly)?|only|about|approximately|around)?\s*\d{1,3}(?:,\d{3})?\s*(?:hours?|hrs?)\b/i,
  /\b(?:engines?|motors?|outboards?)\s+hours?\s*(?:[:=]\s*|(?:are|is|of)\s+)?\d{1,3}(?:,\d{3})?\b/i,
  /\b\d{1,3}(?:,\d{3})?\s*(?:engine\s+)?(?:hours?|hrs?)\s+(?:on|of|since)\s+(?:the\s+)?(?:engines?|motors?|outboards?)\b/i,
  /\b(?:asking(?:\s+price)?|seller(?:'s)?\s+(?:asks?|asking|price)|(?:currently\s+)?listed\s+(?:at|for)|advertised\s+(?:at|for)|for\s+sale\s+(?:at|for))\s*:?\s*\$\s*\d[\d,.]*(?:\s*[km])?\b/i,
  /\$\s*\d[\d,.]*(?:\s*[km])?\s*(?:asking(?:\s+price)?|listed|seller\s+asks)\b/i,
  // A seller's one-off example price is not a market price band for the
  // model. LLMs often say "a 2023 example is offered for $120k" without
  // using the words "asking price" or "listed".
  /\b(?:example|listing|boat|vessel)\b[^.;\n]{0,45}\b(?:offered|priced|available)\s+(?:at|for)\s*\$\s*\d[\d,.]*(?:\s*[km])?\b/i,
];

const WITHHELD_MESSAGE =
  "Seller asking prices and engine hours apply to individual listings; verify the actual boat.";

export function containsListingSpecificModelClaim(value: unknown): boolean {
  return typeof value === "string" && LISTING_SPECIFIC_CLAIMS.some(pattern => pattern.test(value));
}

export function withholdListingSpecificModelClaims(input: unknown): {
  text: string;
  withheld: boolean;
} {
  if (typeof input !== "string" || !input.trim()) {
    return { text: typeof input === "string" ? input : "", withheld: false };
  }
  const chunks = input.split(/(?<=[.!?])\s+(?=[A-Z0-9])|[;\n]+/);
  let withheld = false;
  const result = chunks.map(chunk => {
    if (!containsListingSpecificModelClaim(chunk)) return chunk.trim();
    withheld = true;
    return WITHHELD_MESSAGE;
  });
  return {
    text: result.filter((chunk, index) => chunk && (index === 0 || chunk !== result[index - 1])).join(" ").trim(),
    withheld,
  };
}
