export const DEFAULT_FIELD_TIERS = {
  // Free Discovery
  buyer_role: "free",
  vessel_class: "free",
  boat_size_range: "free",
  operating_area: "free",
  activities: "free",
  experience_level: "free",
  storage: "free",
  purchase_budget_max: "free",
  ownership_timeframe: "free",
  // MATCH+ ($9)
  activity_weights: "match_plus",
  passenger_count: "match_plus",
  occasional_passenger_count: "match_plus",
  previously_owned_boats: "match_plus",
  preferred_manufacturers: "match_plus",
  purchase_budget_min: "match_plus",
  // Refined Match ($29)
  family_use: "refined_match",
  storage_capacity: "refined_match",
  draft: "refined_match",
  towing: "refined_match",
  open_to_project_boats: "refined_match",
  must_haves: "refined_match",
  preferences: "refined_match",
  unacceptable_compromises: "refined_match",
  // Market Match ($99)
  annual_ownership_budget: "market_match",
  ownership_horizon: "market_match",
  priorities: "market_match",
  overnight_requirements: "market_match",
};
export function fieldTiersFromSets(tiers) {
  const fields = Object.fromEntries(Object.keys(DEFAULT_FIELD_TIERS).map(key => [key, "free"]));
  for (const [set, tier] of [[tiers.matchPlus, "match_plus"], [tiers.refinedMatch, "refined_match"], [tiers.marketMatch, "market_match"]]) {
    for (const field of set) fields[field] = tier;
  }
  return fields;
}
