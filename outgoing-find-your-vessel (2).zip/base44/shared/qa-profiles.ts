// SoundHeading MATCH QA — golden profile definitions and synthetic profile generation.
//
// Golden Profiles are stable benchmark buyers used repeatedly to detect regressions.
// They persist in the Test DB (GoldenProfile entity) and survive batch cleanup.
// Synthetic profiles are generated per-batch and cleaned up between runs.
//
// This module is imported by the run-match-qa backend function only. It does NOT
// import or call the shared suggest-engine — it only provides profile data.

// ── Golden profile definitions ──────────────────────────────────────────────
// 25 representative buyer types and difficult MATCH scenarios. Each is a full
// BuyerProfile-shaped object. The run-match-qa function creates a temporary
// BuyerProfile from this data for each run.

function gp(
  name: string,
  description: string,
  category: string,
  p: Record<string, any>,
): { name: string; description: string; category: string; profile_data: Record<string, any> } {
  return {
    name,
    description,
    category,
    profile_data: {
      buyer_role: "buyer",
      vessel_class: "private",
      status: "active",
      open_to_project_boats: false,
      ...p,
    },
  };
}

export const GOLDEN_PROFILE_DEFS: { name: string; description: string; category: string; profile_data: Record<string, any> }[] = [
  gp("Offshore Fisher — Tampa Bay", "Core offshore center console buyer; preferred 30–40 ft but a 29 ft candidate may still win if it fits better and all true physical limits are satisfied.", "offshore_fishing", {
    boat_size_range: "30_40", operating_area: "Tampa Bay, FL", activities: ["Fishing", "Day cruising"],
    activity_weights: { Fishing: 70, "Day cruising": 30 }, experience_level: "experienced",
    previously_owned_boats: "21 ft center console", passenger_count: 4, family_use: "Kids and friends",
    overnight_requirements: "None — day trips only", storage: "marina_slip", storage_capacity: "40 ft max",
    draft: "Moderate — 12-24 inches", towing: "No — slip kept",
    purchase_budget_min: 50000, purchase_budget_max: 80000, annual_ownership_budget: 12000,
    ownership_timeframe: "1_to_3_months", ownership_horizon: "3_to_7_years",
    must_haves: "Self-bailing cockpit, T-top", preferences: "Ride quality in chop, Fuel efficiency",
    unacceptable_compromises: "Wood construction", priorities: ["Ride / seakeeping", "Fishability", "Build quality & construction", "Purchase price / value", "Safety"],
    preferred_manufacturers: [],
  }),
  gp("Family Day Cruiser — Lake Erie", "Beginner family buyer on a budget — tests entry-level matching.", "family_cruising", {
    boat_size_range: "18_24", operating_area: "Lake Erie, OH", activities: ["Day cruising", "Watersports / tubing", "Entertaining"],
    activity_weights: { "Day cruising": 50, "Watersports / tubing": 30, Entertaining: 20 }, experience_level: "beginner",
    previously_owned_boats: "None — first boat", passenger_count: 6, family_use: "Weekend family outings",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Not sure", towing: "6000 lb tow rating — F-150/half-ton",
    purchase_budget_min: 25000, purchase_budget_max: 45000, annual_ownership_budget: 5000,
    ownership_timeframe: "3_to_6_months", ownership_horizon: "3_to_7_years",
    must_haves: "Bimini top", preferences: "Easy to trailer, Low maintenance",
    unacceptable_compromises: "Single outboard only", priorities: ["Comfort / accommodations", "Safety", "Purchase price / value", "Fuel economy", "Resale strength"],
    preferred_manufacturers: [],
  }),
  gp("Overnight Cruiser — Chesapeake Bay", "Buyer explicitly requiring real berths — tests hard overnight-constraint enforcement.", "overnight_cruising", {
    boat_size_range: "30_40", operating_area: "Chesapeake Bay, MD", activities: ["Overnight cruising", "Day cruising", "Fishing"],
    activity_weights: { "Overnight cruising": 45, "Day cruising": 35, Fishing: 20 }, experience_level: "intermediate",
    previously_owned_boats: "24 ft cuddy cabin", passenger_count: 4, family_use: "Couple only",
    overnight_requirements: "Need to sleep 4 for regular weekend overnights; real berths required", storage: "marina_slip", storage_capacity: "40 ft max",
    draft: "Moderate — 12-24 inches", towing: "No — slip kept",
    purchase_budget_min: 80000, purchase_budget_max: 120000, annual_ownership_budget: 15000,
    ownership_timeframe: "3_to_6_months", ownership_horizon: "7_to_12_years",
    must_haves: "Cabin with head, Enclosed head", preferences: "Ride quality in chop, Good resale",
    unacceptable_compromises: "High hours", priorities: ["Comfort / accommodations", "Build quality & construction", "Ride / seakeeping", "Resale strength", "Purchase price / value"],
    preferred_manufacturers: [],
  }),
  gp("Flats Fisher — Florida Keys", "Shallow-water specialist — tests draft and flats-skiff matching.", "flats_fishing", {
    boat_size_range: "18_24", operating_area: "Florida Keys", activities: ["Fishing"],
    activity_weights: { Fishing: 100 }, experience_level: "expert",
    previously_owned_boats: "16 ft skiff", passenger_count: 2, family_use: "Solo fishing",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Shallow — under 12 inches", towing: "3500 lb tow rating — midsize SUV",
    purchase_budget_min: 20000, purchase_budget_max: 35000, annual_ownership_budget: 4000,
    ownership_timeframe: "asap", ownership_horizon: "3_to_7_years",
    must_haves: "Power Pole, Trolling motor", preferences: "Shallow draft, Quiet approach",
    unacceptable_compromises: "Deep draft", priorities: ["Fishability", "Ride / seakeeping", "Purchase price / value", "Fuel economy", "Resale strength"],
    preferred_manufacturers: [],
  }),
  gp("First-Time Buyer — Cape Cod", "No prior ownership — tests beginner calibration, forgiveness, and a real towing ceiling.", "first_time_buyer", {
    boat_size_range: "18_24", operating_area: "Cape Cod, MA", activities: ["Day cruising", "Fishing"],
    activity_weights: { "Day cruising": 60, Fishing: 40 }, experience_level: "none",
    previously_owned_boats: "None — first boat", passenger_count: 4, family_use: "Weekend family outings",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Not sure", towing: "3500 lb tow rating — midsize SUV", tow_capacity_lb: 3500,
    purchase_budget_min: 15000, purchase_budget_max: 25000, annual_ownership_budget: 3000,
    ownership_timeframe: "just_exploring", ownership_horizon: "1_to_3_years",
    must_haves: "Self-bailing cockpit", preferences: "Easy to trailer, Low maintenance",
    unacceptable_compromises: "Wood construction, Sterndrive", priorities: ["Safety", "Purchase price / value", "Fuel economy", "Comfort / accommodations", "Resale strength"],
    preferred_manufacturers: [],
  }),
  gp("Sportfishing Yacht — Florida Keys", "High-budget expert — tests sportfishing yacht matching.", "sportfishing_yacht", {
    boat_size_range: "40_50", operating_area: "Florida Keys", activities: ["Fishing", "Overnight cruising"],
    activity_weights: { Fishing: 65, "Overnight cruising": 35 }, experience_level: "expert",
    previously_owned_boats: "36 ft express fisherman", passenger_count: 6, family_use: "Extended family gatherings",
    overnight_requirements: "Extended cruising trips", storage: "marina_slip", storage_capacity: "50 ft max",
    draft: "Deep — over 24 inches", towing: "No — slip kept",
    purchase_budget_min: 250000, purchase_budget_max: 400000, annual_ownership_budget: 35000,
    ownership_timeframe: "6_plus_months", ownership_horizon: "last_boat",
    must_haves: "Tuna tower, Livewell", preferences: "Ride quality in chop, Good resale",
    unacceptable_compromises: "Older than 15 years", priorities: ["Fishability", "Build quality & construction", "Ride / seakeeping", "Safety", "Resale strength"],
    preferred_manufacturers: [],
  }),
  gp("Pontoon Family — Lake Champlain", "Pontoon buyer — tests pontoon/tri-toon category matching.", "pontoon_family", {
    boat_size_range: "24_30", operating_area: "Lake Champlain, VT", activities: ["Day cruising", "Entertaining", "Watersports / tubing"],
    activity_weights: { "Day cruising": 40, Entertaining: 35, "Watersports / tubing": 25 }, experience_level: "beginner",
    previously_owned_boats: "None — first boat", passenger_count: 8, family_use: "Weekend family outings",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Shallow — under 12 inches", towing: "6000 lb tow rating — F-150/half-ton",
    purchase_budget_min: 20000, purchase_budget_max: 30000, annual_ownership_budget: 3000,
    ownership_timeframe: "1_to_3_months", ownership_horizon: "3_to_7_years",
    must_haves: "Bimini top", preferences: "Easy to trailer, Low maintenance",
    unacceptable_compromises: "High hours", priorities: ["Comfort / accommodations", "Safety", "Purchase price / value", "Fuel economy", "Resale strength"],
    preferred_manufacturers: [],
  }),
  gp("Tow/Sport — Texas Gulf", "Wakeboard/wakesurf buyer — tests tow/sport category matching.", "tow_sport", {
    boat_size_range: "18_24", operating_area: "Texas Gulf Coast", activities: ["Watersports / tubing", "Day cruising"],
    activity_weights: { "Watersports / tubing": 75, "Day cruising": 25 }, experience_level: "intermediate",
    previously_owned_boats: "18 ft bowrider", passenger_count: 6, family_use: "Kids and friends",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Not sure", towing: "6000 lb tow rating — F-150/half-ton",
    purchase_budget_min: 40000, purchase_budget_max: 60000, annual_ownership_budget: 5000,
    ownership_timeframe: "3_to_6_months", ownership_horizon: "1_to_3_years",
    must_haves: "Tower, Ballast system", preferences: "Wake quality, Good resale",
    unacceptable_compromises: "Wood construction", priorities: ["Comfort / accommodations", "Purchase price / value", "Build quality & construction", "Resale strength", "Fuel economy"],
    preferred_manufacturers: [],
  }),
  gp("Pilothouse Express — Puget Sound", "Pacific NW buyer — tests that occasional overnight use improves cabin fit without becoming a hard berth requirement.", "pilothouse_express", {
    boat_size_range: "30_40", operating_area: "Puget Sound, WA", activities: ["Day cruising", "Overnight cruising", "Fishing"],
    activity_weights: { "Day cruising": 40, "Overnight cruising": 35, Fishing: 25 }, experience_level: "experienced",
    previously_owned_boats: "28 ft cabin cruiser", passenger_count: 4, family_use: "Couple only",
    overnight_requirements: "Occasional overnight", storage: "marina_slip", storage_capacity: "40 ft max",
    draft: "Moderate — 12-24 inches", towing: "No — slip kept",
    purchase_budget_min: 100000, purchase_budget_max: 150000, annual_ownership_budget: 18000,
    ownership_timeframe: "6_plus_months", ownership_horizon: "7_to_12_years",
    must_haves: "Cabin with head, Enclosed helm", preferences: "Ride quality in chop, Fuel efficiency",
    unacceptable_compromises: "Open cockpit only", priorities: ["Ride / seakeeping", "Build quality & construction", "Comfort / accommodations", "Safety", "Resale strength"],
    preferred_manufacturers: [],
  }),
  gp("Trawler Cruiser — Long Island Sound", "Trawler buyer — tests displacement-hull/long-range matching.", "trawler", {
    boat_size_range: "40_50", operating_area: "Long Island Sound, CT", activities: ["Overnight cruising", "Day cruising"],
    activity_weights: { "Overnight cruising": 60, "Day cruising": 40 }, experience_level: "experienced",
    previously_owned_boats: "32 ft express cruiser", passenger_count: 2, family_use: "Couple only",
    overnight_requirements: "Extended cruising trips", storage: "marina_slip", storage_capacity: "50 ft max",
    draft: "Deep — over 24 inches", towing: "No — slip kept",
    purchase_budget_min: 150000, purchase_budget_max: 200000, annual_ownership_budget: 20000,
    ownership_timeframe: "6_plus_months", ownership_horizon: "last_boat",
    must_haves: "Cabin with head, Enclosed head", preferences: "Fuel efficiency, Good resale",
    unacceptable_compromises: "Gas engine only", priorities: ["Fuel economy", "Comfort / accommodations", "Build quality & construction", "Ride / seakeeping", "Safety"],
    preferred_manufacturers: [],
  }),
  gp("Performance Boat — Cocoa Beach", "Go-fast buyer — tests performance category matching.", "performance", {
    boat_size_range: "24_30", operating_area: "Cocoa Beach, FL", activities: ["Day cruising"],
    activity_weights: { "Day cruising": 100 }, experience_level: "expert",
    previously_owned_boats: "24 ft bowrider", passenger_count: 4, family_use: "Kids and friends",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Not sure", towing: "10000 lb tow rating — F-250/3/4-ton",
    purchase_budget_min: 60000, purchase_budget_max: 90000, annual_ownership_budget: 8000,
    ownership_timeframe: "1_to_3_months", ownership_horizon: "1_to_3_years",
    must_haves: "High horsepower", preferences: "Speed, Good resale",
    unacceptable_compromises: "Slow displacement hull", priorities: ["Build quality & construction", "Ride / seakeeping", "Purchase price / value", "Resale strength", "Fuel economy"],
    preferred_manufacturers: [],
  }),
  gp("Compact Bay Boat — Mobile Bay", "Small shallow-water buyer — tests weighted activities, normal vs occasional passengers, hard draft, towing ceiling, and compact non-RIB coastal matching.", "bay_boat", {
    boat_size_range: "18_24", operating_area: "Mobile Bay, AL", activities: ["Fishing", "Day cruising"],
    activity_weights: { Fishing: 65, "Day cruising": 35 }, experience_level: "intermediate",
    previously_owned_boats: "16 ft skiff", passenger_count: 4, occasional_passenger_count: 6, family_use: "Kids and friends",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Shallow — under 12 inches", hard_max_draft_ft: 1, towing: "3500 lb tow rating — midsize SUV", tow_capacity_lb: 3500,
    purchase_budget_min: 18000, purchase_budget_max: 35000, annual_ownership_budget: 3000,
    ownership_timeframe: "just_exploring", ownership_horizon: "3_to_7_years",
    must_haves: "Trolling motor capability", preferences: "Shallow draft, Low maintenance",
    unacceptable_compromises: "Deep draft", priorities: ["Fishability", "Safety", "Purchase price / value", "Fuel economy", "Resale strength"],
    preferred_manufacturers: [],
  }),
  gp("Power Catamaran — Outer Banks", "Catamaran cruiser — tests power-cat category and slip-width matching.", "power_catamaran", {
    boat_size_range: "30_40", operating_area: "Outer Banks, NC", activities: ["Overnight cruising", "Day cruising", "Fishing"],
    activity_weights: { "Overnight cruising": 40, "Day cruising": 35, Fishing: 25 }, experience_level: "intermediate",
    previously_owned_boats: "28 ft cabin cruiser", passenger_count: 4, family_use: "Couple only",
    overnight_requirements: "Occasional overnight", storage: "marina_slip", storage_capacity: "40 ft max",
    draft: "Moderate — 12-24 inches", towing: "No — slip kept",
    purchase_budget_min: 120000, purchase_budget_max: 180000, annual_ownership_budget: 15000,
    ownership_timeframe: "6_plus_months", ownership_horizon: "7_to_12_years",
    must_haves: "Cabin with head", preferences: "Fuel efficiency, Stable ride",
    unacceptable_compromises: "Single engine", priorities: ["Ride / seakeeping", "Fuel economy", "Comfort / accommodations", "Build quality & construction", "Safety"],
    preferred_manufacturers: [],
  }),
  gp("Project Boat Buyer — Biloxi", "Open to project boats — tests project-boat tolerance matching.", "project_boat", {
    boat_size_range: "30_40", operating_area: "Biloxi, MS", activities: ["Fishing", "Day cruising"],
    activity_weights: { Fishing: 70, "Day cruising": 30 }, experience_level: "experienced",
    previously_owned_boats: "24 ft center console", passenger_count: 4, family_use: "Kids and friends",
    overnight_requirements: "None — day trips only", storage: "lift_kept", storage_capacity: "6000 lb lift",
    hard_max_overall_length_ft: 36, hard_max_beam_ft: 10.5, hard_max_storage_weight_lb: 6000,
    draft: "Moderate — 12-24 inches", hard_max_draft_ft: 2, towing: "No — lift kept",
    purchase_budget_min: 8000, purchase_budget_max: 15000, annual_ownership_budget: 6000,
    ownership_timeframe: "just_exploring", ownership_horizon: "3_to_7_years",
    must_haves: "Self-bailing cockpit", preferences: "Build quality, Good resale",
    unacceptable_compromises: "Wood construction", priorities: ["Purchase price / value", "Build quality & construction", "Fishability", "Ride / seakeeping", "Resale strength"],
    preferred_manufacturers: [],
    open_to_project_boats: true,
  }),
  gp("Last-Boat Buyer — Florida Keys", "Final purchase — tests longevity and durability weighting.", "last_boat", {
    boat_size_range: "30_40", operating_area: "Florida Keys", activities: ["Fishing", "Overnight cruising", "Day cruising"],
    activity_weights: { Fishing: 50, "Overnight cruising": 30, "Day cruising": 20 }, experience_level: "expert",
    previously_owned_boats: "32 ft express fisherman", passenger_count: 4, family_use: "Couple only",
    overnight_requirements: "Regular weekend overnights", storage: "marina_slip", storage_capacity: "40 ft max",
    draft: "Moderate — 12-24 inches", towing: "No — slip kept",
    purchase_budget_min: 200000, purchase_budget_max: 300000, annual_ownership_budget: 25000,
    ownership_timeframe: "6_plus_months", ownership_horizon: "last_boat",
    must_haves: "Cabin with head, Tuna tower", preferences: "Build quality, Good resale",
    unacceptable_compromises: "Older than 10 years", priorities: ["Build quality & construction", "Ride / seakeeping", "Fishability", "Safety", "Resale strength"],
    preferred_manufacturers: [],
  }),
  gp("Budget-Constrained — $12k Beginner", "Very tight budget — tests low-budget matching and value focus.", "edge_contradiction", {
    boat_size_range: "18_24", operating_area: "Cape Cod, MA", activities: ["Day cruising", "Fishing"],
    activity_weights: { "Day cruising": 55, Fishing: 45 }, experience_level: "beginner",
    previously_owned_boats: "None — first boat", passenger_count: 4, family_use: "Weekend family outings",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Not sure", towing: "3500 lb tow rating — midsize SUV",
    purchase_budget_min: 5000, purchase_budget_max: 12000, annual_ownership_budget: 2000,
    ownership_timeframe: "just_exploring", ownership_horizon: "1_to_3_years",
    must_haves: "", preferences: "Low maintenance, Easy to trailer",
    unacceptable_compromises: "", priorities: ["Purchase price / value", "Fuel economy", "Safety", "Resale strength", "Comfort / accommodations"],
    preferred_manufacturers: [],
  }),
  gp("Large Boat Small Budget — Contradiction", "40-50ft on $25k — tests contradiction detection.", "edge_contradiction", {
    boat_size_range: "40_50", operating_area: "Tampa Bay, FL", activities: ["Fishing", "Overnight cruising"],
    activity_weights: { Fishing: 60, "Overnight cruising": 40 }, experience_level: "intermediate",
    previously_owned_boats: "24 ft cuddy cabin", passenger_count: 6, family_use: "Extended family gatherings",
    overnight_requirements: "Regular weekend overnights", storage: "marina_slip", storage_capacity: "50 ft max",
    draft: "Moderate — 12-24 inches", towing: "No — slip kept",
    purchase_budget_min: 15000, purchase_budget_max: 25000, annual_ownership_budget: 8000,
    ownership_timeframe: "asap", ownership_horizon: "3_to_7_years",
    must_haves: "Cabin with head", preferences: "Good resale",
    unacceptable_compromises: "Wood construction", priorities: ["Purchase price / value", "Comfort / accommodations", "Fishability", "Ride / seakeeping", "Safety"],
    preferred_manufacturers: [],
  }),
  gp("Non-Fishing Day Cruiser — Lake Erie", "No fishing at all — tests non-fishing matching plus a supplied bridge/garage clearance ceiling.", "non_fishing", {
    boat_size_range: "24_30", hard_max_height_ft: 9.5, operating_area: "Lake Erie, OH", activities: ["Day cruising", "Entertaining", "Watersports / tubing"],
    activity_weights: { "Day cruising": 45, Entertaining: 30, "Watersports / tubing": 25 }, experience_level: "intermediate",
    previously_owned_boats: "18 ft bowrider", passenger_count: 6, family_use: "Weekend family outings",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Not sure", towing: "6000 lb tow rating — F-150/half-ton",
    purchase_budget_min: 30000, purchase_budget_max: 50000, annual_ownership_budget: 5000,
    ownership_timeframe: "3_to_6_months", ownership_horizon: "3_to_7_years",
    must_haves: "Bimini top, Swim platform", preferences: "Comfort, Easy to trailer",
    unacceptable_compromises: "Open fishing boat only", priorities: ["Comfort / accommodations", "Safety", "Purchase price / value", "Resale strength", "Fuel economy"],
    preferred_manufacturers: [],
  }),
  gp("Charter Operator — $250k", "Charter buyer — tests charter-class vessel matching.", "charter_operator", {
    boat_size_range: "40_50", operating_area: "Florida Keys", activities: ["Fishing", "Overnight cruising"],
    activity_weights: { Fishing: 70, "Overnight cruising": 30 }, experience_level: "expert",
    previously_owned_boats: "36 ft sportfisherman", passenger_count: 6, family_use: "Extended family gatherings",
    overnight_requirements: "Extended cruising trips", storage: "marina_slip", storage_capacity: "50 ft max",
    draft: "Deep — over 24 inches", towing: "No — slip kept",
    purchase_budget_min: 180000, purchase_budget_max: 250000, annual_ownership_budget: 30000,
    ownership_timeframe: "asap", ownership_horizon: "7_to_12_years",
    must_haves: "Tuna tower, Livewell, Cabin with head", preferences: "Fishability, Good resale",
    unacceptable_compromises: "Older than 15 years", priorities: ["Fishability", "Build quality & construction", "Ride / seakeeping", "Safety", "Resale strength"],
    preferred_manufacturers: [],
    vessel_class: "charter",
  }),
  gp("Step-Up Buyer — 21ft to 30ft", "Moving up in size — tests step-up calibration.", "step_up", {
    boat_size_range: "24_30", operating_area: "Chesapeake Bay, MD", activities: ["Fishing", "Day cruising"],
    activity_weights: { Fishing: 65, "Day cruising": 35 }, experience_level: "intermediate",
    previously_owned_boats: "21 ft center console", passenger_count: 4, family_use: "Kids and friends",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Moderate — 12-24 inches", towing: "6000 lb tow rating — F-150/half-ton",
    purchase_budget_min: 40000, purchase_budget_max: 70000, annual_ownership_budget: 8000,
    ownership_timeframe: "3_to_6_months", ownership_horizon: "3_to_7_years",
    must_haves: "T-top, Livewell", preferences: "Ride quality in chop, Good resale",
    unacceptable_compromises: "Single outboard only", priorities: ["Ride / seakeeping", "Fishability", "Build quality & construction", "Purchase price / value", "Resale strength"],
    preferred_manufacturers: [],
  }),
  gp("Step-Down Buyer — 35ft to 24ft", "Downsizing — tests step-down respect and simplicity focus.", "step_down", {
    boat_size_range: "24_30", operating_area: "Tampa Bay, FL", activities: ["Day cruising", "Fishing"],
    activity_weights: { "Day cruising": 55, Fishing: 45 }, experience_level: "experienced",
    previously_owned_boats: "35 ft express cruiser", passenger_count: 4, family_use: "Couple only",
    overnight_requirements: "Occasional overnight", storage: "marina_slip", storage_capacity: "30 ft max",
    draft: "Moderate — 12-24 inches", towing: "No — slip kept",
    purchase_budget_min: 25000, purchase_budget_max: 40000, annual_ownership_budget: 5000,
    ownership_timeframe: "3_to_6_months", ownership_horizon: "7_to_12_years",
    must_haves: "Cabin with head", preferences: "Low maintenance, Easy to handle",
    unacceptable_compromises: "Twin engine complexity", priorities: ["Purchase price / value", "Fuel economy", "Comfort / accommodations", "Safety", "Resale strength"],
    preferred_manufacturers: [],
  }),
  gp("Trailer-Constrained — Tow Limits", "Trailer with tow limits — tests towing constraint enforcement.", "trailer_constrained", {
    boat_size_range: "24_30", operating_area: "Lake Erie, OH", activities: ["Fishing", "Day cruising"],
    activity_weights: { Fishing: 60, "Day cruising": 40 }, experience_level: "intermediate",
    previously_owned_boats: "20 ft bowrider", passenger_count: 4, family_use: "Kids and friends",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Not sure", towing: "6000 lb tow rating — F-150/half-ton", tow_capacity_lb: 6000,
    purchase_budget_min: 35000, purchase_budget_max: 55000, annual_ownership_budget: 6000,
    ownership_timeframe: "1_to_3_months", ownership_horizon: "3_to_7_years",
    must_haves: "T-top", preferences: "Easy to trailer, Low maintenance",
    unacceptable_compromises: "Over 30 ft", priorities: ["Purchase price / value", "Ride / seakeeping", "Fishability", "Fuel economy", "Safety"],
    preferred_manufacturers: [],
  }),
  gp("Lift-Kept — Weight Limits", "Lift with weight capacity — tests lift-constraint enforcement.", "lift_constrained", {
    boat_size_range: "24_30", operating_area: "Cocoa Beach, FL", activities: ["Fishing", "Day cruising"],
    activity_weights: { Fishing: 70, "Day cruising": 30 }, experience_level: "experienced",
    previously_owned_boats: "22 ft center console", passenger_count: 4, family_use: "Kids and friends",
    overnight_requirements: "None — day trips only", storage: "lift_kept", storage_capacity: "6000 lb lift",
    hard_max_storage_weight_lb: 6000, hard_max_beam_ft: 9.5,
    draft: "Moderate — 12-24 inches", towing: "No — lift kept",
    purchase_budget_min: 60000, purchase_budget_max: 100000, annual_ownership_budget: 10000,
    ownership_timeframe: "1_to_3_months", ownership_horizon: "7_to_12_years",
    must_haves: "Self-bailing cockpit, T-top", preferences: "Ride quality in chop, Fuel efficiency",
    unacceptable_compromises: "Over 6000 lb", priorities: ["Ride / seakeeping", "Fishability", "Build quality & construction", "Purchase price / value", "Safety"],
    preferred_manufacturers: [],
  }),
  gp("Overnight Fishing — Needs Berths", "Fishing + overnight — tests the hardest overnight+fishing combo.", "overnight_cruising", {
    boat_size_range: "30_40", operating_area: "Cape Cod, MA", activities: ["Fishing", "Overnight cruising"],
    activity_weights: { Fishing: 55, "Overnight cruising": 45 }, experience_level: "experienced",
    previously_owned_boats: "24 ft center console", passenger_count: 4, family_use: "Kids and friends",
    overnight_requirements: "Regular weekend overnights", storage: "marina_slip", storage_capacity: "40 ft max",
    draft: "Moderate — 12-24 inches", towing: "No — slip kept",
    purchase_budget_min: 80000, purchase_budget_max: 130000, annual_ownership_budget: 14000,
    ownership_timeframe: "3_to_6_months", ownership_horizon: "7_to_12_years",
    must_haves: "Cabin with head, Berths, Livewell", preferences: "Ride quality in chop, Fishability",
    unacceptable_compromises: "Open console only, No berths", priorities: ["Fishability", "Comfort / accommodations", "Ride / seakeeping", "Build quality & construction", "Safety"],
    preferred_manufacturers: [],
  }),
  gp("Multi-Activity — Fishing + Cruising + Watersports", "Three-way activity split — tests activity-weight balancing.", "multi_activity", {
    boat_size_range: "24_30", operating_area: "Chesapeake Bay, MD", activities: ["Fishing", "Day cruising", "Watersports / tubing"],
    activity_weights: { Fishing: 40, "Day cruising": 35, "Watersports / tubing": 25 }, experience_level: "intermediate",
    previously_owned_boats: "20 ft bowrider", passenger_count: 6, family_use: "Weekend family outings",
    overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
    draft: "Moderate — 12-24 inches", towing: "6000 lb tow rating — F-150/half-ton",
    purchase_budget_min: 45000, purchase_budget_max: 75000, annual_ownership_budget: 7000,
    ownership_timeframe: "3_to_6_months", ownership_horizon: "3_to_7_years",
    must_haves: "Swim platform, Livewell", preferences: "Versatility, Easy to trailer",
    unacceptable_compromises: "Single-purpose boat", priorities: ["Comfort / accommodations", "Fishability", "Purchase price / value", "Ride / seakeeping", "Safety"],
    preferred_manufacturers: [],
  }),
];

// ── Synthetic profile generation ─────────────────────────────────────────────
// Generates varied synthetic profiles for standard batches. Extends the
// existing randomProfile logic from generate-test-profiles with:
//   - non-fishing buyer profiles
//   - project-boat tolerance variation
//   - deliberate edge cases (marked as such)
//   - more realistic activity combinations

const BOAT_SIZE_RANGES = ["under_18", "18_24", "24_30", "30_40", "40_50"];
const EXPERIENCE_LEVELS = ["none", "beginner", "intermediate", "intermediate", "experienced", "expert"];
const STORAGE_TYPES = ["trailer", "marina_slip", "mooring", "dry_stack", "rack_storage", "lift_kept", "private_dock"];
const TIMEFRAMES = ["asap", "1_to_3_months", "3_to_6_months", "6_plus_months", "just_exploring"];
const HORIZONS = ["1_to_3_years", "3_to_7_years", "7_to_12_years", "last_boat"];
const FISHING_ACTIVITIES = ["Fishing", "Offnight cruising", "Diving"];
const NON_FISHING_ACTIVITIES = ["Day cruising", "Overnight cruising", "Watersports / tubing", "Entertaining", "Diving"];
const PRIORITIES = [
  "Build quality & construction", "Ride / seakeeping", "Age / hours & condition",
  "Purchase price / value", "Resale strength", "Fishability",
  "Fuel economy", "Comfort / accommodations", "Service & parts availability", "Safety",
];
const OPERATING_AREAS = [
  "Cape Cod, MA", "Florida Keys", "Tampa Bay, FL", "Chesapeake Bay, MD",
  "Lake Erie, OH", "Texas Gulf Coast", "Puget Sound, WA",
  "Long Island Sound, CT", "Mobile Bay, AL", "Outer Banks, NC",
  "Lake Champlain, VT", "Cocoa Beach, FL", "Venice, LA", "Biloxi, MS",
];
const FAMILY_USE = ["Weekend family outings", "Kids and friends", "Couple only", "Solo fishing", "Extended family gatherings"];
const OVERNIGHT = ["None — day trips only", "Occasional overnight", "Regular weekend overnights", "Extended cruising trips"];
const PREVIOUS_BOATS = ["None", "18 ft bowrider", "21 ft center console", "24 ft cuddy cabin", "16 ft skiff", "None — first boat"];
const MUST_HAVES = ["Self-bailing cockpit", "T-top", "Livewell", "Flush deck", "Cabin with head", "Trolling motor", "Power Pole", "Enclosed head"];
const PREFERENCES = ["Ride quality in chop", "Shallow draft", "Fuel efficiency", "Easy to trailer", "Low maintenance", "Good resale"];
const UNACCEPTABLE = ["Wood construction", "Single outboard only", "No trailer", "High hours", "Older than 15 years", "Sterndrive"];
const TOWING = ["none", "3500 lb tow rating — midsize SUV", "6000 lb tow rating — F-150/half-ton", "10000 lb tow rating — F-250/3/4-ton", "No — slip kept"];
const DRAFT = ["Shallow — under 12 inches", "Moderate — 12-24 inches", "Deep — over 24 inches", "Not sure"];

const pick = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];
const pickN = (arr: string[], n: number) => [...arr].sort(() => Math.random() - 0.5).slice(0, n);
const randInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;

function buildActivityWeights(activities: string[]): Record<string, number> {
  const weights: Record<string, number> = {};
  if (activities.length === 1) {
    weights[activities[0]] = 100;
    return weights;
  }
  const first = randInt(35, 60);
  weights[activities[0]] = first;
  let remaining = 100 - first;
  for (let i = 1; i < activities.length; i++) {
    if (i === activities.length - 1) {
      weights[activities[i]] = remaining;
    } else {
      const w = randInt(10, Math.max(11, Math.floor(remaining / 2)));
      weights[activities[i]] = w;
      remaining -= w;
    }
  }
  return weights;
}

export interface SyntheticProfile {
  profile_data: Record<string, any>;
  is_edge_case: boolean;
  edge_description?: string;
}

export function generateSyntheticProfile(preferredBrands: string[]): SyntheticProfile {
  const roll = Math.random();
  // 15% edge cases, 15% non-fishing, 70% normal
  if (roll < 0.15) {
    return generateEdgeCase(preferredBrands);
  } else if (roll < 0.30) {
    return generateNonFishingProfile(preferredBrands);
  } else {
    return generateNormalProfile(preferredBrands);
  }
}

function generateNormalProfile(preferredBrands: string[]): SyntheticProfile {
  const numActivities = randInt(1, 3);
  const otherActs = pickN(NON_FISHING_ACTIVITIES, numActivities - 1);
  const activities = ["Fishing", ...otherActs];
  const activityWeights = buildActivityWeights(activities);
  const budgetMax = pick([25000, 40000, 60000, 80000, 120000, 180000, 250000]);
  const budgetMin = Math.max(5000, Math.floor(budgetMax * 0.5));
  const storage = pick(STORAGE_TYPES);
  const hasStorageCap = ["marina_slip", "dry_stack", "lift_kept", "private_dock"].includes(storage);
  return {
    profile_data: {
      buyer_role: "buyer",
      vessel_class: pick(["private", "private", "private", "charter", "yacht"]),
      boat_size_range: pick(BOAT_SIZE_RANGES),
      operating_area: pick(OPERATING_AREAS),
      activities,
      activity_weights: activityWeights,
      experience_level: pick(EXPERIENCE_LEVELS),
      previously_owned_boats: pick(PREVIOUS_BOATS),
      passenger_count: randInt(2, 8),
      family_use: pick(FAMILY_USE),
      overnight_requirements: pick(OVERNIGHT),
      storage,
      storage_capacity: hasStorageCap ? pick(["22 ft max", "30 ft max", "40 ft max", "6000 lb lift", "Not sure"]) : "Not sure",
      draft: pick(DRAFT),
      towing: pick(TOWING),
      purchase_budget_min: budgetMin,
      purchase_budget_max: budgetMax,
      annual_ownership_budget: pick([3000, 5000, 8000, 12000, 20000, 35000]),
      ownership_timeframe: pick(TIMEFRAMES),
      ownership_horizon: pick(HORIZONS),
      must_haves: pickN(MUST_HAVES, randInt(1, 3)).join(", "),
      preferences: pickN(PREFERENCES, randInt(1, 2)).join(", "),
      unacceptable_compromises: pickN(UNACCEPTABLE, randInt(0, 2)).join(", "),
      priorities: pickN(PRIORITIES, randInt(4, 6)),
      preferred_manufacturers: preferredBrands.length ? pickN(preferredBrands, randInt(0, 3)) : [],
      open_to_project_boats: Math.random() < 0.15,
      status: "active",
    },
    is_edge_case: false,
  };
}

function generateNonFishingProfile(preferredBrands: string[]): SyntheticProfile {
  const numActivities = randInt(1, 3);
  const activities = pickN(NON_FISHING_ACTIVITIES, numActivities);
  const activityWeights = buildActivityWeights(activities);
  const budgetMax = pick([25000, 40000, 60000, 80000, 120000, 180000]);
  const budgetMin = Math.max(5000, Math.floor(budgetMax * 0.5));
  return {
    profile_data: {
      buyer_role: "buyer",
      vessel_class: pick(["private", "private", "yacht"]),
      boat_size_range: pick(BOAT_SIZE_RANGES),
      operating_area: pick(OPERATING_AREAS),
      activities,
      activity_weights: activityWeights,
      experience_level: pick(EXPERIENCE_LEVELS),
      previously_owned_boats: pick(PREVIOUS_BOATS),
      passenger_count: randInt(2, 8),
      family_use: pick(FAMILY_USE),
      overnight_requirements: pick(OVERNIGHT),
      storage: pick(STORAGE_TYPES),
      storage_capacity: pick(["22 ft max", "30 ft max", "40 ft max", "Not sure"]),
      draft: pick(DRAFT),
      towing: pick(TOWING),
      purchase_budget_min: budgetMin,
      purchase_budget_max: budgetMax,
      annual_ownership_budget: pick([3000, 5000, 8000, 12000, 20000]),
      ownership_timeframe: pick(TIMEFRAMES),
      ownership_horizon: pick(HORIZONS),
      must_haves: pickN(MUST_HAVES.filter(m => m !== "Livewell" && m !== "Trolling motor" && m !== "Power Pole"), randInt(1, 3)).join(", "),
      preferences: pickN(PREFERENCES, randInt(1, 2)).join(", "),
      unacceptable_compromises: pickN(UNACCEPTABLE, randInt(0, 2)).join(", "),
      priorities: pickN(PRIORITIES.filter(p => p !== "Fishability"), randInt(4, 6)),
      preferred_manufacturers: preferredBrands.length ? pickN(preferredBrands, randInt(0, 3)) : [],
      open_to_project_boats: false,
      status: "active",
    },
    is_edge_case: false,
  };
}

function generateEdgeCase(preferredBrands: string[]): SyntheticProfile {
  const edgeType = randInt(0, 3);
  if (edgeType === 0) {
    // Large boat, tiny budget
    return {
      profile_data: {
        buyer_role: "buyer", vessel_class: "private", boat_size_range: "40_50",
        operating_area: pick(OPERATING_AREAS), activities: ["Fishing", "Overnight cruising"],
        activity_weights: { Fishing: 60, "Overnight cruising": 40 }, experience_level: "intermediate",
        previously_owned_boats: "24 ft cuddy cabin", passenger_count: 6, family_use: "Extended family gatherings",
        overnight_requirements: "Regular weekend overnights", storage: "marina_slip", storage_capacity: "50 ft max",
        draft: "Moderate — 12-24 inches", towing: "No — slip kept",
        purchase_budget_min: 10000, purchase_budget_max: 25000, annual_ownership_budget: 8000,
        ownership_timeframe: "asap", ownership_horizon: "3_to_7_years",
        must_haves: "Cabin with head", preferences: "Good resale", unacceptable_compromises: "",
        priorities: ["Purchase price / value", "Comfort / accommodations", "Fishability", "Ride / seakeeping", "Safety"],
        preferred_manufacturers: [], open_to_project_boats: false, status: "active",
      },
      is_edge_case: true,
      edge_description: "Large boat (40-50ft) on very small budget ($25k) — contradiction test",
    };
  } else if (edgeType === 1) {
    // Trailer + 40ft + overnight
    return {
      profile_data: {
        buyer_role: "buyer", vessel_class: "private", boat_size_range: "40_50",
        operating_area: pick(OPERATING_AREAS), activities: ["Overnight cruising", "Day cruising"],
        activity_weights: { "Overnight cruising": 60, "Day cruising": 40 }, experience_level: "intermediate",
        previously_owned_boats: "28 ft cabin cruiser", passenger_count: 4, family_use: "Couple only",
        overnight_requirements: "Regular weekend overnights", storage: "trailer", storage_capacity: "Not sure",
        draft: "Not sure", towing: "Tow vehicle selected, actual rating not yet verified",
        purchase_budget_min: 80000, purchase_budget_max: 120000, annual_ownership_budget: 12000,
        ownership_timeframe: "3_to_6_months", ownership_horizon: "3_to_7_years",
        must_haves: "Cabin with head", preferences: "Easy to trailer", unacceptable_compromises: "Slip required",
        priorities: ["Comfort / accommodations", "Purchase price / value", "Ride / seakeeping", "Safety", "Resale strength"],
        preferred_manufacturers: [], open_to_project_boats: false, status: "active",
      },
      is_edge_case: true,
      edge_description: "40-50ft trailer-stored boat with unknown actual tow rating — verify towing rather than inventing a ceiling; also tests overnight fit",
    };
  } else if (edgeType === 2) {
    // Shallow draft + offshore
    return {
      profile_data: {
        buyer_role: "buyer", vessel_class: "private", boat_size_range: "18_24",
        operating_area: "Florida Keys", activities: ["Fishing"],
        activity_weights: { Fishing: 100 }, experience_level: "expert",
        previously_owned_boats: "16 ft skiff", passenger_count: 2, family_use: "Solo fishing",
        overnight_requirements: "Extended cruising trips", storage: "trailer", storage_capacity: "Not sure",
        draft: "Shallow — under 12 inches", towing: "3500 lb tow rating — midsize SUV",
        purchase_budget_min: 15000, purchase_budget_max: 30000, annual_ownership_budget: 3000,
        ownership_timeframe: "asap", ownership_horizon: "3_to_7_years",
        must_haves: "Cabin with head, Berths", preferences: "Shallow draft",
        unacceptable_compromises: "Deep draft", priorities: ["Fishability", "Comfort / accommodations", "Purchase price / value", "Safety", "Resale strength"],
        preferred_manufacturers: [], open_to_project_boats: false, status: "active",
      },
      is_edge_case: true,
      edge_description: "18-24ft skiff + extended overnight + shallow draft — overnight/draft contradiction test",
    };
  } else {
    // Very high budget, very small boat
    return {
      profile_data: {
        buyer_role: "buyer", vessel_class: "private", boat_size_range: "under_18",
        operating_area: pick(OPERATING_AREAS), activities: ["Day cruising"],
        activity_weights: { "Day cruising": 100 }, experience_level: "expert",
        previously_owned_boats: "16 ft skiff", passenger_count: 2, family_use: "Solo fishing",
        overnight_requirements: "None — day trips only", storage: "trailer", storage_capacity: "Not sure",
        draft: "Shallow — under 12 inches", towing: "3500 lb tow rating — midsize SUV",
        purchase_budget_min: 80000, purchase_budget_max: 150000, annual_ownership_budget: 20000,
        ownership_timeframe: "asap", ownership_horizon: "last_boat",
        must_haves: "", preferences: "Low maintenance", unacceptable_compromises: "",
        priorities: ["Build quality & construction", "Purchase price / value", "Safety", "Resale strength", "Fuel economy"],
        preferred_manufacturers: [], open_to_project_boats: false, status: "active",
      },
      is_edge_case: true,
      edge_description: "Under-18ft boat with $150k budget — budget/size mismatch test",
    };
  }
}