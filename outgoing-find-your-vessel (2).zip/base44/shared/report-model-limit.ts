// Limit Market Match to a distinct, ranked shortlist of three boat models.
// The LLM may return too many entries or duplicate the same make/model with
// different example years. Preserve first-occurrence ranking; never pad.
function identityPart(value: unknown): string {
  return String(value ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

export function limitMarketFinalists(recommendations: unknown): any[] {
  if (!Array.isArray(recommendations)) return [];
  const selected: any[] = [];
  const seen = new Set<string>();
  for (const rec of recommendations) {
    if (!rec || typeof rec !== "object" || Array.isArray(rec)) continue;
    const make = identityPart(rec.make);
    const model = identityPart(rec.model);
    const title = identityPart(rec.title);
    const identity = make && model ? `${make}|${model}` : title;
    if (!identity || seen.has(identity)) continue;
    seen.add(identity);
    selected.push(rec);
    if (selected.length >= 3) break;
  }
  return selected;
}
