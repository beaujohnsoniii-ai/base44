import { IntakeError } from './listing-intake.mjs';

export const SINGLE_SCREENSHOT_POLICY = 'current-top-three-single-screenshot-v1';
export const isSingleScreenshotPolicy = policy => policy?.workspace_kind === 'owner-production' && policy?.submission_policy === SINGLE_SCREENSHOT_POLICY;

// The same stable rank order is used by My Helm and the authoritative intake gate.
// Highlights/tier labels do not grant extra result slots.
const validRank = row => Number.isInteger(Number(row.rank)) && Number(row.rank) > 0;
export function orderedMatchResults(rows) {
  const rank = row => validRank(row) ? Number(row.rank) : Number.MAX_SAFE_INTEGER;
  return [...(rows || [])].sort((a, b) => rank(a) - rank(b) || String(b.created_date || '').localeCompare(String(a.created_date || '')) || String(a.id).localeCompare(String(b.id)));
}
// Legacy unranked rows remain visible, but cannot claim a top-three submission slot.
export const topMatchResults = rows => orderedMatchResults(rows).filter(validRank).slice(0, 3);
export const allIntakeListings = data => [...(data?.listings || []), ...(data?.context_history || []).flatMap(context => context.listings || [])];
export const allListingUploads = listing => [...(listing?.uploads || []), ...(listing?.archived_revisions || []).flatMap(revision => revision.uploads || [])];
export function submissionUsage(data, sourceId) {
  const listings = allIntakeListings(data).filter(l => l.model.source_type === 'suggestion' && l.model.source_id === sourceId);
  const ids = new Set(listings.map(l => l.id));
  const uploads = new Set(listings.filter(l => allListingUploads(l).length > 0).map(l => l.id));
  const readings = new Set(listings.filter(l => allListingUploads(l).some(u => u.read_operation_id || u.extraction || ['reading', 'complete'].includes(u.status))).map(l => l.id));
  for (const operation of data?.operations || []) {
    if (!ids.has(operation.listing_id) && operation.model_source_id !== sourceId) continue;
    if (operation.action === 'upload') uploads.add(operation.listing_id);
    if (operation.action === 'read_screenshot') readings.add(operation.listing_id);
  }
  const slots = new Set(uploads);
  for (const listing of data?.listings || []) if (listing.model.source_type === 'suggestion' && listing.model.source_id === sourceId && listing.status !== 'abandoned') slots.add(listing.id);
  return { uploads, readings, slots };
}
export function assertResultSlot(data, sourceId) {
  if (submissionUsage(data, sourceId).slots.size >= 3) throw new IntakeError('This Match result already has three listing submission slots. Submitted screenshots stay counted, including after Reset.', 409);
}
export function submissionConstraints(ctx, listing) {
  const usage = submissionUsage(ctx.record.data, listing.model.source_id);
  const eligible = listing.model.source_type === 'suggestion' && ctx.topResults?.some(result => result.id === listing.model.source_id);
  const legacy = allListingUploads(listing).length > 1 || (!listing.uploads.length && usage.uploads.has(listing.id));
  const readOnly = Boolean(ctx.stale || !eligible || legacy);
  return {
    read_only: readOnly,
    reason: legacy ? 'Retained earlier evidence is read-only under the one-screenshot-per-submission rule.' : !eligible ? 'This listing stays with an earlier result. Only your top three current Match results accept submissions.' : '',
    screenshot_used: usage.uploads.has(listing.id),
    upload_available: !readOnly && !usage.uploads.has(listing.id) && listing.uploads.length === 0 && usage.slots.size <= 3,
  };
}
export function intakeAllowance(ctx) {
  const operations = ctx.record.data?.operations || [];
  if (!isSingleScreenshotPolicy(ctx.policy)) return {
    screenshots_remaining: Math.max(0, ctx.policy.max_uploads - operations.filter(o => o.action === 'upload').length),
    readings_remaining: Math.max(0, ctx.policy.max_extractions - operations.filter(o => o.action === 'read_screenshot').length),
  };
  const byResult = (ctx.topResults || []).map(result => {
    const usage = submissionUsage(ctx.record.data, result.id);
    return { source_id: result.id, title: result.title, rank: result.rank, listing_slots_used: usage.slots.size, listing_slots_remaining: Math.max(0, 3 - usage.slots.size), screenshots_used: usage.uploads.size, screenshots_remaining: Math.max(0, 3 - usage.uploads.size), readings_remaining: Math.max(0, 3 - usage.readings.size) };
  });
  return {
    scope: 'current_top_three_results', unavailable: Boolean(ctx.resultOrderError), error: ctx.resultOrderError || '', images_per_listing: 1, listings_per_result: 3,
    result_limit: 3, screenshots_limit: 9, by_result: byResult,
    eligible_result_ids: byResult.map(result => result.source_id),
    screenshots_remaining: byResult.reduce((sum, result) => sum + result.screenshots_remaining, 0),
    readings_remaining: byResult.reduce((sum, result) => sum + result.readings_remaining, 0),
  };
}
export function withIntakeAllowance(ctx, result) {
  const single = isSingleScreenshotPolicy(ctx.policy);
  return { ...result,
    ...(single && result.listings ? { listings: result.listings.map(listing => ({ ...listing, submission: submissionConstraints(ctx, listing) })) } : {}),
    allowance: intakeAllowance(ctx),
  };
}
