import { createClientFromRequest } from 'npm:@base44/sdk@0.8.57';
import { IntakeError, INTAKE_LIMITS } from './listing-intake.mjs';
import { loadIntakeContext, runIntakeAction } from './listing-intake-service.mjs';
import { withIntakeAllowance, isSingleScreenshotPolicy } from './listing-intake-allowance.mjs';

const headers = { 'Cache-Control': 'no-store' };
async function boundedBody(req) {
  const maximum = INTAKE_LIMITS.image_bytes + 32768;
  if (Number(req.headers.get('content-length')) > maximum) throw new IntakeError('Screenshot request is too large.', 413);
  const reader = req.body?.getReader(); if (!reader) throw new IntakeError('Request body is required.');
  let size = 0; const chunks = [];
  while (true) { const next = await reader.read(); if (next.done) break; size += next.value.length; if (size > maximum) { await reader.cancel(); throw new IntakeError('Screenshot request is too large.', 413); } chunks.push(next.value); }
  const bytes = new Uint8Array(size); let offset = 0; for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  const contentType = req.headers.get('content-type') || '';
  if (contentType.startsWith('multipart/form-data')) {
    const form = await new Response(bytes, { headers: { 'Content-Type': contentType } }).formData();
    const body = {}; for (const [name, value] of form.entries()) { if (Object.hasOwn(body, name)) throw new IntakeError('Duplicate request field.'); body[name] = value; }
    return body;
  }
  if (!contentType.startsWith('application/json') || size > 32768) throw new IntakeError('Invalid review request.');
  try { return JSON.parse(new TextDecoder().decode(bytes)); } catch { throw new IntakeError('Invalid review request.'); }
}
export function createIntakeHandler(policy, dataEnv, allowedCaller) {
return async function handler(req) {
  if (req.method !== 'POST') return Response.json({ error: 'Method not allowed' }, { status: 405, headers });
  try {
    // Environment is fixed by the server entry, never selected by request input.
    // Preserve platform authentication; dispatch can strip caller environment headers.
    const scopedHeaders = new Headers(req.headers);
    scopedHeaders.set('X-Data-Env', dataEnv);
    const client = createClientFromRequest(new Request(req.url, { headers: scopedHeaders }));
    let user; try { user = await client.auth.me(); } catch { return Response.json({ error: 'Sign in first.' }, { status: 401, headers }); }
    if (!user?.id) return Response.json({ error: 'Sign in first.' }, { status: 401, headers });
    if (!allowedCaller(user, policy, dataEnv)) return Response.json({ error: 'Private listing review is unavailable.' }, { status: 403, headers });
    const body = await boundedBody(req);
    if (isSingleScreenshotPolicy(policy) && Number(body.client_contract) !== 2 && body.action !== 'preview_source') throw new IntakeError('Listing submission rules have changed. Refresh the My Helm page once to load the one-screenshot-per-listing controls. Your saved drafts and screenshots are unchanged.', 409);
    const context = await loadIntakeContext(client, user, policy);
    const result = await runIntakeAction(context, body);
    return Response.json({ ...withIntakeAllowance(context, result), integrations_enabled: policy.integrations_enabled, workspace_kind: policy.workspace_kind || 'dev-stage' }, { headers });
  } catch (error) {
    // Do not expose raw SDK/provider errors, credentials, file URIs or signed URLs.
    return Response.json({ error: error instanceof IntakeError ? error.message : 'Listing review could not be confirmed. Reload to check the saved state before retrying.' }, { status: error instanceof IntakeError ? error.status : 503, headers });
  }
};
}
