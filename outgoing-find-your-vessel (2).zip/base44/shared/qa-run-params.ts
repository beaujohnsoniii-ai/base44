// Bound admin MATCH QA requests before any paid LLM work or database writes.
// 0 max_profiles means use the requested mode's ordinary batch size.
export const QA_MODES = ["golden", "standard", "mixed"] as const;

export function normalizeQARunParams(input: Record<string, unknown>) {
  const mode = typeof input.mode === "string" ? input.mode : "golden";
  if (!(QA_MODES as readonly string[]).includes(mode)) {
    throw new RangeError("Invalid QA mode; choose golden, standard, or mixed.");
  }
  const asBoundedInteger = (value: unknown, fallback: number, min: number, max: number) => {
    if (value === undefined || value === null || value === "") return fallback;
    const n = Number(value);
    if (!Number.isFinite(n) || !Number.isInteger(n) || n < min || n > max) {
      throw new RangeError("QA batch/profile limit must be a whole number within the permitted range.");
    }
    return n;
  };
  return {
    mode,
    batchSize: asBoundedInteger(input.batch_size, 25, 1, 50),
    maxProfiles: asBoundedInteger(input.max_profiles, 0, 0, 50),
    notes: String(input.notes ?? "").slice(0, 500),
  };
}
