import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { paidWindowIsActive } from './paid-access.ts';

const now = Date.parse('2026-10-14T12:00:00Z');

test('a paid window with future expiration is active', () => {
  assert.equal(paidWindowIsActive('2026-10-14T12:00:01Z', now), true);
});

test('an expired or exactly elapsed window cannot generate a paid report', () => {
  assert.equal(paidWindowIsActive('2026-10-14T11:59:59Z', now), false);
  assert.equal(paidWindowIsActive('2026-10-14T12:00:00Z', now), false);
});

test('malformed expiration fails closed', () => {
  assert.equal(paidWindowIsActive('not a date', now), false);
  assert.equal(paidWindowIsActive(42, now), false);
});

test('legacy records without an expiration retain existing entitlement semantics', () => {
  assert.equal(paidWindowIsActive(null, now), true);
  assert.equal(paidWindowIsActive('', now), true);
});

test('paid generation and listing/advisory endpoints share fail-closed expiry validation', () => {
  for (const endpoint of ['suggest-boats', 'analyze-references', 'analyze-saved-boat', 'generate-advisory']) {
    const implementation = endpoint === 'suggest-boats' ? './suggest-boats-handler.ts' : '../functions/' + endpoint + '/entry.ts';
    const code = readFileSync(new URL(implementation, import.meta.url), 'utf8');
    assert.match(code, /paidWindowIsActive\(/, endpoint + ' must use the shared expiry guard');
    assert.doesNotMatch(code, /!expiresAt\s*\|\|\s*new Date\(expiresAt\)/, endpoint + ' must not duplicate expiry logic');
  }
});

test('editable questionnaire tier never grants paid MATCH access to a regular user', () => {
  const code = readFileSync(new URL('./suggest-boats-handler.ts', import.meta.url), 'utf8');
  assert.match(code, /adminTesting\s*=\s*user\.role\s*===\s*["']admin["']/);
  assert.match(code, /rawPlan:\s*string\s*=\s*adminTesting\s*&&[\s\S]*?testTier[\s\S]*?:\s*String\(\(user as any\)\.plan/);
  assert.match(code, /isWindowValid\s*=\s*adminTesting\s*\|\|\s*paidWindowIsActive\(planExpires\)/);
  assert.doesNotMatch(code, /isWindowValid\s*=\s*true/);
});

test('paid MATCH refreshes are metered for real buyers but not admin QA', () => {
  const code = readFileSync(new URL('./suggest-boats-handler.ts', import.meta.url), 'utf8');
  assert.match(code, /shouldMeterRefresh\s*=\s*!adminTesting\s*&&\s*refresh\s*&&\s*!isFirstPaidGeneration\s*&&\s*!isFreeContradictionRerun/);
  assert.doesNotMatch(code, /shouldMeterRefresh\s*=\s*false/);
  assert.match(code, /if\s*\(shouldMeterRefresh\s*&&\s*updatesUsed\s*>=\s*updatesLimit\)/);
  assert.match(code, /if\s*\(isFirstPaidGeneration\s*&&\s*!adminTesting\)/);
});
