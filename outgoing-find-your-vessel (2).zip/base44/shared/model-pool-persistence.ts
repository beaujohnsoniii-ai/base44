// Persist an entire new recommendation pool before retiring the previous one.
// Base44 entity writes are not a transaction, so compensate for known successful
// inserts if a later insert fails. Never delete the buyer's existing pool here.
export async function createReplacementPool<T, R extends { id?: string }>(
  candidates: T[],
  create: (candidate: T) => Promise<R>,
  remove: (id: string) => Promise<unknown>,
): Promise<R[]> {
  const created: R[] = [];
  try {
    for (const candidate of candidates) {
      const record = await create(candidate);
      if (!record?.id) {
        throw new Error("Suggestion insert returned no ID; pool cannot be safely finalized.");
      }
      created.push(record);
    }
    return created;
  } catch (cause) {
    // Reverse creation order and attempt every rollback even if a delete fails.
    // This is best-effort compensation, not an atomic database transaction.
    const cleanup = await Promise.allSettled(
      [...created].reverse().map((record) => remove(record.id!)),
    );
    if (cleanup.some((result) => result.status === "rejected")) {
      throw new Error(
        "Recommendation pool save failed and cleanup was incomplete. Inspect the buyer's suggestions before retrying.",
        { cause },
      );
    }
    throw cause;
  }
}
