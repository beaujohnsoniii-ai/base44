import { pastLikesEnabled } from "./liked-preferences.mjs";
import { DEFAULT_FIELD_TIERS } from "./question-tier-defaults.mjs";
const extraFields = ["hard_max_overall_length_ft", "hard_max_beam_ft", "hard_max_height_ft", "hard_max_storage_weight_lb", "hard_max_draft_ft", "tow_capacity_lb", "match_question_tier", "match_context_id"];
function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map(key => [key, stable(value[key])]));
  return value;
}
// Explicit Likes are stored separately and scoped to this exact answer context.
export async function profileInputFingerprint(profile) {
  const keys = [...Object.keys(DEFAULT_FIELD_TIERS), ...extraFields].sort();
  const inputs = Object.fromEntries(keys.map(key => [key, profile[key] ?? null]));
  if (pastLikesEnabled(profile)) inputs.use_past_likes = true;
  const bytes = new TextEncoder().encode(JSON.stringify(stable(inputs)));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, "0")).join("");
}
