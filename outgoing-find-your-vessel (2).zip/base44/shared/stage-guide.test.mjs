import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const guide = JSON.parse(readFileSync(new URL("../agents/stage_guide.jsonc", import.meta.url), "utf8"));

test("Stage Guide reflects the four currently displayed package prices", () => {
  assert.match(guide.description, /Free Discovery \(\$0\)/);
  assert.match(guide.description, /MATCH\+ \(\$9\)/);
  assert.match(guide.description, /Refined Match \(\$29 total\)/);
  assert.match(guide.description, /Market Match \(\$99 total\)/);
  assert.match(guide.instructions, /\$20 to upgrade from MATCH\+/);
  assert.match(guide.instructions, /\$90 from MATCH\+ or \$70 from Refined Match/);
  assert.doesNotMatch(guide.instructions, /\n2\. Find My Boat \(\$30/);
  assert.doesNotMatch(guide.instructions, /\n3\. Buy With Confidence/);
});

test("Stage Guide guards model-versus-listing and checkout claims", () => {
  assert.match(guide.instructions, /boat MODELS first/);
  assert.match(guide.instructions, /do not claim payment works|not available to purchase/i);
  assert.match(guide.instructions, /catalog-verified until actual evidence integration/);
  assert.ok(guide.tool_configs.every(t => t.allowed_operations.every(op => op === "read")));
});
