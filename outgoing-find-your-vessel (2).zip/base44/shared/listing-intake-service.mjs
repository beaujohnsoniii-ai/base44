import { INTAKE_LIMITS, IntakeError, SCREENSHOT_SCHEMA, assertCurrentContext, digest, draftListing, exactListingReference, mergedListingEvidence, reviewListingIdentity, newListing, normalizeScreenshotExtraction, confirmListing, reopenListing, abandonEmptyListing, restoreEmptyListing, resetListing, safeRecordData } from './listing-intake.mjs';
import { profileInputFingerprint } from './profile-input-fingerprint.mjs';
import { DEFAULT_FIELD_TIERS } from './question-tier-defaults.mjs';
import { isSingleScreenshotPolicy, topMatchResults, submissionUsage, submissionConstraints, assertResultSlot } from './listing-intake-allowance.mjs';

const clone = v => JSON.parse(JSON.stringify(v));
const denied = (message, status = 403) => { throw new IntakeError(message, status); };
const text = v => typeof v === 'string' ? v.trim() : '';
const idPattern = /^[a-zA-Z0-9_-]{8,80}$/;
const id = v => { if (!idPattern.test(v || '')) denied('Invalid review identifier.', 400); return v; };
export function profileSnapshot(profile) {
  const fields = [...Object.keys(DEFAULT_FIELD_TIERS), 'hard_max_overall_length_ft', 'hard_max_beam_ft', 'hard_max_height_ft', 'hard_max_storage_weight_lb', 'hard_max_draft_ft', 'tow_capacity_lb', 'match_question_tier', 'match_context_id', 'use_past_likes', 'past_likes_context_id'];
  return Object.fromEntries([...new Set(fields)].map(key => [key, profile[key] ?? null]));
}
export function allowedStageCaller(user, policy, dataEnv) {
  return policy.enabled === true && dataEnv === 'dev' && Boolean(policy.record_id) && user?.id === policy.owner_id && user?.app_id === policy.app_id && user?.role === 'admin' && user?.is_service !== true && user?.disabled !== true;
}
export function allowedOwnerTrialCaller(user, policy, dataEnv) {
  return policy.enabled === true && policy.workspace_kind === 'owner-production' && dataEnv === 'prod' && Boolean(policy.record_id) && Boolean(policy.workspace_label) && user?.id === policy.owner_id && user?.app_id === policy.app_id && user?.role === 'admin' && user?.is_service !== true && user?.disabled !== true;
}
async function currentTopResults(client, user, profile, fingerprint) {
  const rows = await client.entities.SuggestedBoat.filter({ created_by_id: user.id, buyer_profile_id: profile.id, profile_input_fingerprint: fingerprint }, 'rank', 100);
  if (!Array.isArray(rows) || rows.length >= 100) denied('Current result order could not be verified. Reload your Match results.', 409);
  return topMatchResults(rows.filter(row => row.created_by_id === user.id && row.buyer_profile_id === profile.id && row.profile_input_fingerprint === fingerprint && !row.superseded && !row.test_profile_id));
}
export async function loadIntakeContext(client, user, policy) {
  const profile = (await client.entities.BuyerProfile.filter({ created_by_id: user.id }, '-created_date', 1))?.[0];
  if (!profile || profile.created_by_id !== user.id) denied('Save your Match profile before reviewing listings.', 409);
  const record = await client.asServiceRole.entities.ListingIntake.get(policy.record_id);
  const fingerprint = await profileInputFingerprint(profile);
  if (policy.workspace_kind === 'owner-production') {
    if (record?.stage_fixture !== false || record.fixture_label !== policy.workspace_label || record.id !== policy.record_id) denied('Private owner review is unavailable.');
  } else if (record?.stage_fixture !== true) denied('Private review staging is unavailable.');
  if (record.owner_id !== user.id) denied('Listing review is unavailable.');
  const stale = record.buyer_profile_id !== profile.id || record.profile_fingerprint !== fingerprint;
  let topResults = [], resultOrderError = '';
  if (isSingleScreenshotPolicy(policy)) {
    try { topResults = await currentTopResults(client, user, profile, fingerprint); }
    catch (error) { if (!(error instanceof IntakeError) || error.status !== 409) throw error; resultOrderError = error.message; }
  }
  return { client, user, policy, profile, fingerprint, record, stale, topResults, resultOrderError };
}
export async function assertStillCurrent(ctx) {
  const profiles = await ctx.client.entities.BuyerProfile.filter({ created_by_id: ctx.user.id }, '-created_date', 1);
  const profile = profiles?.[0];
  const fingerprint = profile ? await profileInputFingerprint(profile) : '';
  assertCurrentContext(ctx.record, ctx.user, profile, fingerprint);
  if (isSingleScreenshotPolicy(ctx.policy) && ctx.writeSourceId) {
    ctx.topResults = await currentTopResults(ctx.client, ctx.user, profile, fingerprint);
    if (!ctx.topResults.some(result => result.id === ctx.writeSourceId)) denied('This result is no longer in your current top three. Reload your Match results; its evidence is retained.', 409);
  }
}
export function intakePublicView(record) {
  const data = clone(record.data || { listings: [], operations: [] });
  for (const listing of [...data.listings, ...(data.context_history || []).flatMap(context => context.listings)]) {
    for (const upload of [...listing.uploads, ...(listing.archived_revisions || []).flatMap(revision => revision.uploads)]) delete upload.file_uri;
    listing.evidence = mergedListingEvidence(listing);
  }
  return { schema_version: 1, record_id: record.id, revision: record.revision, buyer_profile_id: record.buyer_profile_id, profile_fingerprint: record.profile_fingerprint, listings: data.listings, context_history: data.context_history || [], operations: data.operations, staging: true, assessment_enabled: false };
}
export async function commitIntake(ctx, next) {
  await assertStillCurrent(ctx);
  const revision = ctx.record.revision;
  if (!Number.isSafeInteger(revision)) denied('Review version is unavailable.', 409);
  const result = await ctx.client.asServiceRole.entities.ListingIntake.updateMany(
    { id: ctx.record.id, owner_id: ctx.user.id, buyer_profile_id: ctx.profile.id, profile_fingerprint: ctx.fingerprint, revision },
    { $set: { data: safeRecordData(next), revision: revision + 1 } },
  );
  if (result?.updated !== 1) denied('Another update arrived first. Reload the saved review before trying again.', 409);
  const confirmed = await ctx.client.asServiceRole.entities.ListingIntake.get(ctx.record.id);
  if (confirmed.owner_id !== ctx.user.id || confirmed.revision < revision + 1) denied('Save was not confirmed. Reload the saved review before trying again.', 503);
  ctx.record = confirmed;
  return intakePublicView(confirmed);
}
// A new profile context starts blank only after the owner explicitly chooses a
// server-validated current Match result. Prior evidence never becomes current.
async function startCurrentContext(ctx, body) {
  if (ctx.policy.workspace_kind !== 'owner-production' || body.model_type !== 'suggestion') denied('Open a current Match result to start a new listing review.', 409);
  let model = await resolveIntakeModel(ctx, body.model_type, body.model_id);
  const start = await beginOperation(ctx, body);
  if (start.replay) return { ...replayResponse(ctx, start.operation), context_stale: ctx.stale === true, model };
  if (!ctx.stale) denied('This review already uses your current Match answers. Reload it to continue.', 409);
  const latest = (await ctx.client.entities.BuyerProfile.filter({ created_by_id: ctx.user.id }, '-created_date', 1))?.[0];
  assertCurrentContext({ ...ctx.record, buyer_profile_id: ctx.profile.id, profile_fingerprint: ctx.fingerprint }, ctx.user, latest, latest ? await profileInputFingerprint(latest) : '');
  model = await resolveIntakeModel(ctx, body.model_type, body.model_id);
  let data = start.data;
  data.context_history = [...(data.context_history || []), {
    id: body.operation_id, buyer_profile_id: ctx.record.buyer_profile_id,
    profile_fingerprint: ctx.record.profile_fingerprint, archived_at: new Date().toISOString(),
    listings: data.listings,
  }];
  data.listings = [];
  if (isSingleScreenshotPolicy(ctx.policy)) assertResultSlot(data, model.source_id);
  data = newListing(data, model, id(body.listing_id), '', new Date().toISOString(), isSingleScreenshotPolicy(ctx.policy) ? ctx.topResults.map(result => result.id) : false);
  // Keep every operation in one lifetime ledger; Reset never refills allowances.
  const revision = ctx.record.revision;
  if (!Number.isSafeInteger(revision)) denied('Review version is unavailable.', 409);
  const result = await ctx.client.asServiceRole.entities.ListingIntake.updateMany(
    { id: ctx.record.id, owner_id: ctx.user.id, buyer_profile_id: ctx.record.buyer_profile_id, profile_fingerprint: ctx.record.profile_fingerprint, revision },
    { $set: { buyer_profile_id: ctx.profile.id, profile_fingerprint: ctx.fingerprint, data: safeRecordData(data), revision: revision + 1 } },
  );
  if (result?.updated !== 1) denied('Another update arrived first. Reload the saved review before trying again.', 409);
  const confirmed = await ctx.client.asServiceRole.entities.ListingIntake.get(ctx.record.id);
  if (confirmed.owner_id !== ctx.user.id || confirmed.revision < revision + 1 || confirmed.buyer_profile_id !== ctx.profile.id || confirmed.profile_fingerprint !== ctx.fingerprint) denied('Context change was not confirmed. Reload the saved review before trying again.', 503);
  ctx.record = confirmed;
  // The profile is a different entity: a simultaneous Reset may happen after
  // validation. Preserve the committed binding, but never report it as current.
  const currentProfile = (await ctx.client.entities.BuyerProfile.filter({ created_by_id: ctx.user.id }, '-created_date', 1))?.[0];
  ctx.stale = !currentProfile || currentProfile.created_by_id !== ctx.user.id || currentProfile.id !== confirmed.buyer_profile_id || await profileInputFingerprint(currentProfile) !== confirmed.profile_fingerprint;
  return { ...intakePublicView(confirmed), context_stale: ctx.stale, model };
}
export async function resolveIntakeModel(ctx, type, sourceId) {
  if (!['suggestion', 'saved'].includes(type)) denied('Invalid model source.', 400);
  const source = await ctx.client.entities[type === 'suggestion' ? 'SuggestedBoat' : 'SavedBoat'].get(id(sourceId));
  if (!source || source.id !== sourceId || source.created_by_id !== ctx.user.id || source.test_profile_id) denied('That model is unavailable.');
  if (type === 'suggestion' && (source.superseded || source.buyer_profile_id !== ctx.profile.id || source.profile_input_fingerprint !== ctx.fingerprint)) denied('That Match result belongs to earlier answers. Open a current model instead.', 409);
  if (isSingleScreenshotPolicy(ctx.policy)) ctx.topResults = await currentTopResults(ctx.client, ctx.user, ctx.profile, ctx.fingerprint);
  if (isSingleScreenshotPolicy(ctx.policy) && (type !== 'suggestion' || !ctx.topResults.some(result => result.id === source.id))) denied('Only your top three current Match results accept listing submissions. Earlier evidence stays read-only.', 409);
  if (isSingleScreenshotPolicy(ctx.policy)) ctx.writeSourceId = source.id;
  // SavedBoat identity remains the buyer's stored model, not a newly generated recommendation.
  const make = text(source.make), model = text(source.model);
  if (!make || !model) denied('This model does not have a complete make and model.', 409);
  const modelKey = [make, model, source.year || ''].map(v => String(v).toLowerCase().replace(/[^a-z0-9]/g, '')).join(':');
  return { source_type: type, source_id: source.id, model_key: modelKey, make, model, year: source.year || null, title: text(source.title) || [make, model].join(' ') };
}
function validateRequest(body, extras = []) {
  const allowed = new Set(['action', 'operation_id', 'revision', 'listing_id', 'model_type', 'model_id', 'reference_url', 'field', 'choice', 'note', 'upload_id', 'file', 'reset_confirmed', 'client_contract', ...extras]);
  if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).some(k => !allowed.has(k))) denied('Unsupported review request fields.', 400);
}
async function operationDigest(body, fileHash) {
  const { operation_id, revision, file, client_contract, ...input } = body;
  return digest({ ...input, file_sha256: fileHash || null });
}
async function beginOperation(ctx, body, { fileHash, reservation } = {}) {
  id(body.operation_id);
  const payloadHash = await operationDigest(body, fileHash);
  const existing = ctx.record.data?.operations?.find(o => o.id === body.operation_id);
  if (existing) {
    if (existing.payload_digest !== payloadHash) denied('That operation was already used for different input.', 409);
    return { replay: true, operation: existing, data: clone(ctx.record.data) };
  }
  if (Number(body.revision) !== ctx.record.revision) denied('Your review changed in another tab. Reload it first.', 409);
  if ((ctx.record.data?.operations || []).some(o => ['reserved', 'uncertain'].includes(o.status))) denied('An earlier operation is still unconfirmed. Reload to check it; no automatic retry was made.', 409);
  if ((ctx.record.data?.operations || []).length >= 250) denied('Review operation limit reached. Existing evidence is retained.', 409);
  const data = clone(ctx.record.data || { listings: [], operations: [] });
  const operation = { id: body.operation_id, action: body.action, listing_id: body.listing_id || null, ...(isSingleScreenshotPolicy(ctx.policy) ? { model_source_id: data.listings.find(listing => listing.id === body.listing_id)?.model.source_id || body.model_id || null } : {}), payload_digest: payloadHash, status: reservation ? 'reserved' : 'complete', started_at: new Date().toISOString() };
  data.operations.push(operation);
  if (reservation) reservation(data, operation);
  return { replay: false, operation, data };
}
function replayResponse(ctx, operation) {
  return { ...intakePublicView(ctx.record), replayed: true, operation_status: operation.status };
}
async function finishExternal(ctx, operationId, mutate) {
  // Reconcile the saved operation before writing an already-obtained external result.
  // Never repeat the integration to recover a failed database update.
  ctx.record = await ctx.client.asServiceRole.entities.ListingIntake.get(ctx.record.id);
  if (ctx.record.owner_id !== ctx.user.id) denied('Review unavailable.');
  const data = clone(ctx.record.data), operation = data.operations.find(o => o.id === operationId);
  if (!operation || operation.status !== 'reserved') denied('Operation completion needs review. No integration was retried.', 409);
  mutate(data, operation); operation.finished_at = new Date().toISOString();
  return commitIntake(ctx, data);
}
async function markUncertain(ctx, operationId, stage) {
  try { return await finishExternal(ctx, operationId, (data, operation) => {
    operation.status = 'uncertain'; operation.stage = stage;
    const upload = data.listings.find(l => l.id === operation.listing_id)?.uploads.find(u => u.operation_id === operationId || u.read_operation_id === operationId);
    if (upload) upload.status = 'uncertain';
  }); } catch { return null; }
}
export async function validateScreenshot(file) {
  if (!file || typeof file.arrayBuffer !== 'function' || !['image/jpeg', 'image/png'].includes(file.type) || file.size < 32 || file.size > INTAKE_LIMITS.image_bytes) denied('Choose a JPEG or PNG screenshot up to 6 MB.', 400);
  const bytes = new Uint8Array(await file.arrayBuffer());
  if (bytes.length !== file.size || bytes.length > INTAKE_LIMITS.image_bytes) denied('Screenshot byte size is invalid.', 400);
  const isPng = bytes.slice(0, 8).every((n, i) => n === [137,80,78,71,13,10,26,10][i]);
  const isJpeg = bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
  if ((file.type === 'image/png' && !isPng) || (file.type === 'image/jpeg' && !isJpeg)) denied('The file contents do not match a supported screenshot.', 400);
  let width = 0, height = 0;
  if (isPng) { const view = new DataView(bytes.buffer); width = view.getUint32(16); height = view.getUint32(20); }
  else {
    let i = 2;
    while (i + 9 < bytes.length) {
      if (bytes[i] !== 255) { i++; continue; }
      const marker = bytes[i + 1]; if (marker === 218 || marker === 217) break;
      if (marker === 216 || marker === 1 || marker >= 208 && marker <= 215) { i += 2; continue; }
      const length = bytes[i + 2] * 256 + bytes[i + 3]; if (length < 2) break;
      if ([192,193,194,195,197,198,199,201,202,203,205,206,207].includes(marker)) { height = bytes[i + 5] * 256 + bytes[i + 6]; width = bytes[i + 7] * 256 + bytes[i + 8]; break; }
      i += length + 2;
    }
  }
  if (!width || !height || width * height > INTAKE_LIMITS.image_pixels || width > 16000 || height > 16000) denied('Screenshot dimensions are unsupported or too large.', 400);
  return { bytes, sha256: await digest(bytes), width, height, mime: file.type, name: text(file.name).replace(/[\x00-\x1f<>]/g, '').slice(0, 160) || 'screenshot' };
}
async function assertSubmissionTarget(ctx, body) {
  if (!isSingleScreenshotPolicy(ctx.policy)) return;
  const listing = ctx.record.data?.listings.find(entry => entry.id === body.listing_id);
  if (!listing) denied('Listing not found.', 404);
  await resolveIntakeModel(ctx, listing.model.source_type, listing.model.source_id);
  const constraints = submissionConstraints(ctx, listing);
  if (constraints.read_only) denied(constraints.reason || 'This listing context is read-only.', 409);
}
export async function runIntakeAction(ctx, body) {
  validateRequest(body);
  if (body.action === 'read') return { ...intakePublicView(ctx.record), context_stale: ctx.stale === true };
  if (body.action === 'model') return { ...intakePublicView(ctx.record), context_stale: ctx.stale === true, context_transition_available: ctx.stale === true && ctx.policy.workspace_kind === 'owner-production' && body.model_type === 'suggestion', model: await resolveIntakeModel(ctx, body.model_type, body.model_id) };
  if (body.action === 'start_current_context') return startCurrentContext(ctx, body);
  if (body.action === 'preview_source') {
    const listing = [...(ctx.record.data?.listings || []), ...(ctx.record.data?.context_history || []).flatMap(context => context.listings)].find(l => l.id === id(body.listing_id));
    const upload = listing && [...listing.uploads, ...(listing.archived_revisions || []).flatMap(revision => revision.uploads)].find(u => u.id === id(body.upload_id));
    if (!upload?.file_uri || !upload.file_uri.startsWith(`mp/private/${ctx.policy.app_id}/`)) denied('Screenshot unavailable.', 404);
    const signed = await ctx.client.asServiceRole.integrations.Core.CreateFileSignedUrl({ file_uri: upload.file_uri, expires_in: 60 });
    if (typeof signed?.signed_url !== 'string') denied('Screenshot preview unavailable.', 503);
    return { preview_url: signed.signed_url, expires_in: 60 }; // Deliberate private owner-only display; never stored or logged.
  }
  if (body.action === 'upload' || body.action === 'read_screenshot') {
    await assertSubmissionTarget(ctx, body);
    return body.action === 'upload' ? uploadScreenshot(ctx, body) : readScreenshot(ctx, body);
  }
  if (!['add_listing', 'save_reference', 'resolve_field', 'review_identity', 'confirm', 'reopen', 'abandon_empty', 'restore_empty', 'reset_listing'].includes(body.action)) denied('Unsupported review action.', 400);
  const start = await beginOperation(ctx, body);
  if (start.replay) return replayResponse(ctx, start.operation);
  if (body.action !== 'add_listing') await assertSubmissionTarget(ctx, body);
  let data = start.data;
  const now = new Date().toISOString();
  if (body.action === 'add_listing') {
    const model = await resolveIntakeModel(ctx, body.model_type, body.model_id);
    if (isSingleScreenshotPolicy(ctx.policy)) assertResultSlot(data, model.source_id);
    data = newListing(data, model, id(body.listing_id), body.reference_url || '', now, isSingleScreenshotPolicy(ctx.policy) ? ctx.topResults.map(result => result.id) : false);
  } else if (body.action === 'abandon_empty') data = abandonEmptyListing(data, id(body.listing_id), now);
  else if (body.action === 'restore_empty') {
    if (isSingleScreenshotPolicy(ctx.policy)) assertResultSlot(data, data.listings.find(listing => listing.id === body.listing_id).model.source_id);
    data = restoreEmptyListing(data, id(body.listing_id), now, isSingleScreenshotPolicy(ctx.policy) ? ctx.topResults.map(result => result.id) : false);
  }
  else if (body.action === 'reset_listing') {
    const listing = data.listings.find(entry => entry.id === body.listing_id);
    if (isSingleScreenshotPolicy(ctx.policy) && submissionUsage(data, listing.model.source_id).uploads.has(listing.id)) denied('This submission already used its one screenshot. Reset does not refill it; use another listing slot for this result.', 409);
    data = resetListing(data, id(body.listing_id), body.reset_confirmed === true, now);
  }
  else if (body.action === 'reopen') data = reopenListing(data, id(body.listing_id));
  else {
    const listing = draftListing(data, id(body.listing_id));
    if (body.action === 'save_reference') { const url = exactListingReference(body.reference_url); if (url && data.listings.some(l => l.id !== listing.id && l.reference_url === url)) denied('That listing link is already saved on another card.', 409); listing.reference_url = url; listing.reference_provenance = url ? 'buyer_saved_reference' : null; }
    if (body.action === 'resolve_field') {
      const entry = mergedListingEvidence(listing).fields[body.field];
      if (!entry || !['unknown', ...entry.candidates.map(c => c.id)].includes(body.choice)) denied('Choose an available source value or Not provided.', 400);
      listing.resolutions[body.field] = { choice: body.choice, note: text(body.note).slice(0, 500), resolved_at: now, resolved_by: ctx.user.id };
    }
    if (body.action === 'review_identity') listing.identity_resolution = await reviewListingIdentity(listing, body.choice, body.note, ctx.user.id, now);
    if (body.action === 'confirm') data = await confirmListing(data, listing.id, profileSnapshot(ctx.profile), ctx.fingerprint, now);
  }
  return commitIntake(ctx, data);
}
async function uploadScreenshot(ctx, body) {
  if (!ctx.policy.integrations_enabled) denied('Private screenshot processing is not enabled for this workspace.', 409);
  const file = await validateScreenshot(body.file);
  const start = await beginOperation(ctx, body, { fileHash: file.sha256, reservation: (data, operation) => {
    const listing = draftListing(data, id(body.listing_id));
    if (isSingleScreenshotPolicy(ctx.policy) && (!submissionConstraints(ctx, listing).upload_available || submissionUsage(data, listing.model.source_id).uploads.size > 3)) denied('One screenshot is allowed per listing submission, with three submissions per current top result. This slot is already used.', 409);
    if (listing.uploads.length >= INTAKE_LIMITS.images_per_listing) denied('Use up to six screenshots for this listing.', 409);
    if (listing.uploads.some(u => u.sha256 === file.sha256)) denied('That screenshot is already attached to this listing.', 409);
    if (!isSingleScreenshotPolicy(ctx.policy) && ctx.policy.max_uploads && data.operations.filter(o => o.action === 'upload').length > ctx.policy.max_uploads) denied('This private workspace’s screenshot allowance is complete.', 409);
    if ([...data.listings, ...(data.context_history || []).flatMap(context => context.listings)].some(l => [...l.uploads, ...(l.archived_revisions || []).flatMap(r => r.uploads)].some(u => u.id === body.upload_id))) denied('That screenshot identifier is already registered.', 409);
    operation.upload_id = id(body.upload_id); operation.listing_revision = listing.revision;
    listing.uploads.push({ id: operation.upload_id, operation_id: operation.id, name: file.name, sha256: file.sha256, mime: file.mime, width: file.width, height: file.height, bytes: file.bytes.length, uploaded_at: new Date().toISOString(), status: 'reserved' });
  } });
  if (start.replay) return replayResponse(ctx, start.operation);
  await commitIntake(ctx, start.data);
  let stage = 'private_upload';
  try {
    // Upload uses the authenticated caller, not a client-supplied URI or public asset API.
    const receipt = await ctx.client.integrations.Core.UploadPrivateFile({ file: body.file });
    stage = 'save_private_receipt';
    const uri = receipt?.file_uri;
    if (typeof uri !== 'string' || !uri.startsWith(`mp/private/${ctx.policy.app_id}/`) || uri.length > 1024) denied('Private upload receipt was not recognized. No public fallback was used.', 502);
    return await finishExternal(ctx, body.operation_id, (data, operation) => {
      const listing = draftListing(data, body.listing_id);
      if (listing.revision !== operation.listing_revision) denied('Listing revision changed during upload.', 409);
      const upload = listing.uploads.find(u => u.id === operation.upload_id);
      upload.file_uri = uri; upload.status = 'uploaded'; operation.status = 'complete';
    });
  } catch { await markUncertain(ctx, body.operation_id, stage); denied('Private upload outcome was not confirmed. It may already be stored. Reload to check; do not upload it again automatically.', 503); }
}
async function readScreenshot(ctx, body) {
  if (!ctx.policy.integrations_enabled) denied('Private screenshot processing is not enabled for this workspace.', 409);
  const start = await beginOperation(ctx, body, { reservation: (data, operation) => {
    const listing = draftListing(data, id(body.listing_id)), upload = listing.uploads.find(u => u.id === id(body.upload_id));
    if (!upload || upload.status !== 'uploaded' || !upload.file_uri?.startsWith(`mp/private/${ctx.policy.app_id}/`)) denied('This screenshot is not ready for reading or has already been attempted.', 409);
    if (isSingleScreenshotPolicy(ctx.policy) && (submissionUsage(ctx.record.data, listing.model.source_id).readings.has(listing.id) || submissionUsage(data, listing.model.source_id).readings.size > 3)) denied('This screenshot reading has already been attempted. Check its saved status; no automatic retry was made.', 409);
    if (!isSingleScreenshotPolicy(ctx.policy) && ctx.policy.max_extractions && data.operations.filter(o => o.action === 'read_screenshot').length > ctx.policy.max_extractions) denied('This private workspace’s reading allowance is complete.', 409);
    operation.upload_id = upload.id; operation.listing_revision = listing.revision;
    upload.status = 'reading'; upload.read_operation_id = operation.id;
  } });
  if (start.replay) return replayResponse(ctx, start.operation);
  await commitIntake(ctx, start.data);
  let stage = 'sign_private_source';
  try {
    const upload = ctx.record.data.listings.find(l => l.id === body.listing_id).uploads.find(u => u.id === body.upload_id);
    const core = ctx.client.asServiceRole.integrations.Core;
    const signed = await core.CreateFileSignedUrl({ file_uri: upload.file_uri, expires_in: 120 });
    if (typeof signed?.signed_url !== 'string') denied('Private screenshot could not be opened.', 503);
    stage = 'read_screenshot';
    const raw = await core.ExtractDataFromUploadedFile({ file_url: signed.signed_url, json_schema: SCREENSHOT_SCHEMA });
    stage = 'save_evidence';
    const extraction = normalizeScreenshotExtraction(raw, upload);
    return await finishExternal(ctx, body.operation_id, (data, operation) => {
      const listing = draftListing(data, body.listing_id);
      if (listing.revision !== operation.listing_revision) denied('Listing revision changed while reading.', 409);
      const saved = listing.uploads.find(u => u.id === operation.upload_id);
      saved.extraction = extraction; saved.status = 'complete'; saved.read_at = new Date().toISOString();
      listing.resolutions = {}; listing.identity_resolution = null; operation.status = 'complete';
    });
  } catch { await markUncertain(ctx, body.operation_id, stage); denied('Screenshot reading was not confirmed. No automatic retry was made and no missing details were invented. Reload to check its status.', 503); }
}
