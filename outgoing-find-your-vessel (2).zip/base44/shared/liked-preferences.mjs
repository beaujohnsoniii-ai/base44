export function pastLikesEnabled(profile) {
  return Boolean(profile?.match_context_id && profile.past_likes_context_id === profile.match_context_id);
}
// A Boolean choice, never an accumulated weight. No choice is inherited across Reset.
export function applyPastLikeChoice(existing, patch, input) {
  const requested = input.use_past_likes === true;
  if (typeof input.use_past_likes === "boolean") {
    patch.past_likes_context_id = requested ? (patch.match_context_id || existing?.match_context_id || null) : null;
  }
  return patch;
}
export function matchingLikes(profile, fingerprint) {
  const likes = Array.isArray(profile?.liked_models) ? profile.liked_models : [];
  const seen = new Set();
  return likes.filter(like => {
    if (like.profile_input_fingerprint !== fingerprint && !pastLikesEnabled(profile)) return false;
    const norm = value => String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    const key = norm(like.make) || norm(like.model) ? norm(like.make) + "|" + norm(like.model) : norm(like.title);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 20).map(like => ({
    make: like.make || "", model: like.model || "", title: like.title || "",
    liked_at_tier: like.liked_at_tier,
  }));
}
