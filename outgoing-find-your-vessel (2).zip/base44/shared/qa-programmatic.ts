// SoundHeading MATCH QA - deterministic programmatic checks.
//
// Runs before AI evaluation to identify obvious failures cheaply and reduce
// unnecessary LLM calls. These checks are NOT a substitute for qualitative
// evaluation - a programmatic pass does not mean the recommendation is good.
//
// Imported by the run-match-qa backend function only.

import { MATCH_SCORE_CAPS, TIER_COUNTS } from "./suggest-engine.ts";
import { containsNumericMarinePerformanceClaim } from "./model-performance-guard.ts";
import { containsUnqualifiedModelEquipmentClaim } from "./model-options-guard.ts";
import { sizeRangeBounds, parseLengthFt } from "./advisor-reasoning.ts";
import { parseLabeledFeet, parseLabeledWeightLb, parseRiggedOverallLengthFt, explicitStorageLengthCapFt, explicitStorageDimensionCapFt, explicitLiftCapacityLb, screenPhysicalCandidate } from "./physical-specs.ts";

export type ConcernLevel = "green" | "yellow" | "red";

export interface ProgrammaticCheckResult {
  concern_level: ConcernLevel;
  checks: {
    count_compliant: boolean;
    count_actual: number;
    count_min: number;
    count_max: number;
    highlight_compliant: boolean;
    highlight_expected: number;
    highlight_actual: number;
    highlight_misplaced: string[];
    budget_violations: string[];
    price_verification_gaps: string[];
    physical_verification_gaps: string[];
    performance_claim_review: string[];
    optional_equipment_review: string[];
    size_violations: string[];
    storage_violations: string[];
    scope_violations: string[];
    duplicate_models: string[];
    unique_makes: number;
    total_suggestions: number;
    make_diversity_ratio: number;
    hard_constraint_violations: string[];
    like_override_detected: boolean;
    like_override_details: string[];
    overnight_violations: string[];
    passenger_violations: string[];
    passenger_verification_gaps: string[];
    occasional_passenger_notes: string[];
    score_violations: string[];
    verification_flags: string[];
  };
  flag_reasons: string[];
}

function checkResultCount(suggestions: any[], tier: string): { compliant: boolean; min: number; max: number; actual: number } {
  const counts = TIER_COUNTS[tier] || TIER_COUNTS.free;
  const actual = suggestions.length;
  return {
    compliant: actual >= counts.minCount && actual <= counts.suggestCount,
    min: counts.minCount,
    max: counts.suggestCount,
    actual,
  };
}

// The recommendation mark is part of a tier's result shape: Free and MATCH+ mark
// nothing (they are deliberately broad sets), Refined Match marks its leading 5-7
// and Market Match marks the top 3. The mark belongs on the leading results by
// rank, so a pool that marks the wrong models — or marks a tier that should mark
// none — is a presentation failure a reviewer should see.
function checkResultHighlights(suggestions: any[], tier: string): { compliant: boolean; expected: number; actual: number; misplaced: string[] } {
  const counts = TIER_COUNTS[tier] || TIER_COUNTS.free;
  // A shortfall lowers how many marks are possible; it never raises them.
  const expected = Math.min(counts.highlightCount, suggestions.length);
  const misplaced: string[] = [];
  let actual = 0;
  suggestions.forEach((s, index) => {
    if (s?.highlighted !== true) return;
    actual += 1;
    if (index >= expected) {
      misplaced.push(`${s.title || s.make || "Unknown"}: marked but ranked ${index + 1}, outside the tier's leading ${expected}`);
    }
  });
  return { compliant: actual === expected && misplaced.length === 0, expected, actual, misplaced };
}

// Only independently established model-generation market evidence can
// establish a hard affordability failure. An LLM-supplied range (including
// a self-declared "verified" flag) is an estimate, not a trusted lower bound.
// Until the caller supplies source-reviewed evidence, an estimated
// above-budget band is a yellow verification concern rather than a red
// hard constraint violation.
function checkBudgetCompliance(
  suggestions: any[],
  budgetMax: number | null,
  verifiedLowerBound?: (suggestion: any) => number | null,
): string[] {
  if (!budgetMax || budgetMax <= 0 || !verifiedLowerBound) return [];
  const violations: string[] = [];
  for (const s of suggestions) {
    const lower = verifiedLowerBound(s);
    if (typeof lower === "number" && Number.isFinite(lower) && lower > 0 && lower > budgetMax) {
      violations.push(`${s.title || s.make || "Unknown"}: independently verified model price lower bound $${lower} exceeds $${budgetMax} budget`);
    }
  }
  return violations;
}

// A missing or overlapping model price range is NOT proof of an over-budget
// model. It does require a visible verification note before the buyer treats
// the model as affordable. This check catches silent confidence, not scarcity.
function checkPriceVerification(suggestions: any[], budgetMax: number | null): string[] {
  if (!Number.isFinite(Number(budgetMax)) || Number(budgetMax) <= 0) return [];
  const gaps: string[] = [];
  for (const s of suggestions) {
    const low = Number(s?.price_range_min);
    const high = Number(s?.price_range_max);
    const validRange = Number.isFinite(low) && low > 0 && Number.isFinite(high) && high >= low;
    // Without independently verified price evidence an above-budget LLM band
    // is not grounds for rejecting the model. It still needs a conspicuous
    // price review warning even when the model has a generic verification flag.
    if (validRange && low > Number(budgetMax)) {
      gaps.push(`${s.title || s.make || "Unknown"}: unverified estimated model band $${low}–$${high} starts above $${budgetMax} budget; confirm comparable model years and real market evidence before excluding or claiming affordability`);
      continue;
    }
    const flags = Array.isArray(s?.verification_required) ? s.verification_required.join(" ") : "";
    const priceFlagged = /price|cost|budget|affordab|market value/i.test(flags);
    // A generic verification flag does not substitute for the generation,
    // years and market that make a broad MODEL price band meaningful.
    // Equally, a model/year/market descriptor is not independent evidence.
    // Until a trusted catalog confirms the range, every LLM-supplied band
    // still needs a visible price-verification flag.
    if (validRange && !String(s?.price_range_context || "").trim()) {
      gaps.push(`${s.title || s.make || "Unknown"}: estimated model price band lacks generation/year/market context${priceFlagged ? "" : " and independent market-verification flag"}`);
      continue;
    }
    if (validRange && !priceFlagged) {
      gaps.push(`${s.title || s.make || "Unknown"}: contextual model price band lacks independent market-verification flag`);
      continue;
    }
    if (validRange && high <= Number(budgetMax)) continue;
    if (!priceFlagged) {
      gaps.push(`${s.title || s.make || "Unknown"}: model price is unknown or overlaps the purchase ceiling, but market-price verification is not flagged`);
    }
  }
  return gaps;
}

// Model-level speed/fuel/range figures are configuration-sensitive. Flag
// unqualified numeric claims for review rather than assuming they are false.
// Evaluate each displayed claim independently: a sourced test elsewhere in
// the recommendation does not substantiate another unsupported number.
// A model-specific published test may be valid when its power/configuration
// and source are identified. This is a diagnostic, not a hard exclusion.
function checkPerformanceClaims(suggestions: any[]): string[] {
  const concerns: string[] = [];
  for (const s of suggestions) {
    const claims = [
      s.why_suggested, s.summary, s.match?.summary, s.engines, s.specs,
      ...(Array.isArray(s.match?.matches) ? s.match.matches : []),
      ...(Array.isArray(s.match?.gaps) ? s.match.gaps : []),
    ].filter(Boolean).map((value) => String(value));
    const unsupported = claims.some((claim) => {
      if (!containsNumericMarinePerformanceClaim(claim)) return false;
      const testContext = /\b(?:test(?:ed)?|published|sea trial|performance bulletin)\b/i.test(claim)
        && /\b(?:engine|hp|horsepower|prop(?:eller)?|configuration|powered by)\b/i.test(claim)
        && /\b(?:source|manufacturer|report|test data|bulletin)\b/i.test(claim);
      return !testContext;
    });
    if (unsupported) {
      concerns.push(`${s.title || s.make || "Unknown"}: numeric speed/fuel/range claim lacks its own named configuration and published test/source context`);
    }
  }
  return concerns;
}

// Advisory diagnostic: MODEL MATCH cannot assume listing-specific optional equipment.
function checkOptionalEquipmentClaims(suggestions: any[]): string[] {
  const alerts: string[] = [];
  for (const s of suggestions) {
    // QA must inspect every buyer-visible recommendation field. An unsupported
    // promise in the engines/specs or tradeoff notes is just as misleading as
    // the same claim in the headline reason to match.
    const claims = [
      s.why_suggested, s.summary, s.match?.summary, s.engines, s.specs,
      ...(Array.isArray(s.match?.matches) ? s.match.matches : []),
      ...(Array.isArray(s.match?.gaps) ? s.match.gaps : []),
    ];
    const suspect = claims.some(containsUnqualifiedModelEquipmentClaim);
    if (suspect) alerts.push(`${s.title || s.make || "Unknown"}: optional equipment described as included without qualification`);
  }
  return alerts;
}

function checkSizeCompliance(suggestions: any[], sizeRange: string): string[] {
  const bounds = sizeRangeBounds(sizeRange);
  if (bounds.min === 0 && bounds.max === Infinity) return [];
  const violations: string[] = [];
  for (const s of suggestions) {
    const len = parseLengthFt(s?.specs || "", s?.specs || "");
    if (len !== null && (len < bounds.min || len > bounds.max)) {
      violations.push(`${s.title || s.make || "Unknown"}: ${len}ft outside ${sizeRange}`);
    }
  }
  return violations;
}

// Align QA with the same evidence rule as production MATCH: a model/LLM
// measurement cannot establish an exclusion until its exact field and year
// were independently source-verified. Report unverified apparent conflicts for
// review, but mark missing verification flags as a QA failure.
function checkStructuredPhysicalLimits(
  suggestions: any[], profile: any,
): { hard: string[]; verification: string[] } {
  const hard: string[] = [];
  const verification: string[] = [];
  const positive = (value: unknown): number | null => {
    const n = Number(value);
    return Number.isFinite(n) && n > 0 ? n : null;
  };
  const cap = (value: unknown) => positive(value);
  const checks = [
    {
      label: "rigged overall length", field: "rigged_overall_length_ft",
      limit: cap(profile.hard_max_overall_length_ft),
      reported: (s: any, specs: string) => positive(s.overall_length_ft) ?? parseRiggedOverallLengthFt(specs),
      flag: /length|loa|overall|engine bracket|platform/i,
    },
    {
      label: "draft", field: "draft_ft",
      limit: cap(profile.hard_max_draft_ft),
      reported: (s: any, specs: string) => positive(s.draft_ft) ?? parseLabeledFeet(specs, "draft"),
      flag: /draft/i,
    },
    {
      label: "beam", field: "beam_ft",
      limit: cap(profile.hard_max_beam_ft),
      reported: (s: any, specs: string) => positive(s.beam_ft) ?? parseLabeledFeet(specs, "beam"),
      flag: /beam/i,
    },
    {
      label: "storage height", field: "storage_height_ft",
      limit: cap(profile.hard_max_height_ft),
      reported: (s: any, specs: string) => positive(s.storage_height_ft)
        ?? parseLabeledFeet(specs, "storage\\s+height|overall\\s+height|height\\s+on\\s+trailer|trailer\\s+height"),
      flag: /height|clearance|storage profile/i,
    },
    {
      label: "loaded storage weight", field: "storage_weight_lb",
      limit: cap(profile.hard_max_storage_weight_lb),
      reported: (s: any, specs: string) => positive(s.loaded_storage_weight_lb)
        ?? parseLabeledWeightLb(specs, "(?:loaded|operating|storage)\\s+(?:weight|displacement)"),
      flag: /loaded|operating|storage weight|storage displacement/i,
    },
    {
      label: "trailered weight", field: "trailered_weight_lb",
      limit: profile.storage === "trailer" ? cap(profile.tow_capacity_lb) : null,
      reported: (s: any, specs: string) => positive(s.trailered_weight_lb)
        ?? parseLabeledWeightLb(specs, "(?:trailer(?:ed)?|tow(?:ing)?)\\s+weight"),
      flag: /trailer(?:ed)? weight|tow(?:ing)? weight/i,
    },
  ];
  for (const s of suggestions) {
    const label = s.title || s.make || "Unknown";
    const specs = String(s?.specs || "");
    const notes = Array.isArray(s.verification_required) ? s.verification_required.join(" ") : "";
    // This server-owned marker is available during internal QA only when
    // provenance survived the engine. A user-supplied "verified" adjective
    // or an LLM-supplied citation inside specs is not acceptable proof.
    const sourceVerified = new Set<string>(
      Array.isArray(s.__catalog_verified_fields) ? s.__catalog_verified_fields : [],
    );
    for (const check of checks) {
      if (check.limit === null) continue;
      const actual = check.reported(s, specs);
      if (actual !== null && sourceVerified.has(check.field)) {
        if (actual > check.limit) {
          hard.push(`${label}: independently verified ${check.label} ${actual} exceeds ${check.limit} hard maximum`);
        }
        continue;
      }
      if (actual !== null && actual > check.limit) {
        verification.push(`${label}: reported ${check.label} ${actual} appears above the ${check.limit} limit, but source/year/measurement basis is unverified; review before excluding the model`);
      }
      if (!check.flag.test(notes)) {
        hard.push(`${label}: ${check.label} is unverified against the ${check.limit} limit, without a verification-required flag`);
      }
    }
    // Nominal hull or brochure LOA exceeding a slip's rigged-length cap is
    // important to investigate, but not proof of the as-rigged length.
    const maxLength = cap(profile.hard_max_overall_length_ft);
    const rigged = positive(s.overall_length_ft) ?? parseRiggedOverallLengthFt(specs);
    const nominal = parseLengthFt(specs, specs);
    if (maxLength !== null && rigged === null && nominal !== null && nominal > maxLength) {
      verification.push(`${label}: nominal/hull length ${nominal} appears above ${maxLength} maximum; confirm actual rigged overall length before excluding`);
    }
  }
  return { hard, verification };
}

// Passenger count belongs to MATCH+, not Free Discovery. Only a published
// maximum-person capacity is a deterministic hard ceiling. Seating count,
// sleeping berths and LOA cannot establish a published person limit.
function checkPassengerCompliance(
  suggestions: any[], profile: any, tier: string,
): { hard: string[]; verification: string[]; occasional: string[] } {
  const hard: string[] = [];
  const verification: string[] = [];
  const occasional: string[] = [];
  if (tier === "free") return { hard, verification, occasional };
  const normal = Number(profile.passenger_count);
  const peak = Number(profile.occasional_passenger_count);
  for (const s of suggestions) {
    const label = s.title || s.make || "Unknown";
    const fromField = Number(s.passenger_capacity);
    const specs = String(s.specs || "");
    const fromSpecs = specs.match(/\b(?:published|unverified) passenger limit\s+(\d+)\b/i);
    const capacity = Number.isSafeInteger(fromField) && fromField > 0
      ? fromField : fromSpecs ? Number(fromSpecs[1]) : null;
    // Only the server's source-qualified MATCH specification label is proof
    // of a manufacturer-published persons limit. A numeric LLM estimate in
    // passenger_capacity must never be described as verified or published.
    const published = specs.match(/\bPublished passenger limit\s+(\d+)\s*\(source-verified\b/i);
    const verified = published !== null && capacity !== null && Number(published[1]) === capacity;
    const flags = Array.isArray(s.verification_required) ? s.verification_required.join(" ") : "";
    const marked = /passenger|person|people aboard|capacity|maximum aboard/i.test(flags);
    if (Number.isFinite(normal) && normal > 0) {
      if (capacity !== null && capacity < normal && verified) {
        hard.push(`${label}: source-verified published person limit ${capacity} is below normal party of ${normal}`);
      } else if (!verified && !marked) {
        // The LLM can invent or misread a person limit. Flag it, rather than
        // reporting a definitive safety violation on an unverified number.
        verification.push(capacity !== null && capacity < normal
          ? `${label}: unverified reported person limit ${capacity} is below normal party of ${normal}; confirm manufacturer rating before relying on this candidate`
          : `${label}: normal party capacity requires independently verified model limit or safe-load guidance`);
      }
    }
    if (Number.isFinite(peak) && peak > 0) {
      if (capacity !== null && capacity < peak) {
        occasional.push(verified
          ? `${label}: occasional party ${peak} exceeds source-verified ${capacity}-person limit; plan a smaller group`
          : `${label}: occasional party ${peak} exceeds unverified reported ${capacity}-person limit; confirm before carrying this group`);
      } else if (!verified && !marked) {
        verification.push(`${label}: occasional party capacity was not verified`);
      }
    }
  }
  return { hard, verification, occasional };
}

function checkDuplicates(suggestions: any[]): string[] {
  const seen = new Map<string, number>();
  const duplicates: string[] = [];
  for (const s of suggestions) {
    const key = `${(s.make || "").toLowerCase().trim()}|${(s.model || "").toLowerCase().trim()}`;
    if (key === "|") continue;
    const count = (seen.get(key) || 0) + 1;
    seen.set(key, count);
    if (count === 2) {
      duplicates.push(s.title || `${s.make} ${s.model}`);
    }
  }
  return duplicates;
}

function checkDiversity(suggestions: any[]): { uniqueMakes: number; total: number; ratio: number } {
  const makes = new Set<string>();
  for (const s of suggestions) {
    const mk = (s.make || "").toLowerCase().trim();
    if (mk) makes.add(mk);
  }
  const total = suggestions.length;
  return {
    uniqueMakes: makes.size,
    total,
    ratio: total > 0 ? makes.size / total : 0,
  };
}

function checkOvernight(suggestions: any[], profile: any): string[] {
  const overnightReq = profile.overnight_requirements || "";
  // Only an explicit NEED is a deterministic overnight hard constraint.
  // Activity weight alone affects ranking; it must not manufacture a hard requirement.
  // Generic "need" or "required" does not prove that sleeping aboard is mandatory:
  // the buyer may need a head or shade while preferring only day trips.
  const noSleepRequired = /\b(?:no overnight(?:ing| stays| use)?|not sleeping|no sleeping|(?:don't|do not|never|not)\s+(?:need|require|plan|want|intend)?\s*(?:to\s+)?(?:sleep|overnight)\b|day trips only|day use only)\b/i.test(overnightReq);
  const explicitSleepNeed = /\b(?:need|needs|require|requires|must|have to)\b.{0,30}\b(?:sleep|sleeping|berth|sleeping quarters)\b|\b(?:need|needs|require|requires|must|have to)\s+(?:to\s+)?(?:overnight|stay overnight)\b|\b(?:sleep|sleeps|berth)\s*(?:at least\s*)?\d+\b|\b(?:overnight|sleeping)\s+(?:stays?|accommodations?|capacity|berths?)\s+(?:is\s+|are\s+)?(?:required|needed|mandatory)\b|\b(?:overnight|sleeping)\s+(?:is\s+)?(?:required|essential|non-negotiable)\b|\b(?:separate|dedicated)\s+(?:guest\s+)?(?:berth|sleeping quarters)\s+(?:required|needed|mandatory)\b/i.test(overnightReq);
  const requiredOvernightSystem = /\b(?:need|require|must have)\b.{0,35}\b(?:off[- ]grid\s+(?:a\/?c|air|heat|cooking)|generator|inverter)\b|\b(?:off[- ]grid\s+(?:a\/?c|air|heat|cooking)|generator|inverter)\b.{0,25}\b(?:required|needed|mandatory)\b/i.test(overnightReq);
  const laterExplicitNeed = /\b(?:but|however|though)\b.{0,120}\b(?:must|need|require|have to)\b.{0,35}\b(?:sleep|sleeping|overnight|berth)\b/i.test(overnightReq);
  const needsOvernight = (!noSleepRequired || laterExplicitNeed) && (explicitSleepNeed || (requiredOvernightSystem && /overnight|off-grid/i.test(overnightReq)));
  if (!needsOvernight) return [];

  const violations: string[] = [];
  for (const s of suggestions) {
    const title = (s.title || "").toLowerCase();
    const why = (s.why_suggested || "").toLowerCase();
    const matches = Array.isArray(s.match?.matches) ? s.match.matches.join(" ").toLowerCase() : "";
    const gaps = Array.isArray(s.match?.gaps) ? s.match.gaps.join(" ").toLowerCase() : "";

    const openBoatMatch = title.match(/center console|skiff|bowrider|rib|inflatable|ponto?on/);
    const openBoat = openBoatMatch !== null;
    // "Overnight", "enclosed head", or "sleep" in a negative explanation
    // is not evidence of actual sleeping accommodations.
    const accommodationEvidence = `${title} ${why} ${matches}`;
    const explicitlyNoBerth = /no (?:real )?(?:berths?|cabin|sleeping)|without (?:a )?(?:berth|cabin)|not (?:overnight|sleeping) capable|open layout|console head only/.test(`${why} ${matches} ${gaps}`);
    const hasCabin = /\b(?:cabin|cuddy|berths?|v-berth|sleeping quarters|dedicated sleeping)\b/.test(accommodationEvidence) && !explicitlyNoBerth;

    if (openBoat && !hasCabin) {
      const boatType = openBoatMatch[0];
      violations.push(`${s.title || "Unknown"}: open boat (${boatType}) for overnight buyer`);
    } else if (explicitlyNoBerth) {
      violations.push(`${s.title || "Unknown"}: gaps mention no berths/cabin for overnight buyer`);
    }
  }
  return violations;
}

function checkLikeOverride(
  suggestions: any[], likedModels: any[], profile: any,
  verifiedLowerBound?: (suggestion: any) => number | null,
): { detected: boolean; details: string[] } {
  if (!likedModels?.length) return { detected: false, details: [] };
  const budgetMax = profile.purchase_budget_max;
  const details: string[] = [];

  for (const s of suggestions) {
    const liked = likedModels.some((lm) => {
      const lmMake = (lm.make || "").toLowerCase().trim();
      const lmModel = (lm.model || "").toLowerCase().trim();
      const sMake = (s.make || "").toLowerCase().trim();
      const sModel = (s.model || "").toLowerCase().trim();
      return lmMake && sMake && (lmMake === sMake || lmMake.includes(sMake) || sMake.includes(lmMake)) &&
        (!lmModel || !sModel || lmModel === sModel || lmModel.includes(sModel) || sModel.includes(lmModel));
    });
    if (!liked) continue;

    const verifiedLow = verifiedLowerBound?.(s);
    if (typeof verifiedLow === "number" && Number.isFinite(verifiedLow) && verifiedLow > 0 &&
        budgetMax && verifiedLow > budgetMax) {
      details.push(`${s.title}: liked model's independently verified lower price bound $${verifiedLow} exceeds budget $${budgetMax}`);
    }
    // Preferred boat-size range is not a hard constraint. A liked model outside
    // that range is acceptable when true physical constraints are still met.
  }
  return { detected: details.length > 0, details };
}

export function runProgrammaticChecks(
  suggestions: any[],
  profile: any,
  tier: string,
  likedModels: any[],
  verifiedLowerBound?: (suggestion: any) => number | null,
): ProgrammaticCheckResult {
  const countResult = checkResultCount(suggestions, tier);
  const highlightResult = checkResultHighlights(suggestions, tier);
  const budgetViolations = checkBudgetCompliance(suggestions, profile.purchase_budget_max, verifiedLowerBound);
  const priceVerificationGaps = checkPriceVerification(suggestions, profile.purchase_budget_max);
  const performanceClaimReview = checkPerformanceClaims(suggestions);
  const optionalEquipmentReview = checkOptionalEquipmentClaims(suggestions);
  const sizeViolations = checkSizeCompliance(suggestions, profile.boat_size_range);
  // QA must use the same stricter-of-structured-and-explicit-notes facility
  // ceilings as live MATCH, including older profiles saved before numeric
  // storage-limit fields were introduced.
  const storageNotes = String(profile.storage_capacity || "");
  const tighter = (...values: unknown[]): number | null => {
    const known = values.map(Number).filter(n => Number.isFinite(n) && n > 0);
    return known.length ? Math.min(...known) : null;
  };
  const physicalProfile = {
    ...profile,
    hard_max_overall_length_ft: tighter(profile.hard_max_overall_length_ft, explicitStorageLengthCapFt(storageNotes)),
    hard_max_beam_ft: tighter(profile.hard_max_beam_ft, explicitStorageDimensionCapFt(storageNotes, "beam")),
    hard_max_height_ft: tighter(profile.hard_max_height_ft, explicitStorageDimensionCapFt(storageNotes, "height")),
    hard_max_storage_weight_lb: tighter(profile.hard_max_storage_weight_lb, explicitLiftCapacityLb(storageNotes)),
  };
  const physicalChecks = checkStructuredPhysicalLimits(suggestions, physicalProfile);
  const storageViolations = physicalChecks.hard;
  // Scope checks are independent of the buyer profile: excluded vessel types
  // and boats over 65 ft must never appear in any tier.
  const scopeViolations = suggestions.flatMap((s: any) => {
    const screen = screenPhysicalCandidate(s, {});
    return screen.reasons
      .filter((reason: string) => reason.startsWith("SoundHeading v1 scope:"))
      .map((reason: string) => `${s.title || s.make || "Unknown"}: ${reason}`);
  });
  const duplicates = checkDuplicates(suggestions);
  const diversity = checkDiversity(suggestions);
  // Overnight needs are only collected in Market Match. Checking the full
  // golden profile against Free/MATCH+/Refined would falsely fail earlier
  // tiers for a requirement those tiers were never given.
  const overnightViolations = tier === "market_match" ? checkOvernight(suggestions, profile) : [];
  const likeOverride = checkLikeOverride(suggestions, likedModels, profile, verifiedLowerBound);
  const passengerCompliance = checkPassengerCompliance(suggestions, profile, tier);
  const scoreMax = MATCH_SCORE_CAPS;
  const scoreViolations: string[] = [];
  const verificationFlags: string[] = [];
  for (const s of suggestions) {
    const b = s.score_breakdown;
    if (typeof s.suitability_score !== "number" || !Number.isFinite(s.suitability_score) || !b || typeof b !== "object") {
      scoreViolations.push(`${s.title || "Untitled"}: missing suitability score/breakdown`);
    } else {
      let total = 0;
      for (const [key, max] of Object.entries(scoreMax)) {
        const value = Number(b[key]);
        if (!Number.isFinite(value) || value < 0 || value > max) scoreViolations.push(`${s.title || "Untitled"}: ${key} outside 0-${max}`);
        else total += value;
      }
      if (Math.abs(total - Number(s.suitability_score)) > 0.01) scoreViolations.push(`${s.title || "Untitled"}: score ${s.suitability_score} does not equal component sum ${total}`);
    }
    if (Array.isArray(s.verification_required)) for (const item of s.verification_required) verificationFlags.push(`${s.title || "Untitled"}: ${item}`);
  }

  const hardConstraintViolations = [
    ...budgetViolations.map(v => `Budget: ${v}`),
    ...scopeViolations.map(v => `Scope: ${v}`),
    ...storageViolations.map(v => `Storage: ${v}`),
    ...overnightViolations.map(v => `Overnight: ${v}`),
    ...passengerCompliance.hard.map(v => `Passenger capacity: ${v}`),
  ];

  const flagReasons: string[] = [];
  let concernLevel: ConcernLevel = "green";

  if (hardConstraintViolations.length > 0) {
    concernLevel = "red";
    flagReasons.push(`${hardConstraintViolations.length} hard-constraint violation(s)`);
  }
  if (likeOverride.detected) {
    concernLevel = "red";
    flagReasons.push(`Like appears to override hard constraint (${likeOverride.details.length})`);
  }
  if (scoreViolations.length > 0) {
    concernLevel = "red";
    flagReasons.push(`${scoreViolations.length} MATCH score integrity violation(s)`);
  }

  // Preserve the pricing diagnostic even when a more serious issue has
  // already made the result red; otherwise reviewers miss an independent gap.
  if (priceVerificationGaps.length > 0) {
    if (concernLevel !== "red") concernLevel = "yellow";
    flagReasons.push(`${priceVerificationGaps.length} model price verification gap(s)`);
  }
  if (physicalChecks.verification.length > 0) {
    if (concernLevel !== "red") concernLevel = "yellow";
    flagReasons.push(`${physicalChecks.verification.length} apparent physical-limit conflict(s) require source verification`);
  }
  if (performanceClaimReview.length > 0) {
    if (concernLevel !== "red") concernLevel = "yellow";
    flagReasons.push(`${performanceClaimReview.length} unqualified model performance claim(s) require review`);
  }
  if (optionalEquipmentReview.length > 0) {
    if (concernLevel !== "red") concernLevel = "yellow";
    flagReasons.push(`${optionalEquipmentReview.length} unqualified optional-equipment claim(s) require review`);
  }
  if (passengerCompliance.verification.length > 0) {
    if (concernLevel !== "red") concernLevel = "yellow";
    flagReasons.push(`${passengerCompliance.verification.length} passenger-capacity verification gap(s)`);
  }
  if (passengerCompliance.occasional.length > 0) {
    if (concernLevel !== "red") concernLevel = "yellow";
    flagReasons.push(`${passengerCompliance.occasional.length} occasional-party accommodation warning(s)`);
  }
  if (concernLevel !== "red") {
    if (!countResult.compliant) {
      // A documented scarcity note explains a short pool; it does not make the
      // shortfall a pass. Every shortfall is flagged for a reviewer to judge.
      concernLevel = "yellow";
      flagReasons.push(`Count: ${countResult.actual} (expected ${countResult.min}-${countResult.max})`);
    }
    if (!highlightResult.compliant) {
      concernLevel = "yellow";
      flagReasons.push(`Recommendation marks: ${highlightResult.actual} marked, expected ${highlightResult.expected} on the leading results`);
    }
    if (duplicates.length > 0) {
      concernLevel = "yellow";
      flagReasons.push(`${duplicates.length} duplicate model(s)`);
    }
    if (diversity.total >= 3 && diversity.ratio < 0.4) {
      concernLevel = "yellow";
      flagReasons.push(`Low make diversity: ${diversity.uniqueMakes} unique / ${diversity.total} total`);
    }
  }

  return {
    concern_level: concernLevel,
    checks: {
      count_compliant: countResult.compliant,
      count_actual: countResult.actual,
      count_min: countResult.min,
      count_max: countResult.max,
      highlight_compliant: highlightResult.compliant,
      highlight_expected: highlightResult.expected,
      highlight_actual: highlightResult.actual,
      highlight_misplaced: highlightResult.misplaced,
      budget_violations: budgetViolations,
      price_verification_gaps: priceVerificationGaps,
      physical_verification_gaps: physicalChecks.verification,
      performance_claim_review: performanceClaimReview,
      optional_equipment_review: optionalEquipmentReview,
      size_violations: sizeViolations,
      storage_violations: storageViolations,
      scope_violations: scopeViolations,
      duplicate_models: duplicates,
      unique_makes: diversity.uniqueMakes,
      total_suggestions: diversity.total,
      make_diversity_ratio: Math.round(diversity.ratio * 100) / 100,
      hard_constraint_violations: hardConstraintViolations,
      like_override_detected: likeOverride.detected,
      like_override_details: likeOverride.details,
      overnight_violations: overnightViolations,
      passenger_violations: passengerCompliance.hard,
      passenger_verification_gaps: passengerCompliance.verification,
      occasional_passenger_notes: passengerCompliance.occasional,
      score_violations: scoreViolations,
      verification_flags: verificationFlags,
    },
    flag_reasons: flagReasons,
  };
}

export interface ProgressionCheckResult {
  overlap_count: number;
  overlap_titles: string[];
  new_models: string[];
  dropped_models: string[];
  churn_rate: number;
  ranking_changed: boolean;
  flag_reasons: string[];
}

export function checkProgression(
  currentSuggestions: any[],
  previousSuggestions: any[] | null,
  currentTier: string,
  previousTier: string | null,
): ProgressionCheckResult {
  if (!previousSuggestions || !previousSuggestions.length) {
    return {
      overlap_count: 0,
      overlap_titles: [],
      new_models: [],
      dropped_models: [],
      churn_rate: 0,
      ranking_changed: false,
      flag_reasons: [],
    };
  }

  const makeModelKey = (s: any) => `${(s.make || "").toLowerCase().trim()}|${(s.model || "").toLowerCase().trim()}`;
  const prevKeys = new Map<string, string>();
  for (const s of previousSuggestions) {
    const k = makeModelKey(s);
    if (k !== "|") prevKeys.set(k, s.title || k);
  }
  const currKeys = new Map<string, string>();
  for (const s of currentSuggestions) {
    const k = makeModelKey(s);
    if (k !== "|") currKeys.set(k, s.title || k);
  }

  const overlapTitles: string[] = [];
  for (const [k, title] of currKeys) {
    if (prevKeys.has(k)) overlapTitles.push(title);
  }
  const newModels = [...currKeys.entries()].filter(([k]) => !prevKeys.has(k)).map(([, t]) => t);
  const droppedModels = [...prevKeys.entries()].filter(([k]) => !currKeys.has(k)).map(([, t]) => t);

  const churnRate = previousSuggestions.length > 0
    ? Math.round((newModels.length / previousSuggestions.length) * 100) / 100
    : 0;

  let rankingChanged = false;
  for (const s of currentSuggestions) {
    const k = makeModelKey(s);
    if (prevKeys.has(k)) {
      const prevRank = previousSuggestions.findIndex(p => makeModelKey(p) === k) + 1;
      if (prevRank > 0 && s.rank !== prevRank) {
        rankingChanged = true;
        break;
      }
    }
  }

  const flagReasons: string[] = [];

  const tierPairs: Record<string, string> = {
    match_plus: "free",
    refined_match: "match_plus",
    market_match: "refined_match",
  };
  const prevTierExpected = tierPairs[currentTier];
  if (prevTierExpected === previousTier) {
    const overlapRatio = currentSuggestions.length > 0 ? overlapTitles.length / currentSuggestions.length : 0;
    if (overlapRatio > 0.8 && currentSuggestions.length > 0) {
      flagReasons.push(`High overlap with ${previousTier}: ${overlapTitles.length}/${currentSuggestions.length} models repeated - paid tier barely refined despite new information`);
    }
  }

  if (churnRate === 1.0 && currentSuggestions.length > 0 && previousSuggestions.length > 0) {
    flagReasons.push(`Complete churn: 0/${currentSuggestions.length} models retained from ${previousTier} - recommendations changed entirely`);
  }

  return {
    overlap_count: overlapTitles.length,
    overlap_titles: overlapTitles,
    new_models: newModels,
    dropped_models: droppedModels,
    churn_rate: churnRate,
    ranking_changed: rankingChanged,
    flag_reasons: flagReasons,
  };
}