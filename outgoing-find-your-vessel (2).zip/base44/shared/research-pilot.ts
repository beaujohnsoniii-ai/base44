import { hasSensitiveSourceParameters } from "./hybrid-evidence.mjs";

// Conservative validation for a low-cost, admin-triggered research pilot.
// Keep every candidate quarantined until manufacturer and specs are verified.
// Web snippets and LLM output are UNTRUSTED. Never promote this data to the model catalog.
export function normalizeResearchText(value: unknown): string {
  return String(value ?? "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

// Plausible numbers from an LLM are not proof of model specifications.
// Only retain pilot numeric facts when the cited search excerpt explicitly
// places that value, its unit, and the corresponding field label together.
function hasSourceEvidence(source: {title: string; content: string}, field: string, n: number): boolean {
  const text = String(source.title || "") + " " + String(source.content || "");
  // Escape every regex metacharacter; never interpret numeric text as syntax.
  const number = String(n).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const unit = field === "fuel_gal" ? "(?:gal(?:lons?)?|gals)" : "(?:ft|feet|foot)";
  const labels: Record<string, string> = {
    // Plain "length" may mean hull length, not overall/rigged LOA.
    // It must not be used as proof of a physical marina or lift fit.
    loa_ft: "(?:loa|length overall|overall length)",
    beam_ft: "(?:beam|width)",
    draft_ft: "(?:draft|draught)",
    fuel_gal: "(?:fuel(?: capacity)?|tank(?: capacity)?)",
  };
  const label = labels[field];
  if (!label) return false;
  // A word boundary alone would incorrectly read "Draft: 0.5 ft" as 5 ft.
  // Reject embedded decimal fragments even when the claimed number has a unit.
  const valueWithUnit = "(?<![\\d.])" + number + "\\s*" + unit + "\\b";
  // A missing LOA must not borrow the next field's number: e.g.
  // "Length overall: not provided, Beam: 9.5 ft" previously certified
  // 9.5 ft as BOTH LOA and beam. Keep label and value in the same clause;
  // a second colon, comma or other field separator ends that clause.
  const sameClause = "[^,:;\\.\\n]";
  const labelStart = "\\b" + label + "\\b\\s*(?:[:=]\\s*)?";
  return new RegExp(labelStart + sameClause + "{0,40}\\b" + valueWithUnit, "i").test(text)
    || new RegExp("\\b" + valueWithUnit + sameClause + "{0,25}\\b" + label + "\\b", "i").test(text);
}

function isPublicHttpsSource(value: string): boolean {
  try {
    const url = new URL(value);
    // Staging is persistent. Never retain API credentials, signed links, or
    // private/nonstandard endpoints even when a search provider returns them.
    if (url.protocol !== "https:" || url.username || url.password || url.port || hasSensitiveSourceParameters(url)) return false;
    const host = url.hostname.toLowerCase();
    if (!host.includes(".") || host.includes("..") || /^(?:\d{1,3}\.){3}\d{1,3}$/.test(host) || host.startsWith("[")) return false;
    if (host === "localhost" || /\.(?:localhost|local|internal)$/.test(host)) return false;
    return true;
  } catch { return false; }
}

export function sanitizePilotRows(raw: unknown, sources: Array<{url:string; title:string; content:string}>, manufacturer: string) {
  const rows = Array.isArray((raw as any)?.models) ? (raw as any).models : [];
  const allowed = new Map(sources.map(s => [s.url, s]));
  const used = new Set<string>();
  const staged: any[] = [];
  const rejected: string[] = [];
  for (const row of rows.slice(0, 12)) {
    if (!row || typeof row !== "object") { rejected.push("invalid row"); continue; }
    const model = String(row.model ?? "").trim().slice(0, 100);
    const url = String(row.source_url ?? "").trim();
    const source = allowed.get(url);
    if (!model || !source || !isPublicHttpsSource(url)) { rejected.push("missing model or invalid/unlisted public HTTPS source"); continue; }
    // A model name must appear in retrieved page title or excerpt. URL slugs
    // can be invented and do not establish that a model actually exists.
    const normalizedModel = normalizeResearchText(model);
    const evidence = normalizeResearchText(source.title + " " + source.content);
    if (!normalizedModel || !(" " + evidence + " ").includes(" " + normalizedModel + " ")) {
      rejected.push("model name not supported by retrieved source snippet");
      continue;
    }
    // A real model name is not proof it belongs to the manufacturer being
    // researched. The source excerpt must identify that builder, or the URL
    // must be hosted on a domain containing the full normalized builder name.
    // Reject ambiguous hits for later manual alias/brand reconciliation;
    // never misattribute a competing builder's boat to the current builder.
    const normalizedManufacturer = normalizeResearchText(manufacturer);
    const hostname = new URL(url).hostname.toLowerCase();
    const normalizedBuilderDomain = normalizedManufacturer.replace(/ /g, "");
    const domainLabels = hostname.replace(/^www\./, "").split(".");
    // Do not accept arbitrary substring matches in hostnames. For example,
    // 'examplemarine.com.evil.test' and 'notexamplemarine.com' are NOT proof
    // that the source belongs to Example Marine. If the source is hosted by
    // an independent publication, it must name the builder in the excerpt.
    const registrableLabel = domainLabels.length === 2 ? domainLabels[0] : "";
    const manufacturerInEvidence = Boolean(normalizedManufacturer) &&
      (" " + evidence + " ").includes(" " + normalizedManufacturer + " ");
    const manufacturerInHost = normalizedBuilderDomain.length >= 5 &&
      (registrableLabel === normalizedBuilderDomain ||
        registrableLabel === normalizedBuilderDomain + "boats");
    if (!manufacturerInEvidence && !manufacturerInHost) {
      rejected.push("manufacturer identity not supported by retrieved source");
      continue;
    }
    const key = normalizeResearchText(manufacturer) + "|" + normalizedModel;
    if (used.has(key)) { rejected.push("duplicate model"); continue; }
    used.add(key);
    const facts: Record<string, unknown> = {};
    const rawFacts = row.facts && typeof row.facts === "object" && !Array.isArray(row.facts) ? row.facts : {};
    // A known out-of-scope length must exclude a model, not be silently
    // discarded as an invalid field (which would let that model through).
    const assertedLength = Number(rawFacts.loa_ft);
    if (Number.isFinite(assertedLength) && assertedLength > 65) {
      rejected.push("over 65 ft"); continue;
    }
    // No inferred values: keep only explicitly extracted, well-formed facts.
    const vesselType = String(rawFacts.vessel_type ?? "").trim();
    if (vesselType) facts.vessel_type = vesselType.slice(0, 80);
    for (const field of ["loa_ft", "beam_ft", "draft_ft", "fuel_gal"]) {
      const v = rawFacts[field];
      if (v === null || v === undefined || v === "") continue;
      const n = Number(v);
      const maximum = ({ loa_ft: 65, beam_ft: 30, draft_ft: 15, fuel_gal: 10000 } as Record<string, number>)[field];
      if (Number.isFinite(n) && n > 0 && n <= maximum && hasSourceEvidence(source, field, n)) facts[field] = n;
    }
    // The model name and source title can identify an excluded vessel even
    // when an LLM leaves vessel_type blank; treat them as scope evidence.
    const type = normalizeResearchText([facts.vessel_type, model, source.title].filter(Boolean).join(" "));
    const paddedType = " " + type + " ";
    const excludedPlural = [" ribs ", " rigid inflatables ", " sailboats ", " jon boats "].some(term => paddedType.includes(term));
    if (excludedPlural) { rejected.push("out-of-scope vessel"); continue; }
    if (/\b(rib|rigid inflatable|sailboat|sailing|jon boat)\b/.test(type)) {
      rejected.push("out-of-scope vessel"); continue;
    }
    if (typeof facts.loa_ft === "number" && facts.loa_ft > 65) {
      rejected.push("over 65 ft"); continue;
    }
    staged.push({
      manufacturer, model,
      generation: String(row.generation ?? "").trim().slice(0, 120),
      model_years: String(row.model_years ?? "").trim().slice(0, 100),
      source_url: url, source_type: "unverified_web_search_result",
      provider: "anthropic", facts, derived_assessments: {},
      status: "staged",
      verification_notes: "UNVERIFIED pilot extraction from a web-search snippet. Source URL was returned by search, but facts and model identity have NOT been independently confirmed. Verify against primary manufacturer records before promotion."
    });
    if (staged.length >= 5) break;
  }
  return { staged, rejected };
}
