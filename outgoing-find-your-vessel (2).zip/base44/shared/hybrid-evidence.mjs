// Workbook values remain immutable. Only explicit reviewed evidence clears a field.
export const FIELDS = {
 "LOA": {key:"loa_ft",unit:"ft",basis:"overall_length"},
 "Length w/ Bracket/Engines": {key:"rigged_overall_length_ft",unit:"ft",basis:"rigged_overall"},
 "Beam": {key:"beam_ft",unit:"ft",basis:"beam"},
 "Draft Engines Down": {key:"draft_ft",unit:"ft",basis:"draft_engines_down"},
 "Dry Weight / Displacement": {key:"dry_weight_lb",unit:"lb",basis:"dry_weight"},
 "Fuel Capacity (gal)": {key:"fuel_capacity_gal",unit:"gal",basis:"fuel_capacity"},
 "Passenger Capacity": {key:"passenger_capacity",unit:"persons",basis:"manufacturer_persons_rating"}
};
export const identity = s => String(s || "").toLowerCase().replace(/[^a-z0-9]/g,"");
// A source link is potentially customer-visible and may be stored for years.
// Reject signed or credential-bearing URLs instead of persisting expiring or
// sensitive tokens as evidence. Ordinary non-secret query strings remain valid.
export function hasSensitiveSourceParameters(url) {
 const secretName = /^(?:api[_-]?key|key|access[_-]?token|token|auth|authorization|signature|sig|secret|password|credential|expires?|policy|awsaccesskeyid|x-amz-.+|x-goog-.+)$/i;
 return [...url.searchParams.keys()].some(name => secretName.test(name)) ||
   /^#(?:access[_-]?token|token|api[_-]?key|secret|password|authorization)=/i.test(url.hash);
}
export function safeSource(url) {
 try { const u=new URL(url); return u.protocol==="https:" && !u.username && !u.password && !u.port && !hasSensitiveSourceParameters(u) && !u.hostname.includes("..") && /^[a-z0-9.-]+\.[a-z]{2,}$/i.test(u.hostname) && !/(^|\.)(localhost|local|internal|test|example|invalid)$/.test(u.hostname) && !/^\d+(\.\d+){3}$/.test(u.hostname); } catch { return false; }
}
export function normalizeResolution(field, body, now = new Date().toISOString()) {
 if(!FIELDS[field]) throw new Error("Unsupported field");
 if(!["source_confirmed","conflict","missing","not_checked"].includes(body.status)) throw new Error("Invalid status");
 const result={status:body.status,notes:String(body.notes||"").trim().slice(0,2500),checked_at:now};
 if(!result.notes) throw new Error("Record the reason for this decision");
 if(body.status!=="source_confirmed") return result;
 const value=Number(body.value),start=Number(body.year_start),end=Number(body.year_end);
 if(body.value==="" || body.value===null || !Number.isFinite(value) || value<=0) throw new Error("A positive numeric value is required");
 if(field==="Passenger Capacity" && !Number.isSafeInteger(value)) throw new Error("Persons rating must be a whole number");
 if(!Number.isInteger(start)||!Number.isInteger(end)||start<1900||end>2100||end<start) throw new Error("Explicit applicable model years are required");
 if(!safeSource(body.source_url) || String(body.quote||"").trim().length<8) throw new Error("Source URL and supporting passage are required");
 if(body.unit!==FIELDS[field].unit || body.basis!==FIELDS[field].basis) throw new Error("Units and measurement basis must match the field");
 if(body.source_reviewed!==true) throw new Error("Review the complete source before confirming");
 return {...result,value,year_start:start,year_end:end,source_url:body.source_url,quote:String(body.quote).slice(0,4000),unit:body.unit,basis:body.basis};
}
export function customerFields(rows, year, issues=[]) {
 return Object.keys(FIELDS).map(field=>{
  const applicable=rows.map(r=>r.field_reviews?.[field]).filter(r=>r?.status==="source_confirmed" && Number.isInteger(year) && year>=r.year_start && year<=r.year_end);
  const conflict=issues.some(i=>i.status==="open" && i.kind==="conflict" && (i.field===field||i.field==="General")) || rows.some(r=>r.field_reviews?.[field]?.status==="conflict");
  if(conflict) return {field,status:"conflict",message:"Sources disagree. This specification cannot establish that the boat meets your requirement."};
  if(applicable.length && new Set(applicable.map(r=>r.value)).size>1) return {field,status:"conflict",message:"Reviewed records disagree; admin review is required."};
  if(applicable.length) { const r=applicable[0]; return {field,status:"source_confirmed",value:r.value,unit:r.unit,source_url:r.source_url,checked_at:r.checked_at,year_start:r.year_start,year_end:r.year_end}; }
  const empty=rows.length>0 && rows.every(r=>r.raw_fields?.[field]===null || r.raw_fields?.[field]===undefined || r.raw_fields?.[field]==="");
  return {field,status:empty?"missing":"not_checked",message:empty?"No usable value is recorded.":"Not confirmed for this model year and configuration."};
 });
}
export function datasetCatalog(rows) {
 return rows.map(r=>{
  const out={id:"dataset:"+r.id,manufacturer_name:r.manufacturer,model_name:r.model,verification_status:"published",production_status:"unknown",fact_sources:{}};
  for(const [field,meta] of Object.entries(FIELDS)) {
   const v=r.field_reviews?.[field];
   if(v?.status!=="source_confirmed" || !safeSource(v.source_url)) continue;
   out[meta.key]=v.value;
   out.fact_sources[meta.key]={status:"verified",source_url:v.source_url,measurement_basis:v.basis,unit:v.unit,applicable_year_start:v.year_start,applicable_year_end:v.year_end,checked_at:v.checked_at};
  }
  return out;
 }).filter(r=>Object.keys(r.fact_sources).length);
}
export function maskConflicts(catalog,issues) {
 return catalog.map(r=>{
  const copy={...r,fact_sources:{...r.fact_sources}};
  for(const i of issues) {
   if(i.status!=="open" || i.kind!=="conflict" || identity(i.manufacturer)!==identity(r.manufacturer_name) || identity(i.model)!==identity(r.model_name)) continue;
   for(const [field,meta] of Object.entries(FIELDS)) if(i.field===field||i.field==="General") { delete copy[meta.key]; delete copy.fact_sources[meta.key]; }
  }
  return copy;
 });
}
