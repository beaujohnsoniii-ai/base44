// Shared listing-link helpers for grounding boat suggestions and paid recommendations
// in neutral search results. Used by suggest-boats and generate-advisory so every
// recommendation has a clickable link the buyer can follow to browse live inventory.
//
// We use neutral Google search links (make + model, no year) instead of marketplace-
// specific deep links. This avoids marketplace bias, broken deep links from
// hallucinated listing IDs, and keeps the buyer in control of where they look.

// Real-listing marketplaces we trust. A link is "real" only if its hostname is one of
// these (or a subdomain of them) — used to preserve buyer-supplied listing URLs.
const ALLOWED_HOSTS = ["boattrader.com", "yachtworld.com", "boats.com"];

export function isRealListingUrl(url: string): boolean {
  if (!url) return false;
  try {
    const h = new URL(url).hostname.replace(/^www\./, "").toLowerCase();
    return ALLOWED_HOSTS.some((d) => h === d || h.endsWith(`.${d}`));
  } catch {
    return false;
  }
}

export function sourceFromUrl(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

// Neutral Google search link — make + model + "for sale", no year.
// Used as the fallback when a strong-match boat has no specific listing URL.
// Broader than a year-specific search so the buyer sees full inventory to filter
// by year, price, and location themselves.
export function modelSearchUrl(title: string, make?: string, model?: string): string {
  const clean = String(title || "").replace(/^\s*(19|20)\d{2}\s+/, "").trim();
  const mk = String(make || "").trim();
  let md = String(model || "").trim();
  if (mk && !md && clean.toLowerCase().startsWith(mk.toLowerCase())) md = clean.slice(mk.length).trim();
  const modelName = [mk, md].filter(Boolean).join(" ").trim() || clean;
  const q = `${modelName} for sale`.trim();
  return `https://www.google.com/search?q=${encodeURIComponent(q)}`;
}