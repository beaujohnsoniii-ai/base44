import test from 'node:test';import assert from 'node:assert/strict';
import {isolatePdfPage,verifyClaimAgainstRow} from './page-scoped-pdf.mjs';
const src='https://parkerboats.com/2025.pdf';
test('isolates the 2520 table row rather than adjacent 2820 page',()=>{
 const pages=[{page:35,text:'2520 XLD Sport Cabin\nLength LOA Passenger Rating Beam Hull Draft\n25’4” 33’1” 12 9’6” 17” 5800 lbs'}, {page:36,text:'2820 XLD Sport Cabin\nLength LOA Passenger Rating Beam Hull Draft\n28’ 35’9” 12 9’6” 18” 6400 lbs'}];
 const r=isolatePdfPage(pages,{model:'2520 XLD',year:2025,sourceUrl:src});assert.equal(r.ok,true);assert.equal(r.page,35);assert.match(r.row_text,/33’1/);
 assert.equal(verifyClaimAgainstRow({field:'LOA',value:'35’9”',unit:'ft',measurement_basis:'rigged',source_page:35,source_row_id:r.row_id,source_model_year:2025,exact_quote:'35’9”'},r),false);
 assert.equal(verifyClaimAgainstRow({field:'LOA',value:'33’1”',unit:'ft',measurement_basis:'rigged',source_page:35,source_row_id:r.row_id,source_model_year:2025,exact_quote:'33’1”'},r),true);
});
test('rejects multiple model headings and ambiguous flattened table',()=>{
 const pages=[{page:35,text:'2520 XLD and 2820 XLD\nLength LOA Passenger Rating Beam Hull Draft\n25’4” 33’1”\n28’ 35’9”'}];
 assert.equal(isolatePdfPage(pages,{model:'2520 XLD',year:2025,sourceUrl:src}).ok,false);
});
