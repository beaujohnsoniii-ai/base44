// SoundHeading MATCH QA — like simulation between tiers.
//
// Simulates reasonable Likes a buyer would make between MATCH tiers, to verify
// that later tiers appropriately incorporate prior Likes. Does NOT call production
// toggle-like — writes the simulated durable liked_models state only to the
// Test DB profile.
//
// Likes follow production behavior conceptually:
//   - durable cumulative history
//   - normalized model identity (dedup by make+model)
//   - liked_at_tier
//   - Likes are preference evidence, not hard constraints
//   - hard constraints override Likes

export interface SimulatedLike {
  make: string;
  model: string;
  title: string;
  liked_at_tier: "free" | "match_plus" | "refined_match" | "market_match";
}

// Normalize a make+model identity for deduplication (mirrors production behavior).
export function normalizeModelIdentity(make: string, model: string): string {
  return `${(make || "").toLowerCase().trim()}|${(model || "").toLowerCase().trim()}`;
}

// Simulate likes from a tier's suggestions and merge into the cumulative liked_models.
// Picks 1-3 top-ranked suggestions (with some randomization for realism) and adds
// them to the existing liked_models, deduplicating by normalized make+model.
export function simulateLikes(
  suggestions: any[],
  tier: "free" | "match_plus" | "refined_match" | "market_match",
  currentLikedModels: any[],
): { newLikedModels: SimulatedLike[]; likesAdded: number } {
  if (!suggestions?.length) return { newLikedModels: currentLikedModels, likesAdded: 0 };

  // How many to like: varies by tier (fewer likes at higher tiers — the buyer is
  // narrowing down, so they like fewer but more carefully)
  const maxLikes = tier === "free" ? 3 : tier === "match_plus" ? 2 : tier === "refined_match" ? 1 : 0;
  if (maxLikes === 0) return { newLikedModels: currentLikedModels, likesAdded: 0 };

  // Pick from the top-ranked suggestions (a buyer likes the most appealing ones)
  // with some randomization — not always exactly the top N
  const numToLike = Math.min(maxLikes, suggestions.length, Math.max(1, Math.floor(Math.random() * maxLikes) + 1));
  const candidates = suggestions.slice(0, Math.min(numToLike + 1, suggestions.length));
  // Shuffle slightly and pick numToLike
  const shuffled = [...candidates].sort(() => Math.random() - 0.5).slice(0, numToLike);

  // Build the new likes
  const existingKeys = new Set(currentLikedModels.map((lm) => normalizeModelIdentity(lm.make, lm.model)));
  const newLikes: SimulatedLike[] = [];
  for (const s of shuffled) {
    const make = s.make || "";
    const model = s.model || "";
    const title = s.title || [make, model].filter(Boolean).join(" ");
    if (!title) continue;
    const key = normalizeModelIdentity(make, model);
    if (existingKeys.has(key)) continue; // dedup
    existingKeys.add(key);
    newLikes.push({ make, model, title, liked_at_tier: tier });
  }

  return {
    newLikedModels: [...currentLikedModels, ...newLikes],
    likesAdded: newLikes.length,
  };
}