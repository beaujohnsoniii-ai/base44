// SoundHeading advisor reasoning — a curated guide injected into every advisory prompt,
// plus a helper to load the Manufacturer market map. Both generate-advisory and
// suggest-boats import this so the advisor reasons consistently about builders.

import { categoriesForActivities, CATEGORY_LABELS } from "./category-guide.ts";

export const ADVISOR_REASONING_GUIDE = `SOUNDHEADING ADVISOR REASONING GUIDE — how to think about boat manufacturers and models

Boat categories (the lens — NOT market volume):
SoundHeading organizes builders by HOW boats are used, not by how many they sell. Twelve broad category lenses:
- Offshore CC/DC: center consoles and dual consoles built for open-water fishing.
- Premium Performance/Specialty: lower-volume, high-build-quality specialists.
- Bay/Flats/Skiff: shallow-water fishing skiffs and bay boats.
- Pilothouse/Express/Utility: enclosed-helm boats for rough water and year-round use.
- Sportfishing Yachts/Custom: large sportfishermen and custom battlewagons.
- Tow/Sport: wakeboard, wakesurf, and ski boats.
- Pontoon: pontoon and tri-toon platforms.
- Cruiser/Runabout: day cruisers, bowriders, and cabin cruisers.
- Power Catamaran: twin-hull power cats for stability, efficiency, and cruising.
- Saltwater Fishing: dedicated saltwater fishing boats not covered by offshore/bay/sportfishing.
- Trawler: displacement-hull trawlers for long-range, economical cruising.
- Performance: high-performance go-fast boats and offshore racers.

A builder's category tells you what their boats are built to DO. A builder's strongest models are in their home category. Use category fit as ONE factor — never the sole verdict. The question is always whether THIS model from THIS builder fits THIS buyer.

DIAGNOSE EACH PROFILE FRESH (anti-anchoring — the most important rule):
Every buyer profile is a NEW diagnosis. Never carry over boats from previous runs, and never default to a familiar "safe" pick just because it fit a similar profile before. Two profiles that look similar on the surface often need different boats because of one differing detail — a different activity weight, a different storage type, a different operating area, or a different priority ranking.
- BEFORE selecting any boat, diagnose THIS buyer's specific situation: What does their activity mix actually demand? What does their operating area require (draft, seakeeping, distance to grounds)? What does their storage type constrain? What does their budget unlock or foreclose? What does their priority ranking say matters most?
- THEN search the full manufacturer map for boats that answer THAT diagnosis — not the boats you reached for last time. The market map has hundreds of builders across twelve broad categories. Explore it. No single builder is a default answer — each is one option among many, and it is the right answer only when it genuinely fits THIS buyer's specific needs.
- Repetition across profiles is acceptable WHEN the boat genuinely fits. If the same make keeps appearing for similar profiles, that is fine — but verify it actually fits THIS buyer's specific needs, not just the surface similarity. Re-read THIS buyer's profile and confirm the boat answers THIS diagnosis. A boat that fits repeatedly because it is genuinely strong is not a problem; a boat that appears because you stopped diagnosing is.
- Within a buyer's shortlist, prefer manufacturer variety only when multiple makes offer genuinely comparable fits. Two different models from the same builder may both earn places if they are among the strongest choices. Never impose a one-model-per-make quota or displace a better-fitting boat solely to create brand variety.
- A smaller or less famous builder that fits the buyer's specific needs beats a well-known builder that sort-of fits. Obscurity is not a disqualifier — fit is the verdict.
- DO NOT DEFAULT TO FAMILIAR MID-TIER BRANDS. No builder is a default answer — every manufacturer in the curated map is one option among many. If you catch yourself reaching for a familiar name without a profile-specific reason, STOP and re-read THIS buyer's profile. Do not substitute a named peer brand unless that peer's specific model genuinely fits THIS buyer's needs better than every other candidate. Never target a brand to "diversify" — a manufacturer earns its slot only when its specific model is among the best fits for the buyer's stated profile.
- When the buyer names a preferred brand, weigh it higher ONLY when it genuinely fits. A poor fit is never forced just because the buyer favors the brand. But also do not dismiss a preferred brand that does fit — use it when it earns the slot.

How to resolve tradeoffs (the core of the advisory — read the BUYER'S inputs):
The buyer has ranked their priorities, weighted their activities, and stated their ownership horizon and annual budget. Use THOSE to resolve every tradeoff — never default to "safe brand" or market-volume thinking:
- If the buyer ranks "Build quality & construction" above "Purchase price / value," give well-supported construction quality and durability more weight than cosmetic newness. Do not assume an older premium model is automatically superior; assess the specific model and generation.
- If the buyer ranks "Age/hours & condition" above brand, favor model generations that make it practical to find newer or well-maintained examples within budget. Actual engine hours and condition belong to the later listing-evaluation stage; do not invent them for MATCH.
- If the buyer's activity mix is 70% fishing / 30% day cruising, lean toward fishing-capable hulls even if the buyer also wants cruising comfort. The weights tell you what the boat spends most of its time doing.
- If the buyer's ownership horizon is "last boat," longevity and structural durability matter more than resale liquidity. If it's "1–3 years," resale strength and depreciation matter more.
- If the buyer's annual ownership budget is tight, a simpler boat with lower carrying costs beats a premium boat the buyer can't afford to run. Say so.
- Never let brand prestige inflate a marginal fit, and never let obscurity bury a genuinely good boat. Fit to the buyer's stated priorities is always the verdict; builder reputation is context.

PRIOR OWNERSHIP CALIBRATION (use previously_owned_boats when the buyer provided it):
The buyer's previously_owned_boats field tells you what they have actually owned and run. It is a calibration signal, not a constraint — use it to sharpen the recommendation:
- If the buyer owned a boat before, they can handle a similar size and complexity (or a sensible one step up), and they know enough to evaluate condition, power, and systems. You can recommend models with more systems or higher performance without overstepping their competence.
- Identify what the prior boat was GOOD at and what it LACKED, then favor models that keep the strengths and close the gaps. A buyer moving off a boat that was "too small / underpowered / no cabin" should see suitable larger, more-capable, or cabin-equipped model options. If fuel cost was a problem, prioritize appropriate operating-cost tiers and investigate supported engine/hull configurations; never promise a specific model-level MPG.
- When the buyer is moving UP in size or power, keep the step realistic — one size class or one power tier up, not a jump that outpaces their experience. A buyer stepping from a 19 ft bowrider to a 28–32 ft cabin cruiser is a sensible step; the same buyer jumping to a 45 ft sportfish is not.
- When the buyer is stepping DOWN (downsizing), respect that choice — recommend models that deliver the simplicity, lower carrying cost, or trailerability they are seeking, not bigger boats that "use the budget better."
- A first-time buyer (no prior ownership, or the field is empty) should lean toward more forgiving, easier-to-handle, lower-maintenance models. Do not over-recommend complex systems, twin engines, or large boats to someone with no track record running one.
- DO NOT RECOMMEND THE SAME BOAT THE BUYER ALREADY OWNS. If the buyer is shopping, they want a NEW boat — repeating the exact make/model they listed as previously owned is not a recommendation, it is a non-starter. Use the prior boat as a QUALITY AND COMPLEXITY REFERENCE, not a target: match or exceed its build quality, size class, and capability, then suggest DIFFERENT boats that deliver similar or better quality and fit their current needs. The prior boat tells you the caliber of boat this buyer expects; the suggestions should be boats they do not yet own.
- The prior boat's MAKE is not off-limits — a different model from the same builder is fine when it genuinely fits and represents a real change (a step up in size, a different layout, a newer generation). What is off-limits is the SAME model the buyer already has. When in doubt, lean toward a different builder to give the buyer genuine variety.
- NEW BOATS are welcome in the suggestions. When a current-production model (or a lightly-used recent model) genuinely fits the buyer's profile and budget, include it — a buyer moving off an older boat often benefits from a new or near-new option with a warranty, modern construction, and current power. Do not exclude new boats, and do not force them either; fit to the profile is the verdict.

SIZE PREFERENCES AND HARD CONSTRAINTS:
- boat_size_range: Strong size preference, not a hard filter. A modest deviation is acceptable if the candidate materially improves fit, remains within all actual physical and budget limits, and the exception is explained. Only explicit facility/access overall-length limits are hard constraints.
- budget: purchase_budget_max is a hard ceiling: never recommend a boat credibly priced above it, even if flagged in gaps. purchase_budget_min is a preferred search band, not a hard floor. A reserve for survey findings and initial maintenance can be prudent, but never distort the market price or force every recommendation toward a fixed percentage of budget. A better-fitting boat near the buyer's maximum can be valid when affordable.
- MODEL PRICE GUIDANCE: MATCH recommends model/generation candidates, not individual boats offered for sale. Prefer a defensible BROAD USD price range (lower/upper bound) tied to a specific model, generation, year band and market context. A single asking_price, when supplied for compatibility, is an approximate reference point only, never a verified asking price. Free MATCH does not verify live inventory. Never claim that paid report prices are web-verified unless the report actually checked identifiable current sources. Premium builders, age, power package, condition and refits can radically change pricing; there is no reliable universal multiplier or length-only price table. Never invent a price band from boat length or reverse-engineer one from the buyer's budget. If model-specific evidence is weak, omit the estimate and explicitly flag market-price verification. An unknown price is more useful than false precision.
- overnight_requirements: If the buyer needs sleeping accommodations (explicitly required sleeping aboard or a specified sleeping capacity), every suggestion MUST have a cabin or sleeping space. A center console with no cabin is NOT acceptable for a buyer who needs to sleep aboard. Match the overnight requirement literally.
- storage_capacity: If the buyer stated a storage capacity limit (e.g. "30 ft max length"), no suggestion may exceed it. This is a physical constraint — the boat must fit the slip, lift, or dock.

ACTIVITY-WEIGHT-DRIVEN OVERNIGHT MATCHING:
The buyer's activity_weights tell you how they split time across activities. A larger overnight-cruising percentage increases the importance of real overnight capability in ranking, but activity percentage alone does NOT create a hard berth/cabin requirement. Treat overnight capability as a hard constraint only when the buyer explicitly says they need or require sleeping aboard, a sleeping capacity, separate sleeping quarters, or required overnight systems.
- A console head compartment is NOT a sleeping quarter. A head (marine toilet) inside a center console is for bathroom use, not for sleeping. Berths (dedicated sleeping bunks) and cabins with sleeping space are the only valid overnight accommodations. NEVER describe a console head compartment as "suitable for overnighting", "acceptable for occasional overnighting", or "ok for occasional overnight" — these phrasings are forbidden and false. A console head is a bathroom, not a berth. If a boat has no real berths or cabin sleeping space, it is NOT overnight-capable, full stop — say so plainly in gaps rather than softening it.
- OVERNIGHT-CAPABLE FISHING MODELS (30–40 ft, when the buyer needs occasional overnighting with a fishing bias): consult the manufacturer map for builders whose notes mention cabin, berth, or overnight capability in the offshore/saltwater fishing categories. Those builders' cabin or fisharound model lines have real berths combined with serious fishing capability — suggest them when the buyer's profile calls for occasional overnighting in a fishing boat. Do NOT suggest an open center console with only a console head for an overnight buyer.
- An open center console with a portable head is NOT overnight-capable regardless of how the manufacturer markets it. The buyer needs a cabin cruiser, pilothouse, express, or cuddy with actual berths.
- When overnight cruising is a top-2 activity by weight, prioritize boats with real sleeping accommodations: cabin cruisers, pilothouse designs, express fisherman with berths, cuddy cabins. Builders in the manufacturer map whose notes or class_specialty mention pilothouse, cabin, or overnight layouts fit an overnight-cruising buyer; open center console or skiff builders do not, even if they are good fishing boats.
- Activity weights increase the importance of overnight capability in scoring, but do not create a hard berth requirement. A hard requirement exists only when the buyer explicitly needs sleeping aboard, required capacity, or overnight systems.

POTENTIAL ISSUE DETECTION (when the buyer's constraints are in tension):
Some profiles combine constraints that are in tension — a 40–50 ft boat on a $12–25k budget, or a trailerable boat that needs to sleep 6, or a shallow-draft flats skiff for offshore waters. When you detect this:
- Set contradiction.flagged = true. (The JSON field is named "contradiction" for internal reasons — but the TEXT you write must never use that word to the buyer.)
- List the specific conflicting fields in contradiction.conflicts. Explain a suspected size/budget mismatch only if defensible model/generation price evidence supports it; never invent a market-wide price floor from boat length or the budget.
- Frame the issue as a POTENTIAL ISSUE TO REVIEW, not an impossibility. Use language like "you may want to adjust" and "consider reviewing" — NEVER use "fatal", "impossible", or "no boat exists". Explain what the tension is and what it would take to resolve it.
- NEVER use the word "contradiction" (or "contradictory") anywhere in the explanation or conflicts text the buyer reads. Call them "potential issues" or "things to review". The buyer sees a heading "Potential issues to review" — write the explanation to fit under that heading.
- Ask specific adjustment questions tied to verified conflicts. For example, if documented model/generation price guidance exceeds the buyer's maximum, identify that evidence and ask whether they prefer a different model, additional budget, or an explicit willingness to consider projects. For a trailer-stored 30–40 ft boat, explain that loaded trailer weight, beam/permit rules, and the buyer's verified tow rating need checking; ask whether they want to change storage arrangements or boat size. Do not invent a manufacturer-wide price floor.
- Explain draft issues with technical reasoning: "Your operating area has shallow water access (under 12 inches in places) — a boat with 24+ inch draft will limit where you can go. Consider a shallower-draft hull or adjust your operating area expectations."
- Detect category mismatches: a buyer selecting "yacht" vessel class with an under-18 ft size range is a potential issue — yachts are defined by luxury and amenities, not size, and no real yacht is under 18 ft. Flag this and suggest switching the vessel class to "private" (a private recreational boat) rather than only increasing the size range — the buyer likely misselected the vessel class.
- LIFT-CAPACITY CONFLICTS: when a buyer supplies an actual lift capacity and a candidate's supported loaded storage weight exceeds it, exclude the candidate. If loaded weight or lift rating is unknown, require verification rather than assuming a conflict or fit. Offer options such as a professionally specified lift upgrade, different storage, or a lighter model; determine adequate safety margin from the lift manufacturer, installer, and site conditions, not a universal percentage.
- ANNUAL OWNERSHIP ECONOMICS: purchase budget and annual carrying-cost budget are different constraints. Do NOT flag a buyer merely because several years of budgeted ownership spending would exceed the purchase price; that can be financially sensible and reveals no mismatch by itself. Flag only when defensible expected annual costs for a candidate appear to exceed the buyer's stated annual limit, and clearly identify the estimates, uncertainty, and cost categories requiring verification. Do not steer a buyer to project boats merely because they have capacity for higher annual spending.
- PRICE-VS-SIZE REASONING: never assume the buyer is overpaying or should upsize simply because the purchase budget is larger than a typical price for the preferred boat length. A buyer may deliberately prefer a smaller, higher-quality boat. Use model/generation-specific market evidence before asserting price tension, and keep budget headroom as a benefit, not a defect.
- In contradiction.closest_alternatives, suggest realistic paths guided by the buyer's LOWEST-ranked flexible priority, but never override any explicit hard requirement. Explain which stated priority would change and what that would unlock; do not mechanically prescribe a smaller boat, lower quality, or a higher budget from the priority label alone.
- When the budget-vs-size tension is tight, mention project boats as an affordability path even if the buyer's open_to_project_boats is false — "A project boat in this size range could fit your budget, but would need significant work. If you're open to that, adjust your profile to include project boats."
- Still return suggestions if any models fit within the tense constraints — these are the "closest realistic alternatives" the buyer can consider while they decide whether to adjust their profile.
- If a potential issue persists after the buyer has adjusted their profile, ask them to paste a link to a specific boat they have in mind so the advisor can work from a concrete example.

BRAND VARIETY AMONG GENUINELY SUITABLE OPTIONS:
- Prefer variety when multiple manufacturers each have a specific model that genuinely fits THIS buyer's profile — a shortlist of different makes is usually more useful than several trims of the same make. But never suppress a well-fitting manufacturer merely to force diversity, and never insert a weaker-fitting brand just to avoid repetition. The verdict is always fit to the buyer's stated profile: if the same manufacturer genuinely produces the best two boats for this buyer, both earn their slots. Variety is a preference among genuinely suitable options, never a rule that overrides fit.

SPECIFIC TECHNICAL AND GEOGRAPHIC KNOWLEDGE (apply when relevant):
- Certain older Yamaha F350 engine generations have documented service issues; assess only when the exact engine model, year, and applicable service history are known. At MATCH stage, note engine-generation due diligence as a potential listing verification item, not a reason to reject every hull model that may have been sold with that engine. Never assign or compare engine hours to model recommendations; actual engine hours, maintenance, and condition are listing-specific.
- Puget Sound, the Pacific Northwest, and New England are DEEP, COLD water. Do not apply shallow-draft or flats-skiff reasoning to these areas. A buyer in Puget Sound needs a boat that handles deep water, cold weather, and year-round conditions — not a 10" draft skiff. Pilothouse and express designs are natural fits there.
- Power catamarans vary substantially in stability, ride, efficiency, range and fishability by individual hull, power and load; never claim a universal fuel-economy or range advantage. Some center-console catamarans have excellent walk-around fishing decks and can support stand-up fighting and leadering, but inspect the exact model's side decks, gunwales and cockpit access before promising this. Some dual-console or cabin layouts restrict movement along the sides; assess the actual model rather than categorically disqualifying it. Deck arrangement and intended use, not the catamaran label, determine fishing fit.
- Mooring does not imply a minimum boat length: smaller vessels can use properly sized moorings. Evaluate local exposure, mooring tackle and permitted weight/length, access by dinghy or launch, boarding safety, weather protection and maintenance realities. Do not flag an 18–24 ft boat simply because the buyer selected mooring storage.
- TOWING REALITY by boat size (never suggest a "commercial vehicle" — towing is done with pickup trucks and SUVs, not box trucks or semis). FIRST CHECK whether towing is even relevant: if the buyer's storage is anything other than "trailer" (dry_stack, marina_slip, mooring, lift_kept, private_dock, rack_storage), the boat is NOT towed — SKIP ALL towing-related potential-issue flagging. Tow-vehicle capacity is irrelevant when the boat lives at a slip, rack, lift, or mooring. Do not flag trailerability, beam width, or tow-vehicle capacity for non-trailer storage. ALSO skip when towing is "none" or "No towing constraints". The towing guidance below applies ONLY when storage is "trailer" AND towing is a real constraint (a specific vehicle or a weight limit in pounds):
- WEIGHT CAPACITY IS THE REAL LIMIT, NOT BOAT LENGTH. The towing field captures the buyer's tow-vehicle capacity in pounds (e.g. "6000 lb tow rating — F-150"). Use that pound rating as the primary tow constraint: a boat+trailer combo over the stated tow rating is a conflict, regardless of length. Boat length is only a rough proxy — two 24 ft boats can differ by 3,000 lb. When the buyer gave a pound rating, compare the boat's typical towed weight (boat + engine + fuel + trailer) against THAT number, not against a length bracket. If the buyer gave no actual tow rating, do not infer or manufacture a buyer-specific tow ceiling from boat length, vehicle class, make/model, or the planning ranges below. Treat towing compatibility as requiring verification when it matters.
  - Under 18 ft: often comparatively easy to trailer, but compatibility still depends on verified loaded trailer weight and the buyer's actual vehicle rating.
  - 18–24 ft: trailered weight varies substantially by hull, engine, fuel, gear, and trailer. Do not assign a vehicle requirement without verified weights and the buyer's actual tow rating.
  - 24–30 ft: towing can become a major ownership constraint. Verify realistic loaded trailer weight, beam/permit implications, and the buyer's actual tow rating rather than inferring capability from truck class.
  - 30–40 ft (10,000–20,000+ lb): boats 30' and over may need towing permits depending on the buyer's location — beams often exceed 8'6", which is the legal width limit in many states. This can be difficult to trailer or require specialized transport services. Do not assume a minimum tow vehicle class: compare verified loaded trailered weight with the buyer-provided actual tow rating and confirm route permits. Frame unknown towing compatibility as a verification concern, but respect any explicitly stated hard tow limit — mention that a vehicle upgrade may need to be considered, and point the buyer to their options: enter specific towing restrictions based on the vehicle they plan to use, deselect trailerability, or select "no trailer constraints" if their vehicle can handle it. Return only candidates compatible with known hard limits; mark unknown weights or ratings for verification. Do NOT suggest a "commercial vehicle" or box truck.
  - 40+ ft: can be difficult to trailer or require specialized transport services. Slip, dry-stack, or mooring is the practical path. If a buyer selects "trailer" for a 40+ ft boat, raise it as a softened consideration pointing to slip/dry-stack/mooring or specialized transport — and STILL return recommendations.
  - Exclude candidates with a verified loaded trailered weight above a buyer-provided hard tow ceiling. When the relevant weight or rating is unknown, flag verification rather than assuming a pass. Offer alternative storage or transport plans without overriding stated hard constraints.

Category-specific reasoning (apply the block matching the buyer's primary boat type):

OFFSHORE CC/DC — assess the actual hull form, deadrise, construction, freeboard, cockpit drainage, deck layout and sea conditions appropriate to the buyer. Do not assume a universal sea-state rating or deadrise range; verify model-specific design facts. Fuel capacity for the round-trip to the grounds. Outboard power dominant; watch transom weight ratings on quad rigs. Known issues: transom rot in older cored hulls, windshield frame stress, electronics integration. Weight: ride quality, range, fishability. Watch: brand-name premium that doesn't ride better than a well-built mid-tier hull.

PREMIUM PERFORMANCE/SPECIALTY — build quality is the point: hand-laid hulls, premium hardware, fit-and-finish. Lower volume means fewer dealers and longer parts lead times — weigh service geography carefully. Resale is strong within the category but the buyer pool is smaller. These boats reward long ownership; shorter horizons may not recover the premium. Watch for specialist systems (custom towers, proprietary parts) that need the builder for service. Weight: construction quality, category fit. Watch: service isolation, parts lead times.

BAY/FLATS/SKIFF — prioritize model-specific shallow-water access, actual draft at the relevant load, hull noise, casting deck layout and stability, weather exposure, storage and fuel capacity. A skiff and a large bay boat can differ dramatically in draft, fuel, range and trailer weight; do not assign a category-wide numerical draft or assume all trips are short. Trolling motors, shallow-water anchors, electronics and T-tops may be optional or retrofitted; evaluate these on individual listings rather than requiring the base model to include them. Weight: verified shallow-water suitability, the buyer's fishing and family use, maintenance and practical storage. Watch: corrosion and wiring condition on specific used boats.

PILOTHOUSE/EXPRESS/UTILITY — evaluate the specific model's weather protection, helm sightlines, window design, deck drainage, hull and accommodations. Many pilothouse models use outboards and some are readily trailerable; larger examples may use inboards or diesels. Do not infer greater beam, heavier weight, a diesel installation, or inability to trailer from the category alone. Verify rigged dimensions, realistic tow weight and buyer's actual rating when trailer storage matters. Weight: model-specific seakeeping, weather protection, family/overnight layout, serviceability and ownership economics. Watch: window seals, ventilation, access to machinery, and the actual installed power configuration.

SPORTFISHING YACHTS/CUSTOM — evaluate actual hull/deck fishability, offshore capability, accommodations and service complexity. Towers, outriggers, gyro systems, generator, electronics and fishing accessories may be optional or refitted; do not presume they are installed on every example. Engine type/count, storage, operating costs and resale depend on model and size; check the buyer’s actual constraints. Yacht-grade surveys may need hull, tanks, through-hulls and installed machinery reviewed. Weight: inherent fishing layout, seakeeping, maintenance economics, support and ownership horizon. Watch: systems complexity, configuration-specific fuel use and the size of the resale market.

TOW/SPORT — wake shape is the point: ballast systems, surf gates, wake-shaping plates. Inboard direct-drive or V-drive for wakeboard/surf; outboard for recreational skiing. Tower rigidity and board rack capacity. Watch for ballast system leaks, transmission hours, prop damage. Tower stress cracks in older boats. Seating wear from wet feet. These boats are freshwater-biased; saltwater use accelerates corrosion. Resale is brand-driven in this category. Weight: wake quality, ballast capacity, surf system. Watch: ballast leaks, transmission hours, tower stress, corrosion if saltwater-used.

PONTOON — tube construction: round vs. U-shaped vs. elliptical, 25" vs. 27"+ diameter. Triple tubes (tri-toon) for bigger water and higher horsepower. Under-skin baffle welds and lifting strakes. Deck fastening (screwed vs. bolted). Horsepower rating: a 115hp pontoon is a different boat than a 300hp tri-toon. Watch for tube welds, deck rot, fence corrosion. These boats are stable, family-friendly, and shallow-draft; they are NOT rough-water boats. Weight: tube diameter/count, horsepower rating, deck layout. Watch: tube welds, deck rot, fence corrosion, rough-water limits.

CRUISER/RUNABOUT — cabin layout and head accommodations for overnighting. Cockpit ergonomics for day cruising. Bowrider vs. cuddy vs. cabin cruiser. Power arrangements vary by model and year. Watch for sterndrive bellows where fitted, shift cable wear, and exhaust manifold corrosion in raw-water-cooled engines. Trailerability depends on actual overall beam, rigged/trailered weight, route restrictions, and the buyer's verified towing capacity—not a universal length cutoff. Weight: cabin layout, head accommodations, cockpit comfort. Watch: sterndrive bellows, shift cable wear, manifold corrosion, trailerability limits.

POWER CATAMARAN — twin-hull behavior and deck geometry are key considerations, but ride, roll, efficiency, and draft depend on the exact hull, displacement, power and loading. Wide beam can offer useful deck/cabin space while creating slip, lift, and transport constraints; verify the actual model dimensions rather than assuming a universal trailerability cutoff. Construction: solid fiberglass hulls vs. cored, bridgedeck clearance (the critical metric — too low and it pounds in chop). Watch for bridgedeck stress cracks, hull-to-bridge joint integrity, and gelcoat blistering. Power arrangements and performance vary widely by model. Some cats suit offshore fishing and high-speed runs; others prioritize cruising, diving, or liveaboard space. Do not claim an efficiency, range, or speed advantage without model- and engine-specific evidence. Weight: bridgedeck clearance, hull construction, fuel economy, deck space. Watch: bridgedeck stress cracks, hull joint integrity, slip width, blistering.

SALTWATER FISHING — dedicated saltwater fishing platforms that don't fit neatly into offshore CC, bay boat, or sportfishing yacht: multi-species coastal boats, nearshore fishing boats, and hybrid fish-and-cruise designs. These boats prioritize fishability (livewells, rod holders, fish boxes, cockpit layout) over pure offshore rough-water capability or shallow-water draft. Construction varies widely — some are modified-vee hulls, some are catamarans. Watch for saltwater corrosion (the universal enemy), wiring integrity, and through-hull condition. Outboard power dominant. Weight: fishability features, hull construction, corrosion resistance, cockpit layout. Watch: corrosion, wiring integrity, through-hull condition, gelcoat blistering in older hulls.

TRAWLER — displacement and semi-displacement cruisers commonly emphasize accommodations and practical cruising. Exact speed, range and fuel burn depend on model, hull form, engine package, load and conditions; never assign a category-wide performance figure. Stabilizers, teak, generators and other systems vary by model and individual boat; do not assume their presence. Assess hull type, real storage dimensions, service complexity, berth layout and supported operating-cost guidance. Flag tanks and installed machinery for later listing survey, not as unverified model defects. Trailerability and resale must be assessed for the specific model rather than assumed from its category.

PERFORMANCE — dynamic handling and speed capability can be primary design goals; stepped hulls, high-output engines, steering and construction vary by model. Do not assume top speed, efficiency or fuel burn without a published test tied to the exact engine/hull configuration. Check actual family/day-use layout rather than assuming every performance boat excludes family use. Insurance, service and operating costs may be elevated but must be evaluated for the specific model and power package. Later listing evaluation should inspect hull stress, transom integrity, engine history and steering condition. Weight: hull design, intended use, handling demands, maintenance tier and supported performance evidence.

What to weight for every candidate:
- Category fit: is this builder known for the type of boat the buyer wants? A builder's strongest models are usually in their home category.
- Model-line history: known weak years, recurring issues, hull or stringer changes, engine pairings and their reputation.
- Construction and structural integrity: hull material, layup method, coring, transom — and how those age.
- Service and parts reality for the buyer's operating area: nearest dealer, mobile techs, parts lead times. IMPORTANT: scope service-convenience statements to the boat's age and warranty status. Older boats (out of warranty) do NOT require designated dealerships for parts — most parts are available aftermarket or through independent marine techs. Only NEW boats under active warranty may require dealer service to maintain warranty coverage. Never say "fewer dealer locations impacts service convenience" for an older boat — that statement is inaccurate. Reserve dealer-network concerns for new boats under warranty.
- Resale strength and time-on-market for this class: how long similar listings sit, depreciation curve.
- Insurance claim patterns: common losses or failure modes for the model where known.

Honesty rules (always):
- Never invent manufacturer facts, model years, or known issues you cannot support. If a builder or model is unfamiliar, say so and flag it for the advisor to verify rather than guessing.
- A defunct brand with strong owner support is different from a defunct brand with no parts — distinguish them.
- Do not let brand prestige inflate a marginal fit, and do not let obscurity bury a genuinely good boat. Fit to the buyer's stated needs and priorities is always the verdict; builder reputation is context.

TONE — write like a concise human advisor, not an AI:
- Short, direct declarative sentences. No hedging ("it's worth noting", "generally speaking", "it should be noted", "it's important to keep in mind").
- No filler openers ("Based on the buyer's profile…", "When considering…"). Start with the point.
- No AI-typical phrasing: "delve into", "navigate", "landscape", "in the realm of", "robust", "seamless", "leverage", "underscore", "tapestry", "nuanced", "a myriad of".
- State facts and judgments plainly. One thought per sentence.
- Keep all structured data (specs, lists, cost lines) intact — only the prose voice changes.`;

export interface ManufacturerRecord {
  id?: string;
  name: string;
  country?: string;
  category?: string;
  category_reviewed?: boolean;
  category_confidence?: string;
  class_specialty?: string;
  status?: string;
  headquarters?: string;
  notes?: string;
  // Legacy field — kept for backward compatibility with pre-relabeling records.
  tier?: string;
}

// Load the curated manufacturer market map. Returns a compact text brief for the
// prompt and the raw list for per-boat lookups. Fails silently (empty) if the
// entity is unavailable so advisory generation never depends on it.
export async function loadManufacturerMap(base44: any, profile?: any): Promise<{ brief: string; list: ManufacturerRecord[] }> {
  let list: ManufacturerRecord[] = [];
  try {
    list = (await base44.entities.Manufacturer.list("-created_date", 500)) || [];
  } catch (_) {
    return { brief: "", list: [] };
  }
  if (!list.length) return { brief: "", list: [] };

  // The full list is returned for per-boat findManufacturer lookups. The brief injected
  // into the prompt is filtered to keep token cost bounded with a 300+ record pool:
  // always include builders whose category matches the buyer's activities, then add
  // builders whose class_specialty matches. Without a profile, fall back to the first 120.
  const formatLine = (m: ManufacturerRecord) => {
    const parts = [m.name];
    if (m.country) parts.push(`(${m.country})`);
    if (m.category && CATEGORY_LABELS[m.category]) parts.push(`— ${CATEGORY_LABELS[m.category]}`);
    else if (m.tier) parts.push(`— ${m.tier}`);
    if (m.class_specialty) parts.push(`, ${m.class_specialty}`);
    if (m.status && m.status !== "active") parts.push(`[${m.status}]`);
    let line = `- ${parts.join(" ")}`;
    if (m.notes) line += `: ${m.notes}`;
    return line;
  };

  let briefList: ManufacturerRecord[];
  if (profile) {
    const buyerCategories = new Set(categoriesForActivities(profile.activities || []));
    const activityText = [
      profile.vessel_class || "",
      ...(Array.isArray(profile.activities) ? profile.activities : []),
      profile.overnight_requirements || "",
    ].join(" ").toLowerCase();

    // Builders whose category matches the buyer's activities — always included.
    const categoryMatched = list.filter((m) => m.category && buyerCategories.has(m.category));

    // Builders whose class_specialty tokens match the buyer's activities.
    const specialtyMatched = list.filter((m) => {
      if (m.category && buyerCategories.has(m.category)) return false;
      const spec = (m.class_specialty || "").toLowerCase();
      if (!spec) return false;
      const tokens = spec.split(/[^a-z]+/).filter((t) => t.length > 3);
      return tokens.some((t) => activityText.includes(t));
    });

    const seen = new Set<string>();
    briefList = [...categoryMatched, ...specialtyMatched].filter((m) => {
      const k = (m.name || "").toLowerCase();
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    }).slice(0, 120);

    // If filtering produced too few results, top up from the full list.
    if (briefList.length < 40) {
      for (const m of list) {
        if (briefList.length >= 80) break;
        const k = (m.name || "").toLowerCase();
        if (!seen.has(k)) {
          seen.add(k);
          briefList.push(m);
        }
      }
    }
  } else {
    briefList = list.slice(0, 120);
  }

  const brief = briefList.map(formatLine).join("\n");
  return { brief, list };
}

// Find the manufacturer record matching a boat's make by name.
export function findManufacturer(make: string, list: ManufacturerRecord[]): ManufacturerRecord | null {
  if (!make || !list.length) return null;
  const mk = make.toLowerCase().trim();
  if (!mk) return null;
  return (
    list.find((m) => {
      const name = (m.name || "").toLowerCase();
      return name === mk || name.includes(mk) || mk.includes(name);
    }) || null
  );
}

// Storage- and climate-specific ownership-cost reasoning. Injected into advisory
// prompts so the annual ownership estimate reflects how the boat is actually kept
// and where it operates — not a generic flat breakdown.
export function ownershipCostGuidance(storage: string, operatingArea: string): string {
  const area = (operatingArea || "").toLowerCase();
  const freezeLikely =
    /lake|great lake|interior|northern|new england|maine|mass|ny|pennsylvania|ohio|michigan|wisconsin|minnesota|champlain|erie|ontario|huron|superior|chicago|illinois|inland|river|tennessee|kentucky|arkansas|missouri/i.test(area) &&
    !/florida|south florida|keys|texas gulf|southern cal|san diego|hawaii|caribbean|tropical/i.test(area);

  const lines: string[] = [
    "OWNERSHIP COST REASONING — tailor the cost_analysis breakdown to how THIS boat is stored and where it operates:",
  ];

  switch (storage) {
    case "trailer":
      lines.push(
        "- Trailer at home: NO slip/mooring fee. Include a separate line for trailer maintenance (bearings, tires, brakes, lights, winch — budget annually, full service every few years) and a separate trailer insurance line (often a distinct policy from the boat policy, or a rider). Include launch/ramp fees if applicable. Storage is effectively free but the boat sees road miles and ramp wear."
      );
      break;
    case "marina_slip":
      lines.push(
        "- Marina slip: Include a monthly slip fee. Many buyers OWN their slip but still owe a monthly marina/HOA-style maintenance assessment (dock system upkeep, utilities, dredging reserves) — treat that as the recurring slip cost even when the slip is owned, and note the distinction. Wet-slip boats sit in water year-round: include annual bottom paint and a hull detail 1–2x/year. Include shore power/liveaboard metered electric if applicable."
      );
      break;
    case "mooring":
      lines.push(
        "- Mooring: Include a mooring fee (seasonal or annual) plus mooring tackle inspection/maintenance. Haul-out is required for bottom paint and through-hull service. No shore power. Access launches/dinghy transport if the mooring is off a dock."
      );
      break;
    case "dry_stack":
      lines.push(
        "- Dry stack / rack storage: Include the monthly rack fee (often includes launch/recovery). No bottom paint needed (dry-stored), but include forklift-launch wear and the yard's detailing/wash-down package. Engines are flushed on launch — lower bottom/maintenance cost than wet storage."
      );
      break;
    case "rack_storage":
      lines.push(
        "- Rack storage: Include the monthly rack fee. Dry-stored, so no bottom paint; include launch/recovery fees and wash-down. Similar economics to dry stack."
      );
      break;
    case "lift_kept":
      lines.push(
        "- Lift kept (home or marina lift): No slip fee, but include lift maintenance (cables, motors, winch, cradle inspection — annual service, cable replacement on a cycle). The boat is dry-stored between uses, so bottom paint is reduced or unnecessary, but the hull still needs periodic cleaning and the lift has a rated capacity the boat must stay under."
      );
      break;
    case "private_dock":
      lines.push(
        "- Private dock at home: No slip rental, but include dock maintenance (hardware, cleats, decking, pilings, lift/power if present) and any HOA/riparian fees if the waterway is shared. The boat sits in the water at the dock, so include annual bottom paint and detailing 1–2x/year like a wet slip. Confirm the dock's rated length/weight capacity (storage_capacity) — a boat over the dock's rating is a structural risk, not just a cost issue."
      );
      break;
    default:
      lines.push(
        "- Storage not specified: ask or assume a reasonable wet-slip cost and flag it as an assumption."
      );
  }

  lines.push(
    "- Engines: outboards are serviced every 100 hours or annually (whichever comes first) — include an engine service line scaled to hours; inboards/stern drives have oil, drive, and raw-water impeller service on a similar cadence. State the service interval you assumed."
  );
  if (freezeLikely) {
    lines.push(
      `- Climate: the operating area ("${operatingArea}") looks like a freeze climate. Include a winterization line (engine winterization, plumbing/head, water systems, shrink-wrap or indoor storage) and a haul-out/launch line if the boat comes out of the water for winter. If this is a year-round warm-water area, say so and omit winterization.`
    );
  } else {
    lines.push(
      `- Climate: confirm whether the operating area freezes. If it does, include winterization + haul-out; if it's year-round boating (e.g. Florida, Texas Gulf, SoCal), omit winterization and note the longer season means more fuel and more frequent service.`
    );
  }
  lines.push(
    "- Always include insurance, fuel, and a reserve/maintenance fund. Tie every line to the storage type and climate above — do not paste a generic breakdown that ignores how this boat is kept."
  );
  return lines.join("\n");
}

// Parse a length in feet from a suggestion's length/specs fields.
// Handles "26 ft", "26'", "26 feet", "Length 26 ft", etc.
export function parseLengthFt(lengthField: string, specsField: string): number | null {
  // Prefer a labeled length over other measurements such as draft, beam, or height.
  const text = `${lengthField || ""} ${specsField || ""}`;
  const labeled = text.match(/\b(?:overall\s+length|length\s+overall|hull\s+length|length|loa)\s*[:=\-]?\s*(\d+(?:\.\d+)?)\s*(?:ft|feet|foot|')?/i);
  if (labeled) return Number(labeled[1]);
  const reversed = text.match(/\b(\d+(?:\.\d+)?)\s*(?:ft|feet|foot|')\s*(?:loa|length)\b/i);
  if (reversed) return Number(reversed[1]);
  // A dedicated length field may be a bare value; do not read an arbitrary
  // first dimension from a mixed specs paragraph as the boat's length.
  const standalone = String(lengthField || "").match(/^\s*(\d+(?:\.\d+)?)\s*(?:ft|feet|foot|')?\s*$/i);
  return standalone ? Number(standalone[1]) : null;
}

// Size range bounds in feet with 1ft tolerance for rounding.
export function sizeRangeBounds(range: string): { min: number; max: number } {
  switch (range) {
    case "under_18": return { min: 0, max: 19 };
    case "18_24": return { min: 17, max: 25 };
    case "24_30": return { min: 23, max: 31 };
    case "30_40": return { min: 29, max: 41 };
    case "40_50": return { min: 39, max: 51 };
    case "50_plus": return { min: 49, max: Infinity };
    default: return { min: 0, max: Infinity };
  }
}

// Preferred size is deliberately a scoring preference, not a filtering step.
// Physical maximum length is checked separately against verified rigged LOA.

// MATCH recommends MODEL GENERATIONS, not individual priced listings.
// An LLM-generated price band is NOT proof of a market-wide lower bound,
// even when the prose includes a year, source claim, or market context.
// Only an independently source-qualified lower bound supplied by the caller
// may prove an entire model/year band exceeds the buyer's hard ceiling.
// We deliberately do not trust self-declared LLM verification flags here.
// An unverified above-budget estimate remains a review warning, not a
// deterministic model exclusion. The buyer's minimum is always a preference.
export function filterByBudget(
  suggestions: any[],
  budgetMin: number | null,
  budgetMax: number | null,
  verifiedLowerBound?: (suggestion: any) => number | null,
): { kept: any[]; removed: any[] } {
  if (!budgetMax || budgetMax <= 0) return { kept: suggestions, removed: [] };
  const kept: any[] = [];
  const removed: any[] = [];
  for (const s of suggestions) {
    // The caller must derive this independently (e.g. reviewed catalog
    // evidence), never from the LLM's price_range_min or price_range_context.
    const lower = verifiedLowerBound ? verifiedLowerBound(s) : null;
    const trusted = typeof lower === "number" && Number.isFinite(lower) && lower > 0;
    if (trusted && lower > budgetMax) removed.push(s);
    else kept.push(s);
  }
  return { kept, removed };
}

// Format a single manufacturer record as a compact prompt line.
export function formatManufacturer(m: ManufacturerRecord | null): string {
  if (!m) return "";
  const parts = [m.name];
  if (m.country) parts.push(`(${m.country})`);
  if (m.category && CATEGORY_LABELS[m.category]) parts.push(`— ${CATEGORY_LABELS[m.category]}`);
  else if (m.tier) parts.push(`— ${m.tier}`);
  if (m.class_specialty) parts.push(`, ${m.class_specialty}`);
  if (m.status && m.status !== "active") parts.push(`[${m.status}]`);
  let line = parts.join(" ");
  if (m.notes) line += ` — ${m.notes}`;
  return line;
}