// Ground advisory links and asking prices in exactly identified buyer records.
// A related model or different variant is never the same individual boat for sale.
// LLM-supplied links, listing prices, and availability claims are not evidence.
import { modelSearchUrl } from "./listing-links.ts";
import { normalizePublicListingUrl } from "./remote-listing.ts";

const identity = (value: unknown): string =>
  String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");

function buyerSuppliedPrice(value: unknown): string {
  const raw = typeof value === "number" ? String(value)
    : typeof value === "string" ? value.trim().replace(/[$,\s]/g, "") : "";
  if (!/^\d+(?:\.\d{1,2})?$/.test(raw)) return "";
  const amount = Number(raw);
  return Number.isFinite(amount) && amount > 0 && amount < 1_000_000_000
    ? `$${amount.toLocaleString("en-US")} (buyer supplied; verify with seller)`
    : "";
}

export function groundReportReferences(
  content: any, type: string, saved: any[], suggested: any[],
): { ok: boolean; reason: string } {
  const introductions = type === "introductions";
  const modelFinalists = type === "top_three";
  const supported = ["top_pick", "top_three", "private_advisory", "introductions"];
  if (!supported.includes(type)) return { ok: true, reason: "" };
  const boats: any[] = introductions ? content?.introductions : content?.recommendations;
  if (!Array.isArray(boats)) return { ok: false, reason: "report recommendations are missing" };
  const safeSaved = Array.isArray(saved) ? saved : [];
  const safeSuggested = Array.isArray(suggested) ? suggested : [];

  if (introductions && boats.length !== safeSaved.length) {
    return { ok: false, reason: "seller introductions did not cover every buyer-submitted candidate" };
  }

  const coveredListings = new Set<string>();
  for (const b of boats) {
    if (!b || typeof b !== "object") {
      return { ok: false, reason: "a recommendation is not a valid boat record" };
    }
    const title = String(b.title || [b.make, b.model, b.year].filter(Boolean).join(" ")).trim();
    const key = identity(title);
    if (!key) return { ok: false, reason: "a recommendation has no identifiable boat or model title" };

    // Never substring-match model names (2520 XL vs 2520 XLD) or choose the
    // first of two indistinguishable saved listings. Both can misdirect buyers.
    const matching = safeSaved.filter(row => identity(row?.title) === key);
    const savedListing = matching.length === 1 ? matching[0] : null;
    const url = savedListing ? normalizePublicListingUrl(savedListing.url) : null;

    if (introductions) {
      if (!url) {
        return { ok: false, reason: "a seller introduction has no unique matching public HTTPS listing URL" };
      }
      if (coveredListings.has(savedListing.id || url)) {
        return { ok: false, reason: "seller introductions repeat a buyer-submitted candidate" };
      }
      coveredListings.add(savedListing.id || url);
    }

    // Market Match is intentionally model-first even when a buyer's saved
    // listing informed their interest in the underlying model.
    if (url && !modelFinalists) {
      b.link = url;
      b.asking_price = buyerSuppliedPrice(savedListing.asking_price);
      b.availability = "Buyer-submitted listing — current availability unverified";
      continue;
    }

    if (introductions) return { ok: false, reason: "a seller introduction lacks an identifiable listing" };
    const exactModel = safeSuggested.find(row => identity(row?.title) === key);
    b.link = modelSearchUrl(title, b.make || exactModel?.make || savedListing?.make,
      b.model || exactModel?.model || savedListing?.model);
    b.asking_price = "";
    b.availability = "Model guidance — not a specific listing";
  }
  return { ok: true, reason: "" };
}
