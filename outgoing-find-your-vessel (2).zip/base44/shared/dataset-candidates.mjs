import {identity,safeSource} from "./hybrid-evidence.mjs";
export const modelKey=(make,model)=>identity(make)+"|"+identity(model);
export function chooseDatasetCandidates(rows,profile,limit=80){
 const range=String(profile.boat_size_range||"").match(/(\d+)[_–-](\d+)/);
 const low=range?Number(range[1]):0,high=range?Number(range[2]):65;
 const shallow=Number(profile.hard_max_draft_ft)>0&&Number(profile.hard_max_draft_ft)<2;
 const fishing=Array.isArray(profile.activities)&&profile.activities.includes("Fishing");
 const unique=new Map();
 for(const row of rows){
  if(!row.manufacturer||!row.model||!safeSource(String(row.raw_fields?.["Primary Manufacturer Source"]||"").split(/[\s,;]/)[0]))continue;
  const key=modelKey(row.manufacturer,row.model),old=unique.get(key);
  if(old&&Number(old.workbook_version)>=Number(row.workbook_version))continue;
  unique.set(key,row);
 }
 const ranked=[...unique.values()].map(row=>{
  const f=row.raw_fields||{},length=Number(f.LOA),type=String(f.Type||"");
  // Discovery priority only. Nominal dimensions never prove physical compliance.
  let score=length>=low&&length<=high?10:Number.isFinite(length)&&length>0?-Math.abs(length-(low+high)/2):0;
  if(shallow&&/bay|flat|skiff|tunnel/i.test(type+" "+row.model))score+=8;
  if(fishing&&/fish|bay|center console|centre console|skiff/i.test(type))score+=3;
  return {row,score};
 }).sort((a,b)=>b.score-a.score||a.row.manufacturer.localeCompare(b.row.manufacturer)||a.row.model.localeCompare(b.row.model));
 // Keep breadth across builders while preserving rank.
 const counts=new Map(),selected=[];
 for(const item of ranked){const make=identity(item.row.manufacturer);if((counts.get(make)||0)>=5)continue;counts.set(make,(counts.get(make)||0)+1);selected.push(item.row);if(selected.length>=limit)break;}
 return selected;
}
export async function loadDatasetCandidates(entity,profile){
 const rows=[];
 for(let skip=0;skip<10000;skip+=500){
  const batch=await entity.list("id",500,skip);
  rows.push(...batch);
  if(batch.length<500)break;
 }
 return chooseDatasetCandidates(rows,profile);
}
export function groundCandidateIdentities(items,rows){
 const byKey=new Map(rows.map(r=>[modelKey(r.manufacturer,r.model),r]));
 return items.flatMap(s=>{
  const row=byKey.get(modelKey(s.make,s.model));
  if(!row)return [];
  return [{...s,make:row.manufacturer,model:row.model,title:[row.manufacturer,row.model,s.year].filter(Boolean).join(" ")}];
 });
}
