import { FIELDS, customerFields, safeSource, identity } from "./hybrid-evidence.mjs";
const text = value => String(value ?? "").slice(0,2500);
const researchKeys = ["Type","LOA","Length w/ Bracket/Engines","Beam","Draft Engines Up","Draft Engines Down","Dry Weight / Displacement","Fuel Capacity (gal)","Passenger Capacity","Published Engine Configuration / Choices","Key Functions / Mission","Notable Standard Equipment","Notable Factory Options"];
// Read stored research only. Never fetch sources, evaluate an LLM, or mutate data.
export async function compareStoredModels(db, models, signal) {
 const results=[];
 for(const boat of models){
  signal?.throwIfAborted();
  let rows=[],issues=[];
  if(boat.make && boat.model){
   [rows,issues]=await Promise.all([
    db.entities.ResearchDataset.filter({manufacturer:boat.make,model:boat.model},"-workbook_version",100),
    db.entities.DataReviewIssue.filter({manufacturer:boat.make,model:boat.model,status:"open"},"-created_date",100)
   ]);
  }
  signal?.throwIfAborted();
  // Exact names only: similar names, unknown years and neighboring hulls are not substitutes.
  rows=rows.filter(r=>identity(r.manufacturer)===identity(boat.make)&&identity(r.model)===identity(boat.model));
  const truncated=rows.length>=100 || issues.length>=100;
  const checkedRows=rows.map(r=>({...r,field_reviews:Object.fromEntries(Object.entries(r.field_reviews||{}).filter(([field,v])=>{
   const meta=FIELDS[field];
   return meta && (v?.status==="conflict" || (v?.status==="source_confirmed" && typeof v.value==="number" && Number.isFinite(v.value) && v.value>0 &&
    (field!=="Passenger Capacity"||Number.isSafeInteger(v.value)) && safeSource(v.source_url) &&
    v.unit===meta.unit && v.basis===meta.basis && Number.isInteger(v.year_start) && Number.isInteger(v.year_end) &&
    v.year_start>=1900 && v.year_end<=2100 && v.year_end>=v.year_start));
  }))}));
  const year=boat.year===null||boat.year===undefined||boat.year===""?NaN:Number(boat.year);
  const fields=customerFields(truncated?[]:checkedRows,year,issues);
  results.push({
   id:boat.id,title:text(boat.title||[boat.make,boat.model,boat.year].filter(Boolean).join(" ")),
   make:text(boat.make),model:text(boat.model),year:Number.isInteger(year)?year:null,
   match:boat.match||null,fields,dataset_matches:rows.length,truncated,
   research:rows.map(r=>({
    id:r.id,generation:text(r.generation||"Model-year applicability not established"),workbook_version:r.workbook_version,
    values:Object.fromEntries(researchKeys.filter(k=>r.raw_fields?.[k]!==null&&r.raw_fields?.[k]!==undefined&&r.raw_fields?.[k]!=="").map(k=>[k,text(r.raw_fields[k])])),
    source_url:safeSource(r.raw_fields?.["Primary Manufacturer Source"])?r.raw_fields["Primary Manufacturer Source"]:"",
    status:"Stored research; not confirmed for this model year and configuration."
   }))
  });
 }
 return {mode:"database_models",results,notice:"Model comparison from stored SoundHeading research. Confirmed specifications require reviewed evidence applicable to the selected year. Stored research and Match fit notes remain provisional. No listing retrieval, paid AI call, or research job is started."};
}
