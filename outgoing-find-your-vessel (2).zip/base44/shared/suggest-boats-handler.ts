import { matchingLikes } from "./liked-preferences.mjs";
// SoundHeading — suggest MODELS WORTH CONSIDERING that fit a buyer's profile and
// store them as the "advisor pool" of suggested candidates.
//
// Tier-aware (Free Discovery / MATCH+ / Refined Match / Market Match). The funnel keeps
// a wide pool and sharpens the recommendation INSIDE it (counts live in
// shared/tier-results.mjs — this file never re-types one):
//   - Free Discovery: 4 broad starting directions using only free-tier fields.
//     Free refreshes are unlimited (no update metering).
//   - MATCH+ ($9): 10-14 models to look around with, using deeper questions plus prior
//     Likes. Deliberately wide — nothing is marked as the recommendation.
//   - Refined Match ($29): the same wide pool, re-ranked by the deeper constraints and
//     deal-breakers, with the leading 5-7 carrying the recommendation mark.
//   - Market Match ($99): the full pool, re-ranked by the deepest ownership-planning
//     answers, with the top 3 marked as finalists.
//     The first paid generation is free (does not consume an update); subsequent refreshes
//     consume one of the buyer's updates (3 / 5 / 10) within the package's access window
//     (30 days for MATCH+/Refined, 90 days for Market Match).
//
// Paid-only questionnaire fields (admin-configured via QuestionConfig) are stripped from
// the prompt based on the buyer's tier. Free sees only free fields; MATCH+ adds match_plus
// fields; Refined Match adds refined_match fields; Market Match sees all fields.
//
// Explicit Like history remains saved in BuyerProfile.liked_models. Only Likes
// tagged with the exact current answer context are supplied as preference evidence.
// Likes are preference signals, never hard constraints.
//
// The recommendation logic lives in base44/shared/suggest-engine.ts and is shared
// with the future automated QA/testing system. This function owns authentication,
// entitlement/access control, refresh metering, production persistence, and
// contradiction/credit side effects. It does NOT own the matching methodology.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { loadManufacturerMap } from "./advisor-reasoning.ts";
import { issueAdvisorCredit } from "./credits.ts";
import { loadQuestionTiers } from "./question-tiers.ts";
import { normalizePlan, isPaidPlan } from "./stages.ts";
import { generateRecommendations, type SuggestEngineContradiction } from "./suggest-engine.ts";
import { profileInputFingerprint } from "./profile-input-fingerprint.mjs";
import { createReplacementPool } from "./model-pool-persistence.ts";
import { paidWindowIsActive } from "./paid-access.ts";
import { loadPublishedMatchCatalog } from "./catalog-loader.ts";
import { loadDatasetCandidates } from "./dataset-candidates.mjs";
import { makeHybridResolver } from "./hybrid-generation.ts";

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

    const base44 = createClientFromRequest(req);
    let user;
    try {
      user = await base44.auth.me();
    } catch (_) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    let refresh = !!body.refresh;

    const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: user.id }, "-created_date", 1);
    const profile = profiles?.[0];
    if (!profile) return Response.json({ error: "Complete your buyer profile first" }, { status: 400 });

    const profileFingerprint = await profileInputFingerprint(profile);

    // Plan + access window + update metering. normalizePlan maps legacy values
    // (initial_boat_match → match_plus, buyer_pass → market_match) so existing
    // records keep working.
    // BuyerProfile.match_question_tier is editable questionnaire state, NEVER
    // proof of payment. Only admins may use it to test an alternate tier.
    // Ordinary buyers receive the server-maintained User plan exclusively.
    const adminTesting = user.role === "admin";
    const testTier = profile.match_question_tier;
    const rawPlan: string = adminTesting && ["match_plus", "refined_match", "market_match"].includes(testTier)
      ? testTier : String((user as any).plan || "free");
    const plan = normalizePlan(rawPlan);
    const isPaid = isPaidPlan(rawPlan);
    if (!isPaid) return Response.json({ error: "Use the free preview for starting points. Specific model research requires a paid package." }, { status: 403 });
    const planExpires: string | null = (user as any).plan_expires ?? null;
    // An admin may exercise paid-tier QA without purchasing. For everyone else,
    // real expiry applies; missing legacy expiry is handled by the shared helper.
    const isWindowValid = adminTesting || paidWindowIsActive(planExpires);
    const updatesUsed = Number((user as any).updates_used) || 0;
    const updatesLimit = Number((user as any).updates_limit) || 0;
    const paidPoolGenerated = !!(user as any).paid_pool_generated;
    const isFirstPaidGeneration = isPaid && !paidPoolGenerated;

    // Contradiction re-runs (up to 3) remain free for paid buyers.
    const hadContradiction = !!profile.contradiction_flag?.flagged;
    const rerunCount = Number(profile.contradiction_rerun_count) || 0;
    const isFreeContradictionRerun = hadContradiction && rerunCount < 3;

    const existing = await base44.entities.SuggestedBoat.filter({ created_by_id: user.id, superseded: { $ne: true } }, "rank", 200);
    const contextSuggestions = (existing || []).filter((s: any) => !s.test_profile_id && s.buyer_profile_id === profile.id && s.profile_input_fingerprint === profileFingerprint);
    // A load may reuse only results proven to belong to these exact answers.
    // Stale results stay saved, and regeneration still obeys the package allowance.
    if (existing?.length && !contextSuggestions.length) refresh = true;

    // Expired paid access is read-only: previously generated suggestions remain
    // viewable, but a first paid generation or regeneration cannot be initiated.
    const hasActiveSuggestions = !!existing?.some((s: any) => !s.superseded);
    if (isPaid && !isWindowValid && (refresh || isFirstPaidGeneration || !hasActiveSuggestions)) {
      return Response.json({
        error: "Your paid access window has expired. Purchase a search extension to generate or refresh matches.",
      }, { status: 403 });
    }

    // Only an authenticated administrator has uncapped test refreshes.
    // Regular paid buyers consume an update after a successful regeneration;
    // the first paid generation and eligible contradiction corrections are free.
    const shouldMeterRefresh = !adminTesting && refresh && !isFirstPaidGeneration && !isFreeContradictionRerun;
    if (refresh) {
      if (shouldMeterRefresh && updatesUsed >= updatesLimit) {
        return Response.json({
          error: `You've used all ${updatesLimit} matching updates in this window. Your profile can still be saved. Purchase a search extension to update matches.`,
          updates_used: updatesUsed,
          updates_limit: updatesLimit,
        }, { status: 403 });
      }
    } else {
      // Idempotent load: return existing suggestions unless this is the buyer's first
      // paid generation (they just purchased and need the full pool).
      if (existing?.length && !isFirstPaidGeneration) {
        return Response.json({ suggestions: contextSuggestions, profile_input_fingerprint: profileFingerprint, result_status: "current_saved" });
      }
    }

    // --- Load all inputs the engine needs (entity reads only, no writes) ---

    const likedModels = matchingLikes(profile, profileFingerprint);

    // Saved candidates are retained for Compare, not inferred matching preferences.
    const savedBoats: any[] = [];

    const tierFields = await loadQuestionTiers(base44);
    const manufacturerMap = await loadManufacturerMap(base44, profile);
    // Only independently reviewed and published model records may influence
    // deterministic screening. Never ingest staged or merely verified drafts.
    let catalogRecords: any[] = [];
    try {
      const catalog = await loadPublishedMatchCatalog(base44.asServiceRole.entities.BoatModelCatalog);
      catalogRecords = catalog.records;
      if (catalog.truncated) {
        console.warn("suggest-boats: published catalog read reached 10,000 records; unmatched models remain unverified, not disproven");
      }
    } catch (error) {
      console.error("suggest-boats: published catalog unavailable; continue with provisional model verification flags", error);
    }

    // Retire the previous pool only after new records are persisted successfully.
    // Capture the original IDs so the replacement records are never affected.
    const retirePreviousPool = async () => {
      if (!(existing?.length && (refresh || isFirstPaidGeneration))) return;
      for (const old of existing) {
        if (!old.superseded) await base44.asServiceRole.entities.SuggestedBoat.update(old.id, { superseded: true });
      }
    };

    const datasetCandidates = await loadDatasetCandidates(base44.asServiceRole.entities.ResearchDataset, profile).catch(() => []);
    // --- Run the shared recommendation engine ---
    const engineResult = await generateRecommendations(base44, {
      profile,
      plan,
      tierFields,
      manufacturerMap,
      catalogRecords,
      datasetCandidates,
      resolveHybrid: makeHybridResolver(base44.asServiceRole, catalogRecords),
      likedModels,
      savedBoats,
      existingSuggestions: contextSuggestions,
      isFirstPaidGeneration,
      hadContradiction,
      refresh,
      contradictionRerunCount: rerunCount,
    });

    // Refuse a result computed from answers that changed while research ran.
    // This is an optimistic check, not a database transaction or distributed lock.
    const latestProfiles = await base44.entities.BuyerProfile.filter({ created_by_id: user.id }, "-created_date", 1);
    const latestProfile = latestProfiles?.[0];
    if (!latestProfile || latestProfile.id !== profile.id || await profileInputFingerprint(latestProfile) !== profileFingerprint) {
      return Response.json({ error: "Your profile changed during matching. Your saved answers and prior results are retained; update matches again." }, { status: 409 });
    }
    const currentPool = await base44.entities.SuggestedBoat.filter({ created_by_id: user.id, superseded: { $ne: true } }, "rank", 200);
    const poolIds = (rows: any[]) => rows.map(row => row.id).sort().join(",");
    if (poolIds(currentPool || []) !== poolIds(existing || [])) {
      return Response.json({ error: "Another match update completed during this request. Reload your results before updating again." }, { status: 409 });
    }
    const generationId = crypto.randomUUID();
    const generationStarted = new Date().toISOString();

    // --- Persist suggestions ---
    const records = await createReplacementPool(engineResult.suggestions, async (s) =>
      base44.entities.SuggestedBoat.create({
        buyer_profile_id: profile.id,
        profile_input_fingerprint: profileFingerprint,
        generation_id: generationId,
        generated_at: generationStarted,
        engine_version: "ai-led-reference-2026-10-16",
        research_source_mode: "published-catalog-and-research-dataset-unpinned",
        title: s.title,
        make: s.make,
        model: s.model,
        year: s.year,
        asking_price: s.asking_price,
        price_range_min: s.price_range_min,
        price_range_max: s.price_range_max,
        price_range_context: s.price_range_context,
        passenger_capacity: s.passenger_capacity,
        engines: s.engines,
        specs: s.specs,
        link: s.link,
        source: s.source,
        why_suggested: s.why_suggested,
        match: s.match,
        suitability_score: s.suitability_score,
        score_breakdown: s.score_breakdown,
        verification_required: s.verification_required,
        evidence_summary: s.evidence_summary,
        image_url: s.image_url,
        image_license: s.image_license,
        rank: s.rank,
        highlighted: !!s.highlighted,
      }),
      (id) => base44.entities.SuggestedBoat.delete(id),
    );

    if (records.length === 0) {
      return Response.json({ error: "No viable replacement matches were generated; prior recommendations were preserved.", note: engineResult.scarcityNote }, { status: 422 });
    }
    // Answers can change while individual rows are being inserted. Discard only
    // this request's rows; never retire history for an obsolete generation.
    const finalPool = await base44.entities.SuggestedBoat.filter({ created_by_id: user.id, superseded: { $ne: true } }, "rank", 200);
    const ownIds = new Set(records.map(record => record.id));
    const poolChanged = poolIds(finalPool.filter((row: any) => !ownIds.has(row.id))) !== poolIds(existing || []);
    const finalProfile = (await base44.entities.BuyerProfile.filter({ created_by_id: user.id }, "-created_date", 1))?.[0];
    if (poolChanged || !finalProfile || finalProfile.id !== profile.id || await profileInputFingerprint(finalProfile) !== profileFingerprint) {
      for (const record of records) await base44.entities.SuggestedBoat.delete(record.id);
      return Response.json({ error: "Your profile or another generation changed while results were saved. Reload before updating again; prior results are retained." }, { status: 409 });
    }
    // --- Contradiction persistence + advisor credit ---
    // The engine detects contradictions; this function persists them and issues credit.
    // Priority: LLM contradiction > hard-filter scarcity contradiction > clear prior flag.
    if (engineResult.llmContradiction?.flagged) {
      try {
        await base44.asServiceRole.entities.BuyerProfile.update(profile.id, {
          contradiction_flag: {
            flagged: true,
            conflicts: engineResult.llmContradiction.conflicts,
            explanation: engineResult.llmContradiction.explanation,
            closest_alternatives: engineResult.llmContradiction.closest_alternatives,
          },
          contradiction_rerun_count: engineResult.newContradictionRerunCount,
        });
      } catch (e) {
        console.error("suggest-boats: failed to save contradiction flag", e);
      }
      await issueAdvisorCredit(base44, profile.id);
    } else if (engineResult.hardFilterRemovedAll && engineResult.scarcityContradiction) {
      try {
        await base44.asServiceRole.entities.BuyerProfile.update(profile.id, {
          contradiction_flag: {
            flagged: true,
            conflicts: engineResult.scarcityContradiction.conflicts,
            explanation: engineResult.scarcityContradiction.explanation,
            closest_alternatives: engineResult.scarcityContradiction.closest_alternatives,
          },
          contradiction_rerun_count: engineResult.newContradictionRerunCount,
        });
      } catch (e) {
        console.error("suggest-boats: failed to save size-filter contradiction", e);
      }
      await issueAdvisorCredit(base44, profile.id);
    } else if (hadContradiction) {
      try {
        await base44.asServiceRole.entities.BuyerProfile.update(profile.id, {
          contradiction_flag: { flagged: false, conflicts: [], explanation: "", closest_alternatives: [] },
          contradiction_rerun_count: engineResult.newContradictionRerunCount,
        });
      } catch (e) {
        console.error("suggest-boats: failed to clear contradiction flag", e);
      }
    }

    let cleanupPending = false;
    try { await retirePreviousPool(); } catch (error) {
      cleanupPending = true;
      console.error("suggest-boats: replacement saved; previous-pool cleanup incomplete", error);
    }

    // Charge a paid refresh only after recommendations were successfully saved.
    // This prevents transient generation failures from consuming an update.
    if (shouldMeterRefresh) {
      try {
        await base44.asServiceRole.entities.User.update(user.id, { updates_used: updatesUsed + 1 } as any);
      } catch (e) {
        console.error("suggest-boats: failed to increment updates_used after persistence", e);
      }
    }

    // Mark the first paid generation complete so subsequent refreshes are metered.
    if (isFirstPaidGeneration && !adminTesting) {
      try {
        await base44.asServiceRole.entities.User.update(user.id, { paid_pool_generated: true } as any);
      } catch (e) {
        console.error("suggest-boats: failed to set paid_pool_generated", e);
      }
    }

    return Response.json({ suggestions: records, cleanup_pending: cleanupPending, buyer_profile_id: profile.id, profile_input_fingerprint: profileFingerprint, generation_id: generationId, note: engineResult.scarcityNote, engine_version: "ai-led-reference-2026-10-16" });
  } catch (err) {
    console.error("suggest-boats error", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}