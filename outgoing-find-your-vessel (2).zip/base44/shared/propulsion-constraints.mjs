// Negative requirements are enforced outside the language model on both passes.
export function propulsionRules(profile) {
 const text=String(profile.unacceptable_compromises||"").toLowerCase();
 return {
  inboard:/\bno\s+inboards?\b/.test(text),
  outdrive:/\bno\s+(?:outdrives?|stern[ -]?drives?)\b/.test(text),
  outboard:/\bno\s+outboards?\b/.test(text),
 };
}
export function screenPropulsion(candidate,profile) {
 const rules=propulsionRules(profile);
 if(!Object.values(rules).some(Boolean))return {excluded:false,pending:false};
 const engines=String(candidate.engines||"").toLowerCase();
 const matches=Array.isArray(candidate.matches)?candidate.matches.join(" ").toLowerCase():"";
 const declared=String(candidate.propulsion_type||"").toLowerCase();
 const knownOutboard=/\boutboards?\b|\bverado\b/.test(engines)||declared==="outboard";
 const outdrive=/\b(?:outdrives?|stern[ -]?drives?|mercruiser|duoprop)\b/.test(engines)||declared==="sterndrive";
 const inboard=/\binboards?\b|\bips\s*\d*\b|\bzeus\b|\bshaft[ -]?drive\b/.test(engines)||["inboard","pod"].includes(declared)||(!knownOutboard&&/\binboard propulsion\b/.test(matches));
 if(rules.inboard&&(inboard||outdrive)||rules.outdrive&&outdrive||rules.outboard&&knownOutboard)
  return {excluded:true,pending:false};
 const pending=!(knownOutboard||outdrive||inboard);
 return {excluded:false,pending};
}
export function enforcePropulsion(items,profile) {
 return items.flatMap(candidate=>{
  const check=screenPropulsion(candidate,profile);
  if(check.excluded)return [];
  return [{...candidate,__propulsion_pending:check.pending,verification_required:[
   ...(candidate.verification_required||[]),
   ...(check.pending?["Propulsion type is unconfirmed; do not assume compliance with the buyer's propulsion exclusions."]:[])
  ]}];
 });
}
