import {normalizePublicListingUrl} from "./remote-listing.ts";
import {extractListingDocument,nullableListingFacts} from "./listing-document.mjs";
import {assessListing,recommendFinalists} from "./listing-comparison.mjs";

// Contract for a future approved provider adapter, not a generic fetch proxy.
// discover({url,marketplace_id,query,signal,max_results:3}) -> {candidates:[{url}]}
// read({url,signal,max_bytes:262144}) -> {url,final_url,text,retrieved_at}
// Both operations must be allowlisted server-side with validated downstream
// public egress/redirect handling. Secrets, adapters and permission policy never
// come from the browser, listing text, or discovery results.
export const DISABLED_RESOLVER_RUNTIME=Object.freeze({provider:null,source_permissions:[]});
const now=()=>new Date().toISOString();
export function listingIdentityHint(raw){
 const url=normalizePublicListingUrl(raw);if(!url)throw Error("Use a public HTTPS listing URL.");
 const u=new URL(url),m=u.pathname.match(/^\/boat\/(\d{4})-(.+)-(\d+)\/?$/);
 const known=/^(www\.)?boattrader\.com$/.test(u.hostname);
 return {original_url:url,marketplace:known?"boattrader":"unknown",marketplace_id:known&&m?m[3]:null,
  year_hint:known&&m?Number(m[1]):null,description_hint:known&&m?m[2].replaceAll("-"," "):null,
  hint_provenance:"URL path only; not verified listing evidence"};
}
function permissionFor(runtime,url){
 const host=new URL(url).hostname.toLowerCase();
 return (runtime.source_permissions||[]).find(p=>p.hostname===host&&p.automated_read===true&&typeof p.approval_reference==="string"&&p.approval_reference.trim()&&Date.parse(p.valid_until)>Date.now());
}
function providerReady(p){
 return p?.kind==="approved_listing_provider"&&p.safe_transport==="base44_custom_integration_proxy"
  &&p.downstream_public_egress_verified===true&&p.redirects_permission_checked===true
  &&p.search_authorized===true&&p.usage_authorized===true&&p.approval_reference
  &&typeof p.discover==="function"&&typeof p.read==="function";
}
async function boundedCall(fn,signal,ms=2000){
 signal?.throwIfAborted();let timer,onAbort;const controller=new AbortController();
 const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(Error("Provider deadline exceeded"));},ms);
  onAbort=()=>{controller.abort();reject(Error("Request aborted"));};signal?.addEventListener("abort",onAbort,{once:true});});
 try{const value=await Promise.race([Promise.resolve().then(()=>fn(controller.signal)),deadline]);signal?.throwIfAborted();return value;}
 finally{clearTimeout(timer);signal?.removeEventListener("abort",onAbort);}
}
const unavailable=(input,hint,status,reason,attempts=[],checked=now())=>({...input,status,reason,facts:{},nullable_facts:nullableListingFacts({}),checks:[],concerns:[],
 unknowns:["Exact individual-listing facts are unavailable. No different boat or model specifications were substituted."],
 eligible:false,resolution:{original_url:hint.original_url,marketplace_id:hint.marketplace_id,checked_at:checked,
 confidence:"none",status,attempts}});
function documentValid(doc,requested,provider,runtime){
 if(!doc||typeof(doc.html??doc.text)!=="string"||new TextEncoder().encode(doc.html??doc.text).length>262144||(doc.html??doc.text).length<100)return false;
 if(normalizePublicListingUrl(doc.url)!==requested)return false;
 const final=normalizePublicListingUrl(doc.final_url);if(!final||!permissionFor(runtime,final))return false;
 const stamp=Date.parse(doc.retrieved_at);
 // An approved adapter must return an actual fresh retrieval timestamp.
 return Number.isFinite(stamp)&&stamp<=Date.now()+60000&&stamp>=Date.now()-3600000
  &&provider.redirects_permission_checked===true;
}
function exactAssociation(parsed,hint){
 for(const association of parsed.entity_associations||[]){
  if(association.kind==="entity_same_as"&&association.url===hint.original_url)return {...association,kind:"entity_bound_exact_url"};
  if(association.kind==="entity_marketplace_id"&&association.marketplace===hint.marketplace&&association.id===hint.marketplace_id)return association;
 }
 return null;
}
function reassess(profile,input,parsed,withheld=[],notes=[]){
 const blocked=new Set(withheld);
 const assessment=assessListing(profile,input,parsed.text,{...parsed.extraction,facts:parsed.extraction.facts.filter(f=>!blocked.has(f.field))});
 assessment.field_evidence=parsed.evidence.filter(e=>!blocked.has(e.field)&&assessment.facts[e.field]&&assessment.facts[e.field].value===e.value);
 assessment.unknowns.push(...notes);assessment.eligible=false;return assessment;
}
export async function resolveListing(profile,input,runtime=DISABLED_RESOLVER_RUNTIME,signal){
 const hint=listingIdentityHint(input.url),checked=now(),provider=runtime.provider;
 if(!providerReady(provider))return unavailable(input,hint,"resolver_unavailable","Automatic resolution is unavailable: an approved safe provider operation has not been established.",[],checked);
 const attempts=[];let discovery;
 try{discovery=await boundedCall(callSignal=>provider.discover({url:hint.original_url,marketplace_id:hint.marketplace_id,
  query:[hint.original_url,hint.marketplace_id,hint.description_hint].filter(Boolean).join(" "),signal:callSignal,max_results:3}),signal);}
 catch{return unavailable(input,hint,"discovery_unavailable","Automatic source discovery could not complete.",attempts,checked);}
 const candidates=[...new Set([hint.original_url,...(Array.isArray(discovery?.candidates)?discovery.candidates.slice(0,3).map(c=>c.url):[])])]
  .map(normalizePublicListingUrl).filter(Boolean).slice(0,4);
 const resolved=[],contexts=new Map();
 for(const url of candidates){
  signal?.throwIfAborted();
  const permission=permissionFor(runtime,url);
  if(!permission){attempts.push({url,status:"source_permission_unestablished"});continue;}
  let doc;
  try{doc=await boundedCall(callSignal=>provider.read({url,signal:callSignal,max_bytes:262144}),signal);}
  catch{attempts.push({url,status:"source_unavailable"});continue;}
  if(!documentValid(doc,url,provider,runtime)){attempts.push({url,status:"invalid_provider_document"});continue;}
  const parsed=extractListingDocument(doc);
  if(parsed.ambiguity){attempts.push({url,status:"ambiguous_listing"});continue;}
  if(/captcha|access denied|verify (?:that )?you are human|unusual traffic/i.test(parsed.text)){
   attempts.push({url,status:"access_restricted"});continue;
  }
  const association=doc.final_url===hint.original_url?{kind:"original_listing_page",quote:hint.original_url}:exactAssociation(parsed,hint);
  if(!association){attempts.push({url:doc.final_url,status:"identity_unconfirmed"});continue;}
  const prices=[...parsed.text.matchAll(/\b(?:Asking price|Price)\s*[:\-]?\s*(USD|EUR|GBP|CAD|AUD|NZD)\s*\$?\s*([\d,]+(?:\.\d{1,2})?)/gi)];
  const priceConflict=(parsed.conflicts||[]).includes("asking_price")||new Set([...prices.map(m=>m[1].toUpperCase()+":"+Number(m[2].replaceAll(",",""))),...parsed.extraction.facts.filter(f=>f.field==="asking_price").map(f=>f.unit+":"+f.value)]).size>1;
  const withheld=priceConflict?["asking_price","asking_price_currency"]:[];
  const notes=(parsed.conflicts||[]).map(field=>"Conflicting structured/page claims were withheld: "+field);
  if(priceConflict)notes.push("Conflicting price claims appear on the source page. Current asking price and currency were withheld.");
  const assessment=reassess(profile,input,parsed,withheld,notes);
  contexts.set(assessment,{parsed,withheld,notes});
  if(hint.year_hint&&assessment.facts.year&&assessment.facts.year.value!==hint.year_hint){attempts.push({url:doc.final_url,status:"conflicting_listing_year"});continue;}
  if(!assessment.facts.make||!assessment.facts.model||!assessment.facts.year){
   attempts.push({url:doc.final_url,status:"insufficient_identity_evidence"});continue;
  }
  assessment.source_metadata=parsed.entity_stock?{stock_number:parsed.entity_stock}:{};
  assessment.resolution={status:"resolved",original_url:hint.original_url,marketplace_id:hint.marketplace_id,
   source_url:doc.final_url,retrieved_at:doc.retrieved_at,checked_at:checked,source_published_at:null,
   provider_reference:provider.approval_reference,source_permission_reference:permission.approval_reference,
   confidence:"exact_listing_reference_with_quoted_identity",association,attempts};
  resolved.push(assessment);
 }
 if(!resolved.length){const status=attempts.some(a=>a.status==="conflicting_listing_year")?"wrong_listing":attempts.some(a=>a.status==="access_restricted")?"blocked":"no_verified_source";return unavailable(input,hint,status,"No permitted readable source established this exact individual listing.",attempts,checked);}
 const identities=new Set(resolved.map(r=>[r.facts.make.value,r.facts.model.value,r.facts.year.value].join("|").toLowerCase()));
 if(identities.size!==1)return unavailable(input,hint,"conflicting_identity","Independent sources disagree about the individual boat. No source was selected.",attempts,checked);
 // Preserve all source evidence; never rank or select the cheapest source claim.
 const result=resolved[0];result.resolution.sources=resolved.map(r=>({url:r.resolution.source_url,retrieved_at:r.resolution.retrieved_at,facts:r.facts}));
 if(resolved.length>1){
  const values=new Set(resolved.filter(r=>r.facts.asking_price).map(r=>JSON.stringify([r.facts.asking_price.value,r.facts.asking_price.unit,r.facts.asking_price_currency?.value??r.facts.asking_price.unit])));
  if(values.size>1){
   const context=contexts.get(result);
   Object.assign(result,reassess(profile,input,context.parsed,[...context.withheld,"asking_price","asking_price_currency"],[...context.notes,"Source asking prices or currencies conflict; current price and currency are unknown."]));
  }
 }
 result.nullable_facts=nullableListingFacts(result.facts);
 return result;
}
export async function resolveCompareListings(profile,inputs,runtime=DISABLED_RESOLVER_RUNTIME,signal){
 const results=[];for(const input of inputs){signal?.throwIfAborted();results.push(await resolveListing(profile,input,runtime,signal));}
 return {results,recommendation:recommendFinalists(results),resolver_available:providerReady(runtime.provider),retrieval_available:providerReady(runtime.provider)};
}

export function canReuseResolution(result,runtime=DISABLED_RESOLVER_RUNTIME,capabilityOnly=false){
 if(!providerReady(runtime.provider))return false;if(capabilityOnly)return true;
 return result?.resolution?.status==="resolved"&&result.resolution.provider_reference===runtime.provider.approval_reference&&Array.isArray(result.resolution.sources)&&result.resolution.sources.length>0&&result.resolution.sources.every(s=>normalizePublicListingUrl(s.url)&&permissionFor(runtime,s.url));
}
