import {resolveListing,canReuseResolution,DISABLED_RESOLVER_RUNTIME} from "./listing-resolver.mjs";
import {recommendFinalists} from "./listing-comparison.mjs";
const VERSION="listing-document-v2";
function stable(x){if(Array.isArray(x))return x.map(stable);if(x&&typeof x==="object")return Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])]));return x;}
async function digest(x){const bytes=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(JSON.stringify(stable(x))));return [...new Uint8Array(bytes)].map(b=>b.toString(16).padStart(2,"0")).join("");}
// Cache storage is server-owned and separate from paid evaluation receipts.
// No stale/failed result can grant entitlement or be returned as fresh evidence.
export async function resolveWithCache({owner,profile,inputs,runtime=DISABLED_RESOLVER_RUNTIME,cache,signal,refresh=false,clock=Date.now}){
 if(!owner||profile.created_by_id!==owner)throw Error("Profile owner mismatch");
 const results=[];
 for(const input of inputs){
  signal?.throwIfAborted();const keys={buyer_user_id:owner,url_key:await digest(input.url),profile_key:await digest({profile,input}),resolver_version:VERSION};
  const enabled=canReuseResolution(null,runtime,true);
  let rows=[];
  if(enabled&&cache&&!refresh){try{rows=await cache.filter(keys,"-created_date",1);}catch{/* A cache miss never fabricates evidence. */}}
  signal?.throwIfAborted();
  const hit=rows[0];
  if(hit&&Object.entries(keys).every(([k,v])=>hit[k]===v)&&Date.parse(hit.expires_at)>clock()&&Date.parse(hit.retrieved_at)<=clock()+60000
   &&hit.result?.url===input.url&&canReuseResolution(hit.result,runtime)){
   results.push({...hit.result,cache:{status:"hit",expires_at:hit.expires_at}});continue;
  }
  const result=await resolveListing(profile,input,runtime,signal);signal?.throwIfAborted();
  if(result.resolution?.status==="resolved"&&enabled&&cache){
   const retrieved=Math.min(...(result.resolution.sources||[]).map(s=>Date.parse(s.retrieved_at)));
   const expires=Math.min(clock()+15*60000,retrieved+15*60000);
   if(Number.isFinite(expires)&&expires>clock()&&new TextEncoder().encode(JSON.stringify(result)).length<=65536){
    try{await cache.create({...keys,canonical_listing_url:input.url,result,retrieved_at:new Date(retrieved).toISOString(),expires_at:new Date(expires).toISOString()});result.cache={status:"stored",expires_at:new Date(expires).toISOString()};}
    catch{result.cache={status:"not_stored"};}
   }
  }
  signal?.throwIfAborted();results.push(result);
 }
 return {results,recommendation:recommendFinalists(results),resolver_available:canReuseResolution(null,runtime,true),retrieval_available:canReuseResolution(null,runtime,true)};
}
