import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import suggestBoats from '../../shared/suggest-boats-handler.ts';
import { allowedStageCaller, loadIntakeContext, assertStillCurrent, commitIntake } from '../../shared/listing-intake-service.mjs';
import { profileInputFingerprint } from '../../shared/profile-input-fingerprint.mjs';
import { IntakeError } from '../../shared/listing-intake.mjs';

// Bounded owner-only DEV verification. Shared handler, never called by listing actions or normal My Helm.
// The existing generator and engine are imported unchanged; no production fallback.
const POLICY = Object.freeze({ enabled: true, generation_enabled: false, app_id: '6abbd00d2cbdcfbf9bef007e', owner_id: '6abbd00e2cbdcfbf9bef007f', record_id: '6add19754e704fed3fffbe38' });
const PROFILE_ID = '6ad916a2cdc1853a76ad831a';
const FINGERPRINT = '1122cb8c8638da3b691b45ad8cea26d634f4d5445afa64bfc8667f47fa1dbccc';
const RUN_ID = 'approved-dev-generation-20261024-once';
const response = (body, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
function devRequest(req, body = {}) {
  const headers = new Headers(req.headers);
  headers.set('X-Data-Env', 'dev'); headers.set('Content-Type', 'application/json'); headers.delete('content-length');
  return new Request(req.url, { method: 'POST', headers, body: JSON.stringify(body) });
}
async function routingProof(ctx) {
  const ordinary = await ctx.client.entities.ListingIntake.get(POLICY.record_id);
  const serviceProfile = await ctx.client.asServiceRole.entities.BuyerProfile.get(PROFILE_ID);
  if (ordinary?.id !== POLICY.record_id || ordinary.owner_id !== ctx.user.id || ordinary.stage_fixture !== true || ctx.profile.id !== PROFILE_ID || ctx.fingerprint !== FINGERPRINT || serviceProfile?.id !== PROFILE_ID || serviceProfile.created_by_id !== ctx.user.id || await profileInputFingerprint(serviceProfile) !== FINGERPRINT) throw new IntakeError('DEV routing or profile context could not be verified.', 409);
  await assertStillCurrent(ctx);
}
async function readView(ctx) {
  const rows = await ctx.client.entities.SuggestedBoat.filter({ created_by_id: ctx.user.id, superseded: { $ne: true } }, 'rank', 200);
  const suggestions = rows.filter(row => !row.test_profile_id && row.buyer_profile_id === ctx.profile.id && row.profile_input_fingerprint === ctx.fingerprint);
  return { staging: true, data_env: 'dev', buyer_profile_id: ctx.profile.id, profile_fingerprint: ctx.fingerprint, plan: ctx.profile.match_question_tier || ctx.user.plan || 'match_plus', suggestions, generation: ctx.record.data?.stage_generation || null, routing_verified: true };
}
export default async function handler(req) {
  if (req.method !== 'POST') return response({ error: 'Method not allowed' }, 405);
  try {
    const scoped = devRequest(req), client = createClientFromRequest(scoped);
    let user; try { user = await client.auth.me(); } catch { return response({ error: 'Sign in first.' }, 401); }
    if (!allowedStageCaller(user, POLICY, 'dev')) return response({ error: 'Private test is unavailable.' }, 403);
    if (Number(req.headers.get('content-length')) > 1024) return response({ error: 'Invalid test request.' }, 400);
    const text = await req.text(); if (text.length > 1024) return response({ error: 'Invalid test request.' }, 400);
    const body = JSON.parse(text || '{}');
    if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).some(key => key !== 'action') || !['read', 'probe', 'generate_once'].includes(body.action)) return response({ error: 'Invalid test request.' }, 400);
    const ctx = await loadIntakeContext(client, user, POLICY); await routingProof(ctx);
    if (body.action !== 'generate_once') return response(await readView(ctx));
    if (!POLICY.generation_enabled) return response({ error: 'The approved one-time generation is not enabled.' }, 409);
    if (ctx.record.data?.stage_generation) return response({ ...await readView(ctx), replayed: true, generation_not_repeated: true });
    const data = structuredClone(ctx.record.data);
    data.stage_generation = { id: RUN_ID, status: 'reserved', started_at: new Date().toISOString(), profile_fingerprint: ctx.fingerprint };
    await commitIntake(ctx, data); // A single pinned row revision reserves the only permitted run.
    let result, status;
    try { const generated = await suggestBoats(devRequest(req, { refresh: true })); status = generated.status; result = await generated.json(); }
    catch { return response({ error: 'Generation outcome is uncertain. Inspect saved results; do not run again.' }, 503); }
    const latest = await client.asServiceRole.entities.ListingIntake.get(POLICY.record_id);
    ctx.record = latest;
    const finished = structuredClone(latest.data);
    if (finished.stage_generation?.id !== RUN_ID || finished.stage_generation.status !== 'reserved') return response({ error: 'Generation completion needs inspection. No retry was made.' }, 409);
    finished.stage_generation = { ...finished.stage_generation, status: status === 200 ? 'complete' : 'failed', finished_at: new Date().toISOString(), response_status: status, generation_id: result?.generation_id || null, result_count: Array.isArray(result?.suggestions) ? result.suggestions.length : 0 };
    await commitIntake(ctx, finished);
    return response({ ...await readView(ctx), generation_not_repeated: false }, status === 200 ? 200 : 502);
  } catch (error) { return response({ error: error instanceof IntakeError ? error.message : 'Private test could not be verified. No automatic retry was made.' }, error instanceof IntakeError ? error.status : 503); }
}
