import { createClientFromRequest } from "npm:@base44/sdk@0.8.57";
import { saveBuyerProfile, ProfileSaveError } from "../../shared/save-buyer-profile.mjs";
export default async function (req: Request): Promise<Response> {
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });
  const client = createClientFromRequest(req);
  let user;
  try { user = await client.auth.me(); } catch { return Response.json({ error: "Unauthorized" }, { status: 401 }); }
  try {
    const body = await req.json();
    const profile = await saveBuyerProfile(client, user, body.profile, { onlyIfMissing: body.only_if_missing === true, resetContext: body.reset_context === true });
    if (body.reset_context === true) {
      const persisted = await client.asServiceRole.entities.BuyerProfile.filter({ created_by_id: user.id }, "-created_date", 1);
      if (persisted?.[0]?.id !== profile.id || !profile.match_context_id || persisted[0].match_context_id !== profile.match_context_id) {
        throw new ProfileSaveError("Fresh matching context persistence could not be confirmed. Reload before retrying.", 503);
      }
    }
    return Response.json({ profile, matching_context_version: "fresh-context-v2", reset_context_applied: body.reset_context === true });
  } catch (error) {
    if (error instanceof ProfileSaveError) return Response.json({ error: error.message }, { status: error.status });
    console.error("save-buyer-profile: save not confirmed", error);
    return Response.json({ error: "Profile save could not be confirmed. Your answers are retained; reload before retrying." }, { status: 503 });
  }
}
