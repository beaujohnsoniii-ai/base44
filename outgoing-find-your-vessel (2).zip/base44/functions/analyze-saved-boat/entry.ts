// SoundHeading — research a boat the buyer has in mind and match it to their needs.
// The buyer names a boat (description, e.g. "2021 Cutwater 30 Pilot House") and may
// optionally include a listing link they considered. This function:
//   1. If a link is provided, fetches the listing page and extracts structured specs.
//   2. Researches the named boat via web search to fill in specs the listing didn't give
//      (many listing sites block automated fetches, so web search is the workhorse).
//   3. Loads the buyer's profile and compares the boat to their needs, wants, and priorities.
// Returns the extracted specs (SavedBoat-shaped) plus the match analysis, so the
// dashboard can display it without a second round trip.
//
// InvokeLLM runs as the service role (Core integration). Entity reads use the
// user-scoped client. Fetch failures are handled gracefully — the analysis proceeds
// with whatever data was retrieved, and the buyer can still save the boat.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { fetchPublicListing, normalizePublicListingUrl } from "../../shared/remote-listing.ts";
import { sourceFromUrl } from "../../shared/listing-links.ts";
import { normalizePlan } from "../../shared/stages.ts";
import { paidWindowIsActive } from "../../shared/paid-access.ts";
import { ADVISOR_REASONING_GUIDE, loadManufacturerMap, findManufacturer, formatManufacturer } from "../../shared/advisor-reasoning.ts";

const EXTRACT_SCHEMA = {
  type: "object",
  properties: {
    title: { type: "string" },
    make: { type: "string" },
    model: { type: "string" },
    year: { type: "number" },
    asking_price: { type: "number" },
    length: { type: "string" },
    engines: { type: "string" },
    hours: { type: "string" },
    fuel: { type: "string" },
    draft: { type: "string" },
    location: { type: "string" },
    condition: { type: "string" },
    key_features: { type: "array", items: { type: "string" } },
    description_summary: { type: "string" },
  },
};

const MATCH_SCHEMA = {
  type: "object",
  properties: {
    matches: { type: "array", items: { type: "string" } },
    gaps: { type: "array", items: { type: "string" } },
    summary: { type: "string" },
  },
  required: ["matches", "gaps", "summary"],
};

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

    const base44 = createClientFromRequest(req);
    let user;
    try {
      user = await base44.auth.me();
    } catch (_) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Buyer-supplied text is placed into paid LLM prompts. Bound it before
    // accessing any providers, so malformed/oversized requests cannot consume
    // uncontrolled tokens or trigger an oversized upstream page search.
    const MAX_REQUEST_BYTES = 16 * 1024;
    let raw = "";
    let bytes = 0;
    const decoder = new TextDecoder();
    const reader = req.body?.getReader();
    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        bytes += value.byteLength;
        if (bytes > MAX_REQUEST_BYTES) {
          await reader.cancel();
          return Response.json({ error: "Request is too large" }, { status: 413 });
        }
        raw += decoder.decode(value, { stream: true });
      }
      raw += decoder.decode();
    }
    let body: any;
    try { body = JSON.parse(raw || "{}"); }
    catch { return Response.json({ error: "Invalid request" }, { status: 400 }); }
    if (!body || typeof body !== "object" || Array.isArray(body) ||
      ["description", "url", "note"].some((field) => body[field] != null && typeof body[field] !== "string")) {
      return Response.json({ error: "Invalid boat information" }, { status: 400 });
    }
    const description = (body.description || "").trim();
    const url = (body.url || "").trim();
    const note = (body.note || "").trim();
    if (description.length > 280 || url.length > 2048 || note.length > 2000) {
      return Response.json({ error: "Boat description, link, or note is too long" }, { status: 413 });
    }

    if (!description && !url) {
      return Response.json({ error: "Name the boat you have in mind" }, { status: 400 });
    }
    let normalizedUrl = "";
    if (url) {
      try {
        normalizedUrl = normalizePublicListingUrl(url) || "";
        if (!normalizedUrl) throw new Error("Unsupported listing URL");
      } catch {
        return Response.json({ error: "Invalid link" }, { status: 400 });
      }
    }

    // Profile is needed for the match step. If absent, we still extract specs.
    const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: user.id }, "-created_date", 1);
    const profile = profiles?.[0] || null;

    let specs: any = null;
    let fetched = false;
    let extractError: string | null = null;

    // 1. If a link is provided, try to fetch the listing page and extract specs.
    if (url) {
      const fetchResult = await fetchPublicListing(url);
      if (fetchResult.ok) {
        fetched = true;
        try {
          specs = await base44.asServiceRole.integrations.Core.InvokeLLM({
            prompt:
              `Extract boat listing specifications from this page content. Only include fields you can identify from the content — omit unknown fields rather than guessing. Do not invent specifications.\n\nURL: ${url}\n\nPage content:\n${fetchResult.text}`,
            response_json_schema: EXTRACT_SCHEMA,
          });
        } catch (e) {
          extractError = "Could not extract specs from page";
        }
      } else {
        extractError = fetchResult.error || "Could not access page";
      }
    }

    // 2. Research the named boat via web search to fill in specs the listing didn't
    //    give us. This is the workhorse: many listing sites block automated fetches,
    //    and the buyer may have named a boat with no link at all.
    const hasIdentity = specs && (specs.make || specs.model || specs.year || specs.title);
    if (!hasIdentity) {
      const query = url ? `${description} (${url})` : description;
      try {
        const webSpecs = await base44.asServiceRole.integrations.Core.InvokeLLM({
          prompt:
            `A buyer is considering this boat: ${query}\n\nSearch for it and extract the boat's specifications. Only include fields you can confirm from the listing or search results — omit unknown fields rather than guessing. Do not invent specifications. If you cannot determine the make and model, return empty strings.`,
          add_context_from_internet: true,
          response_json_schema: EXTRACT_SCHEMA,
        });
        if (webSpecs) {
          specs = { ...(webSpecs || {}), ...(specs || {}) };
          if (!extractError) extractError = null;
        }
      } catch (e) {
        // keep the original extractError
      }
    }

    // Normalize the extracted specs into SavedBoat-shaped fields.
    const boat = {
      title: specs?.title || description,
      make: specs?.make || "",
      model: specs?.model || "",
      year: specs?.year || null,
      // An asking price belongs to an identifiable listing, not the model
      // generally. Search-only fallback may describe a different example.
      asking_price: fetched && normalizedUrl && Number.isFinite(Number(specs?.asking_price)) &&
        Number(specs?.asking_price) > 0 ? Number(specs.asking_price) : null,
      engines:
        [specs?.engines, specs?.hours ? `${specs.hours} hrs` : "", specs?.fuel || ""]
          .filter(Boolean)
          .join(" · ") || "",
      specs:
        [specs?.length ? `Length ${specs.length}` : "", specs?.draft ? `Draft ${specs.draft}` : "", specs?.location ? `Location ${specs.location}` : "", specs?.condition ? `Condition ${specs.condition}` : ""]
          .filter(Boolean)
          .join(" · ") || (specs?.description_summary || ""),
      source: normalizedUrl ? sourceFromUrl(normalizedUrl) : "",
    };

    // 3. Listing evaluation (match analysis) is a Market Match feature. Free and lower-tier
    //    buyers can save boats (specs extracted above), but the detailed match against their
    //    profile requires Market Match (including legacy Buyer Pass) with allowance. Re-evaluating a listing already
    //    evaluated does not consume an allowance; a new listing URL does.
    let match: any = null;
    let evaluationLocked = false;
    const plan: string = normalizePlan((user as any).plan || "free");
    const listingEvalsLimit = Number((user as any).listing_evals_limit) || 0;
    const listingEvalsUsed = Number((user as any).listing_evals_used) || 0;
    const isMarketMatch = plan === "market_match" && paidWindowIsActive((user as any).plan_expires);
    // SavedBoat.analyzed and SavedBoat.match are buyer-editable. NEVER use
    // those fields as proof that an allowance was previously consumed.
    // Only an admin-restricted, service-role-written evaluation ledger grants
    // a no-additional-allowance re-evaluation for the same normalized URL.
    let alreadyEvaluated = false;
    let evaluationLedgerAvailable = true;
    if (normalizedUrl && isMarketMatch) {
      try {
        const prior = await base44.asServiceRole.entities.ListingEvaluationLedger.filter({
          buyer_user_id: user.id, canonical_listing_url: normalizedUrl, status: "complete",
        }, "-created_date", 1);
        alreadyEvaluated = Boolean(prior?.length);
      } catch (e) {
        console.error("analyze-saved-boat: trusted evaluation ledger unavailable", e);
        evaluationLedgerAvailable = false;
      }
    }
    const canEvaluate = isMarketMatch && evaluationLedgerAvailable &&
      (alreadyEvaluated || listingEvalsUsed < listingEvalsLimit);
    if (!isMarketMatch || !evaluationLedgerAvailable) evaluationLocked = true;
    if (profile && canEvaluate) {
      const profileSummary = JSON.stringify({
        vessel_class: profile.vessel_class,
        activities: profile.activities,
        operating_area: profile.operating_area,
        experience_level: profile.experience_level,
        passenger_count: profile.passenger_count,
        overnight_requirements: profile.overnight_requirements,
        storage: profile.storage,
        storage_capacity: profile.storage_capacity,
        boat_size_range: profile.boat_size_range,
        towing: profile.towing,
        budget: [profile.purchase_budget_min, profile.purchase_budget_max],
        annual_ownership_budget: profile.annual_ownership_budget,
        ownership_horizon: profile.ownership_horizon,
        must_haves: profile.must_haves,
        preferences: profile.preferences,
        unacceptable_compromises: profile.unacceptable_compromises,
        priorities: profile.priorities,
      });
      const boatIdentity = [boat.make, boat.model, boat.year].filter(Boolean).join(" ") || boat.title || description;
      const boatDetails = JSON.stringify({
        identity: boatIdentity,
        asking_price: boat.asking_price,
        engines: boat.engines,
        specs: boat.specs,
        key_features: specs?.key_features || [],
        description_summary: specs?.description_summary || "",
        buyer_note: note,
      });
      const { list: manufacturerList } = await loadManufacturerMap(base44);
      const builderRecord = findManufacturer(boat.make, manufacturerList);
      const builderContext = builderRecord
        ? `\n\nBuilder on file: ${formatManufacturer(builderRecord)}`
        : "";
      try {
        match = await base44.asServiceRole.integrations.Core.InvokeLLM({
          prompt:
            `${ADVISOR_REASONING_GUIDE}\n\nYou are SoundHeading, an impartial boat-buying advisory. A buyer is considering a specific boat. Research that boat's year and model and compare it to the buyer's stated needs and wants.\n\nBoat being considered:\n${boatDetails}${builderContext}\n\nBuyer profile (needs / wants / budget / priorities):\n${profileSummary}\n\nUsing what you know (and can find) about this boat's year and model, return JSON with:\n- matches: specific ways this boat matches the buyer's stated needs, wants, and top priorities. Be concrete (e.g. "trailerable — fits your storage answer").\n- gaps: specific ways this boat falls short of or conflicts with the buyer's needs, wants, budget, or unacceptable compromises.\n- summary: one short paragraph the buyer can read at a glance — does this boat fit their life, and the single most important thing to verify next.\n\nDo not invent specifications. If the model year is unknown, say so and base the analysis on the model line generally.`,
          add_context_from_internet: true,
          response_json_schema: MATCH_SCHEMA,
        });
      } catch (e) {
        console.error("analyze-saved-boat match error", e);
      }
      // Record a successful new URL evaluation in server-owned storage before
      // metering it. If metering fails, compensate by deleting that new ledger
      // record and withhold the paid result; no client-editable SavedBoat flag
      // can grant future free evaluations.
      if (match && !alreadyEvaluated && normalizedUrl) {
        let ledgerId: string | null = null;
        try {
          const recorded = await base44.asServiceRole.entities.ListingEvaluationLedger.create({
            buyer_user_id: user.id,
            canonical_listing_url: normalizedUrl,
            buyer_profile_id: String(profile?.id || ""),
            status: "complete",
            summary: String(match.summary || "").slice(0, 280),
            evaluated_at: new Date().toISOString(),
          });
          if (!recorded?.id) throw new Error("Evaluation ledger returned no record ID");
          ledgerId = recorded.id;
          await base44.asServiceRole.entities.User.update(user.id, { listing_evals_used: listingEvalsUsed + 1 } as any);
        } catch (e) {
          console.error("analyze-saved-boat: could not safely record paid evaluation", e);
          if (ledgerId) {
            try { await base44.asServiceRole.entities.ListingEvaluationLedger.delete(ledgerId); }
            catch (cleanupError) { console.error("analyze-saved-boat: evaluation ledger cleanup failed", cleanupError); }
          }
          match = null;
          evaluationLocked = true;
        }
      }
    }

    return Response.json({
      boat,
      match,
      fetched,
      extractError,
      evaluationLocked,
      listingEvalsLimit,
      listingEvalsUsed,
    });
  } catch (err) {
    console.error("analyze-saved-boat error", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}