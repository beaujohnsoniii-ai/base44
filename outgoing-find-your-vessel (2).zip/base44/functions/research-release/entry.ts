import {createClientFromRequest} from 'npm:@base44/sdk@0.8.52';
import {ReleaseService} from '../../shared/release-runtime.mjs';
import {releaseRepository} from '../../shared/release-repository.mjs';
export default async function(req:Request):Promise<Response>{
 if(req.method!=='POST')return Response.json({error:'Method not allowed'},{status:405});
 const client=createClientFromRequest(req);let user;
 try{user=await client.auth.me();}catch{return Response.json({error:'Unauthorized'},{status:401});}
 if(!user)return Response.json({error:'Unauthorized'},{status:401});
 if(user.role!=='admin')return Response.json({error:'Admin required'},{status:403});
 // Authentication precedes body parsing and all service-role reads/writes.
 try{
  const text=await req.text();if(new TextEncoder().encode(text).length>2000000)return Response.json({error:'Request too large'},{status:413});
  const body=JSON.parse(text||'{}'),repo=releaseRepository(client.asServiceRole),service=new ReleaseService(repo);
  const id=String(body.release_id||'');
  if(body.action==='stage'||body.action==='restore')return Response.json(await service.stage(user,body.manifest,body.records||[]));
  if(body.action==='verify'){const {release,records}=await service.verify(id);return Response.json({release_id:id,sealed:release.sealed,approved:release.approved,records:records.length,observations:records.reduce((n,r)=>n+r.observations.length,0),payload_sha256:release.manifest.payload_sha256});}
  if(body.action==='seal')return Response.json(await service.seal(user,id));
  if(body.action==='approve'){await service.verify(id);const r=await repo.approve(id,user);return Response.json({release_id:id,approved:r.approved,approved_by:r.approved_by});}
  if(body.action==='backup')return Response.json(await repo.backup(id,Math.max(0,Math.floor(Number(body.skip)||0))));
  if(body.action==='status')return Response.json({pointer:await repo.getPointer(),release:id?await repo.getRelease(id):null,activation_gate:'conditional pointer writes unverified'});
  if(body.action==='activate'){const r=await repo.getRelease(id);if(!r?.approved)return Response.json({error:'Release approval required'},{status:409});return Response.json(await service.promote(user,id,Number(body.expected_revision)));}
  if(body.action==='rollback')return Response.json(await service.rollback(user,Number(body.expected_revision)));
  return Response.json({error:'Unknown action'},{status:400});
 }catch(error){return Response.json({error:error instanceof Error?error.message:'Release operation failed'},{status:409});}
}