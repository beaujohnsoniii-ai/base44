import {createClientFromRequest} from "npm:@base44/sdk@0.8.54";
import {normalizePlan} from "../../shared/stages.ts";
import {paidWindowIsActive} from "../../shared/paid-access.ts";
import {normalizePublicListingUrl} from "../../shared/remote-listing.ts";
import {selectListingInputs} from "../../shared/listing-comparison.mjs";
import {resolveApprovedListings} from "../../shared/approved-listing-resolver.mjs";
import {normalizeCapturedListings} from "../../shared/captured-listing.mjs";
import {compareStoredModels} from "../../shared/model-comparison.mjs";
import {withCompareDeadline} from "../../shared/compare-deadline.mjs";

// Approved-source resolver: fetches public listing pages from boats.com,
// boattrader.com, and yachtworld.com only. If direct access is blocked, one
// explicit Compare action may use at most three exact-URL indexed searches,
// with no retries or AI evaluation. Unapproved URLs are saved as links only.
// Seller claims remain evidence, not verified specifications or a ranking.
export default async function(req:Request):Promise<Response>{
 if(req.method!=="POST")return Response.json({error:"Method not allowed"},{status:405});
 try{return await withCompareDeadline(async signal=>{
  const client=createClientFromRequest(req);let user;
  try{user=await client.auth.me();}catch{signal.throwIfAborted();return Response.json({error:"Sign in first"},{status:401});}
  signal.throwIfAborted();
  if(!user)return Response.json({error:"Sign in first"},{status:401});
  if(normalizePlan(user.plan||"free")!=="market_match"||!paidWindowIsActive(user.plan_expires))return Response.json({error:"Active Captain access is required."},{status:403});
  const [profiles,spaces]=await Promise.all([
   client.entities.BuyerProfile.filter({created_by_id:user.id},"-created_date",1),
   client.entities.CompareWorkspace.filter({created_by_id:user.id},"-created_date",1)]);
  signal.throwIfAborted();
  const profile=profiles[0],workspace=spaces[0];
  if(!profile||profile.created_by_id!==user.id||!workspace||workspace.created_by_id!==user.id)return Response.json({error:"Save your buyer profile and Compare selection first."},{status:400});
  const ids=workspace.selected_ids;
  if(!Array.isArray(ids)||!ids.length||ids.length>3||new Set(ids).size!==ids.length)return Response.json({error:"Save one to three selected models first."},{status:400});
  const models=[];
  for(const id of ids){
   signal.throwIfAborted();
   const model=await client.entities.SavedBoat.get(id);
   signal.throwIfAborted();
   if(!model||model.created_by_id!==user.id)return Response.json({error:"A selected model is unavailable."},{status:403});
   models.push(model);
  }
  let body={};try{body=await req.json();}catch{body={};}
  if(body?.mode==="models")return Response.json(await compareStoredModels(client.asServiceRole,models,signal));
  let inputs;try{inputs=selectListingInputs(models,ids,normalizePublicListingUrl);}catch(e){return Response.json({error:e.message},{status:400});}
  let capturedByUrl;try{capturedByUrl=normalizeCapturedListings(body?.captures,inputs.map(input=>input.url),normalizePublicListingUrl);}catch(e){return Response.json({error:e.message},{status:400});}
  // Buyer-copied text is bound to an owner-verified saved URL and used without
  // any provider request. Otherwise use direct fetch, then the bounded exact-URL
  // indexed fallback; no model/manufacturer research job or AI evaluation is started.
  const output=await resolveApprovedListings(profile,inputs,signal,{capturedByUrl});
  signal.throwIfAborted();
  return Response.json({...output,buyer_profile_id:profile.id,profile_updated_at:profile.updated_date,checked_at:new Date().toISOString(),
   mode:"approved_source_import",notice:"Listing details may come from buyer-copied page text bound to the exact saved URL, an approved live page, or a clearly labeled exact-URL indexed excerpt. Buyer-copied text is transient and is not independently retrieved or verified. One Compare action is capped at three indexed searches with no retries. Seller claims are evidence only, not verified specifications or a suitability ranking. Finalist recommendations remain unavailable. No AI evaluation allowance consumed."});
 });}catch(e){if(e?.message==="COMPARE_DEADLINE")return Response.json({error:"Comparison timed out. Saved links and selections are unchanged."},{status:504});
 return Response.json({error:"Could not compare saved listings. Your saved links and selections are unchanged."},{status:500});}
}