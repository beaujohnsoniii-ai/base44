// SoundHeading MATCH QA - automated test runner.
//
// Imports the shared suggest-engine.ts directly (the same engine production
// suggest-boats uses). Runs tier progression for test profiles, simulates Likes
// between tiers, runs programmatic checks, runs AI evaluation for non-RED cases,
// checks tier progression and golden-profile regressions, and stores all results
// in the Test DB.
//
// All data stays in the Test DB (X-Data-Env: dev). Manufacturer and QuestionConfig
// records are read from Production via a separate client. No production data is
// altered. No production analytics are triggered.
//
// Actions:
//   - "run" (default): run a QA batch (mode: golden | standard | mixed)
//   - "seed-golden": create/refresh the 25 golden profiles in the Test DB
//   - "cleanup": delete old QA BuyerProfiles and SuggestedBoats from previous runs

import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { loadManufacturerMap } from "../../shared/advisor-reasoning.ts";
import { loadQuestionTiers } from "../../shared/question-tiers.ts";
import { generateRecommendations } from "../../shared/suggest-engine.ts";
import { GOLDEN_PROFILE_DEFS, generateSyntheticProfile } from "../../shared/qa-profiles.ts";
import { runProgrammaticChecks, checkProgression } from "../../shared/qa-programmatic.ts";
import { simulateLikes } from "../../shared/qa-like-sim.ts";
import { evaluateProfile } from "../../shared/qa-evaluator.ts";
import { normalizeQARunParams } from "../../shared/qa-run-params.ts";
import { loadPublishedMatchCatalog } from "../../shared/catalog-loader.ts";

const TIERS = ["free", "match_plus", "refined_match", "market_match"] as const;
type Tier = typeof TIERS[number];

export default async function (req: Request): Promise<Response> {
  let runId: string | null = null;
  try {
    if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

    const base44 = createClientFromRequest(req);
    let user;
    try {
      user = await base44.auth.me();
    } catch (_) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    if (user.role !== "admin") {
      return Response.json({ error: "Admin access required" }, { status: 403 });
    }

    // Safety: refuse to run without the X-Data-Env: dev header. This ensures
    // the QA system NEVER writes synthetic data to Production.
    const dataEnv = req.headers.get("X-Data-Env");
    if (dataEnv !== "dev") {
      return Response.json({ error: "MATCH QA requires X-Data-Env: dev header. Refusing to run against Production." }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const action = String(body.action || "run");
    if (!["run", "seed-golden", "cleanup"].includes(action)) {
      return Response.json({ error: "Unsupported MATCH QA action." }, { status: 400 });
    }

    // Production client for reading Manufacturer and QuestionConfig (they live in Production).
    const prodHeaders = new Headers(req.headers);
    prodHeaders.delete("X-Data-Env");
    const prodReq = new Request(req.url, { method: req.method, headers: prodHeaders });
    const prodBase44 = createClientFromRequest(prodReq);

    // ── Seed golden profiles ──────────────────────────────────────────────────
    if (action === "seed-golden") {
      let created = 0;
      let updated = 0;
      const existing = await base44.asServiceRole.entities.GoldenProfile.list("-created_date", 500);
      const existingByName = new Map((existing || []).map((g: any) => [g.name, g]));

      for (const def of GOLDEN_PROFILE_DEFS) {
        const existingRec = existingByName.get(def.name);
        const data = {
          name: def.name,
          description: def.description,
          category: def.category,
          profile_data: def.profile_data,
          is_approved: true,
        };
        if (existingRec) {
          await base44.asServiceRole.entities.GoldenProfile.update(existingRec.id, data);
          updated++;
        } else {
          await base44.asServiceRole.entities.GoldenProfile.create(data);
          created++;
        }
      }
      return Response.json({ created, updated, total: GOLDEN_PROFILE_DEFS.length });
    }

    // ── Cleanup old test data ──────────────────────────────────────────────────
    if (action === "cleanup") {
      let deletedProfiles = 0;
      let deletedSuggestions = 0;
      try {
        const oldProfiles = await base44.asServiceRole.entities.BuyerProfile.filter({ status: "active" }, "-created_date", 500);
        const qaProfiles = (oldProfiles || []).filter((p: any) => p.test_profile_id?.startsWith("qa_"));
        for (const p of qaProfiles) {
          try { await base44.asServiceRole.entities.BuyerProfile.delete(p.id); deletedProfiles++; } catch (_) {}
        }
      } catch (e) { console.error("qa: cleanup profiles failed", e); }
      try {
        const oldSuggs = await base44.asServiceRole.entities.SuggestedBoat.list("-created_date", 500);
        const qaSuggs = (oldSuggs || []).filter((s: any) => s.test_profile_id?.startsWith("qa_"));
        for (const s of qaSuggs) {
          try { await base44.asServiceRole.entities.SuggestedBoat.delete(s.id); deletedSuggestions++; } catch (_) {}
        }
      } catch (e) { console.error("qa: cleanup suggestions failed", e); }
      return Response.json({ deleted_profiles: deletedProfiles, deleted_suggestions: deletedSuggestions });
    }

    // ── Run QA batch ───────────────────────────────────────────────────────────
    let params: ReturnType<typeof normalizeQARunParams>;
    try {
      params = normalizeQARunParams(body);
    } catch (_) {
      return Response.json({ error: "Invalid QA mode or batch limits (1-50 profiles per run)." }, { status: 400 });
    }
    const { mode, batchSize, maxProfiles, notes } = params;

    // Create the run record
    const run = await base44.asServiceRole.entities.QATestRun.create({
      run_type: mode,
      status: "running",
      profile_count: 0,
      tier_results_count: 0,
      green_count: 0,
      yellow_count: 0,
      red_count: 0,
      uncertain_count: 0,
      flagged_count: 0,
      constraint_failures: 0,
      progression_failures: 0,
      golden_regressions: 0,
      expert_reviews_pending: 0,
      expert_reviews_completed: 0,
      notes,
    });

    runId = run.id;

    // Load shared inputs from Production
    const tierFields = await loadQuestionTiers(prodBase44);
    // QA must use the same published model evidence as production MATCH.
    // A single 500-record page silently changes test outcomes as the catalog grows.
    let catalogRecords: any[] = [];
    try {
      const catalog = await loadPublishedMatchCatalog(prodBase44.asServiceRole.entities.BoatModelCatalog);
      catalogRecords = catalog.records;
      if (catalog.truncated) {
        console.warn("qa: published catalog reached the bounded page cap; unlisted models remain unverified");
      }
    } catch (error) {
      console.error("qa: published model catalog unavailable; model facts remain provisional", error);
    }
    let preferredBrands: string[] = [];
    try {
      const manufacturers = await prodBase44.asServiceRole.entities.Manufacturer.list("-created_date", 500);
      preferredBrands = (manufacturers || [])
        .filter((m: any) => m.status !== "defunct" && m.name)
        .map((m: any) => m.name)
        .slice(0, 200);
    } catch (e) {
      console.error("qa: load manufacturers failed", e);
    }

    // Build the list of test profiles to run
    const testProfiles: { profileData: any; goldenId: string | null; goldenName: string | null; isGolden: boolean }[] = [];

    if (mode === "golden" || mode === "mixed") {
      const goldenProfiles = await base44.asServiceRole.entities.GoldenProfile.filter({ is_approved: true }, "-created_date", 100);
      for (const gp of (goldenProfiles || [])) {
        testProfiles.push({
          profileData: gp.profile_data,
          goldenId: gp.id,
          goldenName: gp.name,
          isGolden: true,
        });
      }
    }

    if (maxProfiles > 0 && testProfiles.length >= maxProfiles) {
      // Already have enough from golden profiles
    } else if (mode === "standard" || mode === "mixed") {
      const remaining = maxProfiles > 0 ? Math.min(batchSize, maxProfiles - testProfiles.length) : batchSize;
      for (let i = 0; i < remaining; i++) {
        const synth = generateSyntheticProfile(preferredBrands);
        testProfiles.push({
          profileData: synth.profile_data,
          goldenId: null,
          goldenName: null,
          isGolden: false,
        });
      }
    }

    // Load previous run's golden tier results for regression comparison
    const previousRuns = await base44.asServiceRole.entities.QATestRun.filter({ status: "complete" }, "-created_date", 1);
    const previousRunId = previousRuns?.[0]?.id || null;
    let previousTierResults: any[] = [];
    if (previousRunId) {
      try {
        previousTierResults = await base44.asServiceRole.entities.QATierResult.filter({ run_id: previousRunId }, "rank", 500);
      } catch (e) {
        console.error("qa: load previous tier results failed", e);
      }
    }
    const prevByGoldenTier = new Map<string, any>();
    for (const tr of previousTierResults) {
      if (tr.golden_profile_id) {
        prevByGoldenTier.set(`${tr.golden_profile_id}|${tr.tier}`, tr);
      }
    }

    // Never process more than 50 profiles in a single LLM-backed QA run,
    // including when a mixed batch includes all golden profiles.
    const runLimit = maxProfiles || 50;
    if (testProfiles.length > runLimit) {
      testProfiles.length = runLimit;
    }

    // Summary counters
    let tierResultsCount = 0;
    let greenCount = 0;
    let yellowCount = 0;
    let redCount = 0;
    let uncertainCount = 0;
    let flaggedCount = 0;
    let constraintFailures = 0;
    let progressionFailures = 0;
    let goldenRegressions = 0;
    let failedProfiles = 0;

    // Process each test profile
    for (let pi = 0; pi < testProfiles.length; pi++) {
      const tp = testProfiles[pi];
      console.log(`qa: processing profile ${pi + 1}/${testProfiles.length} ${tp.isGolden ? "(golden: " + tp.goldenName + ")" : "(synthetic)"}`);

      try {
        // Create a temporary BuyerProfile in the Test DB
        const profile = await base44.asServiceRole.entities.BuyerProfile.create({
          ...tp.profileData,
          test_profile_id: `qa_${runId}`,
        });

        // Load the manufacturer map for this profile (from Production)
        const manufacturerMap = await loadManufacturerMap(prodBase44.asServiceRole, profile);

        // Track liked_models across tiers
        let likedModels: any[] = [];
        const tierResults: { tier: string; suggestions: any[]; likedModels: any[]; programmaticChecks: any; programmaticConcernLevel: string; tierResultId: string }[] = [];
        let prevTierResultId: string | null = null;
        let prevTierSuggestions: any[] = null;
        let prevTier: string | null = null;

        for (let ti = 0; ti < TIERS.length; ti++) {
          const tier = TIERS[ti];
          const isFirstPaidGeneration = tier === "match_plus"; // simulate first paid purchase at MATCH+

          // Run the shared engine
          const engineResult = await generateRecommendations(base44, {
            profile,
            plan: tier,
            tierFields,
            manufacturerMap,
            catalogRecords,
            likedModels,
            savedBoats: [],
            existingSuggestions: prevTierSuggestions || [],
            isFirstPaidGeneration,
            hadContradiction: !!profile.contradiction_flag?.flagged,
            refresh: true,
            contradictionRerunCount: Number(profile.contradiction_rerun_count) || 0,
          });

          // Run programmatic checks
          const progChecks = runProgrammaticChecks(engineResult.suggestions, profile, tier, likedModels);

          // Run progression checks (against previous tier)
          const progProgression = checkProgression(
            engineResult.suggestions,
            prevTierSuggestions,
            tier,
            prevTier,
          );

          // Determine initial concern level and flag reasons
          let concernLevel = progChecks.concern_level;
          const flagReasons = [...progChecks.flag_reasons, ...progProgression.flag_reasons];

          // Store the QATierResult
          const tierResult = await base44.asServiceRole.entities.QATierResult.create({
            run_id: runId,
            test_profile_id: profile.id,
            golden_profile_id: tp.goldenId,
            golden_profile_name: tp.goldenName,
            is_golden: tp.isGolden,
            tier,
            suggestions: engineResult.suggestions,
            liked_models: likedModels,
            profile_snapshot: tp.profileData,
            programmatic_checks: progChecks.checks,
            programmatic_concern_level: progChecks.concern_level,
            ai_concern_level: "not_evaluated",
            concern_level: concernLevel,
            is_flagged: false,
            flag_reasons: flagReasons,
            previous_tier_result_id: prevTierResultId,
            progression_checks: {
              overlap_count: progProgression.overlap_count,
              overlap_titles: progProgression.overlap_titles,
              new_models: progProgression.new_models,
              dropped_models: progProgression.dropped_models,
              churn_rate: progProgression.churn_rate,
              ranking_changed: progProgression.ranking_changed,
            },
            is_regression: false,
          });

          tierResults.push({
            tier,
            suggestions: engineResult.suggestions,
            likedModels: [...likedModels],
            programmaticChecks: progChecks.checks,
            programmaticConcernLevel: progChecks.concern_level,
            tierResultId: tierResult.id,
          });

          tierResultsCount++;
          if (progChecks.concern_level === "red") constraintFailures++;
          if (progProgression.flag_reasons.length > 0) progressionFailures++;

          // Simulate likes for the next tier (except after market_match)
          if (tier !== "market_match") {
            const simResult = simulateLikes(engineResult.suggestions, tier as any, likedModels);
            likedModels = simResult.newLikedModels;
            // Update the Test DB profile with the new liked_models
            try {
              await base44.asServiceRole.entities.BuyerProfile.update(profile.id, {
                liked_models: likedModels,
              });
            } catch (e) {
              console.error(`qa: update liked_models for ${profile.id} failed`, e);
            }
          }

          prevTierResultId = tierResult.id;
          prevTierSuggestions = engineResult.suggestions;
          prevTier = tier;
        }

        // Determine if any tier has RED programmatic checks
        const anyRed = tierResults.some(tr => tr.programmaticConcernLevel === "red");

        // Run AI evaluation only if no RED programmatic checks (cost control)
        if (!anyRed) {
          try {
            const aiResult = await evaluateProfile(base44, profile, tierResults);

            // Update each QATierResult with the AI scorecard for that tier
            for (const tr of tierResults) {
              const perTier = aiResult.scorecard?.per_tier?.find((pt: any) => pt.tier === tr.tier);
              const aiConcern = perTier?.concern_level || aiResult.concern_level || "uncertain";

              // Overall concern level = max of programmatic and AI
              const overallConcern = maxConcern(tr.programmaticConcernLevel, aiConcern as any);
              const isFlagged = overallConcern === "yellow" || overallConcern === "red" || overallConcern === "uncertain";

              const allFlagReasons = [...(await base44.asServiceRole.entities.QATierResult.get(tr.tierResultId)).flag_reasons];
              if (perTier?.summary) allFlagReasons.push(`AI: ${perTier.summary}`);

              await base44.asServiceRole.entities.QATierResult.update(tr.tierResultId, {
                ai_scorecard: {
                  dimensions: aiResult.scorecard?.dimensions || [],
                  per_tier_summary: perTier?.summary || "",
                  progression_assessment: aiResult.scorecard?.progression_assessment || "",
                  overall_summary: aiResult.scorecard?.overall_summary || "",
                  uncertain_areas: aiResult.scorecard?.uncertain_areas || [],
                },
                ai_concern_level: aiConcern,
                concern_level: overallConcern,
                is_flagged: isFlagged,
                flag_reasons: allFlagReasons,
              });

              // Update counters
              if (overallConcern === "green") greenCount++;
              else if (overallConcern === "yellow") yellowCount++;
              else if (overallConcern === "red") redCount++;
              else uncertainCount++;
              if (isFlagged) flaggedCount++;
            }
          } catch (e) {
            console.error(`qa: AI evaluation failed for profile ${profile.id}`, e);
            // On AI failure, mark all tiers as uncertain
            for (const tr of tierResults) {
              await base44.asServiceRole.entities.QATierResult.update(tr.tierResultId, {
                ai_concern_level: "uncertain",
                concern_level: "uncertain",
                is_flagged: true,
                flag_reasons: [...(tr.programmaticConcernLevel === "yellow" ? ["programmatic yellow"] : []), "AI evaluation failed"],
              });
              uncertainCount++;
              flaggedCount++;
            }
          }
        } else {
          // RED programmatic checks - skip AI, flag directly
          for (const tr of tierResults) {
            const isFlagged = tr.programmaticConcernLevel === "red" || tr.programmaticConcernLevel === "yellow";
            await base44.asServiceRole.entities.QATierResult.update(tr.tierResultId, {
              ai_concern_level: "not_evaluated",
              concern_level: tr.programmaticConcernLevel,
              is_flagged: isFlagged,
            });

            if (tr.programmaticConcernLevel === "red") redCount++;
            else if (tr.programmaticConcernLevel === "yellow") yellowCount++;
            else greenCount++;
            if (isFlagged) flaggedCount++;
          }
        }

        // Check golden profile regression
        if (tp.isGolden && tp.goldenId) {
          for (const tr of tierResults) {
            const prevTr = prevByGoldenTier.get(`${tp.goldenId}|${tr.tier}`);
            if (prevTr) {
              const regression = isRegression(prevTr, tr);
              if (regression.is_regression) {
                await base44.asServiceRole.entities.QATierResult.update(tr.tierResultId, {
                  is_regression: true,
                  flag_reasons: [...(await base44.asServiceRole.entities.QATierResult.get(tr.tierResultId)).flag_reasons, `Golden regression: ${regression.reason}`],
                  is_flagged: true,
                });
                goldenRegressions++;
                flaggedCount++;
              }
            }
          }
        }

        // Update golden profile's last_run_id and last_run_date
        if (tp.isGolden && tp.goldenId) {
          try {
            await base44.asServiceRole.entities.GoldenProfile.update(tp.goldenId, {
              last_run_id: runId,
              last_run_date: new Date().toISOString(),
            });
          } catch (e) {
            console.error(`qa: update golden profile ${tp.goldenId} failed`, e);
          }
        }
      } catch (e) {
        failedProfiles++;
        console.error(`qa: profile ${pi + 1} failed`, e);
      }
    }

    // A partially executed or empty run must never be labeled complete: doing
    // so can make QA dashboards claim everything passed when nothing was tested.
    // Four tier results are expected for each fully processed profile.
    const expectedTierResults = testProfiles.length * TIERS.length;
    const runIncomplete = testProfiles.length === 0 || failedProfiles > 0 || tierResultsCount !== expectedTierResults;
    const runNotes = [notes, runIncomplete
      ? `INCOMPLETE QA: ${failedProfiles} profile execution error(s); ${tierResultsCount}/${expectedTierResults} tier results persisted. Review backend logs before relying on this run.`
      : ""].filter(Boolean).join("\n");

    // Update the run record with summary stats
    await base44.asServiceRole.entities.QATestRun.update(runId, {
      status: runIncomplete ? "failed" : "complete",
      notes: runNotes,
      profile_count: testProfiles.length,
      tier_results_count: tierResultsCount,
      green_count: greenCount,
      yellow_count: yellowCount,
      red_count: redCount,
      uncertain_count: uncertainCount,
      flagged_count: flaggedCount,
      constraint_failures: constraintFailures,
      progression_failures: progressionFailures,
      golden_regressions: goldenRegressions,
      expert_reviews_pending: flaggedCount,
    });

    return Response.json({
      run_id: runId,
      profile_count: testProfiles.length,
      tier_results_count: tierResultsCount,
      green: greenCount,
      yellow: yellowCount,
      red: redCount,
      uncertain: uncertainCount,
      flagged: flaggedCount,
      constraint_failures: constraintFailures,
      progression_failures: progressionFailures,
      golden_regressions: goldenRegressions,
      status: runIncomplete ? "failed" : "complete",
      failed_profiles: failedProfiles,
      expected_tier_results: expectedTierResults,
    });
  } catch (err) {
    console.error("run-match-qa error", err);
    if (runId && req.headers.get("X-Data-Env") === "dev") {
      // Do not leave a crashed run permanently "running" or let its partial
      // results be mistaken for a completed QA pass. Preserve the failure even
      // when writing the failure status encounters a second error.
      try {
        const qaClient = createClientFromRequest(req);
        await qaClient.asServiceRole.entities.QATestRun.update(runId, {
          status: "failed",
          notes: "INCOMPLETE QA: backend execution stopped unexpectedly. Inspect backend logs; no pass can be inferred.",
        });
      } catch (markError) {
        console.error("qa: unable to mark crashed run failed", markError);
      }
    }
    return Response.json({ error: "Internal error", run_id: runId, status: runId ? "failed" : "not_started" }, { status: 500 });
  }
}

// Determine the worse of two concern levels.
function maxConcern(a: string, b: string): "green" | "yellow" | "red" | "uncertain" {
  const order: Record<string, number> = { green: 0, yellow: 1, uncertain: 2, red: 3 };
  const aVal = order[a] ?? 0;
  const bVal = order[b] ?? 0;
  const max = Math.max(aVal, bVal);
  const reverse: Record<number, string> = { 0: "green", 1: "yellow", 2: "uncertain", 3: "red" };
  return reverse[max] as any;
}

// Check if the current tier result is a regression from the previous run.
function isRegression(prev: any, curr: { tier: string; suggestions: any[]; programmaticChecks: any; programmaticConcernLevel: string }): { is_regression: boolean; reason: string } {
  const order: Record<string, number> = { green: 0, yellow: 1, uncertain: 2, red: 3 };
  const prevLevel = prev.concern_level || "green";
  const currLevel = curr.programmaticConcernLevel;

  // Regression: concern level got worse
  if ((order[currLevel] || 0) > (order[prevLevel] || 0)) {
    return { is_regression: true, reason: `concern level ${prevLevel} -> ${currLevel}` };
  }

  // Regression: previously compliant constraint now violated
  const prevChecks = prev.programmatic_checks || {};
  const currChecks = curr.programmaticChecks || {};
  const prevHardViolations = prevChecks.hard_constraint_violations?.length || 0;
  const currHardViolations = currChecks.hard_constraint_violations?.length || 0;
  if (prevHardViolations === 0 && currHardViolations > 0) {
    return { is_regression: true, reason: `new hard-constraint violations (${currHardViolations})` };
  }

  // Regression: suggestion count dropped significantly
  const prevCount = prevChecks.total_suggestions || 0;
  const currCount = currChecks.total_suggestions || 0;
  if (prevCount >= 5 && currCount <= 1) {
    return { is_regression: true, reason: `suggestion count dropped ${prevCount} -> ${currCount}` };
  }

  return { is_regression: false, reason: "" };
}