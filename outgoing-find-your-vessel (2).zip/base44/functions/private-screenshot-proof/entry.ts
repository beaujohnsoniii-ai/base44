// Completed temporary proof. Intentionally inert: no SDK, credentials, assets or integrations.
export default async function handler(_req) {
  return Response.json(
    { error: "Proof disabled", runtime_version: "private-jpeg-proof-2026-10-24-disabled", integrations_enabled: false },
    { status: 410, headers: { "Cache-Control": "no-store" } },
  );
}
