import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { runPrivateMatchTrial } from "../../shared/private-match-trial.mjs";
import fixture from "../../shared/private-match-fixture.ts";
// Read-only, admin-only diagnostic. Never invokes the live suggest or QA generators.
export default async function(req: Request): Promise<Response> {
  if (req.method !== "POST") return Response.json({error:"Method not allowed"},{status:405});
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return Response.json({error:"Unauthorized"},{status:401}); }
  if (!user || user.role !== "admin") return Response.json({error:"Admin access required"},{status:403});
  const body = await req.json().catch(()=>({}));
  const profileId = fixture.confirmed_buyer_profile;
  if (body.profile_id && body.profile_id !== profileId) return Response.json({error:"This bounded trial is approved for the selected 26 ft profile only."},{status:400});
  const profiles = await base44.entities.BuyerProfile.filter({id:profileId});
  const profile = profiles.find((p:any)=>p.id===profileId && p.created_by_id===user.id);
  if (!profile) return Response.json({error:"Selected owner profile unavailable"},{status:404});
  const result = runPrivateMatchTrial(profile, fixture.boats, {as_of:fixture.as_of});
  return Response.json({...result, fixture_metadata:{source_master:fixture.source_master,scope:fixture.scope,complete_boat_files:fixture.complete_boat_files}});
}
