import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { loadManufacturerMap } from "../../shared/advisor-reasoning.ts";
import { loadQuestionTiers } from "../../shared/question-tiers.ts";
import { generateRecommendations } from "../../shared/suggest-engine.ts";
import { loadPublishedMatchCatalog } from "../../shared/catalog-loader.ts";
// Admin-only live engine evaluation. Never writes profiles, entitlements, purchases or results.
export default async function(req: Request): Promise<Response> {
 if(req.method!=="POST")return Response.json({error:"Method not allowed"},{status:405});
 const client=createClientFromRequest(req);
 let user;try{user=await client.auth.me();}catch{return Response.json({error:"Unauthorized"},{status:401});}
 if(user?.role!=="admin")return Response.json({error:"Admin access required"},{status:403});
 try{
 const body=await req.json();
 if(JSON.stringify(body).length>60000)return Response.json({error:"Test input too large"},{status:400});
 const plan=body.plan;
 if(!["free","match_plus","refined_match","market_match"].includes(plan)||!body.profile||typeof body.profile!=="object"||Array.isArray(body.profile))return Response.json({error:"A valid tier and questionnaire are required"},{status:400});
 const profile={...body.profile,id:"private-launch-test",created_by_id:user.id};
 const [tierFields,manufacturerMap,catalog]=await Promise.all([loadQuestionTiers(client),loadManufacturerMap(client.asServiceRole,profile),loadPublishedMatchCatalog(client.asServiceRole.entities.BoatModelCatalog)]);
 const result=await generateRecommendations(client,{profile,plan,tierFields,manufacturerMap,catalogRecords:catalog.records,likedModels:[],savedBoats:[],existingSuggestions:[],isFirstPaidGeneration:plan!=="free",hadContradiction:false,refresh:true,contradictionRerunCount:0});
 return Response.json({...result,test_only:true,persisted:false,payment_taken:false});
 }catch(error){console.error("buyer-launch-test failed",error);return Response.json({error:"Live Match test did not complete. Your account was not reset or charged. Check backend logs before retrying."},{status:502});}
}
