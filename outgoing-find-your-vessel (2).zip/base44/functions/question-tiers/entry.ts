// Public question keys and tier labels only; no buyer data or administrative access.
import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { loadQuestionTiers } from "../../shared/question-tiers.ts";
import { fieldTiersFromSets } from "../../shared/question-tier-defaults.mjs";
export default async function (req: Request): Promise<Response> {
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });
  const client = createClientFromRequest(req);
  const tiers = await loadQuestionTiers(client);
  return Response.json({ field_tiers: fieldTiersFromSets(tiers) });
}
