import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { FIELDS, customerFields, normalizeResolution } from "../../shared/hybrid-evidence.mjs";
import { checkDatasetOnline } from "../../shared/hybrid-online.ts";
export default async function(req:Request):Promise<Response> {
 if(req.method!=="POST")return Response.json({error:"Method not allowed"},{status:405});
 const client=createClientFromRequest(req);let user;
 try{user=await client.auth.me();}catch{return Response.json({error:"Unauthorized"},{status:401});}
 const db=client.asServiceRole;const b=await req.json().catch(()=>({}));
 try{
  if(b.action==="status"||b.action==="report"){
   const boat=await db.entities.SuggestedBoat.get(String(b.suggestion_id||""));
   if(!boat || (boat.created_by_id!==user.id&&user.role!=="admin"))return Response.json({error:"Not found"},{status:404});
   const rows=await db.entities.ResearchDataset.filter({manufacturer:boat.make,model:boat.model},"-workbook_version",50);
   const issues=await db.entities.DataReviewIssue.filter({manufacturer:boat.make,model:boat.model,status:"open"},"-created_date",100);
   if(b.action==="report"){
    const description=String(b.description||"").trim().slice(0,2000);
    if(description.length<10)return Response.json({error:"Describe the suspected error in at least 10 characters."},{status:400});
    const field=Object.hasOwn(FIELDS,b.field)?b.field:"General";
    const duplicate=issues.find((i:any)=>i.suggestion_id===boat.id&&i.reporter_id===user.id&&i.field===field&&i.kind==="customer_report");
    if(duplicate)return Response.json({reported:true,id:duplicate.id});
    const issue=await db.entities.DataReviewIssue.create({manufacturer:boat.make,model:boat.model,dataset_id:rows.length===1?rows[0].id:undefined,field,status:"open",kind:"customer_report",suggestion_id:boat.id,reporter_id:user.id,description,evidence:{candidate_year:boat.year,title:boat.title}});
    return Response.json({reported:true,id:issue.id});
   }
   return Response.json({fields:customerFields(rows,Number(boat.year),issues),dataset_matches:rows.length,review_pending:issues.length>0,report_recheck_required:rows.some((r:any)=>Object.values(r.field_reviews||{}).some((v:any)=>v.checked_at>boat.created_date))});
  }
  if(user.role!=="admin")return Response.json({error:"Admin access required"},{status:403});
  if(b.action==="search"){
   const manufacturer=String(b.manufacturer||"").trim().slice(0,100);
   const rows=await db.entities.ResearchDataset.filter(manufacturer?{manufacturer}:{}, "workbook_row",100);
   return Response.json({rows,limit:100,fields:FIELDS});
  }
  if(b.action==="issues"){
   const skip=Math.max(0,Math.floor(Number(b.skip)||0));
   const issues=await db.entities.DataReviewIssue.filter({status:"open"},"-created_date",100,skip);
   return Response.json({issues,has_more:issues.length===100});
  }
  if(b.action==="check"){
   const row=await db.entities.ResearchDataset.get(String(b.dataset_id||""));
   if(!row)return Response.json({error:"Dataset record not found"},{status:404});
   return Response.json({issue:await checkDatasetOnline(db,row)});
  }
  if(b.action==="resolve"){
   const row=await db.entities.ResearchDataset.get(String(b.dataset_id||""));
   if(!row)return Response.json({error:"Dataset record required"},{status:400});
   const field=String(b.field||""); const next=normalizeResolution(field,b);
   const before=row.field_reviews?.[field]||{status:"not_checked"};
   // Audit the attempted transition first. No deletion or original-value overwrite.
   const audit=await db.entities.DataReviewAudit.create({dataset_id:row.id,issue_id:String(b.issue_id||""),field,reviewer_id:user.id,before,after:next});
   await db.entities.ResearchDataset.update(row.id,{reviewed:true,field_reviews:{...row.field_reviews,[field]:{...next,audit_id:audit.id}}});
   if(b.issue_id){
    const issue=await db.entities.DataReviewIssue.get(String(b.issue_id));
    if(issue?.dataset_id===row.id && issue.field===field)await db.entities.DataReviewIssue.update(issue.id,{status:next.status==="conflict"?"open":"resolved",resolution:{...next,audit_id:audit.id}});
   }
   if(next.status==="conflict"){
    const old=await db.entities.DataReviewIssue.filter({dataset_id:row.id,field,kind:"conflict",status:"open"},"-created_date",1);
    if(!old.length)await db.entities.DataReviewIssue.create({dataset_id:row.id,manufacturer:row.manufacturer,model:row.model,field,kind:"conflict",status:"open",description:next.notes,evidence:{workbook_value:row.raw_fields?.[field],review:next}});
   }
   return Response.json({saved:true,audit_id:audit.id});
  }
  return Response.json({error:"Unknown action"},{status:400});
 }catch(e){return Response.json({error:e instanceof Error?e.message:"Request failed"},{status:400});}
}
