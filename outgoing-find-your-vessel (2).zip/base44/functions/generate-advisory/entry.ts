// SoundHeading advisory generation — produces free preliminary feedback and paid shortlist reports.
// Free "preliminary": priorities confirmed, missing information, a limited observation (NO ranking).
// Paid reports: a structured shortlist evaluating the buyer's submitted candidates, gated by the
// purchased stage on the user's `purchased_stages` field.
//
// InvokeLLM runs as the service role (Core integration). Entity reads/writes use the user-scoped
// client so created_by_id is set correctly. The LLM is instructed to be honest: it may recommend a
// submitted boat, must not force a full shortlist when fewer qualify, and must not invent specs,
// availability, or condition.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { formatReportEmail } from "../../shared/report-email.ts";
import { ADVISOR_REASONING_GUIDE, loadManufacturerMap, ownershipCostGuidance } from "../../shared/advisor-reasoning.ts";
import { TOP_THREE_REGENERATION_LIMIT, TOP_PICK_REGENERATION_LIMIT, normalizePlan, planGrantsReport } from "../../shared/stages.ts";
import { groundReportReferences } from "../../shared/report-reference-grounding.ts";
import { paidWindowIsActive } from "../../shared/paid-access.ts";
import { loadQuestionTiers } from "../../shared/question-tiers.ts";
import { limitMarketFinalists } from "../../shared/report-model-limit.ts";

const PRELIM_SCHEMA = {
  type: "object",
  properties: {
    priorities_confirmed: { type: "array", items: { type: "string" } },
    missing_information: { type: "array", items: { type: "string" } },
    preliminary_observation: { type: "string" },
  },
  required: ["priorities_confirmed", "missing_information", "preliminary_observation"],
};

// Shared boat-match fields used across all three paid tiers.
const BOAT_MATCH_PROPS = {
  title: { type: "string" },
  link: { type: "string" },
  asking_price: { type: "string" },
  review_date: { type: "string" },
  availability: { type: "string" },
  match_strength: { type: "string" },
  key_specs: {
    type: "array",
    items: {
      type: "object",
      properties: {
        label: { type: "string" },
        value: { type: "string" },
      },
      required: ["label", "value"],
    },
  },
  fit_reasons: { type: "array", items: { type: "string" } },
  compromises: { type: "array", items: { type: "string" } },
  cost_analysis: {
    type: "object",
    properties: {
      annual_ownership_range: { type: "string" },
      breakdown: {
        type: "array",
        items: {
          type: "object",
          properties: {
            category: { type: "string" },
            estimate: { type: "string" },
          },
          required: ["category", "estimate"],
        },
      },
    },
    required: ["annual_ownership_range", "breakdown"],
  },
  evidence_gaps: { type: "array", items: { type: "string" } },
  seller_questions: { type: "array", items: { type: "string" } },
};
const BOAT_MATCH_REQUIRED = ["title", "match_strength", "fit_reasons", "compromises", "cost_analysis"];

// Top Pick (Refined Match) — a shortlist of up to 3-4 ranked matches.
const TOP_PICK_SCHEMA = {
  type: "object",
  properties: {
    buyer_priorities: { type: "array", items: { type: "string" } },
    recommendations: {
      type: "array",
      items: {
        type: "object",
        properties: BOAT_MATCH_PROPS,
        required: BOAT_MATCH_REQUIRED,
      },
    },
    overall_assessment: { type: "string" },
    remedy_note: { type: "string" },
  },
  required: ["buyer_priorities", "recommendations", "overall_assessment"],
};

// Top Three — Market Match final comparison of no more than three models.
const TOP_THREE_SCHEMA = {
  type: "object",
  properties: {
    buyer_priorities: { type: "array", items: { type: "string" } },
    recommendations: {
      type: "array",
      maxItems: 3,
      items: {
        type: "object",
        properties: BOAT_MATCH_PROPS,
        required: BOAT_MATCH_REQUIRED,
      },
    },
    comparison: { type: "string" },
    investigation_priorities: { type: "array", items: { type: "string" } },
    overall_assessment: { type: "string" },
    remedy_note: { type: "string" },
  },
  required: ["buyer_priorities", "recommendations", "overall_assessment"],
};

// Private Advisory — consultation briefing + strongest shortlist, ready for a call.
const PRIVATE_ADVISORY_SCHEMA = {
  type: "object",
  properties: {
    buyer_priorities: { type: "array", items: { type: "string" } },
    consultation_briefing: { type: "string" },
    recommendations: {
      type: "array",
      items: {
        type: "object",
        properties: BOAT_MATCH_PROPS,
        required: BOAT_MATCH_REQUIRED,
      },
    },
    discussion_topics: { type: "array", items: { type: "string" } },
    follow_up_scope: { type: "string" },
    overall_assessment: { type: "string" },
    remedy_note: { type: "string" },
  },
  required: ["buyer_priorities", "consultation_briefing", "recommendations", "overall_assessment"],
};

// Introductions — prepared discussion packages for engaging sellers (flat fee, no commission).
const INTRODUCTIONS_SCHEMA = {
  type: "object",
  properties: {
    buyer_priorities: { type: "array", items: { type: "string" } },
    introductions: {
      type: "array",
      items: {
        type: "object",
        properties: {
          title: { type: "string" },
          link: { type: "string" },
          asking_price: { type: "string" },
          seller_type: { type: "string", enum: ["broker", "dealership", "private_seller", "unclear"] },
          approach: { type: "string" },
          key_questions: { type: "array", items: { type: "string" } },
          negotiation_leverage: { type: "array", items: { type: "string" } },
          what_to_verify: { type: "array", items: { type: "string" } },
          introduction_note: { type: "string" },
        },
        required: ["title", "seller_type", "approach", "key_questions"],
      },
    },
    overall_assessment: { type: "string" },
    remedy_note: { type: "string" },
  },
  required: ["buyer_priorities", "introductions", "overall_assessment"],
};

// Survey & Inspection Review — impartial interpretation of buyer-commissioned survey/inspection PDFs.
const SURVEY_REVIEW_SCHEMA = {
  type: "object",
  properties: {
    buyer_priorities: { type: "array", items: { type: "string" } },
    documents_reviewed: { type: "array", items: { type: "string" } },
    vessel_identified: { type: "string" },
    material_findings: {
      type: "array",
      items: {
        type: "object",
        properties: {
          finding: { type: "string" },
          severity: { type: "string", enum: ["critical", "significant", "moderate", "minor"] },
          implications: { type: "string" },
        },
        required: ["finding", "severity", "implications"],
      },
    },
    cosmetic_or_minor: { type: "array", items: { type: "string" } },
    red_flags: { type: "array", items: { type: "string" } },
    renegotiation_points: { type: "array", items: { type: "string" } },
    go_no_go: { type: "string", enum: ["go", "go_with_conditions", "no_go"] },
    go_no_go_reasoning: { type: "string" },
    recommended_next_steps: { type: "array", items: { type: "string" } },
    overall_assessment: { type: "string" },
    remedy_note: { type: "string" },
  },
  required: ["documents_reviewed", "material_findings", "go_no_go", "go_no_go_reasoning", "overall_assessment"],
};

const PAID_SCHEMAS = {
  top_pick: TOP_PICK_SCHEMA,
  top_three: TOP_THREE_SCHEMA,
  private_advisory: PRIVATE_ADVISORY_SCHEMA,
  introductions: INTRODUCTIONS_SCHEMA,
  survey_review: SURVEY_REVIEW_SCHEMA,
};

function vesselClassGuidance(cls: string): string {
  if (cls === "charter") {
    return `Vessel class: CHARTER. The buyer intends to operate this boat commercially (charter it out). In addition to standard fit, weigh: commercial compliance (USCG 6-pack / inspected passenger / TUPP), charter revenue potential versus carrying costs, heavy-use durability and hours, charter-friendly brands and layouts, commercial hull insurance, charter slip/mooring availability, and management/crew costs. Flag any candidate unsuitable for charter duty and estimate charter economics where possible.`;
  }
  if (cls === "yacht") {
    return `Vessel class: YACHT. The buyer is pursuing a larger, premium vessel. In addition to standard fit, weigh: crew requirements and licensing, flag/state registration, marina depth and beam clearance, premium systems (stabilizers, generators, watermakers), higher carrying and refit costs, and professional management. Apply yacht-class survey and sea-trial scope. Vessels over 65 feet are outside the current version; future versions will expand coverage to 65 feet and over.`;
  }
  return `Vessel class: PRIVATE. The buyer is purchasing a personal/family recreational boat. Weigh standard ownership factors: storage, towing, family use, accommodations, annual ownership budget, and resale. Do not apply commercial or crew considerations unless the buyer states them.`;
}

function summarizeProfile(p: any, paidFields?: Set<string>, stripPaid?: boolean): string {
  const obj: Record<string, any> = {
    role: p.buyer_role,
    vessel_class: p.vessel_class,
    operating_area: p.operating_area,
    activities: p.activities,
    experience: p.experience_level,
    previously_owned: p.previously_owned_boats,
    passengers: p.passenger_count,
    family_use: p.family_use,
    overnight: p.overnight_requirements,
    storage: p.storage,
    storage_capacity: p.storage_capacity,
    boat_size_range: p.boat_size_range,
    draft: p.draft,
    towing: p.towing,
    purchase_budget: [p.purchase_budget_min, p.purchase_budget_max],
    annual_ownership_budget: p.annual_ownership_budget,
    timeframe: p.ownership_timeframe,
    must_haves: p.must_haves,
    preferences: p.preferences,
    unacceptable: p.unacceptable_compromises,
    priorities: p.priorities,
    activity_weights: p.activity_weights,
    ownership_horizon: p.ownership_horizon,
    preferred_manufacturers: p.preferred_manufacturers,
    open_to_project_boats: p.open_to_project_boats,
  };
  // The free preliminary report never sees admin-configured paid-only fields, so the
  // free output cannot reveal the proprietary ownership-planning insights. Paid
  // reports include every field the buyer answered.
  if (stripPaid && paidFields?.size) {
    for (const k of Object.keys(obj)) {
      if (paidFields.has(k)) delete obj[k];
    }
  }
  return JSON.stringify(obj);
}

function summarizeBoats(boats: any[]): string {
  return JSON.stringify((boats || []).map((b) => ({
    title: b.title,
    url: b.url,
    make: b.make,
    model: b.model,
    year: b.year,
    asking_price: b.asking_price,
    engines: b.engines,
    specs: b.specs,
    attractions: b.attractions,
    attraction_comment: b.attraction_comment,
    notes: b.notes,
  })));
}

function summarizeSuggestedBoats(boats: any[]): string {
  return JSON.stringify((boats || []).map((b) => ({
    title: b.title,
    make: b.make,
    model: b.model,
    year: b.year,
    asking_price: b.asking_price,
    engines: b.engines,
    specs: b.specs,
    link: b.link,
    why_suggested: b.why_suggested,
    fit_summary: b.match?.summary,
  })));
}

function summarizeDiscovery(discovery: any): string {
  if (!discovery?.found_listings?.length) return "";
  return JSON.stringify(discovery.found_listings.map((l) => ({
    title: l.title,
    link: l.link,
    source: l.source,
    asking_price: l.asking_price,
    why_similar: l.why_similar,
  })));
}

const EXCLUDED =
  "Excluded vessel types: rigid inflatable boats (RIBs), jon boats, sailboats, and vessels over 65 feet in the current version. If a submitted boat falls in an excluded category, note it and exclude it from recommendations.";

function buildPrompt(type: string, profile: any, boats: any[], discovery: any, suggested: any[], paidFields: Set<string>): string {
  const p = summarizeProfile(profile, paidFields, type === "preliminary");
  const bs = summarizeBoats(boats);
  const today = new Date().toISOString().slice(0, 10);
  const discoveryListings = summarizeDiscovery(discovery);
  const discoverySection = discoveryListings
    ? `\n\nDiscovered similar listings (from the buyer's reference-boat analysis — consider these alongside the submitted candidates):\n${discoveryListings}\n\nCommon traits identified across the buyer's reference boats: ${JSON.stringify(discovery.common_traits || [])}`
    : "";

  if (type === "preliminary") {
    return `You are SoundHeading, an impartial boat-buying advisory. A buyer has completed their profile and saved candidate boats. Produce FREE preliminary feedback ONLY — NOT a full ranking, recommendation, or cost analysis.

Output JSON with:
- priorities_confirmed: the buyer's key practical requirements and taste preferences, as a short list.
- missing_information: critical details still needed before any recommendation (e.g. minimum usable water depth, annual ownership budget, towing vehicle capacity).
- preliminary_observation: 2-3 sentences acknowledging their search direction and what their saved candidates suggest about their taste. Do not rank or recommend any boat.

${EXCLUDED}
${vesselClassGuidance(profile.vessel_class)}

Buyer profile:
${p}

Saved candidate boats:
${bs}`;
  }

  const boatMatchFields = `For each boat provide:
  - title, link, review_date (use ${today}), availability ("advertised" only for an identified listing; "confirmed" only if independently verified; "Model guidance — not a specific listing" for a model suggestion). Include asking_price only when a buyer-supplied identifiable listing supplies an actual asking price; do not manufacture a specific asking price for a model suggestion.
  - PRICE VERIFICATION: Distinguish buyer-submitted listings from MODEL guidance. A buyer-submitted listing may have a specific asking price from its identifiable source; otherwise mark price unverified. For advisor-suggested models, use a defensible broad model/generation/year price band, NOT a fabricated asking price for a boat that is not for sale. Use web results only when the actual source supports the number; never label a model price band a verified listing price. AVAILABILITY CHECK: Search results are not proof that a listing is current or available. If a recent search finds no supported offerings, mark inventory availability unknown rather than claiming none exist. Encourage the buyer to submit a specific listing for individual-boat evaluation.
- match_strength: one of "Strong match", "Conditional match", or "Marginal" based on how well it meets the buyer's criteria.
- key_specs: an array of {label, value} pairs for buyer-relevant specifications (e.g. Make, Model/Generation, Length, Engine Configuration, Fuel Capacity, Draft, Accommodations). For model guidance, only include supported model/generation facts; do not invent a specific year, engine package, hours, or trailer. For a buyer-submitted listing, use listing-specific facts only when documented. Omit unknown specs.
- fit_reasons: specific ties to the buyer's answers.
- compromises: where the boat falls short of the buyer's needs.
- cost_analysis: an object with annual_ownership_range (e.g. "$8,000–$12,000/yr") and breakdown — an array of {category, estimate} covering the major recurring costs. The breakdown MUST reflect how THIS boat is stored and the climate it operates in — see the OWNERSHIP COST REASONING section below. Do not paste a generic slip/insurance/maintenance list; tie each line to the storage type, engine service interval, and freeze climate. State assumptions.

OWNERSHIP COST REASONING (applies to every cost_analysis):
${ownershipCostGuidance(profile.storage, profile.operating_area)}
- evidence_gaps: anything unverified (engine hours, survey, condition).
- seller_questions: the questions to ask before proceeding.`;

  const commonRules = `DIAGNOSE THIS BUYER FIRST — do not reach for familiar boats. Before selecting any recommendation, identify what THIS buyer's specific activity mix, operating area, storage type, budget, and priority ranking actually demand. Then evaluate the candidate pool against that diagnosis. Two profiles that look similar often need different boats because of one differing detail. If you catch yourself defaulting to the same make you recommended for a similar profile, STOP and re-read THIS buyer's profile — the answer should differ because the profiles differ.

Tone — write like a concise human advisor, not an AI:
- Short, direct declarative sentences. No hedging ("it's worth noting", "generally speaking", "it should be noted", "it's important to keep in mind").
- No filler openers ("Based on the buyer's profile…", "When considering…"). Start with the point.
- No AI-typical phrasing: "delve into", "navigate", "landscape", "in the realm of", "robust", "seamless", "leverage", "underscore", "tapestry", "nuanced", "a myriad of".
- State facts and judgments plainly. One thought per sentence.
- Keep all structured data (specs, lists, cost lines) intact — only the prose voice changes.

Rules:
- SIZE PREFERENCE: boat_size_range is the buyer's preferred range, not automatically a hard physical limit. Strongly favor it, but a modest exception is allowed when the boat materially improves the fit and still satisfies every explicit storage, access, towing, draft, and budget constraint. Explain the reason for the exception.
- HARD FILTER: Respect the buyer's budget range. A reserve for survey findings and initial maintenance can be prudent, but do not force recommendations toward a fixed percentage of the budget. Recommend the strongest affordable fit, never a boat credibly priced above the buyer's maximum.
- HARD FILTER: If the buyer explicitly NEEDS or REQUIRES sleeping aboard, a sleeping capacity, separate sleeping quarters, or required overnight systems, every recommendation MUST satisfy that stated requirement. Overnight activity percentage by itself affects ranking but does NOT create a hard berth/cabin requirement. A console head compartment is NOT a sleeping quarter — berths are. No open center consoles for a buyer who explicitly needs to sleep aboard. NEVER describe a console head as "suitable for overnighting", "acceptable for occasional overnighting", or "ok for occasional overnight" — these phrasings are false and forbidden. A console head is a bathroom, not a berth. If a boat has no real berths, it is NOT overnight-capable — say so in gaps. For overnight-capable fishing models, consult the manufacturer map for builders whose notes mention cabin, berth, or overnight capability.
- HARD FILTER: If the buyer stated a storage_capacity limit, no recommendation may exceed it.
- BRAND VARIETY: Prefer different manufacturers across the recommendations when several makes each have a model that genuinely fits. But never suppress a well-fitting make just to avoid repetition, and never insert a weaker-fitting brand for variety. Fit to the buyer's profile is always the verdict.
- Evaluate each submitted candidate against the buyer profile. For each assessment area (storage, ownership budget, accommodations, equipment, maintenance, service eligibility) use one of four outcomes: Fits / Fits with conditions / Conflicts / More information needed.
- You MAY recommend a boat the buyer already submitted — the value is selecting and explaining, not discovering an unfamiliar listing.
- Do NOT force a full shortlist if fewer candidates genuinely qualify. Recommending fewer is better than manufacturing a weak match.
- Do NOT invent specifications, market availability, or vessel condition. Mark anything unverified as an evidence gap. Distinguish inherent model traits (hull, deck, cabin, berths) from listing-specific options (joystick, bow thruster, windlass, Seakeeper, shower, electronics); do not assume accessories are included or required for a base-model recommendation. If buyer needs an optional accessory, verify factory availability or realistic retrofit feasibility later on the specific boat.
- Do NOT promise numeric model-level MPG, GPH, cruise speed, top speed or range. Any numerical performance evidence must name the exact engine/configuration and published test/source. Missing performance data is a verification item, not proof the model is unsuitable.
- For each recommendation, use the exact title of the suggested or saved boat it came from. Leave link empty — the system attaches the correct link.
- A recommendation drawn from the advisor-suggested pool is MODEL GUIDANCE, not a specific listing: frame documented key_specs as model/generation specifications, set availability to "Model guidance — not a specific listing", omit numeric asking_price (it is a listing-specific field), and describe any substantiated broad year/generation price estimate and its uncertainty in fit_reasons or evidence_gaps instead. A recommendation drawn from a buyer-submitted boat uses that boat's documented listing data — asking price only if supplied and identifiable, and availability "advertised" unless independently confirmed.
- Include buyer_priorities (the requirements driving selection), overall_assessment, and remedy_note (what the buyer receives if the promised shortlist cannot be delivered — e.g. partial refund or continued search).
- Describe results as "the strongest matches we found within the buyer's criteria and the sources reviewed." Do not claim the best boat across the entire market.
- ${EXCLUDED}
${vesselClassGuidance(profile.vessel_class)}${discoverySection}`;

  if (type === "top_pick") {
    return `You are SoundHeading, an impartial boat-buying advisory. Produce a "top_pick" (First Mate) report for this buyer.

Select up to THREE or FOUR strongest matches from both pools: the buyer's submitted candidate boats AND the advisor-suggested boats listed below, ranked from strongest to weakest. Exactly three or four where that many genuinely qualify — never pad with a weak match, and never force four when only one or two qualify.

${commonRules}

Output JSON with: buyer_priorities, recommendations (ranked array of up to 3-4 boat matches where that many qualify), overall_assessment, remedy_note.
${boatMatchFields}

Buyer profile:
${p}

Saved candidate boats:
${bs}

Advisor-suggested boats (researched to match this profile — consider these alongside the submitted candidates when selecting):
${summarizeSuggestedBoats(suggested)}`;
  }

  if (type === "top_three") {
    return `You are SoundHeading, an impartial boat-buying advisory. Produce a "top_three" (Captain) report for this buyer.

This is a DEEPER MODEL-FIRST SEARCH than First Mate — the buyer has answered additional ownership-planning questions (ownership horizon, annual ownership budget, storage capacity, overnight needs, unacceptable compromises, priority ranking). Use those answers to run a fresh, deeper evaluation. Select AT MOST THREE strongest distinct boat MODELS from the advisor-suggested models and models represented by the buyer's submitted candidates. A buyer-submitted listing may signal interest in its underlying model, but its condition, asking price, options, engine hours, and availability are separate listing-specific facts; do not present them as inherent characteristics of every boat of that model. Rank only models that genuinely qualify. If one or two models qualify, return one or two; never pad with weaker picks or recommend four.

${commonRules}

Output JSON with: buyer_priorities, recommendations (ranked array of at most 3 distinct boat-model finalists, fewer if only fewer genuinely qualify), comparison (a paragraph explaining how the models compare and why they are ranked this way), investigation_priorities (what the buyer should investigate first), overall_assessment, remedy_note.
${boatMatchFields}

Buyer profile:
${p}

Saved candidate boats:
${bs}

Advisor-suggested boats (researched to match this profile — consider these alongside the submitted candidates when selecting):
${summarizeSuggestedBoats(suggested)}`;
  }

  if (type === "introductions") {
    return `You are SoundHeading, an impartial boat-buying advisory. Produce an "introductions" report for this buyer.

For each submitted candidate boat, prepare a discussion package that helps the buyer engage the seller — a broker, dealership, or private seller — confidently and on equal footing. SoundHeading takes no commission on any sale; this is impartial preparation only.

For each boat provide:
- title, link, asking_price.
- seller_type: one of "broker", "dealership", "private_seller", or "unclear" (infer from the listing; never invent).
- approach: how the buyer should initiate and frame contact with this seller type.
- key_questions: the specific questions to ask for THIS boat (e.g. engine hours, survey, liens, title, recent work, reason for selling).
- negotiation_leverage: points that strengthen the buyer's position (evidence gaps, condition unknowns, time on market, comparable listings) — state only what is supported by the listing data.
- what_to_verify: what must be confirmed before committing (title/registration, liens, warranties, sea trial, survey).
- introduction_note: a short, neutral first-contact message the buyer can adapt.

Rules:
- Prepare an introduction for every submitted candidate; do not rank or recommend.
- Do NOT invent specifications, seller identity, or vessel condition. Mark anything unverified.
- ${EXCLUDED}
- ${vesselClassGuidance(profile.vessel_class)}${discoverySection}

Output JSON with: buyer_priorities, introductions (one entry per submitted candidate), overall_assessment, remedy_note (what the buyer receives if an introduction cannot be prepared — e.g. partial refund or continued support).

Buyer profile:
${p}

Saved candidate boats:
${bs}`;
  }

  if (type === "survey_review") {
    return `You are SoundHeading, an impartial boat-buying advisory. The buyer commissioned a marine survey and/or mechanic inspection for a boat they are considering and uploaded the report(s) for your review. Produce a "survey_review" — an impartial interpretation of those findings.

The attached documents are the survey and/or mechanic inspection reports. Review them carefully. This is impartial advisory only: SoundHeading takes no commission and did not perform the survey or inspection — the buyer commissioned those directly. Your role is to interpret what the findings mean for THIS buyer.

Output JSON with:
- buyer_priorities: the buyer's key requirements (from their profile) that the survey findings bear on.
- documents_reviewed: the names/types of documents you reviewed.
- vessel_identified: the vessel the survey pertains to (make/model/year/HIN if stated in the report); otherwise "Not stated in documents".
- material_findings: each finding that affects value, safety, or usability, with severity (one of "critical", "significant", "moderate", "minor") and implications (what it means for the buyer — cost to remedy, risk, effect on use).
- cosmetic_or_minor: cosmetic or minor items not affecting value, safety, or usability.
- red_flags: any finding that warrants walking away or demanding remedy before proceeding.
- renegotiation_points: where the findings justify a price reduction or repair demand, with the reasoning.
- go_no_go: one of "go", "go_with_conditions", "no_go".
- go_no_go_reasoning: 2-4 sentences explaining the call.
- recommended_next_steps: what the buyer should do next (e.g. obtain repair quotes, request a sea trial, re-negotiate, walk away).
- overall_assessment.
- remedy_note: what the buyer receives if a review cannot be completed (e.g. documents illegible or not a survey/inspection — partial refund or request resubmission).

Rules:
- Base every finding on what is IN the uploaded documents. Do NOT invent findings, specs, or conditions not present in the reports.
- If a document is not a marine survey or mechanic inspection, say so in the remedy_note and do not fabricate a review.
- ${vesselClassGuidance(profile.vessel_class)}

Buyer profile (context for what matters to this buyer):
${p}`;
  }

  // private_advisory
  return `You are SoundHeading, an impartial boat-buying advisory. Produce a "private_advisory" report for this buyer.

Prepare a private advisory package: a consultation briefing plus the strongest shortlist from both pools — the buyer's submitted candidates AND the advisor-suggested boats listed below — ready for a 45-minute professional call.

${commonRules}

Output JSON with: buyer_priorities, consultation_briefing (a summary of the buyer's situation and key decision factors, ready to open the call), recommendations (the strongest shortlist from the submitted candidates and advisor-suggested boats), discussion_topics (the key topics to cover in the 45-minute consultation), follow_up_scope (what the one included follow-up covers), overall_assessment, remedy_note.
${boatMatchFields}

Buyer profile:
${p}

Saved candidate boats:
${bs}

Advisor-suggested boats (researched to match this profile — consider these alongside the submitted candidates when selecting):
${summarizeSuggestedBoats(suggested)}`;
}

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

    const base44 = createClientFromRequest(req);
    let user;
    try {
      user = await base44.auth.me();
    } catch (_) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const type = String(body.type ?? "preliminary");
    const VALID = ["preliminary", "top_pick", "top_three", "private_advisory", "introductions", "survey_review"];
    if (!VALID.includes(type)) return Response.json({ error: "Invalid type" }, { status: 400 });
    // survey_review ingests buyer-uploaded survey/inspection documents via file_urls (signed URLs).
    const fileUrls = Array.isArray(body.file_urls)
      ? body.file_urls.filter((u) => typeof u === "string" && u.length > 0)
      : typeof body.file_urls === "string" && body.file_urls
        ? [body.file_urls]
        : [];

    const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: user.id }, "-created_date", 1);
    const profile = profiles?.[0];
    if (!profile) return Response.json({ error: "Complete your buyer profile first" }, { status: 400 });
    const boats = await base44.entities.SavedBoat.filter({ created_by_id: user.id }, "-created_date", 50);
    const discoveries = await base44.entities.Discovery.filter({ created_by_id: user.id, status: "complete" }, "-created_date", 1);
    const discovery = discoveries?.[0] || null;
    const suggested = await base44.entities.SuggestedBoat.filter({ created_by_id: user.id }, "rank", 50);

    const PAID = ["top_pick", "top_three", "private_advisory", "introductions", "survey_review"];

    // Paid shortlist reports (Single Deep Dive, Model Shortlist, Private Advisory) read the
    // buyer's collected research links and free-text notes. Free preliminary feedback and the
    // other paid tiers (introductions, survey_review) do not — those stay anchored to the
    // profile, candidates, and (for survey_review) the uploaded documents.
    let researchContext = "";
    if (["top_pick", "top_three", "private_advisory"].includes(type)) {
      try {
        const rns = await base44.entities.ResearchNote.filter({ created_by_id: user.id }, "-created_date", 100);
        const notesText = (profile.research_notes || "").trim();
        if ((rns && rns.length) || notesText) {
          const links = (rns || []).map((n) => `- ${n.label ? n.label + " — " : ""}${n.url}`).join("\n");
          researchContext = `\n\nBuyer-collected research context (links and notes the buyer gathered during their search — weigh these as evidence the buyer found relevant; verify any specific claim before relying on it):\nLinks:\n${links || "(none)"}\nFree-text notes:\n${notesText || "(none)"}`;
        }
      } catch (e) {
        console.error("generate-advisory: failed to load research notes", e);
      }
    }
    const regenLimit = type === "top_three" ? TOP_THREE_REGENERATION_LIMIT
      : type === "top_pick" ? TOP_PICK_REGENERATION_LIMIT
      : null;
    const regenField = type === "top_three" ? "top_three_regenerations_used"
      : type === "top_pick" ? "top_pick_regenerations_used"
      : null;
    let existingPaidReport: any = null;
    // Check allowances before generation; consume them only after a usable
    // report has actually been persisted. A failed LLM call is not a regeneration.
    let consumePaidRegeneration = false;
    let countContradictionRerun = false;
    let previousRegenerations = regenField ? Number((user as any)[regenField]) || 0 : 0;
    let previousContradictionReruns = 0;
    if (PAID.includes(type)) {
      const purchased = Array.isArray(user.purchased_stages) ? user.purchased_stages : [];
      const plan: string = normalizePlan((user as any).plan || "free");
      // Refined Match grants the top_pick report; Market Match grants the top_three report.
      // Legacy purchasers keep access via purchased_stages. Other paid types remain legacy-gated.
      const planGrants = planGrantsReport(plan, type);
      // Never trust a caller-supplied bypass flag: paid entitlements must be verified server-side.
      // Admin QA uses the separate isolated test harness rather than bypassing live purchases.
      if (!purchased.includes(type) && !planGrants) return Response.json({ error: "Stage not purchased" }, { status: 403 });
      // Paid reports are generated once and stored; return the existing one if present.
      const existing = await base44.entities.Report.filter({ created_by_id: user.id, type }, "-created_date", 1);
      existingPaidReport = existing?.[0] || null;
      if (!paidWindowIsActive((user as any).plan_expires)) {
        if (existingPaidReport && !body.regenerate) return Response.json({ report: existingPaidReport });
        return Response.json({ error: "Paid access expired" }, { status: 403 });
      }

      // Top Pick and Top Three: the buyer may edit their profile and regenerate up to the stage's
      // limit. The first generation does not consume the allowance.
      // Contradiction-driven re-runs are free up to 3 times (tracked via contradiction_rerun_count
      // on the profile), then normal regeneration consumption applies. User-initiated changes
      // (no contradiction flag) always consume a regeneration.
      if (regenLimit && regenField && body.regenerate) {
        const hadContradiction = !!profile.contradiction_flag?.flagged;
        previousContradictionReruns = Number(profile.contradiction_rerun_count) || 0;
        previousRegenerations = Number((user as any)[regenField]) || 0;
        const isFreeContradictionRerun = hadContradiction && previousContradictionReruns < 3;
        if (!isFreeContradictionRerun && previousRegenerations >= regenLimit) {
          return Response.json({
            error: `You've used all ${regenLimit} regenerations for this report. Edit your profile, then contact us if you need further changes.`,
            regenerations_used: previousRegenerations,
            regenerations_limit: regenLimit,
          }, { status: 403 });
        }
        consumePaidRegeneration = !isFreeContradictionRerun;
        countContradictionRerun = hadContradiction;
        // Generate first. Counter writes occur only after successful persistence.
      } else if (existingPaidReport) {
        return Response.json({ report: existingPaidReport });
      }
    }
    if (type === "survey_review" && fileUrls.length === 0) {
      return Response.json({ error: "Upload at least one survey or inspection report" }, { status: 400 });
    }

    const { brief: manufacturerBrief } = await loadManufacturerMap(base44, profile);
    // Load the question tiers. The free preliminary report strips ALL non-free fields
    // (Find My Boat + Confidence); paid reports include every field the buyer answered.
    let paidFields: Set<string> = new Set();
    try {
      const { matchPlus, refinedMatch, marketMatch } = await loadQuestionTiers(base44);
      paidFields = new Set([...matchPlus, ...refinedMatch, ...marketMatch]);
    } catch (_) { /* entity may not exist yet */ }
    const advisorPreamble =
      ADVISOR_REASONING_GUIDE +
      (manufacturerBrief
        ? `\n\nManufacturer reference (SoundHeading's curated market map — use as context; verify against the listing, do not treat as exhaustive):\n${manufacturerBrief}\n`
        : "");
    const prompt = advisorPreamble + "\n" + buildPrompt(type, profile, boats || [], discovery, suggested || [], paidFields) + researchContext;
    const schema = type === "preliminary" ? PRELIM_SCHEMA : PAID_SCHEMAS[type];
    // Paid reports (top_pick, top_three) may use web search as evidence; a
    // search result does not establish a live listing, model-specific price,
    // or that any submitted candidate is available for purchase.
    const useWebSearch = type === "top_pick" || type === "top_three";
    const content = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: schema,
      ...(useWebSearch ? { add_context_from_internet: true } : {}),
      ...(fileUrls.length > 0 ? { file_urls: fileUrls } : {}),
    });
    // A malformed or non-compliant model response must never turn the Market
    // Match promise of up to three finalists into an accidental Top Four.
    // This is a defensive ceiling in addition to the JSON schema maxItems.
    if (type === "top_three") {
      content.recommendations = limitMarketFinalists(content?.recommendations);
    }

    // Never attach a buyer's saved listing URL to a merely similar model or variant.
    // Only unique exact titles with safe buyer-supplied URLs may reference an
    // individual listing; all other shortlist entries receive neutral model search
    // links and no invented asking price. Market Match finalists are always models.
    // Seller introductions fail closed when individual links cannot be identified.
    if (PAID.includes(type)) {
      const linkCheck = groundReportReferences(content, type, boats || [], suggested || []);
      if (!linkCheck.ok) {
        return Response.json({ error: `Report not released: ${linkCheck.reason}` }, { status: 500 });
      }
    }

    let report;
    if (type === "preliminary") {
      // Preliminary feedback reflects the latest profile/boats, so refresh it in place.
      const existing = await base44.entities.Report.filter({ created_by_id: user.id, type: "preliminary" }, "-created_date", 1);
      if (existing?.[0]) {
        report = await base44.entities.Report.update(existing[0].id, { content, status: "generated" });
      } else {
        report = await base44.entities.Report.create({ type, content, status: "generated" });
      }
    } else if ((type === "top_three" || type === "top_pick") && body.regenerate && existingPaidReport) {
      // Regeneration updates the existing report in place so feedback stays anchored to it.
      report = await base44.entities.Report.update(existingPaidReport.id, { content, status: "generated" });
    } else {
      report = await base44.entities.Report.create({ type, content, status: "generated" });
    }

    // A failed LLM call, invalid output, or failed persistence never consumes a
    // regeneration or a contradiction rerun. Counter updates happen after save.
    // If a counter update fails, the generated report still exists, but the
    // response must not pretend an allowance was successfully debited.
    let regenerationDebited = false;
    if (body.regenerate && regenLimit && regenField && PAID.includes(type)) {
      if (consumePaidRegeneration) {
        try {
          await base44.asServiceRole.entities.User.update(user.id, { [regenField]: previousRegenerations + 1 } as any);
          regenerationDebited = true;
        } catch (e) {
          console.error("generate-advisory: failed to debit successful regeneration", e);
        }
      }
      if (countContradictionRerun) {
        try {
          await base44.asServiceRole.entities.BuyerProfile.update(profile.id, {
            contradiction_rerun_count: previousContradictionReruns + 1,
          });
        } catch (e) {
          console.error("generate-advisory: failed to count successful contradiction rerun", e);
        }
      }
    }

    // Email the completed report to the buyer for offline review. The report is already
    // persisted above, so a failed email must not fail the response — log and continue.
    if (user.email) {
      try {
        const { subject, html } = formatReportEmail(type, content);
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: user.email,
          subject,
          html,
        });
      } catch (emailErr) {
        console.error("generate-advisory: failed to email report", emailErr);
      }
    }

    const regenInfo = regenLimit && regenField
      ? {
        regenerations_used: previousRegenerations + (regenerationDebited ? 1 : 0),
        regenerations_limit: regenLimit,
      }
      : {};
    return Response.json({ report, ...regenInfo });
  } catch (err) {
    console.error("generate-advisory error", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}