// Admin-only connectivity check for SoundHeading research providers.
// Never returns or logs secret values.
import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";

type Check = { ok: boolean; status?: number; detail: string };

async function checkAnthropic(): Promise<Check> {
  const key = Deno.env.get("ANTHROPIC_API_KEY")?.trim();
  if (!key) return { ok: false, detail: "ANTHROPIC_API_KEY is not available to this backend function" };
  try {
    // Listing models verifies authentication without generating tokens or
    // coupling connectivity to a particular Claude model's availability.
    const res = await fetch("https://api.anthropic.com/v1/models?limit=1", {
      headers: {
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
      },
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) {
      const detail = res.status === 401 ? "Anthropic rejected authentication (401). Verify the active API key."
        : res.status === 403 ? "Anthropic denied access (403). Check workspace permissions."
        : res.status === 429 ? "Anthropic rate or quota limit (429). Retry later or check account limits."
        : "Anthropic model-list request failed. Check endpoint availability and account access.";
      return { ok: false, status: res.status, detail };
    }
    return { ok: true, status: res.status, detail: "Authenticated model-list request succeeded; generation not tested." };
  } catch (e) {
    return { ok: false, detail: "Provider request failed before receiving a successful response." };
  }
}

async function checkGroq(): Promise<Check> {
  // Trim accidental whitespace introduced while pasting the secret. Never
  // expose the key (or any part of it) in diagnostics or logs.
  const key = Deno.env.get("GROQ_API_KEY")?.trim();
  if (!key) return { ok: false, detail: "GROQ_API_KEY is not available to this backend function" };
  try {
    const res = await fetch("https://api.groq.com/openai/v1/models", {
      headers: { Authorization: `Bearer ${key}` },
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) {
      const detail = res.status === 401
        ? "Groq rejected authentication (401). Base44 can read the secret, but Groq did not accept it. Verify the secret belongs to an active Groq API key; do not regenerate keys repeatedly."
        : res.status === 403
          ? "Groq authenticated the request but denied access (403). Check organization/project permissions."
          : res.status === 429
            ? "Groq rate or quota limit (429). Authentication may be valid; retry later or check account limits."
            : "Groq rejected the request. Check account access, endpoint availability, and quota.";
      return { ok: false, status: res.status, detail };
    }
    return { ok: true, status: res.status, detail: "Authenticated request succeeded" };
  } catch (e) {
    return { ok: false, detail: "Provider request failed before receiving a successful response." };
  }
}

async function checkXai(): Promise<Check> {
  const key = Deno.env.get("XAI_API_KEY")?.trim();
  if (!key) return { ok: false, detail: "XAI_API_KEY is not available to this backend function" };
  try {
    const res = await fetch("https://api.x.ai/v1/models", {
      headers: { Authorization: `Bearer ${key}` },
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) return {
      ok: false, status: res.status,
      detail: res.status === 401 ? "xAI rejected authentication. Verify XAI_API_KEY belongs to xAI, not Groq."
        : res.status === 403 ? "xAI denied access. Check team and key permissions."
        : res.status === 429 ? "xAI rate or quota limit. Check account limits."
        : "xAI rejected the request. Check account access and endpoint availability.",
    };
    return { ok: true, status: res.status, detail: "xAI authenticated model-list request succeeded. Generation and research integration are not yet verified." };
  } catch (_) {
    return { ok: false, detail: "xAI request failed or timed out before receiving a successful response." };
  }
}

async function checkTavily(): Promise<Check> {
  const key = Deno.env.get("TAVILY_API_KEY")?.trim();
  if (!key) return { ok: false, detail: "TAVILY_API_KEY is not available to this backend function" };
  try {
    const res = await fetch("https://api.tavily.com/search", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        api_key: key,
        query: "SoundHeading marine research connectivity test",
        max_results: 1,
        search_depth: "basic",
      }),
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) {
      const detail = res.status === 401 ? "Tavily rejected authentication (401). Verify the active API key."
        : res.status === 403 ? "Tavily denied access (403). Check workspace permissions."
        : res.status === 429 ? "Tavily rate or quota limit (429). Retry later or check account limits."
        : "Tavily search request failed. Check account access and quota.";
      return { ok: false, status: res.status, detail };
    }
    return { ok: true, status: res.status, detail: "Authenticated search succeeded (one small search request)." };
  } catch (e) {
    return { ok: false, detail: "Provider request failed before receiving a successful response." };
  }
}

export default async function (req: Request): Promise<Response> {
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

  const base44 = createClientFromRequest(req);
  let user: any;
  try {
    user = await base44.auth.me();
  } catch (_) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (user.role !== "admin") return Response.json({ error: "Admin access required" }, { status: 403 });

  const [anthropic, groq, tavily, xai] = await Promise.all([
    checkAnthropic(),
    checkGroq(),
    checkTavily(),
    checkXai(),
  ]);

  return Response.json({
    checked_at: new Date().toISOString(),
    all_connected: anthropic.ok && groq.ok && tavily.ok && xai.ok,
    // Groq is an optional acceleration worker. Research can proceed with
    // Tavily retrieval + Claude extraction even if Groq authentication fails.
    research_ready: anthropic.ok && tavily.ok,
    optional_provider_issues: [...(!groq.ok ? ["groq"] : []), ...(!xai.ok ? ["xai"] : [])],
    providers: { anthropic, groq, tavily, xai },
  });
}
