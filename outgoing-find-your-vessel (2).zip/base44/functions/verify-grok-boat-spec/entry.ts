import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
export default async function(req:Request):Promise<Response>{
 if(req.method!=="POST")return Response.json({error:"Method not allowed"},{status:405});
 const db=createClientFromRequest(req);
 let user:any;try{user=await db.auth.me()}catch{return Response.json({error:"Unauthorized"},{status:401})}
 if(user.role!=="admin")return Response.json({error:"Admin only"},{status:403});
 const key=Deno.env.get("XAI_API_KEY")?.trim();
 if(!key)return Response.json({error:"XAI_API_KEY missing"},{status:503});
 const label="grok-spec-pilot-2026-10-20-parker-2520";
 const prior=await db.asServiceRole.entities.ResearchJob.filter({job_type:"grok_spec_verification",batch_label:label});
 if(prior.length)return Response.json({already_recorded:true,job:prior[0]});
 const prompt="Independently review the 2025 Parker 2520 XLD boat model. Return JSON with model, model_year, fields (LOA, beam, dry_weight, hull_draft), each with value, unit, measurement_definition, source_url, source_title, source_year, and evidence_quote of at most 20 words. Do not invent sources or values. If you cannot retrieve and verify the actual manufacturer documentation, set verified=false and fields to null and explain. Do not treat hull draft as loaded operating draft. Do not claim web access if you lack it. Include contradictions and limitations. This is a proposed review, not approved catalog data.";
 const job=await db.asServiceRole.entities.ResearchJob.create({job_type:"grok_spec_verification",batch_label:label,provider:"xai",status:"running",calls:0,started_at:new Date().toISOString(),last_message:"Admin-only bounded Grok source-evidence pilot; no catalog writes."});
 try{
 const models=await fetch("https://api.x.ai/v1/models",{headers:{Authorization:"Bearer "+key},signal:AbortSignal.timeout(15000)});
 if(!models.ok)throw Error("Model list HTTP "+models.status);
 const ids=((await models.json()).data||[]).map((x:any)=>x.id);
 const model=["grok-4.3","grok-4"].find(x=>ids.includes(x));
 if(!model)throw Error("Approved Grok model unavailable");
 await db.asServiceRole.entities.ResearchJob.update(job.id,{calls:1});
 const res=await fetch("https://api.x.ai/v1/chat/completions",{method:"POST",headers:{Authorization:"Bearer "+key,"Content-Type":"application/json"},body:JSON.stringify({model,max_tokens:1100,messages:[{role:"user",content:prompt}]}),signal:AbortSignal.timeout(75000)});
 if(!res.ok)throw Error("Generation HTTP "+res.status);
 const data=await res.json();const output=data.choices?.[0]?.message?.content;
 if(typeof output!=="string"||!output.trim())throw Error("No usable output");
 const saved=await db.asServiceRole.entities.ResearchJob.update(job.id,{status:"needs_review",completed_at:new Date().toISOString(),calls:1,input_tokens:data.usage?.prompt_tokens||0,output_tokens:data.usage?.completion_tokens||0,last_message:JSON.stringify({model,output,warning:"UNVERIFIED PROPOSAL. Source URLs and quotes must be independently retrieved before approval."}).slice(0,24000)});
 return Response.json({job:saved,verified_generation:true,source_verified:false,catalog_updated:false});
 }catch(e){const msg=String(e instanceof Error?e.message:e);await db.asServiceRole.entities.ResearchJob.update(job.id,{status:"failed",completed_at:new Date().toISOString(),error_message:msg,last_message:msg});return Response.json({error:msg,job_id:job.id},{status:502})}
}