// Two bounded, admin-triggered provider proof jobs. Provider keys are used only
// for their normal provider authentication. No keys or customer data enter prompts.
// Standard price references checked 2026-10-13: Claude Sonnet 4.6 $3/$15 MTok;
// xAI Grok 4.3 $1.25/$2.50 MTok. Fixed prompts + max1600 yield <$0.05 each.
// This one-time pilot expires after 2026-10-14 UTC; no automatic retries.
import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";

const briefs: Record<string, string> = {
  claude: `Review SoundHeading's paid-entitlement design. This is a code-informed review, not an exploit test. Do not claim any runtime bypass is proven. Return up to five prioritized findings, each with evidence, risk, smallest fix, and one test.
Observed current User schema defines purchased_stages, activation_credit, plan, plan_expires, updates_used, updates_limit, paid_pool_generated, listing_evals_limit, listing_evals_used. No explicit entity or field-level RLS is present in that schema. Its plan description says payments webhook sets the plan.
Observed create-checkout code: authenticates optionally via base44.auth.me(); accepts productId; resolves server-owned stage using resolveStage(productId); checks stage.requires_plan against normalizePlan(appUser.plan); calculates activation credit directly from Number(appUser.activation_credit); resolves advisor credit using server helper; caps total discount to preserve a $0.50 charge; sends one cart item to Wix; persists Base44Purchase through service role with checkoutSessionId, status pending, user ID or null, email or null, productId, amount, currency, creditApplied and advisorCreditProfileId.
The function explicitly requires server-owned return URL via x-base44-app-url header or WIX_CHECKOUT_APP_URL, not request Origin. Base44Purchase comments say client writes are blocked by RLS. Webhook behavior and actual platform defaults have not been examined in this review. We need free users unable to grant themselves paid access or credits, fulfilled purchases tied to the right customer, and no duplicate credit redemption.
Produce an actionable verification and repair plan. Clearly distinguish established code facts, conditional platform risks, and missing evidence.`,
  grok: `You are a creative reviewer for SoundHeading, a practical boat-selection service. Provide three clearly distinct creative-direction briefs for possible future MATCH supporting imagery plus a short QA checklist. This is a text-only assignment; do not claim to have generated or viewed any image.
The approved existing homepage should be preserved. A separately approved Match dashboard image is already installed; do not replace or redesign it. Future alternatives should complement a calm nautical identity and make clear that MATCH helps a buyer compare boats suited to their needs.
Each brief must specify scene, composition, mobile crop strategy, accessible text/contrast treatment, and a realistic-vessel constraint. Avoid invented boats presented as real manufacturer models, impossible hull geometry, unsafe seamanship, legible fabricated gauges, or unsupported performance/safety claims. A generic illustrative boat must be labeled as illustrative; actual named models require authentic reference photos and technical review.
Recommend one modest next experiment, with explicit criteria for deciding whether it helps the customer. Do not claim Grok is better than another image system without a measured comparison. Stay under 650 words.`
};
const batch = "soundheading-provider-proof-2026-10-13";
function diagnostic(provider: string, status: number) {
  return provider + " request returned HTTP " + status + (status === 401 ? "; authentication rejected." : status === 402 ? "; account credit/payment required." : status === 403 ? "; account/model access denied." : status === 429 ? "; quota or rate limit." : "; request did not succeed.");
}
export default async function(req: Request): Promise<Response> {
  if (req.method !== "POST") return Response.json({error:"Method not allowed"},{status:405});
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return Response.json({error:"Unauthorized"},{status:401}); }
  if (user.role !== "admin") return Response.json({error:"Admin access required"},{status:403});
  const body = await req.json().catch(()=>({}));
  const task = String(body.task || "");
  if (!Object.hasOwn(briefs, task)) return Response.json({error:"Choose claude or grok"},{status:400});
  if (new Date() >= new Date("2026-10-15T00:00:00Z")) return Response.json({error:"This one-time pilot approval window has ended."},{status:410});
  if (new TextEncoder().encode(briefs[task]).length > 6000) return Response.json({error:"Prompt exceeds pilot cost guard"},{status:400});
  const jobType = "provider_proof_" + task;
  const prior = await base44.entities.ResearchJob.filter({job_type:jobType,batch_label:batch});
  if (prior.length) return Response.json({already_recorded:true,job:prior[0]});
  const provider = task === "claude" ? "Anthropic Claude" : "xAI Grok";
  const key = Deno.env.get(task === "claude" ? "ANTHROPIC_API_KEY" : "XAI_API_KEY")?.trim();
  if (!key) return Response.json({error:provider+" API secret unavailable in backend"},{status:503});
  const job = await base44.entities.ResearchJob.create({
    job_type:jobType, batch_label:batch, provider:task === "claude" ? "anthropic" : "xai",
    status:"running", started_at:new Date().toISOString(), calls:0,
    last_message:provider+" bounded text job started; no catalog or payment changes."
  });
  let attempted = false;
  try {
    const headers: Record<string,string> = task === "claude"
      ? {"x-api-key":key,"anthropic-version":"2023-06-01","Content-Type":"application/json"}
      : {Authorization:"Bearer "+key,"Content-Type":"application/json"};
    const root = task === "claude" ? "https://api.anthropic.com/v1" : "https://api.x.ai/v1";
    const modelsRes = await fetch(root+"/models", {headers, signal:AbortSignal.timeout(20000)});
    if (!modelsRes.ok) throw new Error(diagnostic(provider,modelsRes.status));
    const models = (await modelsRes.json()).data?.map((m:any)=>String(m.id)) || [];
    const preference = task === "claude" ? ["claude-sonnet-4-6"] : ["grok-4.3"];
    const model = preference.find(m=>models.includes(m));
    if (!model) throw new Error(provider+" authenticated, but none of the bounded pilot models is available. No generation attempted.");
    attempted = true;
    await base44.entities.ResearchJob.update(job.id,{calls:1,last_message:provider+" generation requested using "+model+"; maximum 1600 output tokens."});
    const payload = {model,max_tokens:1600,...(task === "grok" ? {reasoning_effort:"none"} : {}),messages:[{role:"user",content:briefs[task]}]};
    const response = await fetch(root+(task === "claude" ? "/messages" : "/chat/completions"),{
      method:"POST",headers,body:JSON.stringify(payload),signal:AbortSignal.timeout(90000)
    });
    if (!response.ok) throw new Error(diagnostic(provider,response.status));
    const result = await response.json();
    const output = task === "claude" ? result.content?.filter((c:any)=>c.type==="text").map((c:any)=>c.text).join("\n") : result.choices?.[0]?.message?.content;
    if (typeof output !== "string" || !output.trim()) throw new Error(provider+" returned no usable text; generation may have consumed tokens.");
    const record = await base44.entities.ResearchJob.update(job.id,{
      status:"needs_review",completed_at:new Date().toISOString(),calls:1,
      estimated_cost_usd: (Number(result.usage?.input_tokens ?? result.usage?.prompt_tokens ?? 0) * (task === "claude" ? 3 : 1.25) + Number(result.usage?.output_tokens ?? result.usage?.completion_tokens ?? 0) * (task === "claude" ? 15 : 2.5)) / 1000000,
      input_tokens:Number(result.usage?.input_tokens ?? result.usage?.prompt_tokens ?? 0),
      output_tokens:Number(result.usage?.output_tokens ?? result.usage?.completion_tokens ?? 0),
      last_message:JSON.stringify({provider,model,response_id:result.id || null,generated_at:new Date().toISOString(),finish_reason:result.stop_reason ?? result.choices?.[0]?.finish_reason ?? null,output}).slice(0,24000)
    });
    return Response.json({job:record,verified_generation:true});
  } catch(e) {
    const error = e instanceof Error && (e.message.startsWith(provider)) ? e.message : provider+" job did not complete. Inspect function status before retrying; a timed-out generation may still be billable.";
    await base44.entities.ResearchJob.update(job.id,{status:"failed",completed_at:new Date().toISOString(),calls:attempted?1:0,error_message:error,last_message:error});
    return Response.json({error,job_id:job.id},{status:502});
  }
}
