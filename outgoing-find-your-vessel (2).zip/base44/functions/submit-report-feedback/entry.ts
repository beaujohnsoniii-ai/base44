// SoundHeading report feedback — a buyer flags a paid report that doesn't fit their profile or
// answers. We record the feedback and flag it for PERSONAL admin review. No credit or refund is
// granted automatically — any goodwill credit or refund is issued manually by an advisor only after
// they have personally reviewed the case. Both the buyer and the advisor are notified.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { secrets } from "base44:runtime";
import { resolveStage } from "../../shared/stages.ts";

const REASON_LABELS = {
  doesnt_fit_profile: "Doesn't fit my profile",
  missed_my_answers: "Missed how I answered the questions",
  inaccurate_specs: "Inaccurate specifications",
  missing_info: "Missing information I provided",
  other: "Other",
};

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

    const base44 = createClientFromRequest(req);
    let user;
    try {
      user = await base44.auth.me();
    } catch (_) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const reportId = String(body.report_id ?? "");
    const reason = String(body.reason ?? "");
    const details = String(body.details ?? "").slice(0, 2000);
    if (!reportId || !reason) return Response.json({ error: "Report and reason are required" }, { status: 400 });
    if (!REASON_LABELS[reason]) return Response.json({ error: "Invalid reason" }, { status: 400 });

    // Validate the report belongs to this user and is a paid type.
    let report;
    try {
      report = await base44.entities.Report.get(reportId);
    } catch (_) {
      return Response.json({ error: "Report not found" }, { status: 404 });
    }
    if (report.created_by_id !== user.id) return Response.json({ error: "Report not found" }, { status: 404 });
    if (report.type === "preliminary") return Response.json({ error: "Feedback is only available for paid reports" }, { status: 400 });

    const stage = resolveStage(report.type);
    if (!stage) return Response.json({ error: "Feedback is only available for paid reports" }, { status: 400 });

    // One feedback entry per report.
    const existing = await base44.asServiceRole.entities.ReportFeedback.filter({ report_id: reportId }, "-created_date", 1);
    if (existing?.[0]) return Response.json({ error: "Feedback already submitted for this report", feedback: existing[0] }, { status: 409 });

    // No credit or refund is granted automatically. credit_owed stays 0 until an advisor personally
    // reviews the case and decides a goodwill credit or refund is warranted.
    const feedback = await base44.asServiceRole.entities.ReportFeedback.create({
      report_id: reportId,
      report_type: report.type,
      reason,
      details,
      status: "pending",
      credit_owed: 0,
      credit_issued: false,
    });

    // Email the buyer a confirmation. Non-critical: log and continue on failure.
    if (user.email) {
      try {
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: user.email,
          subject: `SoundHeading — feedback received on your ${stage.name}`,
          html: `<p>We received your feedback on your ${stage.name} report.</p><p><strong>Reason:</strong> ${REASON_LABELS[reason]}</p>${details ? `<p><strong>Details:</strong> ${details}</p>` : ""}<p>Your report is now flagged for personal review by a SoundHeading advisor. No credit or refund is issued automatically — if one is warranted, an advisor will follow up with you directly after reviewing your case.</p>`,
        });
      } catch (e) {
        console.error("submit-report-feedback: buyer email failed", e);
      }
    }

    // Notify the advisor if configured.
    const advisorEmail = secrets.get("ADVISOR_EMAIL");
    if (advisorEmail) {
      try {
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: advisorEmail,
          subject: `SoundHeading — report feedback needs personal review (${stage.name})`,
          html: `<p>Feedback submitted by ${user.email || "(no email on file)"} on report <code>${reportId}</code> (${stage.name}).</p><p><strong>Reason:</strong> ${REASON_LABELS[reason]}</p>${details ? `<p><strong>Details:</strong> ${details}</p>` : ""}<p>This case requires your personal review before any credit or refund is considered. Review the report, follow up with the buyer, and issue a credit/refund only if warranted — set <code>credit_owed</code> and <code>credit_issued</code> on the feedback record if so.</p>`,
        });
      } catch (e) {
        console.error("submit-report-feedback: advisor email failed", e);
      }
    }

    return Response.json({ feedback });
  } catch (err) {
    console.error("submit-report-feedback error", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}