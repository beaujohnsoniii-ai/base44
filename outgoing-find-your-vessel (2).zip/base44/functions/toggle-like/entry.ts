// SoundHeading — durable Like toggle.
//
// Updates both the SuggestedBoat.liked boolean (for instant UI feedback) AND the
// BuyerProfile.liked_models durable history (the source of truth that survives
// SuggestedBoat regeneration). Deduplicates by normalized make+model identity,
// preserving the original liked_at_tier when the same active model appears again.
// Unliking removes the entry; re-liking after unliking adds it back with the
// current tier.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { profileInputFingerprint } from "../../shared/profile-input-fingerprint.mjs";
import { normalizePlan } from "../../shared/stages.ts";

const norm = (s: any) => String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");

function likeKey(make: string, model: string, title: string): string {
  const mk = norm(make);
  const md = norm(model);
  if (mk || md) return `${mk}|${md}`;
  return `title:${norm(title)}`;
}

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

    const base44 = createClientFromRequest(req);
    let user;
    try {
      user = await base44.auth.me();
    } catch (_) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const { suggestionId, liked } = (body && typeof body === "object" && !Array.isArray(body) ? body : {}) as any;
    if (typeof liked !== "boolean" || typeof suggestionId !== "string" ||
      suggestionId.length < 1 || suggestionId.length > 150) {
      return Response.json({ error: "Provide a valid suggestion and Like state" }, { status: 400 });
    }

    // Never use client-supplied make/model/title to update durable preferences.
    // The suggestion's stored identity is authoritative. RLS and the explicit
    // owner check prevent accidentally mixing an admin's QA or another buyer's
    // results into the signed-in buyer's liked-model history.
    let suggestion: any;
    try {
      suggestion = await base44.entities.SuggestedBoat.get(suggestionId);
    } catch (_) {
      return Response.json({ error: "Suggestion not found" }, { status: 404 });
    }
    if (!suggestion || suggestion.created_by_id !== user.id || suggestion.test_profile_id) {
      return Response.json({ error: "Suggestion not found" }, { status: 404 });
    }

    const profiles = await base44.entities.BuyerProfile.filter({ created_by_id: user.id }, "-created_date", 1);
    const profile = profiles?.[0];
    if (!profile) {
      return Response.json({ error: "Complete a buyer profile before saving Likes" }, { status: 400 });
    }

    const fingerprint = await profileInputFingerprint(profile);
    if (liked && (suggestion.superseded || suggestion.buyer_profile_id !== profile.id || suggestion.profile_input_fingerprint !== fingerprint)) {
      return Response.json({ error: "This result belongs to an earlier profile. Update matches before adding preference signals." }, { status: 409 });
    }
    const { make = "", model = "", title = "" } = suggestion;
    const tier = normalizePlan((user as any).plan || "free");
    const key = likeKey(make, model, title);
    if (key === "title:") return Response.json({ error: "Suggestion has no model identity" }, { status: 400 });
    let likedModels: any[] = Array.isArray(profile.liked_models) ? [...profile.liked_models] : [];

    if (liked) {
      // Add if not already present — preserve the original liked_at_tier.
      const exists = likedModels.some((m) => likeKey(m.make, m.model, m.title) === key && m.profile_input_fingerprint === fingerprint);
      if (!exists) {
        likedModels.push({ make: make || "", model: model || "", title: title || "", liked_at_tier: tier, profile_input_fingerprint: fingerprint });
      }
    } else {
      // Remove the matching entry.
      likedModels = likedModels.filter((m) => likeKey(m.make, m.model, m.title) !== key);
    }

    // Keep the immediate Like display and the durable preference history in
    // sync. If the second write fails, restore the prior suggestion flag.
    // Snapshot before writing: local/mock SDK objects can be mutated by update.
    const previousLiked = Boolean(suggestion.liked);
    try {
      await base44.entities.SuggestedBoat.update(suggestionId, { liked });
      await base44.entities.BuyerProfile.update(profile.id, { liked_models: likedModels });
    } catch (e) {
      console.error("toggle-like: could not persist Like state", e);
      try {
        await base44.entities.SuggestedBoat.update(suggestionId, { liked: previousLiked });
      } catch (_) {
        console.error("toggle-like: rollback of suggestion Like failed");
      }
      return Response.json({ error: "Could not save Like; please retry" }, { status: 500 });
    }

    return Response.json({ ok: true, liked_models: likedModels });
  } catch (err) {
    console.error("toggle-like error", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}