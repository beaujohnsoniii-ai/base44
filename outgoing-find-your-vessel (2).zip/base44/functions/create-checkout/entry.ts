// Base44 Payments checkout starter — base44/functions/create-checkout/entry.ts
//
// Provided by the platform. Do NOT rewrite the plumbing (session construct + persisting the
// join key + return-URL resolution). Edit only the region marked `// ===== APP-SPECIFIC =====`
// to resolve — SERVER-SIDE — what the buyer is purchasing and its price.
//
// PUBLIC by default: a buyer does NOT need to be logged in to check out. Backend function routes
// are callable anonymously, and storefront buyers often have no account — requiring login here is
// what blocks real purchases. If a buyer IS signed in we record their app-user id as the
// fulfillment target; otherwise the webhook grants by the buyer's email. Never 401 here.
//
// CRITICAL: Wix's checkout has NO custom-metadata field, so the returned `checkoutSession.id` is
// the ONLY thing that ties this payment back to this purchase. We persist it on a pending
// Base44Purchase BEFORE redirecting; the webhook resolves the purchase by that same id
// (order.checkoutId === checkoutSession.id). Skipping this write makes fulfillment impossible.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.31";
import { resolveStage, normalizePlan } from "../../shared/stages.ts";
import { resolveAdvisorCredit } from "../../shared/credits.ts";

const CONSTRUCT_URL = "https://www.wixapis.com/payments/platform/v1/checkout-sessions/construct";

// The app's public base URL for the buyer's return links. Use the platform-injected
// `X-Base44-App-Url` header (server-set from app state — correct behind custom domains), then the
// server-owned `WIX_CHECKOUT_APP_URL` secret. We do NOT fall back to the request `Origin`: it's
// caller-controlled, so a spoofed Origin would make Wix send the paid buyer to an attacker page
// (open redirect). Both sources above are always present for a connected payments app.
function resolveAppUrl(req: Request): string {
  return (
    req.headers.get("x-base44-app-url") ||
    Deno.env.get("WIX_CHECKOUT_APP_URL") ||
    ""
  );
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });
    }
    // Launch testing: checkout is closed server-side until Beau explicitly authorizes payments.
    return Response.json({ error: "Payments are disabled during launch testing. No payment has been taken." }, { status: 503 });
    // Read per request, never at module scope: disconnecting payments blanks these, and a warm
    // isolate that captured them at startup would keep charging with the old credentials.
    const WIX_API_KEY = Deno.env.get("WIX_CHECKOUT_API_KEY");
    const WIX_SITE_ID = Deno.env.get("WIX_CHECKOUT_SITE_ID");
    if (!WIX_API_KEY || !WIX_SITE_ID) {
      console.error("create-checkout: Wix payment config not set");
      return new Response(JSON.stringify({ error: "Payments not configured" }), { status: 500 });
    }

    const appUrl = resolveAppUrl(req);
    if (!appUrl) {
      // Fail closed: with no server-owned app URL (both the X-Base44-App-Url header AND the
      // WIX_CHECKOUT_APP_URL secret are absent — e.g. a slug-less or partially-wired app) we'd build
      // relative return links like `/ThankYou` and strand the paid buyer. Never fall back to the
      // caller-controlled Origin (open redirect). Reconnecting payments repopulates the secret.
      console.error("create-checkout: no app URL (X-Base44-App-Url header and WIX_CHECKOUT_APP_URL both empty)");
      return new Response(JSON.stringify({ error: "Payments not configured" }), { status: 500 });
    }
    const base44 = createClientFromRequest(req);

    // Capture the buyer's app-user id IF signed in — but never REQUIRE it. This is the
    // fulfillment target the webhook grants to; when absent (anonymous buyer) the webhook grants
    // by the email the buyer enters on Wix's checkout page.
    let appUser = null;
    try {
      appUser = await base44.auth.me();
    } catch (_) {
      appUser = null;
    }

    const body = await req.json().catch(() => ({}));

    // ===== APP-SPECIFIC =====
    // Resolve what is being bought AND its price SERVER-SIDE. NEVER trust a price sent by the
    // client — a buyer can tamper the request body and pay any amount. The client sends only a
    // product identifier; look up the authoritative price here. All SoundHeading products are
    // one-time purchases (no subscriptions, no auto-renewal).
    const productId = String(body.productId ?? "");
    const stage = resolveStage(productId);
    if (!stage) {
      return new Response(JSON.stringify({ error: "Unknown package" }), { status: 400 });
    }
    // Upgrades and add-ons require the buyer to already hold a specific package.
    // normalizePlan maps legacy values (initial_boat_match → match_plus, etc.) so
    // existing records keep working with the new product IDs.
    if (stage.requires_plan) {
      if (!appUser) {
        return new Response(JSON.stringify({ error: "Sign in to purchase this" }), { status: 400 });
      }
      const currentPlan = normalizePlan((appUser as any).plan || "free");
      const requiredPlan = normalizePlan(stage.requires_plan);
      if (currentPlan !== requiredPlan) {
        return new Response(JSON.stringify({ error: "This purchase requires a different package" }), { status: 400 });
      }
    }
    const currency = "USD";
    const thankYouPath = "/ThankYou";
    const postFlowPath = "/dashboard";

    // Single one-time cart item. Activation/advisor credit may apply to the credit-eligible
    // direct purchases (refined_match, buyer_pass). Upgrades, add-ons, and extensions are
    // not credit-eligible — the prior payment credit is already baked into the upgrade price.
    const cartItems: any[] = [];
    let creditApplied = 0;
    let advisorCreditApplied = 0;
    let advisorCreditProfileId: string | null = null;
    let listPriceTotal = 0;

    const listPrice = parseFloat(stage.price);
    if (stage.credit_eligible && appUser && Number(appUser.activation_credit) > 0) {
      creditApplied = Math.min(Number(appUser.activation_credit), listPrice);
    }
    if (stage.credit_eligible && appUser && creditApplied < listPrice) {
      const advisorCredit = await resolveAdvisorCredit(base44, appUser.id);
      if (advisorCredit.amount > 0 && advisorCredit.profileId) {
        const remaining = listPrice - creditApplied;
        advisorCreditApplied = Math.min(advisorCredit.amount, remaining);
        creditApplied += advisorCreditApplied;
        advisorCreditProfileId = advisorCredit.profileId;
      }
    }
    // Cap total credit so the charge is always at least $0.50 (Wix rejects charges under 0.50).
    if (creditApplied > listPrice - 0.50) {
      const reduction = creditApplied - Math.max(0, listPrice - 0.50);
      creditApplied -= reduction;
      if (advisorCreditApplied > 0) {
        advisorCreditApplied = Math.max(0, advisorCreditApplied - reduction);
      }
    }
    const chargedPrice = (listPrice - creditApplied).toFixed(2);
    cartItems.push({ name: `SoundHeading — ${stage.name}`, quantity: 1, price: chargedPrice });
    listPriceTotal = listPrice;
    // ===== END APP-SPECIFIC =====

    const total = cartItems.reduce((sum: number, it: any) => sum + parseFloat(it.price) * (it.quantity || 1), 0);
    if (!(total >= 0.5)) {
      // Wix rejects charges under 0.50 in the charged currency (major units, not cents).
      return new Response(JSON.stringify({ error: "Amount must be at least 0.50" }), { status: 400 });
    }

    const constructBody = {
      cart: {
        items: cartItems,
        // Prefill the signed-in buyer's email if we have one; anonymous buyers enter it on Wix.
        ...(appUser?.email ? { customerInfo: { email: appUser.email } } : {}),
      },
      callbackUrls: {
        thankYouPageUrl: `${appUrl}${thankYouPath}`,
        postFlowUrl: `${appUrl}${postFlowPath}`,
      },
    };

    const wixRes = await fetch(CONSTRUCT_URL, {
      method: "POST",
      headers: {
        "Authorization": WIX_API_KEY,
        "wix-site-id": WIX_SITE_ID,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(constructBody),
    });

    if (!wixRes.ok) {
      const errText = await wixRes.text();
      console.error("create-checkout: Wix construct failed", { status: wixRes.status, errText });
      return new Response(JSON.stringify({ error: "Could not start checkout" }), { status: 502 });
    }

    const { checkoutSession } = await wixRes.json();
    const checkoutSessionId: string = checkoutSession?.id;
    const redirectUrl: string = checkoutSession?.redirectUrl;

    if (!checkoutSessionId || !redirectUrl) {
      console.error("create-checkout: missing checkoutSession id/redirectUrl", checkoutSession);
      return new Response(JSON.stringify({ error: "Could not start checkout" }), { status: 502 });
    }

    // PERSIST THE JOIN KEY (the whole point). Pending until the webhook flips it to "paid".
    // asServiceRole so the row is trustworthy — Base44Purchase RLS blocks client writes, so a buyer
    // can't forge a paid purchase. appUserId is the fulfillment target when known; null for an
    // anonymous buyer (the webhook then grants by buyerEmail).
    await base44.asServiceRole.entities.Base44Purchase.create({
      checkoutSessionId,
      status: "pending",
      appUserId: appUser?.id ?? null,
      buyerEmail: appUser?.email ?? null,
      productId,
      productName: stage.name,
      quantity: 1,
      amount: total.toFixed(2),
      currency,
      creditApplied,
      advisorCreditApplied,
      advisorCreditProfileId,
      listPrice: listPriceTotal.toFixed(2),
    });

    return new Response(JSON.stringify({ redirectUrl }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("create-checkout: unhandled error", err);
    return new Response(JSON.stringify({ error: "Internal error" }), { status: 500 });
  }
});