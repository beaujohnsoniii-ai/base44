import { createIntakeHandler } from '../../shared/listing-intake-http.ts';
import { allowedStageCaller } from '../../shared/listing-intake-service.mjs';

// Isolated, pre-provisioned DEV fixture only. No User/profile mutations, automatic
// bootstrap, customer rollout, page fetching, scraping, emails or payment actions.
const STAGE_POLICY = Object.freeze({
  enabled: true, integrations_enabled: false, max_uploads: 3, max_extractions: 3,
  app_id: '6abbd00d2cbdcfbf9bef007e', owner_id: '6abbd00e2cbdcfbf9bef007f',
  record_id: '6add19754e704fed3fffbe38',
});
export default createIntakeHandler(STAGE_POLICY, 'dev', allowedStageCaller);
