import {createClientFromRequest} from "npm:@base44/sdk@0.8.54";
import {secrets} from "base44:runtime";
import {BROKER_TEST_URL,BROKER_APPROVAL,scrapeApprovedBroker,brokerFailureDiagnostic} from "../../shared/firecrawl-broker-test.mjs";
import {withCompareDeadline} from "../../shared/compare-deadline.mjs";

// Only the explicitly approved fixed broker test. Never an arbitrary-URL proxy.
export default async function(req:Request):Promise<Response>{
 if(req.method!=="POST")return Response.json({error:"Method not allowed"},{status:405});
 try{return await withCompareDeadline(async signal=>{
  const client=createClientFromRequest(req);let user;
  try{user=await client.auth.me();}catch{return Response.json({error:"Unauthorized"},{status:401});}
  signal.throwIfAborted();if(!user)return Response.json({error:"Unauthorized"},{status:401});
  if(user.role!=="admin")return Response.json({error:"Admin access required"},{status:403});
  const reader=req.body?.getReader();let raw="",length=0;const decoder=new TextDecoder();
  if(reader)while(true){const n=await reader.read();if(n.done)break;length+=n.value.byteLength;if(length>1024){await reader.cancel();return Response.json({error:"Request too large"},{status:413});}raw+=decoder.decode(n.value,{stream:true});}
  let body;try{body=JSON.parse(raw||"{}");}catch{return Response.json({error:"Invalid request"},{status:400});}
  if(!body||Array.isArray(body)||typeof body!=="object"||Object.keys(body).some(k=>k!=="action")||!["status","run_basic_test"].includes(body.action||"status"))return Response.json({error:"Only the fixed approved test is supported"},{status:400});
  const key=secrets.get("FIRECRAWL_API_KEY")?.trim();
  const ledger=client.asServiceRole.entities.FirecrawlBrokerTest;
  const rows=await ledger.filter({approval_id:BROKER_APPROVAL},"-created_date",2);
  signal.throwIfAborted();
  if(rows.length!==1)return Response.json({error:"Approved test slot is unavailable or ambiguous; no provider call made",key_configured:Boolean(key)},{status:409});
  const slot=rows[0];
  if(slot.approved_url!==BROKER_TEST_URL||slot.max_calls!==1)return Response.json({error:"Approval scope mismatch; no provider call made"},{status:409});
  if((body.action||"status")==="status")return Response.json({key_configured:Boolean(key),test_status:slot.status,approved_url:BROKER_TEST_URL,result:slot.result||null,failure:slot.failure||null,diagnostic:slot.diagnostic||null});
  if(!key)return Response.json({error:"Add FIRECRAWL_API_KEY directly in Base44 Dashboard → Secrets. No provider call made.",key_configured:false},{status:503});
  const nonce=crypto.randomUUID();
  const reservation=await ledger.updateMany({id:slot.id,approval_id:BROKER_APPROVAL,status:"ready",max_calls:1,approved_url:BROKER_TEST_URL},{$set:{status:"reserved",reserved_by:user.id,reserved_at:new Date().toISOString(),request_nonce:nonce}});
  signal.throwIfAborted();
  if(reservation?.success!==true||reservation.updated!==1)return Response.json({error:"This one-call test is already reserved/spent, or reservation was not confirmed. No new provider call made."},{status:409});
  const confirmed=await ledger.get(slot.id);
  if(confirmed.status!=="reserved"||confirmed.request_nonce!==nonce)return Response.json({error:"Reservation readback failed; no provider call made."},{status:409});
  signal.throwIfAborted();
  let stage="provider_fetch",httpStatus:number|null=null;const started=Date.now();
  try{
   const result=await scrapeApprovedBroker(key,signal,fetch,(next:string,status?:number)=>{stage=next;if(status!==undefined)httpStatus=status;});
   stage="ledger_complete";
   await ledger.update(slot.id,{status:"complete",completed_at:new Date().toISOString(),result});
   return Response.json({key_configured:true,test_status:"complete",result});
  }catch(error){
   const diagnostic=brokerFailureDiagnostic(error,stage,httpStatus,Date.now()-started);
   // A timeout/error can still be billable. Never release the slot or retry.
   await ledger.update(slot.id,{status:"uncertain",completed_at:new Date().toISOString(),failure:"One provider attempt failed or was not confirmed. It may be billable; no automatic retry is allowed.",diagnostic});
   return Response.json({error:"The one-call attempt was not confirmed. Check the saved test status; do not rerun.",test_status:"uncertain",diagnostic},{status:502});
  }
 },35000);}catch{return Response.json({error:"Test response unavailable or timed out. Check saved status before any further action; no automatic retry."},{status:504});}
}
