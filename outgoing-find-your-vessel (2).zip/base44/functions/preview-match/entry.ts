import { TIER_RESULT_COUNTS } from "../../shared/tier-results.mjs";
// Public, deliberately inexpensive preview: no SDK, database, AI, web research or private scoring.
const OPTIONS = [
  { id: "center-console", title: "Center-console fishing boats", tags: ["Fishing", "Diving"], reason: "An open working cockpit is a starting point for fishing and diving." },
  { id: "dual-console", title: "Dual-console day boats", tags: ["Day cruising", "Entertaining", "Watersports / tubing"], reason: "A mixed seating and cockpit layout is a starting point for varied day trips." },
  { id: "pilothouse", title: "Pilothouse boats", tags: ["Commuting", "Fishing", "Overnight cruising"], reason: "An enclosed helm is a starting point when shelter matters." },
  { id: "cabin-cruiser", title: "Cabin cruisers", tags: ["Overnight cruising", "Liveaboard", "Entertaining"], reason: "Cabin space is a starting point for time aboard beyond a day trip." },
  { id: "day-boat", title: "Open day boats", tags: ["Day cruising", "Watersports / tubing"], reason: "Day-use layouts are a starting point for short recreational outings." },
];
export default async function(req: Request): Promise<Response> {
  const headers = { "Cache-Control": "no-store" };
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405, headers });
  const raw = await req.text();
  if (raw.length > 4096) return Response.json({ error: "Preview request too large" }, { status: 413, headers });
  let body;
  try { body = JSON.parse(raw); } catch { return Response.json({ error: "Invalid preview request" }, { status: 400, headers }); }
  const activities = Array.isArray(body?.activities) ? body.activities.filter((v: unknown) => typeof v === "string").slice(0, 8) : [];
  // Show activity-related examples first, then clearly identified general examples.
  // These are fixed boat-type illustrations, never qualified model recommendations.
  const directions = OPTIONS.map((o, order) => ({ ...o, order, count: o.tags.filter(t => activities.includes(t)).length }))
    .sort((a, b) => b.count - a.count || a.order - b.order).slice(0, TIER_RESULT_COUNTS.free.suggestCount)
    .map(({ id, title, reason, count }) => ({
      id, title, reason: count > 0 ? reason : "General illustrative example; not selected from your activities.",
      example_kind: count > 0 ? "activity_starting_point" : "general_example",
    }));
  return Response.json({
    kind: "category_preview",
    directions,
    note: "Four illustrative example results: activity-related starting points are shown first, followed by general examples where needed. These are boat types to explore, not verified model recommendations. Budget, dimensions, draft, propulsion and passenger suitability still require model-specific checks. No boat is confirmed to meet your requirements by this preview."
  }, { headers });
}
