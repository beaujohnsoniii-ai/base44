import { createIntakeHandler } from '../../shared/listing-intake-http.ts';
import { allowedOwnerTrialCaller } from '../../shared/listing-intake-service.mjs';

// Explicitly approved private owner trial. PROD profile/model reads are one-way:
// only this separate pinned ListingIntake may be written. No automatic bootstrap.
const OWNER_POLICY = Object.freeze({
  enabled: true, integrations_enabled: true, max_uploads: 9, max_extractions: 9,
  submission_policy: 'current-top-three-single-screenshot-v1',
  workspace_kind: 'owner-production', workspace_label: 'private-owner-intake-2026-10-24',
  app_id: '6abbd00d2cbdcfbf9bef007e', owner_id: '6abbd00e2cbdcfbf9bef007f',
  record_id: '6add2ffa67a782c6ce9d9317',
});
export default createIntakeHandler(OWNER_POLICY, 'prod', allowedOwnerTrialCaller);
