import { applyPastLikeChoice } from "../../shared/liked-preferences.mjs";
import { createClientFromRequest } from "npm:@base44/sdk@0.8.57";
import { saveBuyerProfile, ProfileSaveError } from "../../shared/save-buyer-profile.mjs";
import { profileInputFingerprint } from "../../shared/profile-input-fingerprint.mjs";
import { DEFAULT_FIELD_TIERS } from "../../shared/question-tier-defaults.mjs";
const VERSION = "profile-save-v1";
const fields = new Set([...Object.keys(DEFAULT_FIELD_TIERS), "hard_max_overall_length_ft", "hard_max_beam_ft", "hard_max_height_ft", "hard_max_storage_weight_lb", "hard_max_draft_ft", "tow_capacity_lb", "match_question_tier", "status"]);
export default async function (req: Request): Promise<Response> {
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });
  const client = createClientFromRequest(req);
  let user;
  try { user = await client.auth.me(); } catch { return Response.json({ error: "Unauthorized" }, { status: 401 }); }
  if (!user?.id) return Response.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = await req.json();
    if (!body.profile || typeof body.profile !== "object" || Array.isArray(body.profile)) return Response.json({ error: "Invalid profile" }, { status: 400 });
    const profiles = client.asServiceRole.entities.BuyerProfile;
    const read = async () => (await profiles.filter({ created_by_id: user.id }, "-created_date", 1))?.[0];
    const existing = await read();
    let profile;
    if (!existing) {
      // Retain the permanent first-profile creation claim; never duplicate rows.
      profile = await saveBuyerProfile(client, user, body.profile, { onlyIfMissing: true });
    } else if (body.only_if_missing === true) {
      profile = existing;
    } else {
      const patch: Record<string, any> = Object.fromEntries(Object.entries(body.profile).filter(([key]) => fields.has(key)));
      applyPastLikeChoice(existing, patch, body.profile);
      const next = { ...existing, ...patch };
      // Explicit past-Like opt-in needs a context even for a legacy profile.
      // Merely saving unchanged legacy answers does not allocate one.
      if (body.reset_context === true || (!existing.match_context_id && body.profile.use_past_likes === true) || await profileInputFingerprint(existing) !== await profileInputFingerprint(next)) patch.match_context_id = crypto.randomUUID();
      applyPastLikeChoice(existing, patch, body.reset_context === true && (existing.past_likes_context_id || body.profile.use_past_likes === true) ? { use_past_likes: false } : body.profile);
      // Persist answers and the fresh context together, conditional on the exact
      // record read. No second Reset request or partial answers-only save.
      const result = await profiles.updateMany(
        { id: existing.id, created_by_id: user.id, updated_date: existing.updated_date, match_context_id: { $in: [existing.match_context_id ?? null] } },
        { $set: patch },
      );
      if (result?.updated !== 1) throw new ProfileSaveError("Your profile changed during saving. Keep this form open and review the saved profile before retrying.", 409);
      profile = { ...existing, ...patch };
    }
    const persisted = await read();
    // Older profiles legitimately have no context. An unchanged save/read must
    // not silently rotate their fingerprint and invalidate existing matches.
    // Changed answers and explicit Reset still require a fresh persisted context.
    const unchangedLegacy = existing && !existing.match_context_id && !profile.match_context_id
      && (body.only_if_missing === true || body.reset_context !== true)
      && await profileInputFingerprint(existing) === await profileInputFingerprint(profile);
    if (persisted?.id !== profile.id || (!profile.match_context_id && !unchangedLegacy) || await profileInputFingerprint(persisted) !== await profileInputFingerprint(profile)) throw new ProfileSaveError("Profile persistence could not be confirmed. Your answers may already be saved; keep this form open before retrying.", 503);
    console.info("save-matching-profile: persisted", VERSION);
    return Response.json({ profile: persisted, profile_save_version: VERSION, matching_context_version: "fresh-context-v2", reset_context_applied: body.reset_context === true });
  } catch (error) {
    if (error instanceof ProfileSaveError) return Response.json({ error: error.message }, { status: error.status });
    console.error("save-matching-profile: persistence not confirmed");
    return Response.json({ error: "Profile save could not be confirmed. Your answers may already be saved; keep this form open before retrying." }, { status: 503 });
  }
}
