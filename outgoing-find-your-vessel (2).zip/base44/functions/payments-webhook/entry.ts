// Base44 Payments fulfillment webhook — base44/functions/payments-webhook/entry.ts
//
// Provided by the platform. Do NOT rewrite the plumbing (JWT verification, envelope parsing,
// purchase resolution, idempotency). Only edit the region marked
// `// ===== APP-SPECIFIC =====` to define what "grant access" means for this app.
//
// It receives Wix `ORDER_APPROVED` events (and optional subscription lifecycle events),
// verifies the RS256 JWT, resolves the buyer's pending Purchase by checkout id, and marks
// it paid exactly once. It pairs with `create-checkout`, which MUST persist
// `checkoutSession.id` on the Purchase — Wix has no custom-metadata field, so the checkout
// id is the ONLY correlation key back to this app's user.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.31";
import { importSPKI, jwtVerify } from "npm:jose@5.9.6";
import { consumeAdvisorCredit } from "../../shared/credits.ts";

// Wix event types (verbatim from Wix docs).
const ORDER_APPROVED = "wix.ecom.v1.order_approved";
const SUBSCRIPTION_CANCELED = "wix.ecom.subscription_contracts.v1.subscription_contract_canceled";
const SUBSCRIPTION_EXPIRED = "wix.ecom.subscription_contracts.v1.subscription_contract_expired";

// Unwrap Wix's triple-nested envelope: the request body is a JWT whose verified
// payload has a `data` JSON string; that parses to an envelope with `eventType` and
// another `data` JSON string; that parses to the event data, which for these events
// wraps the entity in a per-action wrapper (see extractOrder).
function parseWixEnvelope(payload: Record<string, unknown>): { eventType: string; eventData: any } {
  const outer = typeof payload.data === "string" ? JSON.parse(payload.data) : payload.data;
  // eventType lives on the parsed envelope; newer DomainEvent envelopes may also carry it as a
  // top-level JWT claim — fall back to that so the event isn't misrouted to the ignore branch.
  const eventType: string = outer?.eventType ?? (payload.eventType as string) ?? "";
  const eventData = typeof outer?.data === "string" ? JSON.parse(outer.data) : outer?.data;
  return { eventType, eventData };
}

// order_approved is an ACTION event: the order is at `actionEvent.body.order`
// (per the Wix docs' sample payload, where `order.checkoutId === checkoutSession.id`).
// The flat `order` / `entity` forms are fallbacks for the other envelope variants Wix emits.
function extractOrder(eventData: any): any | null {
  return eventData?.actionEvent?.body?.order ?? eventData?.order ?? eventData?.entity ?? null;
}

// The buyer's email, as entered on Wix's hosted checkout page. This is the ONLY identity for an
// anonymous buyer (one who wasn't signed in when create-checkout ran, so appUserId is null). Wix
// exposes it in a few places depending on the flow; check the common ones.
function extractBuyerEmail(order: any): string | null {
  return (
    order?.buyerInfo?.email ??
    order?.billingInfo?.contactDetails?.email ??
    order?.billingInfo?.email ??
    null
  );
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method !== "POST") {
      return new Response("Method not allowed", { status: 405 });
    }

    // Read per request, never at module scope: the key is stored when the webhook is registered, so
    // a warm isolate that captured it at startup would stay keyless and 500 every ORDER_APPROVED.
    const WEBHOOK_PUBLIC_KEY = Deno.env.get("WIX_CHECKOUT_WEBHOOK_PUBLIC_KEY");
    if (!WEBHOOK_PUBLIC_KEY) {
      // Never process an unverifiable event. Missing key = misconfiguration, not a retry case.
      console.error("payments-webhook: WIX_CHECKOUT_WEBHOOK_PUBLIC_KEY is not set");
      return new Response("Webhook not configured", { status: 500 });
    }

    // The raw body IS the JWT (Wix signs the whole payload, RS256).
    const token = await req.text();

    let payload: Record<string, unknown>;
    try {
      const key = await importSPKI(WEBHOOK_PUBLIC_KEY, "RS256");
      const verified = await jwtVerify(token, key);
      payload = verified.payload as Record<string, unknown>;
    } catch (err) {
      // Signature invalid / malformed. Reject — do NOT grant anything.
      console.error("payments-webhook: JWT verification failed", err);
      return new Response("Invalid signature", { status: 401 });
    }

    const { eventType, eventData } = parseWixEnvelope(payload);
    const base44 = createClientFromRequest(req);
    const db = base44.asServiceRole; // No end user is authenticated on a webhook call.

    if (eventType === ORDER_APPROVED) {
      return await handleOrderApproved(db, eventData);
    }

    if (eventType === SUBSCRIPTION_CANCELED || eventType === SUBSCRIPTION_EXPIRED) {
      return await handleSubscriptionEnded(db, eventData);
    }

    // Unknown/irrelevant event — acknowledge so Wix stops retrying.
    console.log(`payments-webhook: ignoring event ${eventType}`);
    return new Response("OK", { status: 200 });
  } catch (err) {
    // Unexpected failure: 500 tells Wix to retry later (the handler is idempotent, so a
    // retry after a partial failure is safe).
    console.error("payments-webhook: unhandled error", err);
    return new Response("Internal error", { status: 500 });
  }
});

async function handleOrderApproved(db: any, eventData: any): Promise<Response> {
  const order = extractOrder(eventData);
  const checkoutId: string | undefined = order?.checkoutId;
  const orderId: string | undefined = order?.id;
  // Subscription id (if any) — persisted below so SUBSCRIPTION_CANCELED/EXPIRED can later
  // resolve this purchase by subscriptionId and revoke access.
  const subscriptionId: string | undefined = (order?.lineItems ?? [])
    .map((li: any) => li?.subscriptionInfo?.id)
    .find((id: any) => !!id);

  if (!checkoutId) {
    // Nothing to correlate on. Acknowledge to stop retries; log for investigation.
    console.error("payments-webhook: ORDER_APPROVED missing order.checkoutId", { orderId });
    return new Response("OK", { status: 200 });
  }

  // Resolve the pending purchase created by `create-checkout` (join key: checkoutSessionId).
  const matches = await db.entities.Base44Purchase.filter({ checkoutSessionId: checkoutId });
  const purchase = matches?.[0];

  if (!purchase) {
    // The pending Base44Purchase is written by create-checkout before the buyer pays, so a miss
    // here is a transient race (entity not yet visible) — return 500 so Wix retries, rather
    // than ACKing a paid order we can't fulfill. (Wix stops after its retry window.)
    console.warn("payments-webhook: no Base44Purchase for checkoutId yet, asking Wix to retry", { checkoutId, orderId });
    return new Response("Purchase not found yet", { status: 500 });
  }

  // IDEMPOTENCY + terminal states: Wix delivers ORDER_APPROVED more than once, and may deliver
  // a stale approval after a cancellation. Skip if already "paid" (prevents double-grant) or
  // "canceled" (a late approval must not resurrect a revoked subscription).
  if (purchase.status === "paid" || purchase.status === "canceled") {
    console.log("payments-webhook: purchase already terminal, skipping", { checkoutId, status: purchase.status });
    return new Response("OK", { status: 200 });
  }

  // The buyer's email: from create-checkout if they were signed in, otherwise from the Wix order
  // (the only identity an anonymous buyer has). Persisted below and used by the grant block.
  const buyerEmail: string | null = purchase.buyerEmail ?? extractBuyerEmail(order);

  // ===== APP-SPECIFIC =====
  // Grant the purchased package. New packages set the buyer's `plan`, an access window
  // (`plan_expires`), and an update allowance (`updates_limit`, `updates_used` reset to 0).
  // Upgrades replace the lower tier's remaining allowance with the higher tier's and start a
  // new access window on the purchase date. Add-ons increment the listing-evaluation allowance.
  // Extensions extend the access window and add updates. Idempotent: duplicate ORDER_APPROVED
  // deliveries (which Wix sends) are a no-op.
  const stageId = purchase.productId;
  const ACTIVATION_CREDIT = 29;
  const EXTENSION_ACCESS_DAYS = 90;
  const EXTENSION_UPDATES = 10;

  // Map each product to the plan it grants, its access-window length, and its update allowance.
  // New tier names grant new plan values; legacy product IDs are aliases that grant the
  // same new plan value so existing checkout flows and pending purchases keep working.
  const PACKAGE_GRANTS: Record<string, { plan: string; days: number; updates: number; listingEvals?: number }> = {
    match_plus: { plan: "match_plus", days: 30, updates: 3 },
    refined_match: { plan: "refined_match", days: 30, updates: 5 },
    market_match: { plan: "market_match", days: 90, updates: 10, listingEvals: 3 },
    upgrade_match_plus_to_refined: { plan: "refined_match", days: 30, updates: 5 },
    upgrade_match_plus_to_market: { plan: "market_match", days: 90, updates: 10, listingEvals: 3 },
    upgrade_refined_to_market: { plan: "market_match", days: 90, updates: 10, listingEvals: 3 },
    // Legacy aliases
    initial_boat_match: { plan: "match_plus", days: 30, updates: 3 },
    buyer_pass: { plan: "market_match", days: 90, updates: 10, listingEvals: 3 },
    upgrade_initial_to_refined: { plan: "refined_match", days: 30, updates: 5 },
    upgrade_initial_to_buyer: { plan: "market_match", days: 90, updates: 10, listingEvals: 3 },
    upgrade_refined_to_buyer: { plan: "market_match", days: 90, updates: 10, listingEvals: 3 },
  };
  const LISTING_EVAL_ADDONS: Record<string, number> = {
    listing_eval_1: 1,
    listing_eval_3: 3,
  };

  const grantToUser = async (userId: string) => {
    const user = await db.entities.User.get(userId);
    const current: string[] = Array.isArray(user?.purchased_stages) ? user.purchased_stages : [];
    const updates: Record<string, any> = {};
    const stagesToAdd: string[] = [];

    const pkgGrant = PACKAGE_GRANTS[stageId];
    const evalAddon = LISTING_EVAL_ADDONS[stageId];

    if (pkgGrant) {
      // A package purchase or upgrade: set the plan, open a fresh access window, reset updates.
      const expires = new Date();
      expires.setDate(expires.getDate() + pkgGrant.days);
      updates.plan = pkgGrant.plan;
      updates.plan_expires = expires.toISOString();
      updates.updates_limit = pkgGrant.updates;
      updates.updates_used = 0;
      updates.paid_pool_generated = false;
      if (pkgGrant.listingEvals) {
        updates.listing_evals_limit = pkgGrant.listingEvals;
        updates.listing_evals_used = 0;
      }
      if (!current.includes(pkgGrant.plan)) stagesToAdd.push(pkgGrant.plan);
    } else if (evalAddon) {
      // An additional-listing-evaluation add-on: increment the allowance.
      updates.listing_evals_limit = (Number(user?.listing_evals_limit) || 0) + evalAddon;
    } else if (stageId === "search_extension") {
      // A search extension: extend the access window by 90 days and add 10 updates.
      const base = user?.plan_expires ? new Date(user.plan_expires) : new Date();
      const startFrom = base.getTime() > Date.now() ? base : new Date();
      startFrom.setDate(startFrom.getDate() + EXTENSION_ACCESS_DAYS);
      updates.plan_expires = startFrom.toISOString();
      updates.updates_limit = (Number(user?.updates_limit) || 0) + EXTENSION_UPDATES;
    } else if (stageId === "activate") {
      // Legacy activation stage.
      updates.activation_credit = ACTIVATION_CREDIT;
      if (!current.includes("activate")) stagesToAdd.push("activate");
    }

    if (stagesToAdd.length > 0) {
      updates.purchased_stages = [...current, ...stagesToAdd];
    }
    // Consume activation credit: the portion of creditApplied that wasn't advisor credit.
    const activationCreditUsed = Number(purchase.creditApplied) - Number(purchase.advisorCreditApplied || 0);
    if (activationCreditUsed > 0) {
      updates.activation_credit = 0;
    }
    if (Object.keys(updates).length > 0) {
      await db.entities.User.update(userId, updates);
    }
    // Consume advisor credit on the buyer's profile after the purchase is granted.
    if (Number(purchase.advisorCreditApplied) > 0 && purchase.advisorCreditProfileId) {
      await consumeAdvisorCredit(db, purchase.advisorCreditProfileId);
    }
  };
  if (purchase.appUserId) {
    await grantToUser(purchase.appUserId);
  } else if (buyerEmail) {
    // Anonymous buyer: link by email if a matching user exists. If none, the Base44Purchase record
    // (buyerEmail + productId) remains the source of truth for a later claim-on-signup.
    const users = await db.entities.User.filter({ email: buyerEmail });
    if (users?.[0]) await grantToUser(users[0].id);
  }
  // ===== END APP-SPECIFIC =====

  // Mark paid LAST, so "paid" always implies the grant above completed. The idempotency
  // check at the top short-circuits on this status, so it must only be set after fulfillment.
  // subscriptionId is stored here so SUBSCRIPTION_CANCELED/EXPIRED can resolve this purchase.
  await db.entities.Base44Purchase.update(purchase.id, {
    status: "paid",
    orderId: orderId ?? purchase.orderId ?? null,
    subscriptionId: subscriptionId ?? purchase.subscriptionId ?? null,
    // Persist the buyer email (backfilled from the Wix order for anonymous buyers) so the record
    // always shows who paid, even when create-checkout had no signed-in user.
    buyerEmail: buyerEmail ?? purchase.buyerEmail ?? null,
    paidAt: new Date().toISOString(),
  });

  console.log("payments-webhook: fulfilled purchase", { purchaseId: purchase.id, checkoutId, orderId });
  return new Response("OK", { status: 200 });
}

async function handleSubscriptionEnded(db: any, eventData: any): Promise<Response> {
  // Canceled = ended early; Expired = ran all billing cycles. Both revoke access.
  // Mirrors the order path (actionEvent.body.<entity> first); keep the flat fallbacks since
  // the subscription contract webhook body isn't as tightly documented as order_approved.
  const contract =
    eventData?.actionEvent?.body?.subscriptionContract ??
    eventData?.subscriptionContract ??
    eventData?.entity ??
    null;
  const subscriptionId: string | undefined = contract?.id;

  if (!subscriptionId) {
    console.error("payments-webhook: subscription event missing contract id");
    return new Response("OK", { status: 200 });
  }

  const matches = await db.entities.Base44Purchase.filter({ subscriptionId });
  const purchase = matches?.[0];
  if (!purchase) {
    // The subscriptionId is written on the Purchase by the ORDER_APPROVED handler. If a
    // cancel/expire arrives before (or racing) that approval, no Purchase matches yet —
    // return 500 so Wix retries until the approval has linked it, instead of losing the
    // revoke by acking a not-yet-linkable event.
    console.warn("payments-webhook: no Purchase for subscription yet, asking Wix to retry", { subscriptionId });
    return new Response("Purchase not linkable yet", { status: 500 });
  }

  if (purchase.status === "canceled") {
    return new Response("OK", { status: 200 }); // Idempotent.
  }

  // ===== APP-SPECIFIC =====
  // No subscriptions are sold anymore — all packages are one-time purchases with no
  // auto-renewal. This handler is retained for safety but has nothing to revoke.
  // ===== END APP-SPECIFIC =====

  // Mark canceled LAST, so "canceled" always implies access was actually revoked.
  await db.entities.Base44Purchase.update(purchase.id, {
    status: "canceled",
    canceledAt: new Date().toISOString(),
  });

  console.log("payments-webhook: revoked subscription", { purchaseId: purchase.id, subscriptionId });
  return new Response("OK", { status: 200 });
}