// Same handler and request semantics. Shared only for isolated DEV verification.
export { default } from "../../shared/suggest-boats-handler.ts";
