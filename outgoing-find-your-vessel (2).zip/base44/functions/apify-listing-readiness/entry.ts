import {createClientFromRequest} from "npm:@base44/sdk@0.8.54";
import {secrets} from "base44:runtime";
import {guardedApifyListingTest,APIFY_TEST_POLICY} from "../../shared/apify-listing-test.mjs";
import {withCompareDeadline} from "../../shared/compare-deadline.mjs";

// Server-owned policy stays disabled. No request can choose a URL, token, budget,
// source permission, Actor or policy. Never accepts user-controlled execution flags.
export default async function(req:Request):Promise<Response>{
 if(req.method!=="POST")return Response.json({error:"Method not allowed"},{status:405});
 try{return await withCompareDeadline(async signal=>{
  const client=createClientFromRequest(req);
  // Authenticate before reading request fields, secret presence or any service-role data.
  let user;try{user=await client.auth.me();}catch{return Response.json({error:"Sign in first"},{status:401});}
  if(!user)return Response.json({error:"Sign in first"},{status:401});
  if(user.role!=="admin")return Response.json({error:"Admin access required"},{status:403});
  const reader=req.body?.getReader();let raw="",count=0;const decoder=new TextDecoder();
  if(reader)while(true){const n=await reader.read();if(n.done)break;count+=n.value.byteLength;if(count>1024){await reader.cancel();return Response.json({error:"Request too large"},{status:413});}raw+=decoder.decode(n.value,{stream:true});}
  let body;try{body=JSON.parse(raw||"{}");}catch{return Response.json({error:"Invalid request"},{status:400});}
  if(!body||typeof body!=="object"||Array.isArray(body)||Object.keys(body).some(k=>k!=="action"))return Response.json({error:"Only action is accepted"},{status:400});
  const result=await guardedApifyListingTest({client,getSecret:()=>secrets.get("APIFY_API_TOKEN"),action:body.action||"status",policy:APIFY_TEST_POLICY,signal});
  return Response.json(result.body,{status:result.status});
 },30000);}catch{return Response.json({error:"Readiness response unavailable. Do not retry a spent or uncertain test."},{status:504});}
}
