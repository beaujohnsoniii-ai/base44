import { createClientFromRequest } from "npm:@base44/sdk@0.8.57";

// Deliberately self-contained: Reset must not depend on a separately bundled
// copy of the general profile-save helper. It never accepts buyer answers.
const VERSION = "reset-matching-context-v1";
export default async function (req: Request): Promise<Response> {
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });
  const client = createClientFromRequest(req);
  let user;
  try { user = await client.auth.me(); } catch { return Response.json({ error: "Unauthorized" }, { status: 401 }); }
  if (!user?.id) return Response.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = await req.json();
    if (typeof body.buyer_profile_id !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(body.request_id || "") || !(body.expected_context_id == null || typeof body.expected_context_id === "string")) {
      return Response.json({ error: "Invalid Reset request" }, { status: 400 });
    }
    const profiles = client.asServiceRole.entities.BuyerProfile;
    const read = async () => (await profiles.filter({ created_by_id: user.id }, "-created_date", 1))?.[0];
    let profile = await read();
    if (!profile || profile.id !== body.buyer_profile_id) return Response.json({ error: "Your current profile changed. Reload before resetting." }, { status: 409 });
    // A response lost after commit can be reconciled with the same request id.
    if (profile.match_context_id !== body.request_id) {
      if ((profile.match_context_id ?? null) !== (body.expected_context_id ?? null)) return Response.json({ error: "Your matching context changed. Reload before resetting." }, { status: 409 });
      const result = await profiles.updateMany(
        { id: profile.id, created_by_id: user.id, match_context_id: { $in: [profile.match_context_id ?? null] } },
        { $set: { match_context_id: body.request_id } },
      );
      if (result?.updated !== 1) return Response.json({ error: "Reset was not confirmed. Reload before retrying." }, { status: 409 });
      profile = await read();
    }
    if (profile?.id !== body.buyer_profile_id || profile.match_context_id !== body.request_id) return Response.json({ error: "Reset persistence was not confirmed. Reload before retrying." }, { status: 503 });
    console.info("reset-matching-context: persisted", VERSION);
    return Response.json({ profile, matching_context_version: VERSION, reset_context_applied: true, request_id: body.request_id });
  } catch (error) {
    console.error("reset-matching-context: persistence not confirmed");
    return Response.json({ error: "Reset could not be confirmed. Your answers and history are retained; reload before retrying." }, { status: 503 });
  }
}
