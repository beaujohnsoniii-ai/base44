// SoundHeading - test profile simulator (profile generation only).
//
// The duplicate recommendation engine that previously lived in this file has been
// RETIRED. The MATCH recommendation logic now lives exclusively in
// base44/shared/suggest-engine.ts, shared between production suggest-boats and
// the automated QA system (run-match-qa).
//
// This function now only generates synthetic buyer profiles in the Test DB.
// The QA workflow (running the engine, simulating Likes, evaluating results,
// expert review) is handled by run-match-qa and the AdminMatchQA page.
//
// Admin-only. The Test DB is targeted via the X-Data-Env: dev header sent by
// the frontend test client.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";

// ── Random value pools ──────────────────────────────────────────────────────

const VESSEL_CLASSES = ["private", "private", "private", "charter", "yacht"];
const BOAT_SIZE_RANGES = ["under_18", "18_24", "24_30", "30_40", "40_50"];
const EXPERIENCE_LEVELS = ["beginner", "intermediate", "intermediate", "experienced", "expert"];
const STORAGE_TYPES = ["trailer", "marina_slip", "mooring", "dry_stack", "rack_storage", "lift_kept", "private_dock"];
const TIMEFRAMES = ["asap", "1_to_3_months", "3_to_6_months", "6_plus_months", "just_exploring"];
const HORIZONS = ["1_to_3_years", "3_to_7_years", "7_to_12_years", "last_boat"];
const OTHER_ACTIVITIES = ["Day cruising", "Overnight cruising", "Watersports / tubing", "Diving", "Entertaining"];
const PRIORITIES = [
  "Build quality & construction", "Ride / seakeeping", "Age / hours & condition",
  "Purchase price / value", "Resale strength", "Fishability",
  "Fuel economy", "Comfort / accommodations", "Service & parts availability", "Safety",
];
const OPERATING_AREAS = [
  "Cape Cod, MA", "Florida Keys", "Tampa Bay, FL", "Chesapeake Bay, MD",
  "Lake Erie, OH", "Texas Gulf Coast", "Puget Sound, WA",
  "Long Island Sound, CT", "Mobile Bay, AL", "Outer Banks, NC",
  "Lake Champlain, VT", "Cocoa Beach, FL", "Venice, LA", "Biloxi, MS",
];
const FAMILY_USE = ["Weekend family outings", "Kids and friends", "Couple only", "Solo fishing", "Extended family gatherings"];
const OVERNIGHT = ["None — day trips only", "Occasional overnight", "Regular weekend overnights", "Extended cruising trips"];
const PREVIOUS_BOATS = ["None", "18 ft bowrider", "21 ft center console", "24 ft cuddy cabin", "16 ft skiff", "None — first boat"];
const MUST_HAVES = ["Self-bailing cockpit", "T-top", "Livewell", "Flush deck", "Cabin with head", "Trolling motor", "Power Pole", "Enclosed head"];
const PREFERENCES = ["Ride quality in chop", "Shallow draft", "Fuel efficiency", "Easy to trailer", "Low maintenance", "Good resale"];
const UNACCEPTABLE = ["Wood construction", "Single outboard only", "No trailer", "High hours", "Older than 15 years", "Sterndrive"];
const TOWING = ["none", "3500 lb tow rating — midsize SUV", "6000 lb tow rating — F-150/half-ton", "10000 lb tow rating — F-250/3/4-ton", "No — slip kept"];
const DRAFT = ["Shallow — under 12 inches", "Moderate — 12-24 inches", "Deep — over 24 inches", "Not sure"];

const pick = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];
const pickN = (arr: string[], n: number) => [...arr].sort(() => Math.random() - 0.5).slice(0, n);
const randInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;

function randomProfile(preferredBrands: string[]): any {
  const numActivities = randInt(1, 3);
  const otherActs = pickN(OTHER_ACTIVITIES, numActivities - 1);
  const activities = ["Fishing", ...otherActs];

  const activityWeights: Record<string, number> = {};
  // A one-activity buyer must allocate the entire 100% to that activity.
  // Otherwise the QA profile violates the same scoring contract as real buyers.
  const fishingWeight = otherActs.length ? randInt(40, 80) : 100;
  activityWeights["Fishing"] = fishingWeight;
  let remaining = 100 - fishingWeight;
  for (let i = 0; i < otherActs.length; i++) {
    if (i === otherActs.length - 1) {
      activityWeights[otherActs[i]] = remaining;
    } else {
      const w = randInt(5, Math.max(6, Math.floor(remaining / 2)));
      activityWeights[otherActs[i]] = w;
      remaining -= w;
    }
  }

  const budgetMax = pick([25000, 40000, 60000, 80000, 120000, 180000, 250000, 400000]);
  const budgetMin = Math.max(5000, Math.floor(budgetMax * 0.5));

  return {
    buyer_role: "buyer",
    vessel_class: pick(VESSEL_CLASSES),
    boat_size_range: pick(BOAT_SIZE_RANGES),
    operating_area: pick(OPERATING_AREAS),
    activities,
    activity_weights: activityWeights,
    experience_level: pick(EXPERIENCE_LEVELS),
    previously_owned_boats: pick(PREVIOUS_BOATS),
    passenger_count: randInt(2, 8),
    family_use: pick(FAMILY_USE),
    overnight_requirements: pick(OVERNIGHT),
    storage: pick(STORAGE_TYPES),
    storage_capacity: pick(["22 ft max", "30 ft max", "40 ft max", "6000 lb lift", "Not sure"]),
    draft: pick(DRAFT),
    towing: pick(TOWING),
    purchase_budget_min: budgetMin,
    purchase_budget_max: budgetMax,
    annual_ownership_budget: pick([3000, 5000, 8000, 12000, 20000, 35000]),
    ownership_timeframe: pick(TIMEFRAMES),
    ownership_horizon: pick(HORIZONS),
    must_haves: pickN(MUST_HAVES, randInt(1, 3)).join(", "),
    preferences: pickN(PREFERENCES, randInt(1, 2)).join(", "),
    unacceptable_compromises: pickN(UNACCEPTABLE, randInt(0, 2)).join(", "),
    priorities: pickN(PRIORITIES, randInt(4, 6)),
    preferred_manufacturers: preferredBrands.length ? pickN(preferredBrands, randInt(0, 3)) : [],
    open_to_project_boats: false,
    status: "active",
  };
}

// ── Handler ──────────────────────────────────────────────────────────────────

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

    const base44 = createClientFromRequest(req);
    let user;
    try {
      user = await base44.auth.me();
    } catch (_) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    if (user.role !== "admin") {
      return Response.json({ error: "Admin access required" }, { status: 403 });
    }

    // Synthetic buyers must never be created in the real production database.
    // Match the stricter guard already enforced by run-match-qa.
    if (req.headers.get("X-Data-Env") !== "dev") {
      return Response.json({ error: "Synthetic profiles require the isolated QA test database (X-Data-Env: dev)." }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const phase = String(body.phase || "profiles");

    // ── Phase: Generate profiles ─────────────────────────────────────────────
    if (phase === "profiles") {
      // Build a Production client (no X-Data-Env header) to read the curated
      // manufacturer market map - it lives in Production, not the Test DB.
      const prodHeaders = new Headers(req.headers);
      prodHeaders.delete("X-Data-Env");
      const prodReq = new Request(req.url, { method: req.method, headers: prodHeaders });
      const prodBase44 = createClientFromRequest(prodReq);

      let preferredBrands: string[] = [];
      try {
        const manufacturers = await prodBase44.asServiceRole.entities.Manufacturer.list("-created_date", 500);
        preferredBrands = (manufacturers || [])
          .filter((m: any) => m.status !== "defunct" && m.name)
          .map((m: any) => m.name)
          .slice(0, 200);
      } catch (e) {
        console.error("test-profiles: load manufacturers for preferred brands failed", e);
      }

      const count = Math.min(Number(body.count) || 10, 50);
      const profiles: any[] = [];
      for (let i = 0; i < count; i++) {
        try {
          const profile = await base44.asServiceRole.entities.BuyerProfile.create(randomProfile(preferredBrands));
          profiles.push(profile);
        } catch (e) {
          console.error(`test-profiles: create profile ${i} failed`, e);
        }
      }
      return Response.json({ profiles });
    }

    return Response.json({ error: "Invalid phase. This function now only generates profiles. Use run-match-qa for QA testing." }, { status: 400 });
  } catch (err) {
    console.error("generate-test-profiles error", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}