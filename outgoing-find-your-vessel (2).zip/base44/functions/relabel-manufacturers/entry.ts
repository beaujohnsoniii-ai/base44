// SoundHeading — hybrid manufacturer relabeling. Reads all Manufacturer records,
// proposes a usage category for each using InvokeLLM (batched), auto-applies
// high-confidence mainstream builders, and flags uncertain assignments plus
// every premium/specialist builder for human review in the admin queue.
//
// InvokeLLM runs as the service role (Core integration). Entity reads/writes use
// the service-role client so this can bulk-update regardless of RLS.
//
// Idempotent: re-running proposes categories for records that still lack one
// (or all records when reset=true). Already-reviewed records are skipped unless
// reset=true.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.52";
import { REVIEW_REQUIRED_CATEGORIES } from "../../shared/category-guide.ts";

const CATEGORY_ENUM = [
  "offshore_cc_dc",
  "premium_performance_specialty",
  "bay_flats_skiff",
  "pilothouse_express_utility",
  "sportfishing_yacht_custom",
  "tow_sport",
  "pontoon",
  "cruiser_runabout",
  "rib_tender",
  "power_catamaran",
  "saltwater_fishing",
  "trawler",
  "performance",
];

const ASSIGN_SCHEMA = {
  type: "object",
  properties: {
    assignments: {
      type: "array",
      items: {
        type: "object",
        properties: {
          name: { type: "string" },
          category: { type: "string", enum: CATEGORY_ENUM },
          confidence: { type: "string", enum: ["high", "medium", "low"] },
          reasoning: { type: "string" },
        },
        required: ["name", "category", "confidence"],
      },
    },
  },
  required: ["assignments"],
};

const BATCH_SIZE = 25;

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

    const base44 = createClientFromRequest(req);
    let user;
    try {
      user = await base44.auth.me();
    } catch (_) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    if (user.role !== "admin") {
      return Response.json({ error: "Admin access required" }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const reset = !!body.reset;

    // Load all manufacturers (up to 600).
    const all = (await base44.entities.Manufacturer.list("name", 600)) || [];

    // Decide which records to propose categories for.
    let toProcess = all;
    if (!reset) {
      toProcess = all.filter((m: any) => !m.category);
    }

    if (toProcess.length === 0) {
      return Response.json({
        total: all.length,
        proposed: 0,
        auto_applied: 0,
        flagged_for_review: 0,
        message: reset ? "No manufacturers to process." : "All manufacturers already have a category.",
      });
    }

    const byName = new Map<string, any>();
    for (const m of all) {
      if (m.name) byName.set(m.name.toLowerCase(), m);
    }

    let autoApplied = 0;
    let flagged = 0;
    const flaggedRecords: any[] = [];

    // Process in batches to keep each InvokeLLM call bounded.
    for (let i = 0; i < toProcess.length; i += BATCH_SIZE) {
      const batch = toProcess.slice(i, i + BATCH_SIZE);
      const batchText = batch.map((m: any) => {
        const parts = [m.name];
        if (m.country) parts.push(`country: ${m.country}`);
        if (m.class_specialty) parts.push(`specialty: ${m.class_specialty}`);
        if (m.headquarters) parts.push(`HQ: ${m.headquarters}`);
        if (m.notes) parts.push(`notes: ${m.notes}`);
        return `${batch.indexOf(m) + 1}. ${parts.join(" | ")}`;
      }).join("\n");

      const prompt =
        `You are categorizing boat manufacturers by HOW their boats are used. Assign each builder exactly ONE primary category from this list:\n` +
        CATEGORY_ENUM.map((c) => `- ${c}`).join("\n") +
        `\n\nCategory definitions:\n` +
        `- offshore_cc_dc: offshore center consoles and dual consoles for open-water fishing\n` +
        `- premium_performance_specialty: lower-volume, high-build-quality specialists (e.g. Edgewater, Everglades, Jupiter)\n` +
        `- bay_flats_skiff: bay boats, flats skiffs, technical poling skiffs for shallow-water fishing\n` +
        `- pilothouse_express_utility: enclosed-helm boats for rough water (e.g. C-Dory, Raider, Eastern)\n` +
        `- sportfishing_yacht_custom: large sportfishermen and custom battlewagons (e.g. Viking, Hatteras, Jarrett Bay)\n` +
        `- tow_sport: wakeboard, wakesurf, ski boats (e.g. Malibu, Nautique, MasterCraft)\n` +
        `- pontoon: pontoon and tri-toon platforms (e.g. Bennington, Manitou, Sun Tracker)\n` +
        `- cruiser_runabout: day cruisers, bowriders, cabin cruisers (e.g. Sea Ray, Chaparral, Cobalt)\n` +
        `- rib_tender: rigid inflatable boats and yacht tenders (e.g. AB Inflatables, Highfield, Zodiac)\n` +
        `- power_catamaran: twin-hull power catamarans for stability, efficiency, and cruising (e.g. Leopard, Aquila, World Cat)\n` +
        `- saltwater_fishing: dedicated saltwater fishing boats not covered by offshore/bay/sportfishing (e.g. multi-species coastal fishing platforms)\n` +
        `- trawler: displacement-hull trawlers for long-range economical cruising (e.g. Nordhavn, Kadey-Krogen, Ranger Tugs)\n` +
        `- performance: high-performance go-fast boats and offshore racers (e.g. Fountain, Cigarette, Nor-Tech)\n\n` +
        `For each builder, return its name, the best-fit category, your confidence (high/medium/low), and a one-sentence reasoning.\n` +
        `Use "low" confidence when the builder is unfamiliar or could fit multiple categories. Use "high" only when the builder's primary product line clearly matches one category.\n\n` +
        `Builders to categorize:\n${batchText}\n\n` +
        `Return JSON with an "assignments" array, one entry per builder, using the exact name from the list above.`;

      try {
        const result: any = await base44.asServiceRole.integrations.Core.InvokeLLM({
          prompt,
          response_json_schema: ASSIGN_SCHEMA,
        });

        const assignments = Array.isArray(result?.assignments) ? result.assignments : [];
        for (const a of assignments) {
          const record = byName.get((a.name || "").toLowerCase());
          if (!record) continue;
          const category = a.category;
          const confidence = a.confidence || "low";

          // Auto-apply only high-confidence assignments that are NOT in the
          // review-required categories (premium/specialty and sportfishing).
          const shouldAutoApply =
            confidence === "high" && !REVIEW_REQUIRED_CATEGORIES.has(category);

          if (shouldAutoApply) {
            try {
              await base44.asServiceRole.entities.Manufacturer.update(record.id, {
                category,
                category_confidence: confidence,
                category_reviewed: true,
              });
              autoApplied++;
            } catch (e) {
              console.error(`relabel: failed to auto-apply ${record.name}`, e);
              flagged++;
              flaggedRecords.push({ name: record.name, category, confidence, reasoning: a.reasoning });
            }
          } else {
            // Flag for human review — store the proposal but mark unreviewed.
            try {
              await base44.asServiceRole.entities.Manufacturer.update(record.id, {
                category,
                category_confidence: confidence,
                category_reviewed: false,
              });
              flagged++;
            } catch (e) {
              console.error(`relabel: failed to flag ${record.name}`, e);
            }
          }
        }
      } catch (e) {
        console.error(`relabel: batch ${i / BATCH_SIZE} failed`, e);
      }
    }

    return Response.json({
      total: all.length,
      processed: toProcess.length,
      auto_applied: autoApplied,
      flagged_for_review: flagged,
      message: `Proposed categories for ${toProcess.length} builders. ${autoApplied} auto-applied, ${flagged} flagged for review.`,
    });
  } catch (err) {
    console.error("relabel-manufacturers error", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}